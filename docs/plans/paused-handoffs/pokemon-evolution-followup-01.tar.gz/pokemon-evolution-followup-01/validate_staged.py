#!/usr/bin/env python3
"""Root-owner entry point. Compile only unless --execute is explicit."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--project', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('--sdk')
parser.add_argument('--scenario', help='root native owner scenario after integration hooks are installed')
parser.add_argument('--execute', action='store_true', help='root Simulator owner only')
args = parser.parse_args()
project = Path(args.project).resolve()
stage = Path(__file__).resolve().parent
base_stage = Path("/private/tmp/pokemon-evolution")
def staged_file(relative):
    candidate=stage / relative
    return candidate if candidate.is_file() else base_stage / relative
sys.path.insert(0, str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json

manifest = json.loads((stage / 'foundation-manifest.json').read_text())
original_prepare = harness.prepare


def prepare(project, sdk, output, session):
    for name, original_sha in manifest['owned_originals'].items():
        live = project / 'Source' / name
        staged = staged_file(Path('Source') / name)
        assert not live.exists() or hashlib.sha256(live.read_bytes()).hexdigest() in (original_sha, hashlib.sha256(staged.read_bytes()).hexdigest()), 'live owned evolution module changed since handoff'
    for item in manifest.get('tool_files', []):
        assert hashlib.sha256((project / item['path']).read_bytes()).hexdigest() in (item['original_sha256'], item['sha256']), 'live generator changed since handoff'
        assert hashlib.sha256(staged_file(item['path']).read_bytes()).hexdigest() == item['sha256'], 'staged generator changed'
    metadata = original_prepare(project, sdk, output, session)
    for item in manifest['owned_files']:
        relative = Path(item['path'])
        source = staged_file(relative)
        assert hashlib.sha256(source.read_bytes()).hexdigest() == item['sha256'], 'staged handoff changed'
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
    main = output / 'Source/main.lua'
    text = main.read_text()
    if 'import "game/evolutionState"' not in text:
        text = text.replace('import "dev/catalog"', 'import "game/evolutionState"\nimport "dev/catalog"', 1)
    if 'import "dev/evolutionContracts"' not in text:
        text = text.replace('import "dev/catalog"', 'import "dev/evolutionContracts"\nimport "dev/catalog"', 1)
    if 'Contracts.register("evolution", EvolutionContracts.run)' not in text:
        text = text.replace('import "dev/catalog"', 'Contracts.register("evolution", EvolutionContracts.run)\nimport "dev/catalog"', 1)
    main.write_text(text)
    main=output / 'Source/main.lua'
    text=main.read_text()
    if 'machine:register("evolution", EvolutionState(game))' not in text:
        text=text.replace('machine:register("learning", LearningState(game))','machine:register("learning", LearningState(game))\nmachine:register("evolution", EvolutionState(game))',1)
    main.write_text(text)
    diagnostics=output / 'Source/dev/diagnostics.lua'
    text=diagnostics.read_text()
    if 'evolution = root:get("evolution"):getSnapshot()' not in text:
        text=text.replace('party_ui = ui(', 'evolution = root:get("evolution"):getSnapshot(),\n        party_ui = ui(',1)
    if 'pending_evolution =' not in text:
        text=text.replace('pending_moves = #mon:getPendingMoveChoices()', 'pending_evolution = mon.pendingEvolution~=nil, pending_evolution_level = mon.pendingEvolution and mon.pendingEvolution.level or 0,\n        pending_moves = #mon:getPendingMoveChoices()',1)
    diagnostics.write_text(text)
    pdxinfo = output / 'Source/pdxinfo'
    generated_pdxinfo = pdxinfo.read_text()
    pdxinfo.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256'] = harness.fingerprint(output)
    metadata['build_id'] = metadata['revision'] + ':' + metadata['source_sha256']
    source_manifest = {str(path.relative_to(output / 'Source')): hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in sorted((output / 'Source').rglob('*')) if path.is_file()
                       and path.relative_to(output / 'Source').as_posix() != 'dev/harness_build.lua'}
    atomic_json(output / 'source-manifest.json', source_manifest)
    pdxinfo.write_text(generated_pdxinfo)
    values = []
    for key in ('protocol', 'session_id', 'build_id', 'output_dir', 'bundle_id', 'sdk_version', 'enabled', 'data_dir'):
        value = metadata[key]
        values.append(f'    {key} = ' + ('true' if value is True else json.dumps(value, ensure_ascii=False)) + ',')
    (output / 'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n' + '\n'.join(values) + '\n}\n')
    metadata['compiled_source_sha256'] = harness.fingerprint(output, exclude_generated=False)
    metadata['evolution_followup'] = manifest['followup']
    metadata['evolution_foundation'] = {'base_revision': manifest['base_revision'], 'owned_files': manifest['owned_files'], 'tool_files': manifest['tool_files'], 'scenario_files': manifest['scenario_files']}
    with (output / 'evolution-build.log').open('w') as log:
        subprocess.run([str(sdk / 'bin/pdc'), str(output / 'Source'), metadata['bundle']], stdout=log, stderr=subprocess.STDOUT, check=True)
    atomic_json(output / 'build.json', metadata)
    return metadata

harness.prepare = prepare
harness.PROJECT = project
scenario = Path(args.scenario).resolve() if args.scenario else stage / 'evolution-contract-scenario.json'
if not args.scenario:
    atomic_json(scenario, {'commands': ['contracts', 'shot evolution-foundation'], 'outputs': []})
try:
    code = harness.run(SimpleNamespace(sdk=args.sdk, output=args.output, scenario=str(scenario), commands=[],
                                       build_only=not args.execute, timeout=60, ready_timeout=20, max_frames=1800))
finally:
    harness.prepare = original_prepare
raise SystemExit(code)

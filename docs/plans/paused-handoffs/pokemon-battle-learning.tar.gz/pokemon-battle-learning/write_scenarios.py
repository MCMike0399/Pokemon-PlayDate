import json
from pathlib import Path
root=Path('/private/tmp/pokemon-battle-learning/scenarios')
def aw(path,value,frames=240):return {'op':'await','path':path,'equals':value,'frames':frames}
def ass(path,value):return {'op':'assert','path':path,'equals':value}
def start(species,level,xp,two=True):
    enemy=[{'species':'rattata','level':5}]
    if two:enemy.append({'species':'geodude','level':5})
    return [{'op':'fixture','options':{'intro':'skip','opening':False,'zone':'reds_house_2f','seed':42,
        'player_pokemon':{'species':species,'level':level},'grant_xp':{'amount':xp},
        'trainer_name':'LEARNING TEST','enemy_party':enemy}},aw('battle.introPhase','ready'),
        'wait 12','press a','wait 12','press a',aw('battle.phase','command'),
        {'op':'fixture','options':{'adjust_battle':{'enemy_hp':1,'enemy_status':'sleep','enemy_status_turns':3,'enemy_sleep_duration':3}}},
        'seed 42','press a',aw('battle.inMoveSelect',True),'press a']
def advances(n,hold=False):
    result=[]
    for i in range(n):result += ['wait 12','hold a' if hold and i==n-1 else 'press a']
    return result
def write(name,commands):
    (root/(name+'.json')).write_text(json.dumps({'commands':commands,'outputs':[]},indent=2)+'\n')
c=start('squirtle',6,56)+advances(6,True)+[aw('root','learning'),ass('learning.phase','message'),ass('learning.input_blocked',True),
    ass('battle.enemy.species','rattata'),ass('pokemon.level',7),ass('pokemon.pp.bubble',30),'shot midbattle-bubble-held-entry',
    'wait 20',ass('learning.phase','message'),ass('battle.enemy.species','rattata'),'release a','wait 2',ass('learning.input_blocked',False),
    aw('learning.dialog_ready',True),'press a',aw('root','battle'),ass('battle.enemy.species','geodude'),'shot midbattle-bubble-next-enemy',
    'wait 12','press a',aw('battle.phase','command'),'press a',aw('battle.inMoveSelect',True),'press down','press a',
    ass('battle.current_move','bubble'),ass('pokemon.pp.bubble',29),'record midbattle-bubble-attack 32','wait 32','shot midbattle-bubble-used-against-enemy2']
write('battle-learning-two-enemy-bubble',c)
c=start('charmander',15,499)+advances(5,True)+[aw('root','learning'),ass('learning.phase','ask'),ass('learning.input_blocked',True),
    ass('battle.enemy.species','rattata'),'wait 20',ass('learning.phase','ask'),'shot midbattle-full-held-entry','release a','wait 2',
    'press a',ass('learning.phase','replace'),'press b',ass('learning.phase','ask'),'press b',ass('learning.phase','stop'),
    'press b',ass('learning.phase','ask'),'press a','press down','press a',ass('learning.phase','confirm'),'shot midbattle-replace-confirm',
    'press b',ass('learning.phase','replace'),'press a','press a',ass('learning.phase','message'),ass('pokemon.moves.2','dragonRage'),
    ass('pokemon.pp.dragonRage',10),aw('learning.dialog_ready',True),'press a',aw('learning.dialog_ready',True),'press a',
    aw('root','battle'),ass('battle.enemy.species','geodude'),'shot midbattle-replacement-resumed']
write('battle-learning-two-enemy-replacement-back',c)
c=start('charmander',15,499)+advances(5)+[aw('root','learning'),ass('learning.phase','ask'),'wait 2','press b',ass('learning.phase','stop'),
    'press b',ass('learning.phase','ask'),'press down','press a',ass('learning.phase','stop'),'press a',ass('learning.phase','message'),
    ass('pokemon.moves.2','growl'),ass('pokemon.pending_moves',0),'shot midbattle-declined-move',aw('learning.dialog_ready',True),'press a',
    aw('root','battle'),ass('battle.enemy.species','geodude'),'shot midbattle-decline-resumed']
write('battle-learning-two-enemy-refusal',c)

from pathlib import Path
root=Path('/private/tmp/pokemon-battle-learning/Source')
p=root/'battle/battle.lua';s=p.read_text()
s=s.replace('local MESSAGE_MIN_FRAMES <const> = 10','local MESSAGE_MIN_FRAMES <const> = 10\n-- Opaque receipts bind one learning overlay to one suspended production script.\nlocal learningReceipts = setmetatable({}, {__mode = "k"})',1)
s=s.replace('    self.co = co\n    self.waiting = false','    self.co = co\n    self.cancelled = false\n    self.waiting = false',1)
s=s.replace('function BattleScriptPhase:advance()\n    local ok','function BattleScriptPhase:exit()\n    self.battle:cancelPendingLearning()\nend\n\nfunction BattleScriptPhase:advance()\n    if self.cancelled then return false, "script-cancelled" end\n    if self.battle.pendingLearning then return false, "learning-pending" end\n    local ok',1)
s=s.replace('        self.waiting = true\n    end\nend\n\nfunction BattleScriptPhase:update()\n    self.messageTimer = self.messageTimer + 1','        self.waiting = true\n    elseif kind == "learning" then\n        assert(value and value:is("Pokemon") and #value:getPendingMoveChoices() > 0, "invalid learning yield")\n        local receipt = {}\n        learningReceipts[receipt] = {battle=self.battle, script=self, co=self.co, pokemon=value, claimed=false}\n        self.battle.pendingLearning = receipt\n        self.waiting = false\n    else\n        error("unknown battle script event: " .. tostring(kind))\n    end\n    return true\nend\n\nfunction BattleScriptPhase:update()\n    if self.cancelled or self.battle.pendingLearning then return end\n    self.messageTimer = self.messageTimer + 1',1)
s=s.replace('function Battle:clearVolatiles() self.conditions:clearAll() end','function Battle:clearVolatiles()\n    self:cancelPendingLearning()\n    self.conditions:clearAll()\nend',1)
marker='function Battle:setDirection(side)'
methods='''-- Only the owner may claim once, present LearningState, then resume this exact
-- coroutine. Rejections never advance rules or consume RNG.
function Battle:takeLearningRequest()
    local receipt = self.pendingLearning
    local data = receipt and learningReceipts[receipt]
    if not data or data.claimed or self:phase() ~= "script" or data.script.cancelled then return nil end
    data.claimed = true
    return receipt, data.pokemon
end

function Battle:resumeLearning(receipt)
    local data = learningReceipts[receipt]
    if not data or data.battle ~= self or self.pendingLearning ~= receipt or not data.claimed
       or self:phase() ~= "script" or self.machine:current() ~= data.script
       or data.script.co ~= data.co or data.script.cancelled then return false, "stale-learning" end
    if #data.pokemon:getPendingMoveChoices() > 0 then return false, "learning-pending" end
    self.pendingLearning = nil
    learningReceipts[receipt] = nil
    data.script:advance()
    return true
end

function Battle:cancelPendingLearning()
    if self.pendingLearning then learningReceipts[self.pendingLearning] = nil end
    self.pendingLearning = nil
    local script = self.machine and self.machine:get("script")
    if script then script.cancelled = true; script.waiting = false end
end

function Battle:getLearningSnapshot()
    local data = self.pendingLearning and learningReceipts[self.pendingLearning]
    return {pending=data~=nil, claimed=data and data.claimed or false,
        species=data and data.pokemon.species or "", remaining=data and #data.pokemon:getPendingMoveChoices() or 0}
end

'''
s=s.replace(marker,methods+marker,1)
s=s.replace('if mon:gainXP(xpGained) then self:say(mon.name .. " grew to Lv" .. mon.level .. "!") end','if mon:gainXP(xpGained) then self:say(mon.name .. " grew to Lv" .. mon.level .. "!") end\n                if #mon:getPendingMoveChoices() > 0 then coroutine.yield("learning", mon) end',1)
p.write_text(s)
p=root/'game/battleState.lua';s=p.read_text()
s=s.replace('function BattleState:exit()\n','function BattleState:exit()\n    if self.battle then self.battle:cancelPendingLearning() end\n    self.learningRequest = nil\n',1)
s=s.replace('    self:openSelection()\nend\n\nfunction BattleState:handleInput()', '    self:openPendingLearning()\n    self:openSelection()\nend\n\nfunction BattleState:handleInput()',1)
s=s.replace('function BattleState:handleInput()\n    if self.scene then self.scene:handleInput() end\n    self:openSelection()', 'function BattleState:handleInput()\n    if not self:isTop() then return end\n    if self.scene then self.scene:handleInput() end\n    self:openPendingLearning()\n    self:openSelection()',1)
marker='function BattleState:openSelection()'
method='''-- Present the real learning overlay without returning/replacing this battle.
function BattleState:openPendingLearning()
    if not self:isTop() or not self.battle or self.learningRequest then return false end
    local battle, session = self.battle, self.game.session
    local receipt, pokemon = battle:takeLearningRequest()
    if not receipt then return false end
    self.learningRequest = receipt
    assert(LearningState.open(self.game, pokemon, function()
        if self.battle ~= battle or self.game.session ~= session or not self:isTop()
           or self.learningRequest ~= receipt then
            battle:cancelPendingLearning()
            return
        end
        self.learningRequest = nil
        assert(battle:resumeLearning(receipt))
    end), "suspended battle requires pending learning")
    return true
end

'''
s=s.replace(marker,method+marker,1);p.write_text(s)

from pathlib import Path
import difflib,hashlib,json,subprocess
root=Path('/private/tmp/pokemon-battle-learning');project=Path('/Users/burbujamc/Developer/Pokemon-PlayDate')
files=[]
for p in sorted((root/'Source').rglob('*.lua')):
    rel=p.relative_to(root);base=root/'base'/p.relative_to(root/'Source')
    item={'path':str(rel),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest() if base.exists() else None}
    patch=root/'patches'/p.relative_to(root/'Source');patch=patch.with_suffix('.patch');patch.parent.mkdir(parents=True,exist_ok=True)
    patch.write_text(''.join(difflib.unified_diff(base.read_text().splitlines(True) if base.exists() else [],p.read_text().splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel))))
    item['patch']=str(patch.relative_to(root));files.append(item)
manifest={'schema':1,'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip(),'owned_files':files,'expected_new_groups':18,'source_frozen':True}
(root/'foundation-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

from pathlib import Path
p=Path('/private/tmp/pokemon-battle-learning/Source/dev/fixtures.lua');s=p.read_text()
start=s.index('            fields(spec, {species=true')
end=s.index('            prepared.party.members[i] = SessionCodec.encodePokemon(mon)',start)
moncode=s[start:end]
# Reuse the exact production fixture preparation for both owned and trainer mons.
body='\n'.join(line[12:] if line.startswith('            ') else line for line in moncode.splitlines())
helper='local function preparePokemon(spec)\n'+''.join('    '+line+'\n' for line in body.splitlines())+'    return SessionCodec.encodePokemon(mon)\nend\n'
s=s[:start]+'            prepared.party.members[i] = preparePokemon(spec)\n'+s[end+len('            prepared.party.members[i] = SessionCodec.encodePokemon(mon)\n'):]
s=s.replace('local function prepare(options)',helper+'local function prepare(options)',1)
s=s.replace('adjust_battle=true,pokedex_seen=true})','adjust_battle=true,pokedex_seen=true,trainer_name=true,enemy_party=true})',1)
marker='    if options.inventory ~= nil then'
addition='''    assert((options.trainer_name == nil) == (options.enemy_party == nil), "trainer team requires name and party")
    if options.enemy_party ~= nil then
        assert(options.intro == "skip" and prepared.party, "trainer team requires explicit owned party and skipped intro")
        assert(type(options.trainer_name) == "string" and #options.trainer_name >= 1 and #options.trainer_name <= 30
            and not options.trainer_name:find("[^ -~]"), "invalid synthetic trainer name")
        assert(Party._array(options.enemy_party,6) and #options.enemy_party >= 1, "trainer team requires one to six members")
        prepared.enemyParty = {version=1, active=1, members={}}
        for i,spec in ipairs(options.enemy_party) do
            local data=preparePokemon(spec)
            assert(data.hp>0,"trainer fixture member must be conscious")
            prepared.enemyParty.members[i]=data
        end
        -- Party schema/ownership capacity preflight occurs before any live reset.
        assert(Party.fromData(prepared.enemyParty,SessionCodec.decodePokemon))
        prepared.trainerName = options.trainer_name
    end
    if options.grant_xp then
        fields(options.grant_xp,{amount=true,to_level=true})
        local xp=options.grant_xp
        assert((xp.amount==nil) ~= (xp.to_level==nil),"XP fixture requires amount or target")
        assert(xp.amount==nil or integer(xp.amount,0,1000000),"invalid XP fixture amount")
        assert(xp.to_level==nil or integer(xp.to_level,1,100),"invalid XP target level")
        if prepared.party then
            local mon=assert(SessionCodec.decodePokemon(prepared.party.members[1]))
            assert(not xp.to_level or xp.to_level>=mon.level,"XP fixture cannot lower level")
            mon:gainXP(xp.amount or mon:xpForLevel(xp.to_level)-mon.xp)
            if prepared.enemyParty then
                assert(#mon:getPendingMoveChoices()==0 and mon.pendingEvolution==nil,
                    "trainer fixture XP must settle before battle without a learning/evolution overlay")
            end
        end
    end
'''
s=s.replace(marker,addition+marker,1)
marker='    if options.grant_xp then game:offerLearning(game:getPlayerPokemon()) end'
replacement='''    if prepared.enemyParty then
        local enemies=assert(Party.fromData(prepared.enemyParty,SessionCodec.decodePokemon))
        -- Synthetic harness identity never aliases a source trainer flag/reward.
        local npc={name=prepared.trainerName,trainerID="fixture:trainer-team",fixtureDefeated=false,
            markInteracted=function(self) self.fixtureDefeated=true end}
        machine:change("battle",assert(game:getPlayerPokemon()),enemies:active(),npc,enemies)
    elseif options.grant_xp then game:offerLearning(game:getPlayerPokemon()) end'''
s=s.replace(marker,replacement,1);p.write_text(s)
# Explicit host-command validation delegates the full detached team preflight to
# HarnessFixtures.validate below; no second mutable/partial team parser.
p=Path('/private/tmp/pokemon-battle-learning/Source/dev/harness.lua');s=p.read_text().replace('        HarnessFixtures.validate(options)\n','        -- Includes detached trainer-team member/PP/status validation before execution.\n        HarnessFixtures.validate(options)\n',1);p.write_text(s)

#!/usr/bin/env python3
"""Root-owner runner. Default compiles only; --execute is root Simulator owner only."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--controller',help='optional independently proved trainer controller to merge narrow learning hunk onto')
a=p.parse_args();project=Path(a.project).resolve();stage=Path(__file__).resolve().parent
sys.path.insert(0,str(project));from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'foundation-manifest.json').read_text());original=harness.prepare

def prepare(project,sdk,output,session):
    for item in manifest['owned_files']:
        assert hashlib.sha256((stage/item['path']).read_bytes()).hexdigest()==item['sha256'],'staged packet drift'
        live=project/item['path']
        assert not live.exists() or hashlib.sha256(live.read_bytes()).hexdigest() in (item['base_sha256'],item['sha256']),'live owned Source drift: '+item['path']
    metadata=original(project,sdk,output,session)
    for item in manifest['owned_files']:
        target=output/item['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/item['path'],target)
    if a.controller:
        shutil.copyfile(Path(a.controller).resolve(),output/'Source/game/battleState.lua')
        subprocess.run(['patch','--batch','-p1','-i',str(stage/'patches/game/battleState.patch')],cwd=output,check=True)
    main=output/'Source/main.lua';text=main.read_text();anchor='import "dev/catalog"'
    assert anchor in text,'main import seam changed'
    text=text.replace(anchor,'import "dev/battleLearningContracts"\nContracts.register("battle-learning", BattleLearningContracts.run)\n'+anchor,1);main.write_text(text)
    info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted((output/'Source').rglob('*')) if x.is_file() and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    info.write_text(generated);values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        value=metadata[key];values.append('    '+key+' = '+('true' if value is True else json.dumps(value,ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['battle_learning_foundation']=manifest
    with (output/'battle-learning-build.log').open('w') as log: subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
scenario=Path(a.scenario).resolve() if a.scenario else stage/'contracts.json'
if not a.scenario: atomic_json(scenario,{'commands':['contracts','shot battle-learning-contracts'],'outputs':[]})
try: code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(scenario),commands=[],build_only=not a.execute,timeout=90,ready_timeout=20,max_frames=1800))
finally: harness.prepare=original
raise SystemExit(code)

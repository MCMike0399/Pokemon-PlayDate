#!/usr/bin/env python3
"""Root-owner entry point. Compile only unless --execute is explicit."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--project', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('--sdk')
parser.add_argument('--execute', action='store_true', help='root Simulator owner only')
args = parser.parse_args()
project = Path(args.project).resolve()
stage = Path(__file__).resolve().parent
sys.path.insert(0, str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json

manifest = json.loads((stage / 'runtime-manifest.json').read_text())
original_prepare = harness.prepare


def prepare(project, sdk, output, session):
    for name, original_sha in manifest['owned_originals'].items():
        live = project / 'Source' / name
        staged = stage / 'Source' / name
        assert hashlib.sha256(live.read_bytes()).hexdigest() in (original_sha, hashlib.sha256(staged.read_bytes()).hexdigest()), 'live owned world module changed since handoff'
    metadata = original_prepare(project, sdk, output, session)
    for item in manifest['owned_files']:
        relative = Path(item['path'])
        source = stage / relative
        assert hashlib.sha256(source.read_bytes()).hexdigest() == item['sha256'], 'staged handoff changed'
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
    main = output / 'Source/main.lua'
    text = main.read_text()
    text = text.replace('import "data/viridianSlice"', 'import "data/viridianSlice"\nimport "data/pewterSlice"\nimport "world/importedMaps"\nimport "world/pewterSprites"\nimport "game/trainerEvents"\nimport "game/pewterEvents"\nimport "world/pewterBindings"\nimport "game/pewterWorld"')
    text = text.replace('GameContext({sessionLocationPolicy=KantoWorld.locationPolicy()})', 'GameContext({sessionLocationPolicy=PewterWorld.locationPolicy()})')
    text = text.replace('KantoWorld.install(game)', 'KantoWorld.install(game)\nPewterWorld.install(game)')
    text += '\nimport "dev/trainerContracts"\nContracts.register("trainer-progression", TrainerContracts.run)\nimport "dev/pewterProviderContracts"\nContracts.register("pewter-provider", PewterProviderContracts.run)\n'
    text += '\nimport \"dev/pewterInstallContracts\"\nContracts.register(\"pewter-install-rollback\",PewterInstallContracts.run)\nimport \"dev/pewterCatalog\"\nVisualCatalog.write=PewterCatalog.write\n'
    main.write_text(text)
    pdxinfo = output / 'Source/pdxinfo'
    generated_pdxinfo = pdxinfo.read_text()
    pdxinfo.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256'] = harness.fingerprint(output)
    metadata['build_id'] = metadata['revision'] + ':' + metadata['source_sha256']
    source_manifest = {str(path.relative_to(output / 'Source')): hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in sorted((output / 'Source').rglob('*')) if path.is_file()
                       and path.relative_to(output / 'Source').as_posix() != 'dev/harness_build.lua'}
    atomic_json(output / 'source-manifest.json', source_manifest)
    pdxinfo.write_text(generated_pdxinfo)
    values = []
    for key in ('protocol', 'session_id', 'build_id', 'output_dir', 'bundle_id', 'sdk_version', 'enabled', 'data_dir'):
        value = metadata[key]
        values.append(f'    {key} = ' + ('true' if value is True else json.dumps(value, ensure_ascii=False)) + ',')
    (output / 'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n' + '\n'.join(values) + '\n}\n')
    metadata['compiled_source_sha256'] = harness.fingerprint(output, exclude_generated=False)
    metadata['pewter_runtime'] = {'base_revision': manifest['base_revision'], 'owned_files': manifest['owned_files']}
    with (output / 'pewter-build.log').open('w') as log:
        subprocess.run([str(sdk / 'bin/pdc'), str(output / 'Source'), metadata['bundle']], stdout=log, stderr=subprocess.STDOUT, check=True)
    atomic_json(output / 'build.json', metadata)
    return metadata

harness.prepare = prepare
harness.PROJECT = project
scenario = stage / 'trainer-contract-scenario.json'
atomic_json(scenario, {'commands': ['contracts', 'catalog', 'shot pewter-candidate'], 'outputs': []})
try:
    code = harness.run(SimpleNamespace(sdk=args.sdk, output=args.output, scenario=str(scenario), commands=[],
                                       build_only=not args.execute, timeout=60, ready_timeout=20, max_frames=1800))
finally:
    harness.prepare = original_prepare
raise SystemExit(code)

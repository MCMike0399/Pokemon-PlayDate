-- Explicit development export. Isolated Zones/private palettes never enter the
-- provider LRU, global registry or session, including maps not visited in play.
PewterCatalog={}
local gfx <const> = playdate.graphics
local function sortedKeys(source)local out={};for k in pairs(source)do out[#out+1]=k end;table.sort(out);return out end
function PewterCatalog.write(output)
    assert(playdate.isSimulator and type(output)=="string" and output:sub(1,1)=="/" and output:sub(-1)=="/","absolute Simulator output directory required")
    local before={ids=WorldTiles:maxID(),zones=#zoneList,zone=currentZone,sprites=gfx.sprite.spriteCount(),rng=RulesRNG.snapshot()}
    local offsetX,offsetY=gfx.getDrawOffset()
    local report={schema=1,source_revision="af519899719f0754965776faac0e836a3b906e6d",images={},maps={},tiles={},missing={}}
    local function save(image,name,kind,extra)
        assert(image,"missing native image");playdate.simulator.writeToFile(image,output..name..".png")
        local w,h=image:getSize();local entry={path=name..".png",width=w,height=h,kind=kind}
        for key,value in pairs(extra or {})do entry[key]=value end
        report.images[#report.images+1]=entry;return entry
    end
    local source=assert(json.decodeFile("data/pewterSlice/sprites.json"))
    for _,name in ipairs(sortedKeys(source.sprites)) do
        local strip=source.sprites[name]
        for _,index in ipairs(sortedKeys(strip.frames)) do
            local image=SpriteFactory.makeSprite(strip.frames[index],{0,0})
            save(image,"pewter-sprite-"..name.."-"..index,"sprite",{source_id=strip.id,frame=index})
            save(assert(image:getMaskImage()),"pewter-mask-"..name.."-"..index,"mask",{source_id=strip.id,frame=index})
        end
    end
    local metadata=PewterSlice.compact()
    for index,key in ipairs(sortedKeys(metadata.tiles)) do
        local tile=PewterSlice.tile(key)
        local entry=save(TileFactory.renderGrid(tile.grid,nil,{0,0}),string.format("pewter-tile-%03d",index),"tile",{stable_key=key,collision=tile.collision,terrain=tile.terrain})
        report.tiles[#report.tiles+1]={stable_key=key,path=entry.path}
    end
    for _,name in ipairs(PewterSlice.names()) do
        local zone=PewterWorld.isolated(name);local d=PewterSlice.descriptor(name)
        local view
        local ok,problem=pcall(function()
            view=WorldView(zone,{attach=false});local image=view:render()
            save(image,"pewter-"..name.."-terrain","terrain",{zone_id=d.id,source_width=d.source_width,padding=d.padding})
            local collision=gfx.image.new(zone.width*TILE_SIZE,zone.height*TILE_SIZE,gfx.kColorWhite)
            gfx.pushContext(collision);gfx.setDrawOffset(0,0);gfx.setColor(gfx.kColorBlack)
            for y,row in ipairs(zone.collision)do for x,value in ipairs(row)do if value==1 then gfx.fillRect((x-1)*TILE_SIZE,(y-1)*TILE_SIZE,TILE_SIZE,TILE_SIZE)end end end
            gfx.popContext();save(collision,"pewter-"..name.."-collision","collision",{zone_id=d.id})
            local actors=image:copy();gfx.pushContext(actors);gfx.setDrawOffset(0,0)
            for _,def in ipairs(zone.npcDefs)do
                if not def.appearsIf or def.appearsIf() then
                    local strip=PewterSlice.sprite(def.source_sprite)
                    local direction=def.facing;local index=strip.standing[direction=="right" and "left" or direction]
                    local sprite=SpriteFactory.makeSprite(assert(strip.frames[tostring(index)],"missing exact source direction"),{0,0})
                    if direction=="right"then sprite=SpriteFactory.flipped(sprite)end
                    sprite:draw(def.gridX*TILE_SIZE,def.gridY*TILE_SIZE-8)
                end
            end
            gfx.popContext();save(actors,"pewter-"..name.."-actors","actors",{zone_id=d.id})
            report.maps[#report.maps+1]={name=name,zone_id=d.id,width=zone.width,height=zone.height,source_width=d.source_width,padding=d.padding,
                events=PewterSlice.padded(name).events,directional_rules=PewterSlice.padded(name).directional_rules,issues=zone:getBindingIssues(),
                campaign_ready=zone:isCampaignReady(),slice_ready=zone:isSliceReady()}
        end)
        if view then view:dispose()end
        if not ok then gfx.setDrawOffset(offsetX,offsetY);error(problem,0)end
    end
    local shock=PewterSprites.exclamation()
    save(shock,"pewter-exclamation","sprite");save(shock:getMaskImage(),"pewter-exclamation-mask","mask")
    gfx.setDrawOffset(offsetX,offsetY)
    assert(WorldTiles:maxID()==before.ids and #zoneList==before.zones and currentZone==before.zone,"catalog mutated world ownership")
    assert(gfx.sprite.spriteCount()==before.sprites,"catalog leaked native sprites")
    local after=RulesRNG.snapshot()
    assert(after.algorithm==before.rng.algorithm and after.seed==before.rng.seed and after.state==before.rng.state and after.rolls==before.rng.rolls,"catalog consumed rules RNG")
    return report
end

import importlib.util
from pathlib import Path
import unittest
from PIL import Image
s=importlib.util.spec_from_file_location('comparator',Path(__file__).with_name('compare_catalog.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class ComparatorTests(unittest.TestCase):
    def test_rgb_difference_under_transparent_alpha_is_visible_to_comparator(self):
        a=Image.new('RGBA',(2,2),(0,0,0,0));b=a.copy();b.putpixel((1,1),(255,0,0,0))
        self.assertEqual(m.changed_pixels(a,b),1)
    def test_alpha_difference_is_visible(self):
        a=Image.new('RGBA',(2,2),(0,0,0,0));b=a.copy();b.putpixel((0,0),(0,0,0,255))
        self.assertEqual(m.changed_pixels(a,b),1)
    def test_dimension_mismatch_fails_before_pixel_comparison(self):
        with self.assertRaises(ValueError):m.changed_pixels(Image.new('RGBA',(1,1)),Image.new('RGBA',(2,1)))
if __name__=='__main__':unittest.main()

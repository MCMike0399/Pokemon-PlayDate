#!/usr/bin/env python3
"""Independent host validation of runtime-sidecar reproduction."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--pin',type=Path,required=True);p.add_argument('--check-dir',type=Path,required=True)
args,rest=p.parse_known_args()
spec=importlib.util.spec_from_file_location('runtime_data',Path(__file__).with_name('reproduce_runtime_data.py'));g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)

class RuntimeDataTests(unittest.TestCase):
    def test_exact_reviewed_bytes(self):
        products=g.generate(args.candidate,args.reference,args.pin)
        self.assertEqual(set(products),{'compact.json','tile-grids.json','descriptors.json','doors.json','trainerNames.json','emote.json'})
        for name,raw in products.items():self.assertEqual(raw,(args.check_dir/name).read_bytes(),name)
    def test_bad_primary_source_hash_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            pin=json.loads(args.pin.read_text());pin['files']['gfx/emotes/shock.png']='0'*64
            path=Path(tmp)/'pin.json';path.write_text(json.dumps(pin))
            with self.assertRaisesRegex(ValueError,'source hash mismatch'):g.generate(args.candidate,args.reference,path)
    def test_modified_candidate_rejected_before_decode(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'candidate';shutil.copytree(args.candidate,target)
            path=target/'maps/Route2.json';path.write_bytes(path.read_bytes()+b' ')
            with self.assertRaisesRegex(ValueError,'candidate hash mismatch'):g.generate(target,args.reference,args.pin)
    def test_malformed_dimensions_even_with_updated_manifest_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'candidate';shutil.copytree(args.candidate,target)
            path=target/'maps/Route2.json';d=json.loads(path.read_text());d['tile_ids'].pop();path.write_text(json.dumps(d))
            path_manifest=target/'source-manifest.json';manifest=json.loads(path_manifest.read_text());manifest['artifacts']['maps/Route2.json']=g.sha(path.read_bytes());path_manifest.write_text(json.dumps(manifest))
            with self.assertRaisesRegex(ValueError,'malformed dimensions'):g.generate(target,args.reference,args.pin)
    def test_runtime_padding_and_gate_bounds(self):
        out=g.generate(args.candidate,args.reference,args.pin);compact=json.loads(out['compact.json']);descriptors=json.loads(out['descriptors.json'])
        self.assertEqual(len(compact['maps']),8);self.assertEqual(len(compact['tiles']),138)
        for name,d in compact['maps'].items():
            self.assertEqual(len(d['tile_rows']),d['height'])
            for row in d['tile_rows']:self.assertEqual(len(row),d['width']*2)
            for warp in descriptors['maps'][name]['warps']:
                self.assertTrue(0<=warp['x']<d['width']);self.assertTrue(0<=warp['y']<d['height'])
        self.assertFalse(descriptors['maps']['ViridianForestNorthGate']['warps'][0]['passable'])
        self.assertEqual(descriptors['maps']['PewterGym']['padding'],1)
        self.assertEqual(descriptors['maps']['PewterMart']['padding'],2)

if __name__=='__main__':unittest.main(argv=[__file__]+rest)

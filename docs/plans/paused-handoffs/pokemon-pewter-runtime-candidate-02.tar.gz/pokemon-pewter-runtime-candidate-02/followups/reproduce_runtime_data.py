#!/usr/bin/env python3
"""Reproduce provider sidecars from a verified candidate and explicit pinned source.

This command never edits Source. --check-dir compares bytes without writes.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
from PIL import Image

REVISION = 'af519899719f0754965776faac0e836a3b906e6d'
KEYS = {'Route2':'route2','ViridianForest':'viridian_forest','ViridianForestSouthGate':'forest_south_gate','ViridianForestNorthGate':'forest_north_gate','PewterCity':'pewter_city','PewterGym':'pewter_gym','PewterMart':'pewter_mart','PewterPokecenter':'pewter_center'}

def sha(data): return hashlib.sha256(data).hexdigest()
def encode(value, pretty=False, unicode=False):
    return (json.dumps(value, indent=2 if pretty else None, separators=None if pretty else (',',':'), sort_keys=not pretty, ensure_ascii=not unicode)+'\n').encode()

def generate(candidate, reference, pin):
    inputs=json.loads(pin.read_text())
    if inputs['revision'] != REVISION: raise ValueError('unsupported source revision')
    for name, expected in inputs['files'].items():
        if sha((reference/name).read_bytes()) != expected: raise ValueError('source hash mismatch: '+name)
    manifest=json.loads((candidate/'source-manifest.json').read_text())
    if manifest['source_revision'] != REVISION or set(manifest['maps']) != set(KEYS): raise ValueError('candidate map/revision mismatch')
    decoded={}
    for name in manifest['maps']:
        path='maps/'+name+'.json';raw=(candidate/path).read_bytes()
        if sha(raw) != manifest['artifacts'][path]: raise ValueError('candidate hash mismatch: '+path)
        decoded[name]=json.loads(raw)
    maps={};palette={};descriptors={}
    constants={d['source_map_constant'] for d in decoded.values()}
    for name,d in decoded.items():
        width,height=d['dimensions']['cells'];pad=max(0,(13-width)//2);runtime_width=max(13,width)
        if len(d['tile_ids']) != height or any(len(row)!=width for row in d['tile_ids']): raise ValueError('malformed dimensions')
        entries=[]
        for entry in d['grids']:
            value={'key':entry['stable_id'],'grid':entry['grid'],'collision':0 if entry['terrain']['land_passable'] else 1,'terrain':entry['terrain']}
            if value['key'] in palette and palette[value['key']] != value: raise ValueError('canonical tile conflict')
            palette[value['key']]=value;entries.append(value['key'])
        void={'key':'adapter:pewter:void','grid':['#'*16]*16,'collision':1,'terrain':{'foot_tile':-1,'land_passable':False,'grass':False,'counter':False,'warp_tile':False,'water_candidate':False,'adapter_padding':True}}
        if runtime_width!=width: palette[void['key']]=void;entries.append(void['key'])
        rows=[]
        for row in d['tile_ids']:
            padded=[len(entries)]*runtime_width
            for x,value in enumerate(row):
                if not 1<=value<=len(d['grids']): raise ValueError('unknown source tile')
                padded[x+pad]=value
            rows.append(''.join(f'{identity:02x}' for identity in padded))
        blocked={}
        for warp in d['events']['warps']:
            dst=warp['destination']
            if dst['kind']!='last_outdoor_map' and dst.get('map') not in constants:
                blocked[str(warp['y']*runtime_width+warp['x']+pad+1)]=warp['id']
        key='kanto_'+KEYS[name]
        maps[name]={'name':name,'id':d['id'],'key':key,'revision':d['source_revision'],'source_sha256':sha((candidate/'maps'/f'{name}.json').read_bytes()),'width':runtime_width,'height':height,'padding':pad,'source_width':width,'palette':entries,'tile_rows':rows,'blocked':blocked}
        warps=[]
        for original in d['events']['warps']:
            warp=dict(original);warp['source_x'],warp['source_y']=warp['x'],warp['y'];warp['x']+=pad;warp['passable']=d['collision'][warp['source_y']][warp['source_x']]==0;warps.append(warp)
        descriptors[name]={'name':name,'id':d['id'],'key':key,'width':runtime_width,'height':height,'padding':pad,'source_width':width,'tileset':d['tileset']['constant'],'warps':warps,'connections':d['connections']}
    common={'schema':1,'source_revision':REVISION}
    out={'compact.json':encode(dict(common,maps=maps,tiles={key:{k:v for k,v in entry.items() if k!='grid'} for key,entry in palette.items()})),
         'tile-grids.json':encode(dict(common,tiles=palette)), 'descriptors.json':encode(dict(common,maps=descriptors))}
    trainer_data=json.loads((candidate/'trainers.json').read_text())
    if sha((candidate/'trainers.json').read_bytes()) != manifest['artifacts']['trainers.json']: raise ValueError('candidate trainer hash mismatch')
    class_ids=re.findall(r'^\s*trainer_const\s+(\w+)',(reference/'constants/trainer_constants.asm').read_text(),re.M)
    names=re.findall(r'^\s*li "([^"]+)"',(reference/'data/trainers/names.asm').read_text(),re.M)
    if class_ids[0]!='NOBODY' or len(class_ids)-1!=len(names): raise ValueError('trainer name table mismatch')
    class_names=dict(zip(('OPP_'+x for x in class_ids[1:]),names));selected={};sprites={}
    for trainer in trainer_data['trainers']:
        selected[trainer['class_source']]=class_names[trainer['class_source']]
        event=next(e for d in decoded.values() for e in d['events']['objects'] if e['id']==trainer['id'])
        sprites[trainer['id']]=event['sprite']
    out['trainerNames.json']=encode(dict(common,names={key:value for key,value in class_names.items() if key in selected},sprites=dict(sorted(sprites.items()))),pretty=True,unicode=True)
    door_text=(reference/'data/tilesets/door_tile_ids.asm').read_text();tables={}
    for label,values in re.findall(r'^\.(\w+):\s*\n\s*door_tiles([^\n]*)',door_text,re.M):
        tables[label]=[int(x.strip()[1:],16) for x in values.split(',') if x.strip()]
    doors={tileset:tables[label] for tileset,label in re.findall(r'^\s*dbw\s+(\w+),\s*\.(\w+)',door_text,re.M)}
    out['doors.json']=encode(dict(common,tilesets=doors))
    raw=(reference/'gfx/emotes/shock.png').read_bytes()
    image=Image.open(io.BytesIO(raw)).convert('RGBA')
    if image.size!=(16,16): raise ValueError('unexpected source emote size')
    shades={255:'.',170:'1',85:'2',0:'#'};grid=[]
    for y in range(16):
        row=''
        for x in range(16):
            r,g,b,a=image.getpixel((x,y))
            if r!=g or r!=b or a!=255 or r not in shades: raise ValueError('unexpected source palette')
            row+=shades[r]
        grid.append(row)
    out['emote.json']=encode(dict(common,source='gfx/emotes/shock.png',source_sha256=sha(raw),grid=grid,native_notice_frames=30,source_notice_frames=60,native_offset_y=-32),pretty=True)
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--pin',type=Path,required=True)
    mode=p.add_mutually_exclusive_group(required=True);mode.add_argument('--output',type=Path);mode.add_argument('--check-dir',type=Path);a=p.parse_args()
    products=generate(a.candidate,a.reference,a.pin)
    if a.check_dir:
        for name,data in products.items():
            if (a.check_dir/name).read_bytes()!=data: raise SystemExit('byte mismatch: '+name)
        print('PASS: exact reproduction of',len(products),'runtime sidecars')
    else:
        if a.output.exists(): raise SystemExit('output already exists')
        a.output.mkdir(parents=True)
        for name,data in products.items(): (a.output/name).write_bytes(data)
        print(a.output)
if __name__=='__main__':main()

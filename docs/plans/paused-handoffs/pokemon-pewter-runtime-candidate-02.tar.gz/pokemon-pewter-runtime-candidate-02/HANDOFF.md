# Frozen Pewter/provider candidate 02

This candidate changes staged files only. Root owns Simulator execution and live Source integration. The original `pokemon-pewter-runtime`, standalone accepted trainer-domain proof, and generated-04/05 artifacts remain preserved.

Compile completed at `/private/tmp/pokemon-pewter-candidate-build-03`. Five host runtime-data reproduction tests passed in 0.117s. No native acceptance is claimed for this packet before root runs it.

Root-only consolidated probe:

```sh
python3 /private/tmp/pokemon-pewter-runtime-candidate-02/validate_staged.py \
  --project /Users/burbujamc/Developer/Pokemon-PlayDate \
  --output /private/tmp/pokemon-pewter-provider-native-02 --execute
```

The validator checks existing-file baseline hashes and every staged Source hash, stages a fresh identified bundle, imports/installs the provider, registers 22 added contracts, then runs `contracts`, isolated `catalog`, and a named shot. It replaces `VisualCatalog.write` only inside this probe's staged main. This is not the final production/default catalog integration. It never skips old successful output directories.

Expected isolated catalog: **300 PNGs**: 128 source sprite/mask images, 138 stable canonical terrain tiles, eight maps × terrain/collision/actors/events-warps-connections, and original shock image/mask. Map manifests enumerate source objects, background events, warps, hidden interactions and connections, including blocked and external-PC-registration dependencies. Actor composites and event overlays require visual review. Three comparator regressions passed (including RGB changes hidden beneath transparent alpha).

Root/host independent pixel check after native completion:

```sh
/private/tmp/pokemon-visual-venv/bin/python \
  /private/tmp/pokemon-pewter-runtime-candidate-02/followups/compare_catalog.py \
  --project /Users/burbujamc/Developer/Pokemon-PlayDate \
  --candidate /private/tmp/pokemon-pewter-slice/generated-05 \
  --runtime-data /private/tmp/pokemon-pewter-runtime-candidate-02/Source/data/pewterSlice \
  --run /private/tmp/pokemon-pewter-provider-native-02 \
  --report /private/tmp/pokemon-pewter-provider-native-02/pixel-comparison.json
```

The comparator checks presence/dimensions of all 300 files and exact event/connection inventory, then compares 284 images with the independent Python fine-dither/mask renderer. RGB differences underneath alpha=0 count. Terrain expectations preserve the source preview with only documented opaque black camera padding. Collision expectations include explicitly blocked unsupported warps. No golden regeneration is allowed to conceal a mismatch.

Six provider sidecars reproduce exactly from explicit inputs:

```sh
/private/tmp/pokemon-visual-venv/bin/python \
  /private/tmp/pokemon-pewter-runtime-candidate-02/followups/reproduce_runtime_data.py \
  --candidate /private/tmp/pokemon-pewter-slice/generated-05 \
  --reference /private/tmp/pokered-af519899719f0754965776faac0e836a3b906e6d \
  --pin /private/tmp/pokemon-pewter-runtime-candidate-02/additional-source-pin.json \
  --check-dir /private/tmp/pokemon-pewter-runtime-candidate-02/Source/data/pewterSlice
```

Use `--output <new-directory>` instead of `--check-dir` to write candidates. Primary-source hashes and candidate artifact hashes are verified before decode. These host tools require Pillow from `tools/requirements-dev.txt`.

## Integration and limits

Merge narrow existing-file differences; do not copy obsolete whole session/context/controller snapshots over siblings' accepted patches. Evolution's append-only session method/context progression callbacks, PC capture methods, HealingComposition draw/dirty hunks, and midbattle-learning controller hooks belong to separate reviewed packets. This candidate already conditionally calls `Evolution.afterBattle`; do not insert it twice. The provider helper rejects changed owned live files rather than silently overwriting them.

The cache retains at most two new imported Zones, compact shared per-palette terrain, and sparse durable world deltas separately. Current six authored plus four previously integrated imported maps remain the reviewed interim baseline. The canonical tile pool for this bounded content is finite; the design does not claim unbounded global tile/image eviction or device memory acceptance. Checkpoint validation and SessionCodec decode remain pure and do not materialize remote maps or allocate numeric tile IDs.

Nontrainer random wandering retains source movement metadata but is not implemented by this packet; these actors remain stationary. Source trainer walking/exclamation are transcribed from pinned originals. NPC eight-frame walking samples the original 16-frame cadence at 30 FPS; RED's legacy walking path is unchanged. Boundary transitions reuse the existing fade/arrival presentation; they do not implement original continuous map scrolling. Interior bottom warps keep the reviewed outward edge-door usability adaptation.

Trainer definitions contain original Blue species/levels and original payout values only. Production Pokémon initialization supplies the project's battle data. New Gen V abilities/held items/natures require the separate reviewed specimen/default policy; this packet does not invent those attributes for original Gen I teams.

Five source trainer outcomes, original lab payout/loss exception, ordinary blackout penalty and Brock badge/TM retry are implemented but require native real-input/controller acceptance beyond the accepted domain-only proof. Original source flags map to one canonical trainer flag; no second divergent defeated-state alias is persisted. Source scripts outside the bounded handler table remain explicit blockers, including Route3, museum/houses/cave/trade connections and unsupported escort/tutorial/song controls. The full Kanto campaign remains incomplete.

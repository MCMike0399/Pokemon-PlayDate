#!/usr/bin/env python3
"""Compact immutable validation metadata derived only from reviewed source JSON."""
import argparse,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--candidate',required=True);p.add_argument('--output',required=True);args=p.parse_args();candidate=Path(args.candidate);target=Path(args.output)
source=json.loads((candidate/'source-manifest.json').read_text());maps={};palette={};paths={}
for name in source['maps']:
 raw=(candidate/'maps'/f'{name}.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==source['artifacts']['maps/'+name+'.json'];d=json.loads(raw);paths[name]=hashlib.sha256(raw).hexdigest();width,height=d['dimensions']['cells'];pad=max(0,(13-width)//2);runtimeWidth=max(13,width)
 grids={e['id']:e for e in d['grids']};entries=[]
 for entry in d['grids']:
  value={'key':entry['stable_id'],'grid':entry['grid'],'collision':0 if entry['terrain']['land_passable'] else 1,'terrain':entry['terrain']}
  if entry['stable_id']in palette:assert palette[entry['stable_id']]==value
  palette[entry['stable_id']]=value;entries.append(entry['stable_id'])
 void={'key':'adapter:pewter:void','grid':['#'*16]*16,'collision':1,'terrain':{'foot_tile':-1,'land_passable':False,'grass':False,'counter':False,'warp_tile':False,'water_candidate':False,'adapter_padding':True}}
 if pad or runtimeWidth!=width:palette[void['key']]=void;entries.append(void['key'])
 rows=[]
 for row in d['tile_ids']:
  padded=[len(entries)]*runtimeWidth
  for x,value in enumerate(row):padded[x+pad]=value
  rows.append(''.join(f'{identity:02x}' for identity in padded))
 blocked={}
 for warp in d['events']['warps']:
  dst=warp['destination'];supported=dst['kind']=='last_outdoor_map' or dst.get('map') in {json.loads((candidate/'maps'/f'{n}.json').read_text())['source_map_constant'] for n in source['maps']}
  if not supported:blocked[str(warp['y']*runtimeWidth+warp['x']+pad+1)]=warp['id']
 key='kanto_'+{'Route2':'route2','ViridianForest':'viridian_forest','ViridianForestSouthGate':'forest_south_gate','ViridianForestNorthGate':'forest_north_gate','PewterCity':'pewter_city','PewterGym':'pewter_gym','PewterMart':'pewter_mart','PewterPokecenter':'pewter_center'}[name]
 maps[name]={'name':name,'id':d['id'],'key':key,'revision':d['source_revision'],'source_sha256':paths[name],'width':runtimeWidth,'height':height,'padding':pad,'source_width':width,'palette':entries,'tile_rows':rows,'blocked':blocked}
metadata={'schema':1,'source_revision':source['source_revision'],'maps':maps,'tiles':{key:{k:v for k,v in entry.items() if k!='grid'} for key,entry in palette.items()}}
for name,value in [('compact.json',metadata),('tile-grids.json',{'schema':1,'source_revision':source['source_revision'],'tiles':palette})]:
 path=target/name
 if path.exists():raise SystemExit('output exists: '+str(path))
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,separators=(',',':'),sort_keys=True)+'\n')
print('compact maps',len(maps),'canonical tiles',len(palette))

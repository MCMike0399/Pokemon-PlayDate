from pathlib import Path
import json,re,struct,hashlib
root=Path(__file__).resolve().parent;source=(root/'references/personal_b2w2').read_bytes();assert len(source)%0x4c==0
raw=(root/'references/data_abilities.ts').read_text();names={}
blocks=re.split(r'^\t([a-z0-9]+): \{',raw,flags=re.M)
for i in range(1,len(blocks),2):
 m=re.search(r'\bnum: (\d+)',blocks[i+1])
 if m:names[int(m.group(1))]=blocks[i]
production=Path('/Users/burbujamc/Developer/Pokemon-PlayDate/Source/data/pokemon.lua').read_text()
species={int(dex):key for key,dex in re.findall(r'^    (\w+) = \{\n        name = "[^"]+", dex = (\d+)',production,re.M)};assert len(species)==151
rows=[];normal=set();hidden=set();held=set()
for dex in range(1,152):
 row=source[dex*0x4c:(dex+1)*0x4c];abilities=list(row[0x18:0x1b]);items=list(struct.unpack_from('<hhh',row,0xc));assert all(a in names for a in abilities)
 normal.update(abilities[:2]);hidden.add(abilities[2]);held.update(x for x in items if x)
 rows.append({'dex':dex,'species':species[dex],'normal_ability_ids':abilities[:2],'hidden_ability_id':abilities[2],
  'ability_names':[names[a] for a in abilities],'wild_personal_item_fields':items,'wild_item_availability_claimed':False})
report={'schema':1,'source_sha256':hashlib.sha256(source).hexdigest(),'record_size':76,'species_count':151,
 'unique_normal_abilities':len(normal),'unique_hidden_abilities':len(hidden),'unique_abilities_union':len(normal|hidden),
 'normal_ids':sorted(normal),'hidden_ids':sorted(hidden),'unique_wild_item_fields':sorted(held),'rows':rows}
(root/'specimen-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='rows'})

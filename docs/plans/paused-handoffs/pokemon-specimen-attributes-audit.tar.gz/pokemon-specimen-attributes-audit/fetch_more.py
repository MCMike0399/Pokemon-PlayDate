from pathlib import Path
import urllib.request,hashlib,json
root=Path(__file__).resolve().parent;p=root/'references/source-pins.json';m=json.loads(p.read_text());s=m['showdown_revision'];b=m['pokebw2_revision']
paths={}
for gen in range(6,10):
 for name in ('abilities.ts','items.ts','scripts.ts'):
  path=f'data/mods/gen{gen}/{name}';paths['ps_'+path.replace('/','_')]=f'https://raw.githubusercontent.com/smogon/pokemon-showdown/{s}/{path}'
for path in ('src/ov167/ability_handlers.c','src/ov167/item_handlers.c','src/ov167/btl_handler_work.c','src/ov167/btl_event.c','include/pml/poke_param.h'):
 paths['bw_'+path.replace('/','_')]=f'https://raw.githubusercontent.com/fuddlesworth/pokebw2/{b}/{path}'
for name,url in paths.items():
 try:
  target=root/'references'/name;raw=target.read_bytes() if target.exists() else urllib.request.urlopen(url,timeout=30).read();target.write_bytes(raw);m['files'][name]={'url':url,'sha256':hashlib.sha256(raw).hexdigest()};print(name,len(raw),flush=True)
 except Exception as e: print('NOT FOUND',name,str(e),flush=True)
p.write_text(json.dumps(m,indent=2)+'\n')

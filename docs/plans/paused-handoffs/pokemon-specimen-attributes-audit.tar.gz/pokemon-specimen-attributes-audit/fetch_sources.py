from pathlib import Path
import hashlib,json,urllib.request
root=Path(__file__).resolve().parent;project=Path('/Users/burbujamc/Developer/Pokemon-PlayDate');files={}
growth=json.loads((project/'tools/references/growth-sources.json').read_text())
for name in ('personal_b2w2','PersonalInfo5B2W2.cs'):files[name]=growth['files'][name]
ps='9b136a8c8cdb860a8ab96fa063f906604e352547'
for name in ('data/abilities.ts','data/items.ts','data/natures.ts','data/mods/gen5/abilities.ts','data/mods/gen5/items.ts','data/mods/gen5/scripts.ts','sim/battle.ts','sim/battle-actions.ts','sim/pokemon.ts'):
    files[name.replace('/','_')]={'url':f'https://raw.githubusercontent.com/smogon/pokemon-showdown/{ps}/{name}'}
for name,item in files.items():
    target=root/'references'/name
    raw=target.read_bytes() if target.exists() else urllib.request.urlopen(item['url'],timeout=30).read()
    digest=hashlib.sha256(raw).hexdigest();assert 'sha256' not in item or digest==item['sha256'],'checksum mismatch '+name
    item['sha256']=digest
    if not target.exists():target.write_bytes(raw)
    print(name,len(raw),digest)
(root/'references/source-pins.json').write_text(json.dumps({'pkhex_revision':growth['pkhex_revision'],'showdown_revision':ps,'pokebw2_revision':'b279bbefa99bb2f6fbabcc95e4b6d3e939290353','files':files},indent=2)+'\n')

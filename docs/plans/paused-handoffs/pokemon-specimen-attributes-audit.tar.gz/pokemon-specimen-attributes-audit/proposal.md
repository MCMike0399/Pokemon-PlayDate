# Gen V specimen attributes and battle effects — proposal for review

Status: research/architecture only. No new Source code or live edits. Audited live
clean HEAD `b11414590b5f8f56915e5f60273ec5b8798b0f65`. Frozen evolution14+followup2
and initial midbattle5+separate followup2 hashes verified intact on resume.
The user explicitly chose abilities, held items and natures. This proposal does
not waive any of those systems or claim implementation.

## Recommended shape

Keep the actual owned Pokemon as the durable specimen, GameSession as the owner
of bag/Pokemon transactions, and Battle as the owner of disposable battle effects.
Add generated B2W2 immutable specimen definitions and a pure specimen-creation
module. Extend the existing Pokemon constructor/codec/evolution owner; do not
create another party, bag, mutable species record or save owner. Add a battle-owned
ability/item effect module behind explicit typed call sites in current battle/DSL.
Preserve existing HSM overlays and the accepted battle-script coroutine.

Implement in reviewed stages: durable attributes/natures/creation first; atomic
held-item give/take next; battle effect ordering plus the entire naturally exposed
early-Kanto ability slice next; remaining original151 abilities/dependencies as
campaign milestones expose them. A generated ability row is not implemented
mechanics. All75 normal and111 total ability IDs remain full-goal work, with
explicit unsupported mechanics inventory until each has production contracts.

## Pinned findings

`references/source-pins.json` pins28 primary files. B2W2 personal data from PKHeX
revision `d2fea14b563f4b16fef7788b9699b20d5b3f410f` has SHA256
`6df24e7f00dab32322d9d8f8b3209d30de1c89b0de88277081fe53434211830f`.
[PersonalInfo5B2W2](https://github.com/kwsch/PKHeX/blob/d2fea14b563f4b16fef7788b9699b20d5b3f410f/PKHeX.Core/PersonalInfo/Info/PersonalInfo5B2W2.cs)
defines76-byte rows, normal slots at0x18/0x19, hidden slot0x1A, wild-item fields
at0x0C/0x0E/0x10. `specimen-inventory.json` records exactly151 rows and the raw
three item fields, with no encounter-rate/availability claim. Counts:75 unique
normal IDs,61 hidden IDs,111 union;38 distinct nonzero wild item fields.

Literal checks include Bulbasaur65/65/H34, Charmander66/66/H94,
Squirtle67/67/H44, Geodude69/5/H8, Eevee50/91/H107, Gengar26/26/H26.
Gengar is Levitate in this generation; importing contemporary species abilities
would silently introduce Cursed Body.

Primary B2W2 decompilation revision `b279bbefa99bb2f6fbabcc95e4b6d3e939290353`:

- [poke_tool.c](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/system/poke_tool.c)
  `PML_CreatePkm` rolls/stores nature independently with RandomLC(NATURE_COUNT).
  Gen V nature is not recomputed as PID modulo25. `natureStat` has25 rows and
  `adjustStatForNature` multiplies the completed non-HP stat by110/100 or90/100
  using integer division. Five natures are neutral. HP is unaffected.
- Same file `setAbilityForForm` preserves the persistent hidden flag or normal
  PID ability bit; it looks up the resulting species/form's slot. The source
  does not infer provenance by matching the old ability name. Caterpie H50→
  Metapod H61→Butterfree H110 proves why equal slot effects are not absent slots.
  Eevee normal slot2→Vaporeon's duplicated Water Absorb must retain preference.
- Same file `setChangedPkmSpecies` changes species and recomputes ability/stats,
  without rerolling nature or held item. Current frozen evolution's HP/status/
  nickname/XP/moves/PP sequencing remains the baseline to preserve.
- [shinka_check.c](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/system/shinka_check.c)
  checks held no-evolve effect for non-item evolution, except Kadabra. Stone use
  bypasses that check. Everstone is therefore an actual evolution dependency.
- [battle_event.c](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/battle_event.c)
  registers factors in ordered lists, tracks nested calls, validates active/
  suppressed/removed handlers, and defers removal while executing. A listener
  registered mid-event must not accidentally rerun the triggering event.
- [ability_handlers.c](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/ability_handlers.c)
  and [item_handlers.c](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/item_handlers.c)
  register per-effect events/priorities and speed subpriority. They establish
  that one undifferentiated after-move pass cannot implement abilities/items.

Pinned Showdown `9b136a8c8cdb860a8ab96fa063f906604e352547` independently checks
all25 nature stat signs and supplies readable effect/event expectations. Gen5
scripts inherit Gen6→Gen7→Gen8→base. The audit downloaded the entire relevant
ability/item override chain; applying only current base plus Gen5 would be wrong.
Numeric priorities are not assumed interchangeable between cartridge and Showdown.

Offline evidence command:

```sh
python3 /private/tmp/pokemon-specimen-attributes-audit/check_audit.py
```

Result:28 pinned checksums,151 binary rows,8 literal species vectors and25
independent nature-table comparisons PASS. This validates the audit inputs,
not an unimplemented Lua model or battle effect.

## Proposed durable model and creation interface

Pokemon gains `natureId`0..24, `abilitySlot` enum `first|second|hidden`, and
`heldItem` canonical item ID or `none`. Derive current ability ID/name from species
and slot; do not save a second mutable ability ID. Both normal slots are valid
preferences even if their current IDs coincide. Hidden slot provenance is valid
through forms such as Metapod whose effective abilities coincide. Generation
eligibility is a separate source policy, not a codec restriction on such records.
No PID is required merely to preserve this game-relevant slot preference. Full
PID/shininess/gender/OT simulation is a separate dependency, not invented here.

`Pokemon(species,level,attributes)` remains pure: no RulesRNG or cosmetic draws.
Explicit attributes are validated before any construction; default two-argument
calls deterministically use Hardy/first/none for fixtures and legacy internal
construction. They still receive the species' real first normal ability; no
production no-ability compatibility mode is proposed. Decode/recalc/evolution
must pass preserved attributes, never use constructor defaults over saved choices.
`Pokemon:ability()` derives the current definition. Public stat recalculation
uses nature after the completed base stat; every caller/codec/evolution must use
the same method. Existing baseline stats mathematically equal IV0/EV0. Keep that
explicit baseline while adding nature; do not quietly add six random IVs or EV
training as part of this bounded slice. IV/EV fidelity remains recorded work.

`Specimen.create(species,level,origin,rng)` is the only normal random creation
seam. Origin is a validated definition/policy, not arbitrary UI data. Proposed
stable draw protocol: one normal-slot preference roll1..2 and one independent
nature roll0..24, even when current slot IDs match; future held-item roll is
separately versioned and enabled only by an explicit source availability policy.
Preserve the slot bit through evolution. Validate full request before drawing;
if later generation can fail after draws, use a detached RulesRNG snapshot and
commit continuation only on successful creation. Rejected creation is unchanged.
This is reproducible GenV distribution, not a claim to reproduce cartridge PRNG.

Ordinary wild/starter/gift/trainer origins never randomly select hidden abilities.
Hidden construction requires explicit approved source/event eligibility. Fixtures
may select hidden slot to test mechanics; that does not create player availability.
Trainer authored natures/slots can override random origin values explicitly.
Migrate actual Zone encounter, Story starter/rival, trainer team and debug creation
sites to this factory; Codec and Evolution remain pure. Cosmetic/UI draws cannot
alter specimen generation. Capture retains the same enemy identity/attributes.
Debug level changes must preserve attributes rather than constructing a new random
specimen. No default-nature changes during healing, transfer or PC release.

## Held ownership and acquisition

Extend generated item definitions with explicit `holdable`, stable GenV item ID,
and held-effect metadata. Original non-key medicine/balls/stones may be held when
primary item rules permit; medicine held does not automatically heal and a held
ball does not throw itself. TM/HM/key-item holdability must be checked explicitly.
Do not classify every non-key item as a functioning battle held item. Meaningful
GenV held effects require catalog additions with pinned item source names/effects;
retain existing original Blue IDs/prices/sourceName bytes for current rows.

Proposed owner methods: `GameSession:giveHeldItem(mon,id)` and
`:takeHeldItem(mon)`. They validate actual same-session ownership and current bag,
then prepare a detached bag record and mon attribute result. Giving onto an
occupied slot swaps the old held item into bag only if capacity permits. Remove
one new item before testing whether its freed slot can hold the old item; a full
bag with new stack quantity1 can therefore differ from quantity2. Commit the bag
via existing Inventory:_replaceData and one straight heldItem assignment only
after every validation. No yield/callback/throwing work after first assignment.
Failure leaves both identities, quantities, PP/status and RNG unchanged. No second
bag owner or UI read-modify-write plan is accepted.

Battle consumption checks the exact current held item and one actual eligible
effect receipt, removes it once, then resolves its source-backed effect. Repeated
or stale events cannot duplicate consumption. Persistent player held consumption
survives ordinary return; trainer/enemy consumption does not touch the player's
bag. Capture/recruit/storage/evolution preserve the same object's remaining item.
Thief/Trick/Recycle/Knock Off and item suppression require explicit separate
semantics as their dependencies become supported; do not fake success.

Recommended acquisition policy for root review: ordinary Blue authored shops/gifts
keep their identity; introduce meaningful held items through explicitly documented
B2W2 species-held distributions for existing wild encounters first, after their
exact ordinary-grass rates are primary-verified. The raw three personal item
fields are not enough to assert those rates. Do not add an unexplained Leftovers
shop, berry gift or hidden-ability encounter to existing Blue story. Later explicit
rewards may be intentional GenV enhancements recorded in fidelity ledger. Root
should approve the concrete distribution/availability manifest before enabling it.

## Battle event integration and first playable slice

Use one battle-owned `BattleEffects` module with immutable ability/item handlers
and disposable state keyed by actual battler identity. Existing BattleConditions
continues owning hazards/Rollout/Rage/status counters. It contributes to the same
ordered residual plan instead of maintaining an unrelated second end-of-turn loop.
No global effect bus, class-per-ability, fake move, or added callback on every mon.

Place typed internal call sites in current Battle/DSL at entry/withdrawal, speed/
action order, before move/PP gate, status/secondary eligibility, immunity/target,
damage modifier stages, each actual hit, after-hit contact/drain/recoil/faint,
ordered residuals, and item use/consumption. Define a separate immutable hit receipt
with actual HP removed, direct/indirect/cause/move/contact provenance; do not infer
contact from a physical category or a translated message. Each effect operates
at its primary-source stage; numbers/priority/flooring are pinned with vectors.
Use Q12/rational integer modifier chains where cartridge code requires them rather
than adding float multipliers to the current formula. Preserve deterministic
suspended scripts and do not run handlers/consume RNG from draw/snapshots.

Handler dispatch snapshots current eligible factors and rechecks active identity,
suppression, faint state and item still present before applying each. Additions
wait until the next relevant event; consumption/removal cannot run twice. Forced
exit clears all disposable state; major status, nature/slot and remaining held item
persist. Entry effects and residual effects need source-defined speed tie behavior
and explicit RNG only for actual ties/chances; unordered pairs iteration cannot
choose their order. Update current early-combat residual vectors when a newly
implemented factor changes the source order, without weakening assertions.

First naturally exposed implementation set must include starters Overgrow/Blaze/
Torrent, Rattata Run Away/Guts, Pidgey Keen Eye/Tangled Feet, Caterpie/Weedle Shield
Dust, Metapod/Kakuna Shed Skin, Butterfree Compound Eyes, Beedrill Swarm,
Pikachu Static, Geodude/Onix Rock Head/Sturdy, plus every other normal slot actually
exposed by the accepted early campaign encounter manifest. Audit the manifest
before freezing that list. Sand Veil and any weather-related exposed slot require
the actual weather dependency; do not leave it as an always-inactive no-op and call
the species implemented. Hidden mechanics all remain tracked even while naturally
unavailable. Sturdy especially changes Brock and multi-hit outcomes; rerun native
starter/rival/Forest/Brock balance from controlled factory seeds.

## Persistence and migration proposal requiring review

Evolution candidate Codec4 owns pending evolution plus its strict old3→absent-event
migration. Do not overwrite that work. Attribute extension should be Codec5 and
validate all attributes before constructing/recalculating a Pokemon. Session
encoding can retain its existing lossless counter wire format; save envelope need
not change merely because the nested Pokemon version changes. Give/take must be
outside transient battle/overlay save boundaries; no battle-resume save is added.

Recommended current unreleased policy: reject old4/3 records explicitly for the
attributes release, because no nature or ability preference existed to reconstruct.
All aggregate saves so far are private harness evidence, not shipped player saves.
Root must confirm this before implementation. Alternative explicit migration is
Hardy/first/none, documented as a deliberate legacy default rather than historical
inference; it preserves former derived stat values but activates a newly selected
ability and loses unknown slot provenance. Do not choose that policy silently or
randomize old records. Preserve original nickname, XP, HP, sleep/major status,
selected moves/PP, choices and pending evolution exactly if a migration is chosen.
Old-codec unsupported errors and malformed mixed schemas need regression tests.

## Required acceptance for implementation packets

- All151 slots compare against an independent GenV oracle,25 natures/signs and
  integer stat vectors; Gen7 Gengar regression; no silently missing/zero IDs.
- Factory literal known RNG continuations, slot preference through duplicated
  intermediates, origin rejection/no RNG, hidden eligibility, draw-cadence
  independence, no reconstruction RNG; creation receipt records policy version.
- Same owned identity on evolution; HA Caterpie→Metapod→Butterfree and normal
  Eevee second preference→Vaporeon; custom/default names, HP0/injured HP, status,
  PP, nature, held item and pending queues; Everstone/Kadabra/stone exceptions.
- Give/take empty/occupied, bag full, stack1 vs2, foreign mon, unknown/nonholdable
  item, stale UI selection, key/TM rejection, exact single consumption, save+restart.
- Actual battle vectors for low-HP starters, Guts/burn, Static per contact hit,
  Shield Dust secondary versus primary status, Shed Skin residual order/RNG,
  Compound Eyes accuracy, Sturdy full HP/partial HP/multi-hit, Rock Head versus
  Struggle, Run Away/trainer refusal, faint-and-consume ordering. Include controlled
  mutants proving the new contract predicates detect removal/order/draw mistakes.
- Native party/specimen details and give/take show actual nature/ability/item;
  same menus and original sprites. Actual early campaign/intro/Brock sessions
  prove outcomes with factory seeds and preserve protected art pixel comparisons.

No new Source is authorized by this document. Await root interface/migration/
acquisition review, then implement bounded staged packets and root-run SDK proofs.

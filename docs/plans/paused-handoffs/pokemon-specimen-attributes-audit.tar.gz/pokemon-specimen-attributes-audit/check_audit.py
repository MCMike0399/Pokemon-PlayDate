from pathlib import Path
import hashlib,json,re
root=Path(__file__).resolve().parent;m=json.loads((root/'references/source-pins.json').read_text())
for name,row in m['files'].items():assert hashlib.sha256((root/'references'/name).read_bytes()).hexdigest()==row['sha256'],name
personal=(root/'references/personal_b2w2').read_bytes();assert len(personal)%76==0
rows=json.loads((root/'specimen-inventory.json').read_text())['rows'];assert len(rows)==151 and len({r['dex'] for r in rows})==151
for r in rows:
 row=personal[r['dex']*76:(r['dex']+1)*76];assert r['normal_ability_ids']==list(row[24:26]);assert r['hidden_ability_id']==row[26]
expected={1:([65,65],34),4:([66,66],94),7:([67,67],44),11:([61,61],61),12:([14,14],110),74:([69,5],8),94:([26,26],26),133:([50,91],107)}
for dex,(normal,hidden) in expected.items():r=rows[dex-1];assert r['normal_ability_ids']==normal and r['hidden_ability_id']==hidden
poke=(root/'references/bw_src_system_poke_tool.c').read_text();part=poke.split('static const s8 natureStat[NATURE_COUNT][NATURE_STAT_COUNT] = {',1)[1].split('\n};',1)[0]
natures=[]
for nums,name in re.findall(r'\{([^}]+)\},?\s*// NATURE_(\w+)',part):natures.append((name.lower(),[int(x.strip()) for x in nums.split(',')]))
assert len(natures)==25
ps=(root/'references/data_natures.ts').read_text();parsed={}
for key,body in re.findall(r'^\t(\w+): \{(.*?)\n\t\}',ps,re.M|re.S):
 plus=re.search(r"plus: '(\w+)'",body);minus=re.search(r"minus: '(\w+)'",body);parsed[key]=(plus.group(1) if plus else None,minus.group(1) if minus else None)
assert len(parsed)==25
for key,changes in natures:
 actual=parsed[key];stats=['atk','def','spa','spd','spe'];expected=([stats[i] for i,x in enumerate(changes) if x==1],[stats[i] for i,x in enumerate(changes) if x==-1]);assert actual==(expected[0][0] if expected[0] else None,expected[1][0] if expected[1] else None),key
print(f'{len(m["files"])} pinned source checksums;151 personal rows;8 literal species vectors;25 independent nature-table comparisons PASS')

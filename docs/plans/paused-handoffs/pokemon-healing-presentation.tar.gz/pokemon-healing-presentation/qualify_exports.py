#!/usr/bin/env python3
"""Host-only required-artifact failure proof; produces no runtime substitute images."""
import argparse,json,sys,tempfile
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--project',type=Path,required=True)
parser.add_argument('--native-sample',type=Path,help='Optional completed genuine native PNG positive check')
args=parser.parse_args();sys.path.insert(0,str(args.project.resolve()))
from tools.harness.run import verify_png
from tools.harness.protocol import ProtocolError
stage=Path(__file__).resolve().parent
healing=(stage/'Source/dev/healingCompositionContracts.lua').is_file()
scenario=json.loads((stage/('healing-composition-scenario.json' if healing else 'pc-contract-scenario.json')).read_text())
required=json.loads((stage/'required-outputs.json').read_text())
assert scenario['outputs']==required
assert len(required)==(14 if healing else 5) and len(set(required))==len(required)
for name in required:
    assert Path(name).name==name and name.endswith('.png')
contract=stage/'Source/dev'/('healingCompositionContracts.lua' if healing else 'pcContracts.lua')
text=contract.read_text()
assert 'HarnessBuild.output_dir..name..".png"' in text
assert 'HarnessBuild.output_dir.."/frames/"' not in text
with tempfile.TemporaryDirectory(prefix='required-native-panels-missing-') as temporary:
    for name in required:
        try:verify_png(Path(temporary)/'frames'/name)
        except ProtocolError as error:assert 'missing output' in str(error)
        else:raise AssertionError('missing required PNG was accepted: '+name)
if args.native_sample:verify_png(args.native_sample,400,240)
print('PASS: '+str(len(required))+' unique required native panel paths; every absent PNG rejected; no replacement images generated')

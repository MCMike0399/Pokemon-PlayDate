# Original healing palette and timing audit

Pin: pret/pokered `af519899719f0754965776faac0e836a3b906e6d`; `source-pins.json` records exact local input hashes. Original code is [healing_machine.asm](https://github.com/pret/pokered/blob/af519899719f0754965776faac0e836a3b906e6d/engine/overworld/healing_machine.asm); OAM packing is [macros/gfx.asm](https://github.com/pret/pokered/blob/af519899719f0754965776faac0e836a3b906e6d/macros/gfx.asm). The helper script reads the pinned originals directly. Web fetch of these two paths returned cache misses; local immutable source is the evidence used.

Original rOBP1 starts atE0, then FlashSprite8Times XORs28 eight times. Two-bit source indices map as follows (output palette0white/1light/2dark/3black):

| Source index | E0 | C8=E0 XOR28 |
|---|---|---|
|0|transparent OAM|transparent OAM|
|1|white|dark|
|2|dark|white|
|3|black|black|

This changes both monitor and balls. Current EventArt represents the original source-index grid with the project's ordinary LIGHT/DARK dither; current animation only toggles ball visibility. The composition patch deliberately preserves those existing raw images and that approximation. It does **not** claim original palette fidelity.

At nominal source60Hz, per-ball delay30 becomes15 native30Hz frames. Eight flashes at10 source frames each become8×5 native frames. The final32-frame wait becomes16 native frames, giving existing visual bound15×party+56. Source also waits on music/fade state; the game does not currently reproduce that audio synchronization. Timings therefore match those explicit delay counters, not the full original audio duration. The original nurse faces the machine, then bows after the fit message; the current guarded lifecycle preserves its existing facing restoration. No new bow pose is invented.

Proposed separate phase work: add four explicitly named derived images, `event_heal_monitor_pal_e0`, `event_heal_monitor_pal_c8`, `event_heal_ball_pal_e0`, `event_heal_ball_pal_c8`, without replacing any existing EventArt image. Render source-index1/2 through the table above with explicit phase0; apply the unchanged source-index0 transparency mask **after** rasterization so white-phase monitor pixels stay opaque. Independent host oracle should decode the pinned8x16 PNG indices directly, use the already-calibrated phase0 dither, verify everyRGBA/mask pixel and compare native map composites. Catalog would gain20 separately unreviewed raw/mask/white/black/texture artifacts. All existing1635 artifacts remain protected unchanged. These images are a proposal, not implemented or accepted; renderer/mask/palette details deserve their own SDK/source proof before replacing animation behavior.

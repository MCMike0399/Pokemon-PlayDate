#!/usr/bin/env python3
"""Real pinned input proof plus isolated art/OAM/map drift rejection."""
import argparse, json, shutil, tempfile
from pathlib import Path
from PIL import Image
from check_source import check, STAGE

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--project',type=Path,required=True)
parser.add_argument('--reference-root',type=Path,required=True)
args=parser.parse_args()
assert check(args.project,args.reference_root)['ok']
pins=json.loads((STAGE/'source-pins.json').read_text())
changes=[('reference','gfx/overworld/heal_machine.png'),('reference','engine/overworld/healing_machine.asm'),('project','Source/data/viridianSlice/ViridianPokecenter.json')]
for kind,name in changes:
    with tempfile.TemporaryDirectory(prefix='healing-source-drift-') as temporary:
        roots={key:Path(temporary)/key for key in ('reference','project')}
        for row in pins['inputs']:
            source=(args.reference_root if row['root']=='reference' else args.project)/row['path']
            destination=roots[row['root']]/row['path'];destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination)
        destination=roots[kind]/name
        if name.endswith('.png'):
            image=Image.open(destination).convert('L');image.putpixel((0,0),0);image.save(destination)
        elif name.endswith('.asm'):
            text=destination.read_text();destination.write_text(text.replace('6,  4,  4,  4','6,  4,  5,  4',1));assert destination.read_text()!=text
        else:
            data=json.loads(destination.read_text());data['grids'][0]['grid'][0]='#'+data['grids'][0]['grid'][0][1:];destination.write_text(json.dumps(data))
        try:check(roots['project'],roots['reference'])
        except AssertionError as error:
            assert 'source input drift' in str(error),str(error)
        else:raise AssertionError('mutated input was accepted: '+name)
print('PASS: exact pinned source/OAM/map proof; one-pixel art, OAM offset and map drift rejected; originals untouched')

# Staged in-world healing composition

Composition candidate only; no live Source/art/Simulator edits. `healing-composition.patch` + `bridge-manifest.json` contain3Lua files. Compile01 passed against current Source. Existing7 EventArt images, masks, factory raster policy, healing/checkpoint commit and nurse callback lifecycle remain intact.

`HealingComposition.draw(zone,partyCount,clock,camera)` draws existing16px assets in world space over the actual source machine; no popup/white rectangle/title. Monitor anchor is native(56,8); balls use source OAM relative offsets and alternating right-hand X flips. `layout` returns a defensive placement table. Current map whitelist is explicit Viridian Center; future Centers require validated anchors rather than a silent universal guess.

The absolute anchor now has an independent source-pixel derivation: `check_source.py` finds exactly one6x3 monitor cavity/highlight signature left of the actual source nurse. Source cavity(29,6), minus the tile's opaque-mask offset(1,2), derives logical anchor(28,4), hence native(56,8). The same script parses original OAM records for all6 relative offsets/flips and checks unchanged protected source grids/masks. This evidence makes the anchor traceable; root still must inspect native overlays before visual acceptance.

EventState marks the bounded400x240 framebuffer dirty during healing and redraws static sprites with all actor updates suppressed, then draws the OAM composition in camera space. This restores map pixels when the existing visibility flash turns off, without player/NPC/rules progression. Completion/cancel dirty redraw clears transient OAM. The full-frame redraw is deliberate bounded correctness work, not a performance optimization; no unmeasured device-budget claim.

```sh
python3 /private/tmp/pokemon-healing-presentation/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-healing-build-UNIQUE
# Root only: append --execute for actual SDK/native panel proof.
/private/tmp/pokemon-validation-venv/bin/python /private/tmp/pokemon-healing-presentation/qualify_source.py --project "$PWD" --reference-root PINNED_POKERED_TREE
```

Compile-only is default and uses the current source snapshot, exact original/candidate hashes and ordinary ownership/build manifests. Root production integration imports `game/healingComposition` beside `game/eventArt` before `game/eventState`, imports the dev suite and registers `HealingCompositionContracts.run`. The helper inserts imports/suite into its private current main only. It does not install an old map or UI tree.

Four SDK groups use actual WorldView/Player/NPC/StateMachine/Dialog/EventState and source renderer. They compare every400x240 working-framebuffer pixel against an independent fixed-source-OAM composition for party1/2/6 at camera(0,0) and(32,16), checking draw does not advance clock. They check all original16px asset mask pixels, full-frame map restoration on flash-off, cancel restoration of nurse/map/entire session, guarded full-party healing/checkpoint completion, no global rules RNG consumption. Existing root EventContracts remain an additional lifecycle proof.

Native exports: `healing-party-{1,2,6}-camera-{0-0,32-16}.png` plus separately labeled copies (labels/guide rectangle alter only that inspection copy), `healing-six-flash-off.png`, `healing-cancel-restored.png`. Actual raw native panels stay unlabeled/unaltered. No baseline regeneration or automatic visual acceptance. Actual SDK execution belongs to root; worker performed compile and host source qualification only.

Host qualification passed exact pinned inputs and independently rejected one-pixel art, OAM offset and map mutations in temporary copies. `source-proof.json` records coordinates, masks, palette table and timing; `source-pins.json` hashes original ASM/art and current source map/EventArt JSON. Originals remain untouched. `source-center-layout.png` from the PC proposal is a source-grid preview only, not native gameplay evidence.

See `palette-audit.md`: current hide-ball flash remains an explicit approximation of original E0 XOR28 palette flashing. The source timing counters/palette mapping and separate20-artifact derived-phase catalog proposal are documented; no new palette phase assets are implemented, and full flashing fidelity remains pending.

## Required native export followup

Root's completed first SDK evidence remains untouched. Passing SDK assertions did not establish image publication: the helper incorrectly appended `frames/` to HarnessBuild.output_dir, which already ends in `frames/`. The export now appends only the filename. No SDKwriteToFile boolean return is assumed.

Default validator scenario explicitly lists all 14 required native PNGs in `outputs`; absent/invalid PNG fails the ordinary host runner before success. `required-outputs.json` is the exact inventory. `export-path-followup.patch` changes only the narrow Source helper relative to the prior candidate; full patch/manifest hashes and explicit refreeze reason are updated. No placeholder/substitute images or directories were manufactured. Compile passed at `/private/tmp/pokemon-healing-composition-compile-02`.

`python3 /private/tmp/pokemon-healing-presentation/qualify_exports.py --project "$PWD"` validates scenario inventory/path wiring and proves the real runner rejects every absent output, without generating replacement images. The optional `--native-sample` accepts a completed genuine native400x240 PNG for the existing validator's positive branch. Actual new exports still require root execution/visual inspection.

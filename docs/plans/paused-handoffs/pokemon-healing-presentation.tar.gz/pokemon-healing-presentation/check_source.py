#!/usr/bin/env python3
"""Independent pinned OAM/map/asset proof; no runtime or input mutation."""
import argparse, hashlib, json, re
from pathlib import Path
from PIL import Image

REVISION = 'af519899719f0754965776faac0e836a3b906e6d'
STAGE = Path(__file__).resolve().parent

def check(project, reference):
    pins = json.loads((STAGE / 'source-pins.json').read_text())
    for row in pins['inputs']:
        path = (reference if row['root'] == 'reference' else project) / row['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], 'source input drift: ' + row['path']
    text = (reference / 'engine/overworld/healing_machine.asm').read_text()
    block = text.split('PokeCenterOAMData:', 1)[1].split('; d =', 1)[0]
    entries = []
    for line in block.splitlines():
        match = re.search(r'dbsprite\s+(\d+),\s*(\d+),\s*(\d+),\s*(\d+),\s*\$7[cd],\s*(.*)', line)
        if match:
            x, y, dx, dy = map(int, match.groups()[:4])
            entries.append({'x': x * 8 + dx, 'y': y * 8 + dy, 'flip_x': 'OAM_XFLIP' in match.group(5)})
    assert len(entries) == 7
    relative = [{'x': 2*(e['x']-entries[0]['x']), 'y': 2*(e['y']-entries[0]['y']), 'flip_x': e['flip_x']} for e in entries[1:]]
    assert relative == [{'x': x, 'y': y, 'flip_x': bool(i % 2)} for i, (x, y) in enumerate([(-8,14),(8,14),(-8,24),(8,24),(-8,34),(8,34)])]
    definition = json.loads((project / 'Source/data/viridianSlice/ViridianPokecenter.json').read_text())
    grids = {g['id']: g['grid'] for g in definition['grids']}
    def cell(x, y):
        return grids[definition['tile_ids'][y//16][x//16]][y % 16][x % 16]
    nurse = next(e for e in definition['events']['objects'] if e['sprite'] == 'SPRITE_NURSE')
    candidates = []
    # Exact6x3 cavity/highlight signature, only to the left of this source nurse.
    signature = ('......', '.11111', '.1....')
    for y in range(nurse['y']*16):
        for x in range(nurse['x']*16-6):
            if tuple(''.join(cell(x+dx,y+dy) for dx in range(6)) for dy in range(3)) == signature:
                candidates.append((x,y))
    assert candidates == [(29,6)], ('machine cavity changed/ambiguous', candidates)
    anchor = {'x': (29-1)*2, 'y': (6-2)*2}
    image = Image.open(reference / 'gfx/overworld/heal_machine.png').convert('L')
    assert image.size == (8,16)
    mapping = {255:'.',170:'1',85:'2',0:'#'}
    rows = [''.join(mapping[image.getpixel((x,y))] for x in range(8)) for y in range(16)]
    event = json.loads((project / 'Source/data/event-art.json').read_text())
    assert event['heal_machine']['grid'] == rows, 'protected raw source grid changed'
    def mask(first, flip):
        return [[rows[first+y][7-x if flip else x] != '.' for x in range(8)] for y in range(8)]
    return {'ok':True,'revision':REVISION,'monitor_anchor_native':anchor,
            'anchor_evidence':'unique source monitor6x3 cavity left of actual nurse; native overlay review still required',
            'oam_relative_native':relative,'raw_grid_equal':True,
            'monitor_mask_logical':mask(0,False),'ball_mask_logical':mask(8,False),'ball_mask_flipped_logical':mask(8,True),
            'palette':{'base_hex':'e0','xor_hex':'28','alternate_hex':'c8','e0_indices':[0,0,2,3],'c8_indices':[0,2,0,3],'index0':'transparent regardless of palette'},
            'timing':{'native_hz':30,'source_hz':60,'per_ball_native_frames':15,'flash_toggles':8,'per_toggle_native_frames':5,'post_music_wait_native_frames':16},
            'limitations':['current visibility flash is not original palette flashing','absolute native composition awaits root inspection','source music fade/music duration not simulated by this visual-only proof']}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',type=Path,required=True)
    parser.add_argument('--reference-root',type=Path,required=True)
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    result=check(args.project.resolve(),args.reference_root.resolve())
    text=json.dumps(result,indent=2)+'\n'
    if args.report:
        if args.report.exists():parser.error('refusing to overwrite source proof')
        args.report.write_text(text)
    print(text,end='')
if __name__=='__main__':main()

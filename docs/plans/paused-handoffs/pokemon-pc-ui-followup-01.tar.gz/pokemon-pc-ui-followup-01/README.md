# SDK01 followup — original packet/evidence preserved

This separate candidate fixes14 actual SDK setup/layout failures without weakening SessionCodec. `sdk01-followup.patch` modifies only pcState/pcContracts relative to the frozen original packet; `pc-ui.patch` remains a complete current-base six-file integration candidate. Context/Storage/GameSaves/terminal source bytes are unchanged from that original packet. The original sdk01 evidence and /private/tmp/pokemon-pc-ui remain intact.

Contract setup now has a valid completed Charmander/Squirtle intro tuple. Every boxed Pokemon is recruited through GameSession (seen/owned flags) then deposited through existing storage if recruited into party. No direct Storage.receive bypasses session dex bookkeeping. The UI uses the exact existing production battle font Asheville-Sans-14-Bold, with actual SDK getTextSize/getHeight metrics written to private `pc-font-metrics-SESSION.json`. Details compact metadata to3 rows; four move rows are placed from measured font height to end at footer188. BOX rows50+22step place bottom row160. Exact native glyph/PP and bottom-row checks remain; no assertion removed.

# Staged PC storage overlay

Refrozen before root SDK: non-table outsider guard plus actual fourth-move/PP and bottom box-row clipping fixes. Six owned Lua files are frozen in `bridge-manifest.json`; `pc-ui.patch` is the exact current-base patch. No live Source, Simulator or Data writes were performed by worker. Followup compile02 passed against current dependencies. This is a candidate requiring root SDK/native acceptance.

```sh
python3 /private/tmp/pokemon-pc-ui-followup-01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-pc-build-UNIQUE
# Root only: append --execute for16SDK groups,5native rendered panels.
# Root actual two-process UI proof:
python3 /private/tmp/pokemon-pc-ui-followup-01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-pc-native-UNIQUE --scenario /private/tmp/pokemon-pc-ui-followup-01/pc-restart-scenario.json --execute
```

The helper overlays only manifest files after exact original/candidate hashes match, imports/registers PCState/PCTerminals/PCContracts privately, adds the PC snapshot and inserts the direct terminal hook into the private current KantoWorld interaction seam. Root owns the eventual live main/diagnostic/provider merge. Its source/build manifests retain exact compiled identities and standard owner locks. Default remains compile-only.

Interfaces: `PCState(game):enter({terminal_id,onComplete})`, `handleButton`, `getSnapshot`; `PCTerminals.query(position)` is a pure defensive lookup, `tryInteract(game)` directly pushes PC only over settled base exploration. Source terminals are hidden index2 at(13,3), player(13,4) facingup, stable IDs `pokered:VIRIDIAN_POKECENTER:hidden:2` / Pewter equivalent. Root provider worker will invoke this before Event dispatch; Pewter runtime proof waits for that provider/map integration. No EventState parent is permitted.

Menu top uses SOMEONE'S PC/BILL'S PC based on EVENT_MET_BILL; RED/Oak entries explicitly say unavailable. Oak entry appears only after Pokédex. Storage menu order is WITHDRAW/DEPOSIT/RELEASE/CHANGE BOX/SEE YA. Lists scroll20 box mons; details preserve caller graphics state. RELEASE is boxed-only, defaultNO, explicit YES, and `Storage:release(index,expectedMon)` clears ownership exactly once after identity/index checks. Transfers reuse existing actual owners and lastmember/lastusable/fullparty/fullbox rules. All HP/status/sleep/PP/XP/move choices/evolution fields stay on the same actual Pokemon object; no automatic box healing. Source pins and exact hashes are in `source-references.json`.

`GameContext:isPCSaveBoundary(pc,epoch)` requires registered actual PCState identity, active captured epoch/same session, exact stack registeredoverworld+pc, settled explore/Player and no movement/jump/pendingconnection/step. `captureSessionFromPC` shares traversal encoding only after that boundary; ordinary captureSession retains its existing base-overworld guard semantics. Root serial-merges only that context hunk, preserving provider rollback/progression additions from other workers.

`GameSaves:changeBoxFromPC(pc,index,epoch)` validates pure readiness and index before mutation, selects the box, captures and synchronously saves using existing two-slot Store. It has no callbacks. Any returned failure/raised error restores prior active box and traversal using the same session/Inventory/Party/Storage objects. Guarded UI callbacks reject stale generations and display success only on actual true return. Transfers/releases persist only when a later manual/box save succeeds, matching source session behavior.

Important existing Store ambiguity is preserved: rename can succeed before acknowledgment or verification fails. A failed save restores live selection but a new published slot or candidate may exist. UI says **Save not confirmed. BOX selection restored.** It does not claim disk unchanged, automatically retry, delete evidence or recover. SDK contract proves this distinction with a real rename followed by controlled failure.

16SDK groups cover pure source queries, flags/unavailable services, actual same-object transfer withpartialHP/sleep/0PP, fullbox/fullparty/lastmember/lastusable atomicity, releaseNO/YES/stale/ownership, exit/reentry/callback cancellation, fakePC/foreign/staleepoch/depth3/Eventparent/pendingmovement rejection, native list/details/12boxes/release drawing, a real4-move mon with exact framebuffer glyph/PP comparisons and text bounds below footer, bottom BOX12 glyph comparison, all12 realSDK box saves, returned/raised failures with exact aggregate+owners/RNG unchanged, pendingcandidate and postrename ambiguity, independent decode without healing. Isolated prefixes are unique HarnessBuild session identifiers; save artifacts are retained.

Native panels: `pc-ui-full-box.png`, `pc-ui-detail.png`, `pc-ui-storage-menu.png`, `pc-ui-twelve-boxes.png`, `pc-ui-release-no.png`. The supplied two-process scenario uses an explicit two-mon settled Center fixture, real menu input to deposit Charmander, box2 autosave, owned PID restart, Continue (no reset), verifies Squirtle remains active/box2 retained, then saves box1 and withdraws the original serialized Charmander. Root must inspect panels/save text, distinct PIDs, durable hashes and semantic assertions; worker has not executed or accepted them.

Primary source anchors at the pinned revision: BillsPCDeposit/Withdraw/Release and menu in `engine/pokemon/bills_pc.asm`; `_MoveMon` in `engine/pokemon/add_mon.asm` copies BOXMON including HP/status/PP and only recalculates derived party stats; ChangeBox in `engine/menus/save.asm` confirms then saves; hidden-event facing guard in `engine/events/hidden_events/pokecenter_pc.asm`. Source prose is combined into native-width lines with POKEMON token expansion. Lastusable protection, defaultNO release/box confirmation and honest failed-save reporting are deliberate safety adaptations. Unsupported player-item/Oak/League/link effects are not invented.

Separate pending presentation work: root reviewed functional healing/source assets but flagged the small floating monitor/ball popup composition. After this PC candidate proof, inspect original healing OAM/map placement and propose an in-world machine animation. No EventState change is included here; full visual completion is not claimed.

SDK01 cleanup followup: each case records preexisting sprite identities/visibility/update flags; after success/failure it exits temporary states, removes every new sprite (including Player overlays/arrows), restores original flags and zone, and asserts global RNG data/active owner plus Story context owner unchanged. Private store files remain retained. No production cleanup workaround.

## Required native export followup

Root's completed first SDK evidence remains untouched. Passing SDK assertions did not establish image publication: the helper incorrectly appended `frames/` to HarnessBuild.output_dir, which already ends in `frames/`. The export now appends only the filename. No SDKwriteToFile boolean return is assumed.

Default validator scenario explicitly lists all 5 required native PNGs in `outputs`; absent/invalid PNG fails the ordinary host runner before success. `required-outputs.json` is the exact inventory. `export-path-followup.patch` changes only the narrow Source helper relative to the prior candidate; full patch/manifest hashes and explicit refreeze reason are updated. No placeholder/substitute images or directories were manufactured. Compile passed at `/private/tmp/pokemon-pc-ui-followup-01-compile-03`.

`python3 /private/tmp/pokemon-pc-ui-followup-01/qualify_exports.py --project "$PWD"` validates scenario inventory/path wiring and proves the real runner rejects every absent output, without generating replacement images. The optional `--native-sample` accepts a completed genuine native400x240 PNG for the existing validator's positive branch. Actual new exports still require root execution/visual inspection.

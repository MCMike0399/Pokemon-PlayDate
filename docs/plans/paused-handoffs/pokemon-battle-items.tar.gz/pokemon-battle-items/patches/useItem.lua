
-- Successful medicine replaces the player's action, then resolves one enemy
-- action and the normal residual boundary. Invalid commands are entirely inert.
function Battle:useItem(id,partyIndex,moveSlot)
    if self.outcome or not self:isAwaitingCommand() or self:needsForcedSwitch() then return false,"wrong-phase" end
    if self.selectionKind and self.selectionKind~="bag" then return false,"selection-open" end
    if not self.session or not self.party then return false,"bag-unavailable" end
    if GameSession.activeRNGSession()~=self.session or self.session:party()~=self.party
        or self.party:active()~=self.player then return false,"stale-session" end
    if not self.player:isAlive() or not self.enemy:isAlive() then return false,"fainted" end
    if self.conditions:locked(self.player) then return false,"locked-move" end
    local item=type(id)=="string" and ItemData.definitions[id] or nil
    local legal={heal=true,fullRestore=true,cure=true,revive=true,pp=true}
    if not item or not legal[item.effect] then return false,"unsupported-item-use" end
    partyIndex=type(partyIndex)=="number" and math.tointeger(partyIndex) or nil
    if not partyIndex then return false,"invalid-index" end
    local target,problem=self.party:get(partyIndex)
    if not target then return false,problem end
    if Party._owner(target)~=self.party then return false,"stale-target" end
    local ok,result=Items.use(self.session:inventory(),id,target,moveSlot)
    if not ok then return false,result end
    self.selectionKind=nil
    self:clearHitPresentation()
    self:runScript(function()
        self:say("RED used "..item.name.." on "..target.name.."!")
        local outcome=self:resolveTurn(self:enemyTurn())
        if outcome and outcome~="replacement" then return outcome end
        return self:finishRound()
    end)
    return true,result
end

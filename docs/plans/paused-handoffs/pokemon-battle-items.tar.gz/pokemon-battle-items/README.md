# Battle medicine candidate — staged only

Base clean checkout b114145. No live Source, Simulator, SDK Data or protected art changes. Proposal was approved by root. `validate_staged.py` composes narrow medicine changes onto CURRENT Source; compile-only is default. Root must execute and review integrated SDK/native evidence before acceptance.

```sh
python3 /private/tmp/pokemon-battle-items/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-battle-items-build-UNIQUE
# Root owner only, actual SDK contracts:
python3 /private/tmp/pokemon-battle-items/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-battle-items-sdk-UNIQUE --execute
# Root owner only, five real-input medicine cases and eight required captures:
python3 /private/tmp/pokemon-battle-items/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-battle-items-native-UNIQUE --execute --journey
```

Owned behavior is one appended `Battle:useItem(id,partyIndex,moveSlot)` plus narrow Bag selection hooks. BattleState controller migration belongs to root; its separate three-anchor patch is provided for serial merge with learning/trainer handlers. No full-file overwriting of those workers' candidates is required.

`Battle:useItem` checks command phase, selection lock, conscious active battlers, authoritative active session/RNG owner, actual party/active-mon identity and target ownership. It accepts only existing Items heal/fullRestore/cure/revive/pp effects. Stones/balls/unsupported items cannot enter medicine use. It delegates the synchronous preflight/commit to production `Items.use`; no reimplementation of healing, cure or PP rules. Failure leaves selection, owners, payload and RNG unchanged. Success consumes one item and clears selection, yields the item message, resolves exactly one enemy action, then the existing residual/faint/replacement boundary. It does not add a player attack or PP cost. Blocked/sleeping enemy behavior remains the actual normal enemy action; one response does not promise damage.

Battle Bag receives the root controller's captured `battle` and guarded `trySelect`. It pushes Party with copied roster identities. Single-move PP items then show the current selected mon's actual moves; callback captures mon/index/move identity and visit/session/battle/controller capability. Stale roster/move/session/controller callbacks fail before commit. Valid use pops back to battle and normal script messages. Invalid/no-effect use displays a message and remains in bag. Party B and Ether move B return to bag list; bag B cancels the selection and returns to command without a turn. Forced replacement cannot open/use bag. Menus preserve the existing BattleState pause policy. Field evolution hooks remain byte-preserved as the base; no in-battle evolution or held-item Give/Take UI is introduced.

Integration artifacts:

- `patches/useItem.lua` / `battle-useItem.patch`: append-only domain method, safe to compose with the learning worker's BattleScript changes.
- `patches/bag-medicine-relative-to-evolution.patch`: only medicine changes relative to the exact frozen Evolution Bag. `bases/bagState-evolution.lua` is that verified small base (rules worker confirmed no newer Bag file); prerequisite patch is included for a current live bag without the evolution hook.
- `patches/battleState-owner-hook.patch`: root callback accepts optional partyIndex/moveSlot, dispatches useItem for medicine, retains throwBall when no target is supplied, and injects captured battle into Bag options. Preserve learning polls and trainer finish methods.
- `Source/dev/battleItemContracts.lua`: import and `Contracts.register("battle-items", BattleItemContracts.run)` in root main after dependencies.
- Full staged Source files are review/compile candidates, not instructions to copy old Battle/BattleState files over other workers' work.

The validator appends the method to current Battle, edits only the three BattleState callback anchors, and accepts Bag only if its full hash equals the known live or frozen Evolution base. Unknown changes fail for an explicit serial merge. It hashes staged bytes/bases, writes exact source/build manifests and uses ordinary global/private locks. Its temporary generated scenario never modifies the repository. Existing saves and root live Source remain untouched.

Nine actual SDK groups cover Potion plus one poison residual, exactly one enemy Splash PP use and no player attack; existing status/fullrestore/revive/maxrevive/single/all PP medicines; no-item/no-effect/invalid targets/moves/stones atomicity; wrong phase/forced replacement/inactive-session rejection; paused Party/move previews and cancellation; bench Revive + exact second PP move through actual controller; stale roster/move/reentry/session/scene callback rejection; unchanged capture capability. Failed-command snapshots include exact session/party/inventory/active/enemy object identities, encoded domain records, selection/phase/message/conditions and RNG. No SDK mocks or parser substitutions.

SDK setup uses valid completed intro and authoritative session recruitment, then real BattleState/BattleScene/BagState/PartyState. Test cleanup exits temporary controllers, restores original sprite instances/visibility/update flags (BattleState legitimately removes the sprite list), restores RNG owner/data/Story/zone, and retains no private disk fixtures. Rule tests advance actual production coroutine receipts under a bounded helper; real input is tested separately.

`journey.py` uses explicit party/item/battle fixtures and real presses/state assertions for: damaged-active Potion success; full-HP Potion no-effect; fainted-bench Revive; Ether selecting Growl rather than Scratch; move/party/bag cancellation. Each successful use must consume one item and one enemy Splash PP. No-effect/cancel compares party, bag and RNG unchanged and enemy PP40. Native cases use Magikarp5 and never force outcomes. They do not claim natural Brock completion. Eight required captures: medicine-potion-bag/used/enemy-response, medicine-no-effect, medicine-bench-revived, medicine-ether-move-menu/used, medicine-cancel-no-turn. Missing/invalid images fail the ordinary runner.

Existing ItemData/Items and battle response/residual code are the authority; no prices/effects/species/art are redefined. Future Gen V specimen attributes, choices and evolution state remain on the same objects; this patch neither guesses new save fields nor adds attribute placeholders. Full ability/held-item/nature integration remains another bounded task.

#!/usr/bin/env python3
"""Compose narrow medicine hunks on CURRENT Source. Compile-only unless root --execute."""
import argparse,hashlib,importlib.util,json,shutil,subprocess,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--project',required=True);parser.add_argument('--output',required=True)
parser.add_argument('--sdk');parser.add_argument('--execute',action='store_true');parser.add_argument('--journey',action='store_true')
args=parser.parse_args();project=Path(args.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness,journeys
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'bridge-manifest.json').read_text());entries={row['path']:row for row in manifest['files']}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def replace(text,before,after):
    if text.count(before)!=1:raise ValueError('medicine integration anchor changed: '+before[:80])
    return text.replace(before,after,1)
original_prepare,original_journey=harness.prepare,journeys.run

def prepare(project,sdk,output,session):
    for row in manifest['files']:assert sha(stage/row['path'])==row['sha256'],'staged candidate changed'
    assert sha(stage/'patches/useItem.lua')==manifest['composition']['useItem_sha256']
    assert sha(stage/'bases/bagState-evolution.lua')==manifest['composition']['evolution_bag_sha256']
    metadata=original_prepare(project,sdk,output,session)
    battle=output/'Source/battle/battle.lua';text=battle.read_text()
    assert 'function Battle:useItem(' not in text,'medicine method already present; review instead of overwrite'
    battle.write_text(text+(stage/'patches/useItem.lua').read_text())
    bag=output/'Source/game/bagState.lua'
    assert sha(bag) in (entries['Source/game/bagState.lua']['original_sha256'],manifest['composition']['evolution_bag_sha256']),'current Bag differs from known live/frozen Evolution bases; serial merge required'
    shutil.copyfile(stage/'Source/game/bagState.lua',bag)
    state=output/'Source/game/battleState.lua';text=state.read_text()
    text=replace(text,'local function select(value)\n','local function select(value,partyIndex,moveSlot)\n')
    text=replace(text,'else ok, reason = battle:throwBall(value) end','elseif partyIndex~=nil then ok, reason = battle:useItem(value,partyIndex,moveSlot)\n        else ok, reason = battle:throwBall(value) end')
    text=replace(text,'{prompt = "Choose a POKEMON!", allowCancel = not request.forced, trySelect = select, tryCancel = cancel}','{prompt = "Choose a POKEMON!", allowCancel = not request.forced, trySelect = select, tryCancel = cancel, battle = battle}')
    state.write_text(text)
    target=output/'Source/dev/battleItemContracts.lua';assert not target.exists(),'contract already integrated';shutil.copyfile(stage/'Source/dev/battleItemContracts.lua',target)
    main=output/'Source/main.lua';text=main.read_text();marker='import "dev/catalog"'
    text=replace(text,marker,'import "dev/battleItemContracts"\nContracts.register("battle-items", BattleItemContracts.run)\n'+marker);main.write_text(text)
    pdx=output/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(p.relative_to(output/'Source')):sha(p) for p in sorted((output/'Source').rglob('*')) if p.is_file() and p.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    pdx.write_text(generated);values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        value=metadata[key];values.append('    '+key+' = '+('true' if value is True else json.dumps(value,ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['battle_items']=manifest
    with (output/'battle-items-build.log').open('w') as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata

spec=importlib.util.spec_from_file_location('battle_items_journey',stage/'journey.py');job=importlib.util.module_from_spec(spec);spec.loader.exec_module(job)
harness.prepare=prepare;harness.PROJECT=project
journeys.run=lambda client,scenario,evidence:job.run(client,scenario,evidence) if scenario.get('journey',{}).get('name')=='battle-medicine' else original_journey(client,scenario,evidence)
scenario={'commands':['contracts','shot battle-medicine-contracts'],'outputs':['battle-medicine-contracts.png']}
if args.journey:
    scenario={'journey':{'name':'battle-medicine'},'outputs':[name+'.png' for name in ('medicine-potion-bag','medicine-potion-used','medicine-potion-enemy-response','medicine-no-effect','medicine-bench-revived','medicine-ether-move-menu','medicine-ether-used','medicine-cancel-no-turn')]}
try:
    with tempfile.TemporaryDirectory(prefix='battle-medicine-scenario-') as temporary:
        path=Path(temporary)/'scenario.json';atomic_json(path,scenario)
        result=harness.run(SimpleNamespace(sdk=args.sdk,output=args.output,scenario=str(path),commands=[],build_only=not args.execute,timeout=60,ready_timeout=20,max_frames=1800))
finally:harness.prepare=original_prepare;journeys.run=original_journey
raise SystemExit(result)

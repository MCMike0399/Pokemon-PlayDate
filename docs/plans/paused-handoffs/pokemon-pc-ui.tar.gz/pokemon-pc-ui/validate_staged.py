#!/usr/bin/env python3
"""Root-owner PC UI overlay validator. Compile-only unless --execute."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--project', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('--sdk')
parser.add_argument('--scenario', help='Optional root-owned native/restart recipe')
parser.add_argument('--execute', action='store_true', help='Root Simulator owner only')
args = parser.parse_args()
project = Path(args.project).resolve()
stage = Path(__file__).resolve().parent
sys.path.insert(0, str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json

manifest = json.loads((stage / 'bridge-manifest.json').read_text())
original_prepare = harness.prepare


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(project, sdk, output, session):
    # Current unowned Source is always used. Never copy an old staged tree over
    # growth/codec/world/main/Story or any other worker's production work.
    for item in [entry for entry in manifest['files'] if entry['path'].startswith('Source/')]:
        relative = Path(item['path'])
        assert relative.parts[0] == 'Source' and '..' not in relative.parts
        staged = stage / relative
        assert digest(staged) == item['sha256'], 'staged owned file changed after manifest'
        live = project / relative
        if live.exists():
            assert digest(live) in (item.get('original_sha256'), item['sha256']), 'live owned file changed since handoff'
        else:
            assert item['operation'] == 'add', 'owned modified file missing from current source'
    metadata = original_prepare(project, sdk, output, session)
    for item in [entry for entry in manifest['files'] if entry['path'].startswith('Source/')]:
        relative = Path(item['path'])
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(stage / relative, destination)
    main = output / 'Source/main.lua'
    text = main.read_text()
    additions = []
    for module in ('game/pcState','world/pcTerminals','dev/pcContracts'):
        if f'import "{module}"' not in text:
            additions.append(f'import "{module}"')
    registration = 'Contracts.register("pc-ui", PCContracts.run)'
    if registration not in text:
        additions.append(registration)
    marker = 'import "dev/catalog"'
    assert marker in text, 'expected current harness import seam'
    text = text.replace(marker, '\n'.join(additions + [marker]), 1)
    shop_registration = 'machine:register("pc", PCState(game))'
    if shop_registration not in text:
        marker_registration = 'machine:register("learning", LearningState(game))'
        assert marker_registration in text
        text = text.replace(marker_registration, marker_registration + '\n' + shop_registration, 1)
    main.write_text(text)
    # Native proof only: root owns the eventual live dispatch/diagnostic merge.
    interaction = output / 'Source/game/kantoWorld.lua'
    code = interaction.read_text()
    hook = '    if PCTerminals.tryInteract(game) then return true end\n'
    anchor = 'function KantoWorld.tryInteract(game)\n'
    if hook not in code:
        assert code.count(anchor) == 1, 'changed PC interaction seam'
        interaction.write_text(code.replace(anchor, anchor + hook, 1))
    diagnostics = output / 'Source/dev/diagnostics.lua'
    code = diagnostics.read_text()
    anchor = '        display = HarnessCapture.display(),'
    assert code.count(anchor) == 1
    code = code.replace(anchor, '        pc = game.machine:get("pc"):getSnapshot(),\n' + anchor, 1)
    diagnostics.write_text(code)

    pdxinfo = output / 'Source/pdxinfo'
    generated_pdxinfo = pdxinfo.read_text()
    pdxinfo.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256'] = harness.fingerprint(output)
    metadata['build_id'] = metadata['revision'] + ':' + metadata['source_sha256']
    source_manifest = {str(path.relative_to(output / 'Source')): digest(path)
                       for path in sorted((output / 'Source').rglob('*')) if path.is_file()
                       and path.relative_to(output / 'Source').as_posix() != 'dev/harness_build.lua'}
    atomic_json(output / 'source-manifest.json', source_manifest)
    pdxinfo.write_text(generated_pdxinfo)
    values = []
    for key in ('protocol', 'session_id', 'build_id', 'output_dir', 'bundle_id', 'sdk_version', 'enabled', 'data_dir'):
        value = metadata[key]
        values.append(f'    {key} = ' + ('true' if value is True else json.dumps(value, ensure_ascii=False)) + ',')
    (output / 'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n' + '\n'.join(values) + '\n}\n')
    metadata['compiled_source_sha256'] = harness.fingerprint(output, exclude_generated=False)
    metadata['pc_ui'] = {'base_revision': manifest['base_revision'], 'owned_files': manifest['files']}
    with (output / 'pc-build.log').open('w') as log:
        subprocess.run([str(sdk / 'bin/pdc'), str(output / 'Source'), metadata['bundle']], stdout=log, stderr=subprocess.STDOUT, check=True)
    atomic_json(output / 'build.json', metadata)
    return metadata


harness.prepare = prepare
harness.PROJECT = project
scenario = Path(args.scenario).resolve() if args.scenario else stage / 'pc-contract-scenario.json'
if not args.scenario:
    atomic_json(scenario, {'commands': ['contracts', 'shot pc-ui-contracts'], 'outputs': []})
try:
    result = harness.run(SimpleNamespace(sdk=args.sdk, output=args.output, scenario=str(scenario), commands=[],
                                         build_only=not args.execute, timeout=60, ready_timeout=20, max_frames=1800))
finally:
    harness.prepare = original_prepare
raise SystemExit(result)

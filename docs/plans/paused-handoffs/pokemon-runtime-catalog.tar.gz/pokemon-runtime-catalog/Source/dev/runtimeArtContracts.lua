RuntimeArtContracts={}
function RuntimeArtContracts.run()
    local tests={};local function test(name,fn)local ok,error=pcall(fn);tests[#tests+1]={name=name,ok=ok,error=not ok and tostring(error)or nil}end
    test("Comprehensive runtime art inventory includes all50 explicit unreviewed variants",function()
        local paths={};for _,item in ipairs(VisualCatalog.additionInventory().images)do paths[item.path]=true end
        local count=0;for name in pairs(CaptureAnimationData.assets)do
            for _,suffix in ipairs({"","__mask","__white","__black","__texture"})do assert(paths["capture_"..name..suffix..".png"]);count=count+1 end
        end
        for _,suffix in ipairs({"","__mask","__white","__black","__texture"})do assert(paths["jump_shadow"..suffix..".png"]);count=count+1 end
        assert(count==50)
    end)
    test("Actual Player jump uses the exact shared catalog shadow object",function()
        local old=currentZone;currentZone=assert(zoneRegistry.kanto_route1)
        local player=Player(4,4,currentZone.collision,NPCManager());player:setUpdatesEnabled(false)
        local ok,error=pcall(function()player:tryMove(0,1);assert(player.isJumping);assert(player.jumpShadow:getImage()==Player.getJumpShadowImage())end)
        player:remove();player.grassOverlay:remove();player.exitArrow:remove();currentZone=old;assert(ok,error)
    end)
    local passed=0;for _,row in ipairs(tests)do if row.ok then passed=passed+1 end end
    return {ok=passed==#tests,passed=passed,failed=#tests-passed,tests=tests}
end

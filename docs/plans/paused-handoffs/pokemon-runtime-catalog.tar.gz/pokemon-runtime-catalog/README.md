# Capture animation + actual jump-shadow catalog (separate staged patch)

`runtime-catalog.patch` starts from CURRENT live `dev/catalog.lua` and `world/player.lua`. It adds no image pixels or Source PNG changes. The only Player seam extracts its existing lazy shadow creation into `Player.getJumpShadowImage()`, and the actual jump uses that same cached object. Catalog export can therefore cover the real shadow before or after the first hop without substituting another renderer.

All9 current CaptureAnimationData PNGs and the actual jump shadow export raw image, SDK mask and white/black/texture composites: **50 additions**. Filenames are stable `capture_<declared asset name>` and `jump_shadow`, with source IDs/revision/path/phase policy in `runtime_art`. Existing915 and registered-map/event artifact names/render paths remain unchanged. From the existing1585 expected four-map+event inventory, this gives expected1635 only when all prior content is registered. Explicit staged inventory flags `--include-events --include-runtime-art` require720 added paths (670 prior +50), leaving the default635 behavior unchanged. Every new path remains unreviewed; no original baseline is regenerated.

Two SDK contracts check all50 variants and identity between the actual hopping Player's shadow image and the catalog getter. Compile passed at `/private/tmp/pokemon-runtime-catalog-compile-01`. Root-only validation:

```sh
python3 /private/tmp/pokemon-runtime-catalog/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-runtime-catalog-runtime-01 --execute
```

The helper overlays only the three Source manifest entries, privately registers the suite and uses the ordinary owned harness. No live Source, runtime or Data access occurred in worker preparation.

## Independent checks

The staged `tools/visual/runtime_art.py` uses the existing pinned `generate_capture_art.py` assembly/OAM source pipeline for all9 capture frames and portable `generate_jump_art.py` original seven-pin shadow pipeline. It independently computes exact native masks/backgrounds and checks all50 decoded RGBA images, including invisible RGB, dimensions, source metadata and standalone mask pixels. Any storage/loader discrepancy is reported as a failure with pixel count/region; it is not normalized or waived. Native motion/source-scene acceptance remains separate even if every pixel matches.

After integration, or using `PYTHONPATH=/private/tmp/pokemon-runtime-catalog:$PWD` with the staged script:

```sh
python tools/visual/runtime_art.py --reference-root PINNED_POKERED --catalog RUN_ROOT --report /private/tmp/runtime-art-source.json
python tools/visual/compare.py ORIGINAL_REVIEWED RUN_ROOT --protected-preservation --report /private/tmp/runtime-art-protected.json
```

The source report always lists all50 `added_unreviewed` paths and does not approve an extended baseline. Root must inspect capture throw/absorb/shake/breakout/poof frames and grounded shadow/motion, then freeze any extended reviewed catalog explicitly while retaining the original.

Two host tests passed with original pinned inputs: exact10-asset/50-variant inventory and valid fixture comparison followed by a controlled one-pixel standalone shadow-mask mutation that fails with exact count/bbox. No actual native artifact equality is claimed by the worker. Exact Source/host file hashes are in `bridge-manifest.json`.

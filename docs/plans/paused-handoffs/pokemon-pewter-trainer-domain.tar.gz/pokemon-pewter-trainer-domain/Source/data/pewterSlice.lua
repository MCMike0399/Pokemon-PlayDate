-- Eight reviewed source maps. Raw definitions are weakly cached, not eagerly
-- constructed/registered. Existing zoneRegistry remains the sole Zone owner.
PewterSlice={}
local REVISION <const> = "af519899719f0754965776faac0e836a3b906e6d"
local names={Route2=true,ViridianForestSouthGate=true,ViridianForest=true,ViridianForestNorthGate=true,PewterCity=true,PewterGym=true,PewterMart=true,PewterPokecenter=true}
local rawCache=setmetatable({},{__mode="v"})
local descriptors,trainerData,sprites,texts
local function copy(v) if type(v)~="table" then return v end;local out={};for k,x in pairs(v) do out[k]=copy(x) end;return out end
local function record(filename)
    local d=assert(json.decodeFile("data/pewterSlice/"..filename..".json"),"missing pinned Pewter source data")
    assert(d.schema==1 and d.source_revision==REVISION,"unverified Pewter source revision")
    return d
end
local function catalogue()
    if not descriptors then descriptors=record("descriptors").maps end
    return descriptors
end
function PewterSlice.names()
    local out={};for name in pairs(names) do out[#out+1]=name end;table.sort(out);return out
end
function PewterSlice.descriptor(name) assert(names[name],"map outside Pewter slice");return copy(assert(catalogue()[name])) end
function PewterSlice.definition(name)
    assert(names[name],"map outside Pewter slice")
    local d=rawCache[name]
    if not d then d=record(name);assert(d.name==name and d.id==catalogue()[name].id,"Pewter map identity mismatch");rawCache[name]=d end
    return copy(d)
end
function PewterSlice.trainers()
    if not trainerData then
        trainerData={}
        local display=record("trainerNames").names
        for _,d in ipairs(record("trainers").trainers) do
            assert(not trainerData[d.id] and type(d.payout)=="number" and d.payout>=0,"invalid source trainer identity")
            for _,mon in ipairs(d.party) do assert(pokemonData[mon.species] and mon.level>=1 and mon.level<=100,"unresolved trainer species") end
            d.name=assert(display[d.class_source],"unresolved original trainer name")
            trainerData[d.id]=d
        end
    end
    return copy(trainerData)
end
function PewterSlice.trainer(id) return PewterSlice.trainers()[id] end
function PewterSlice.sprite(source)
    if not sprites then sprites=record("sprites") end
    local binding=assert(sprites.mapping[source],"unresolved original Pewter sprite constant")
    return copy(assert(sprites.sprites[binding.name])),binding.name
end
function PewterSlice.text(label)
    if not texts then texts=record("dialogue").texts end
    return copy(assert(texts[label],"missing original Pewter text: "..tostring(label)))
end

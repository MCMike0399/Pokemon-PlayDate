-- Source-backed extensions only. Existing seven shared sprite mappings are
-- reused byte-for-byte; imported frames request explicit reviewed phase0.
PewterSprites={}
local names={super_nerd="pewterSuperNerd",gramps="pewterGramps",little_girl="pewterLittleGirl",cooltrainer_f="pewterCooltrainerF",gym_guide="pewterGymGuide",poke_ball="pewterPokeBall",fairy="pewterFairy"}
local shared={SPRITE_YOUNGSTER=true,SPRITE_GIRL=true,SPRITE_CLERK=true,SPRITE_COOLTRAINER_M=true,SPRITE_NURSE=true,SPRITE_GENTLEMAN=true,SPRITE_LINK_RECEPTIONIST=true}
local rendered={}
function PewterSprites.key(source)
    if shared[source] then return SliceSprites.key(source) end
    local _,name=PewterSlice.sprite(source)
    return assert(names[name],"unmapped original Pewter sprite")
end
function PewterSprites.frame(source,index)
    local strip=PewterSlice.sprite(source)
    assert(type(index)=="number" and index%1==0,"integer original frame required")
    return SpriteFactory.makeSprite(assert(strip.frames[tostring(index)],"missing original Pewter frame"),{0,0})
end
function PewterSprites.installFor(definition)
    assert(type(definition)=="table" and definition.source_revision=="af519899719f0754965776faac0e836a3b906e6d","verified source map required")
    local selected={}
    for _,event in ipairs(definition.events.objects) do
        local key=PewterSprites.key(event.sprite)
        if not shared[event.sprite] then
            assert(SpriteFactory.npc[key]==nil or SpriteFactory.npc[key]==rendered[key],"conflicting imported Pewter sprite key")
            selected[event.sprite]=key
        end
    end
    SliceSprites.install()
    for source,key in pairs(selected) do
        if not rendered[key] then
            local strip=PewterSlice.sprite(source);local images={}
            for direction,index in pairs(strip.standing) do images[direction]=PewterSprites.frame(source,index) end
            if images.left then images.right=SpriteFactory.flipped(images.left) end
            rendered[key]=images
        end
    end
    for _,key in pairs(selected) do SpriteFactory.npc[key]=rendered[key] end
end

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

parser=argparse.ArgumentParser();parser.add_argument('--project',type=Path,required=True);parser.add_argument('--build',type=Path,required=True);args,rest=parser.parse_known_args();sys.path.insert(0,str(args.project))
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
root=Path(__file__).parent;b=module('brock_candidate',root/'brock_journey.py');r=module('restart_candidate',root/'tools/harness/restarting.py')
from tools.harness.protocol import ProtocolError,OwnerLock,atomic_json

def move(index=1,key='tackle',power=50,pp=35,effectiveness=1,category='physical'):
 return dict(index=index,key=key,power=power,pp=pp,effectiveness=effectiveness,category=category,type='normal',accuracy=100,stab=1,attack=20,defense=20)

class PolicyTests(unittest.TestCase):
 def test_type_effectiveness_outweighs_raw_power(self):self.assertEqual(b.choose_move([move(),move(2,'bubble',20,effectiveness=4)])['key'],'bubble')
 def test_depleted_move_not_selected(self):self.assertEqual(b.choose_move([move(pp=0),move(2,'bubble',20)])['index'],2)
 def test_immune_move_not_selected(self):self.assertEqual(b.choose_move([move(effectiveness=0),move(2,'bubble',20)])['index'],2)
 def test_nonfinite_and_bool_fail(self):
  for value in [float('nan'),float('inf'),True]:
   with self.assertRaises(ProtocolError):b.choose_move([move(power=value)])
 def test_duplicate_indices_fail(self):
  with self.assertRaises(ProtocolError):b.choose_move([move(),move(key='bubble')])
 def test_learning_replaces_status(self):self.assertEqual(b.learn_decision(move(3,'bubble',20),[move(),move(2,'tailWhip',0,category='status')]),2)
 def test_learning_explicitly_retains_stronger_moves(self):self.assertIsNone(b.learn_decision(move(power=0,category='status'),[move(),move(2,'bubble',20)]))
 def test_boolean_flags_empty_only(self):
  self.assertEqual(b.boolean_map([],'flags'),{})
  for bad in [[True],{'flag':1},None]:
   with self.assertRaises(ProtocolError):b.boolean_map(bad,'flags')
 def test_natural_shortcuts_fail_before_client(self):
  j=b.BrockJourney(None,root,{'starter':'squirtle'})
  for command in [{'op':'fixture','options':{'seed':1}},'warp 1 1','seed 42','battle rattata 2','encounters off']:
   with self.assertRaises(ProtocolError):j.send(command)

class GeometryTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.models,cls.doors,cls.trainers=b.load_models(args.build)
 def journey(self,zone,x=0,y=0):
  j=b.BrockJourney(None,root,{'starter':'squirtle'},args.build);j.models=self.models;j.doors=self.doors;j.state={'zone_id':zone,'player':{'x':x,'y':y}};return j
 def test_eight_padded_source_maps(self):
  self.assertEqual(len(self.models),14);self.assertEqual(self.models[b.MAPS['PewterGym']].width,13);self.assertEqual(self.models[b.MAPS['PewterMart']].padding,2)
 def test_gate_projection_uses_source_door_foot(self):
  j=self.journey(b.MAPS['Route2']);event=j.model().events['warps'][1]
  self.assertEqual(j.warp_projection(event),(b.MAPS['ViridianForestNorthGate'],(6,1)))
  j=self.journey(b.MAPS['ViridianForestNorthGate']);self.assertEqual(j.warp_projection(j.model().events['warps'][1]),(b.MAPS['Route2'],(3,11)))
 def test_connection_offsets(self):
  j=self.journey(b.PARCEL_NAMES['ViridianCity'],18,0);self.assertEqual(j.project('up'),(b.MAPS['Route2'],(8,71)))
  j=self.journey(b.MAPS['Route2'],8,0);self.assertEqual(j.project('up'),(b.MAPS['PewterCity'],(18,35)))
 def test_unsupported_warp_does_not_project(self):
  j=self.journey(b.MAPS['Route2'])
  with self.assertRaises(ProtocolError):j.warp_projection(j.model().events['warps'][0])
 def test_ledge_occupancy_and_reverse(self):
  model=b.SourceGeometry('ledge',[[0,1,0]],feet=[[1,2,3]],rules=[{'facing':'SPRITE_FACING_RIGHT','standing_foot_tile':1,'target_foot_tile':2}])
  self.assertEqual(model.path((0,0),{(2,0)})[0].kind,'ledge')
  for occupied in [{(1,0)},{(2,0)}]:
   with self.assertRaises(ProtocolError):model.path((0,0),{(2,0)},occupied)
  self.assertIsNone(model.terrain_step((2,0),'left'))
 def test_all_five_source_trainer_approaches_reachable(self):
  for trainer in self.trainers:
   model=self.models[trainer['map_id']];event=next(e for e in model.events['objects']if e['id']==trainer['id'])
   start=(16,47)if trainer['map_id']==b.MAPS['ViridianForest']else(5,13)
   occupied={(e['x'],e['y'])for e in model.events['objects']}
   self.assertTrue(model.path(start,model.approaches((event['x'],event['y'])),occupied))

class RestartTests(unittest.TestCase):
 def scenario(self):return {'processes':[{'journey':{'name':'brock-natural'}},{'restart':True,'journey':{'name':'brock-continue'}}]}
 def test_known_journeys_accepted(self):r.validate(self.scenario())
 def test_unknown_top_level_field_rejected(self):
  value=self.scenario();value['hidden_callback']='bad'
  with self.assertRaises(ProtocolError):r.validate(value)
 def test_conflicts_unknown_fields_and_missing_predecessor(self):
  bad=[{'processes':[{'requests':[['snapshot']],'journey':{'name':'brock-natural'}},{'restart':True,'requests':[['snapshot']]}]}, {'processes':[{'journey':{'name':'arbitrary-import'}},{'restart':True,'journey':{'name':'brock-continue'}}]}, {'processes':[{'requests':[['snapshot']]},{'restart':True,'journey':{'name':'brock-continue'}}]}]
  for value in bad:
   with self.assertRaises(ProtocolError):r.validate(value)
  value=self.scenario();value['processes'][0]['journey']['teleport']=True
  with self.assertRaises(ProtocolError):r.validate(value)
 def test_receipt_requires_hash_build_and_regular_file(self):
  with tempfile.TemporaryDirectory()as tmp:
   path=Path(tmp)/'receipt.json';packet={'schema':1,'kind':'brock-saved','build_id':'build','session_id':'session','state':{}};atomic_json(path,packet);ref={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};meta={'build_id':'build','session_id':'session'}
   self.assertEqual(r.read_receipt(ref,meta),packet)
   with self.assertRaises(ProtocolError):r.read_receipt(ref,dict(meta,build_id='other'))
   path.write_text('{}')
   with self.assertRaises(ProtocolError):r.read_receipt(ref,meta)
   with self.assertRaises(ProtocolError):r.read_receipt(None,meta)
 def test_failed_journey_stops_owned_process_and_does_not_start_second(self):
  from tools.harness import journeys
  class Process:
   pid=987654321;returncode=None;terminated=False
   def poll(self):return self.returncode
   def terminate(self):self.terminated=True;self.returncode=0
   def wait(self,timeout):return self.returncode
  class Client:
   def __init__(self,*a,**kw):self.sequence=0;self._pending_id=None
   def ready(self,*a):return {'tick':1}
  with tempfile.TemporaryDirectory()as tmp:
   output=Path(tmp)/'output';output.mkdir();(output/'frames').mkdir();data=Path(tmp)/'data';data.mkdir();process=Process();metadata={'simulator':'not-executed','bundle':'not-executed','build_id':'build','session_id':'session'}
   runner=SimpleNamespace(finalize_captures=lambda *a:None,verify_request_outputs=lambda *a:None,verify_png=lambda *a:None)
   with OwnerLock(data/'owner.lock')as owner,patch.object(r.subprocess,'Popen',return_value=process)as launch,patch.object(r,'Client',Client),patch.object(journeys,'run',side_effect=ProtocolError('controlled failed journey')):
    code=r.run(SimpleNamespace(ready_timeout=1,timeout=1,max_frames=30),self.scenario(),metadata,output,data,owner,runner)
   self.assertEqual(code,1);self.assertTrue(process.terminated);self.assertEqual(launch.call_count,1);self.assertFalse(json.loads((output/'outcome.json').read_text())['ok']);self.assertTrue((output/'processes/0001/runtime-data').is_dir())


 def test_successful_journeys_share_build_owner_and_prior_receipt_without_save_copy(self):
  from tools.harness import journeys
  class Process:
   def __init__(self,pid):self.pid=pid;self.returncode=None
   def poll(self):return self.returncode
   def terminate(self):self.returncode=0
   def wait(self,timeout):return self.returncode
  class Client:
   def __init__(self,*a,**kw):self.sequence=0;self._pending_id=None
   def ready(self,*a):return {'tick':1}
  with tempfile.TemporaryDirectory()as tmp:
   output=Path(tmp)/'output';output.mkdir();(output/'frames').mkdir();data=Path(tmp)/'data';data.mkdir();(data/'private-save').write_text('unchanged')
   meta={'simulator':'not-executed','bundle':'not-executed','build_id':'build','session_id':'session'};calls=[]
   def journey(client,scenario,evidence,**options):
    self.assertEqual(options['build_evidence'],output);self.assertEqual(options['capture_dir'],output/'frames');self.assertNotEqual(evidence,output)
    if calls:self.assertEqual(options['prior_receipt']['state'],{'token':'actual prior receipt'})
    else:self.assertIsNone(options['prior_receipt'])
    calls.append(evidence);packet={'schema':1,'kind':'brock-saved','build_id':'build','session_id':'session','state':{'token':'actual prior receipt'}};path=evidence/'journey-receipt.json';atomic_json(path,packet)
    return {'ok':True,'receipt':{'path':'journey-receipt.json','sha256':hashlib.sha256(path.read_bytes()).hexdigest()}}
   runner=SimpleNamespace(finalize_captures=lambda *a:None,verify_request_outputs=lambda *a:None,verify_png=lambda *a:None)
   with OwnerLock(data/'owner.lock')as owner,patch.object(r.subprocess,'Popen',side_effect=[Process(900001),Process(900002)]),patch.object(r,'Client',Client),patch.object(journeys,'run',side_effect=journey):
    self.assertEqual(r.run(SimpleNamespace(ready_timeout=1,timeout=1,max_frames=30),self.scenario(),meta,output,data,owner,runner),0)
   self.assertEqual(len(calls),2);self.assertEqual((data/'private-save').read_text(),'unchanged')
   records=json.loads((output/'run.json').read_text())['processes'];self.assertEqual([x['status']for x in records],['exited','exited']);self.assertNotEqual(records[0]['pid'],records[1]['pid'])
 def test_success_without_receipt_is_failure_and_stops_owned_producer(self):
  from tools.harness import journeys
  class Process:
   pid=900003;returncode=None
   def poll(self):return self.returncode
   def terminate(self):self.returncode=0
   def wait(self,timeout):return self.returncode
  class Client:
   def __init__(self,*a,**kw):self.sequence=0;self._pending_id=None
   def ready(self,*a):return {'tick':1}
  with tempfile.TemporaryDirectory()as tmp:
   output=Path(tmp)/'output';output.mkdir();(output/'frames').mkdir();data=Path(tmp)/'data';data.mkdir();process=Process();meta={'simulator':'not-executed','bundle':'not-executed','build_id':'build','session_id':'session'}
   runner=SimpleNamespace(finalize_captures=lambda *a:None,verify_request_outputs=lambda *a:None,verify_png=lambda *a:None)
   with OwnerLock(data/'owner.lock')as owner,patch.object(r.subprocess,'Popen',return_value=process)as launch,patch.object(r,'Client',Client),patch.object(journeys,'run',return_value={'ok':True}):
    self.assertEqual(r.run(SimpleNamespace(ready_timeout=1,timeout=1,max_frames=30),self.scenario(),meta,output,data,owner,runner),1)
   self.assertEqual(process.returncode,0);self.assertEqual(launch.call_count,1)

if __name__=='__main__':unittest.main(argv=[__file__]+rest)

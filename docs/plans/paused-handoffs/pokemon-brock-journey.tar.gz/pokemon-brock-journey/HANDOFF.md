# Brock host journey candidate

Staged only; current parcel driver and live Source remain unchanged. This packet is executable host code and offline path evidence, **not a native passage report**. Root alone launches the Simulator and integrates shared files.

## Files and integration

- `brock_journey.py` → new `tools/harness/brock_journey.py`.
- `tools/harness/journeys.py` / `journeys.patch`: optional build-evidence/prior-receipt/capture-dir arguments and three explicit Brock dispatch names. Existing callers retain their three-argument interface. `Journey.frames_dir` defaults to its original evidence/frames directory.
- `tools/harness/restarting.py` / `restarting.patch`: process groups accept exactly one of requests or a known Brock natural/Continue journey. Strict fields, 2..8 groups, original uninterrupted global/private locks, PID lifecycle, durable-file checks and failure cleanup remain. The runner owns all process creation and termination.
- `Source/dev/diagnostics.lua` / `diagnostics.patch`: separate read-only observation patch. Actual available move indices, PP, type/category/power/accuracy, noncritical stage-adjusted attack/defense, burn reduction, STAB and TypeChart effectiveness; current Pokémon types; pending/current learning move descriptors; payout/money delta. No RNG draws, rule advancement or calls to damage calculation. `event.trainer` comes from the separately staged provider EventState.
- `scenarios/`: natural save, natural two-process Save/Continue, all five isolated source trainers, full-bag TM retry, real trainer blackout, and failed sight range.
- `offline-path-plan.json`: source-derived individual path legs and input directions, not native validation. All geometry is consumed from the exact identified build Source and source-manifest hashes, never a machine-global reference checkout.

Required gameplay integration: provider/trainer candidate03, midbattle learning before enemy2, current session/party/field Bag/shop/Center/save UI, and diagnostics above. Gen V abilities, held items and natures remain required user scope; this host code invents no attributes and reads actual production move/stats observations. It does not assume a future random specimen outcome.

## Natural route

Compose the passed parcel driver's new Squirtle game, actual intro/BLUE battle, parcel/Oak/Pokédex, shop/healing/save. The battle method is overridden throughout to choose from actual legal move descriptors rather than fixed move-index mashing. Continue by purchasing Antidotes from original Viridian stock, walking City→Route2→South Gate→Forest, collecting the source visible Potion, defeating the three actual Forest trainers, North Gate→Route2→Pewter, Center healing, real Potion purchase, Jr trainer, Brock, badge/TM, repeat interaction and save. Current HP/status/observed damaging PP determine field medicine or actual Center backtracking. No later teleport, inventory/HP/XP fixture, encounter disable, enemy adjustment or forced outcome is allowed.

The move heuristic uses power × accuracy × type effectiveness × STAB × observed offense/defense, with live PP/available indices. It neither rolls rules RNG nor predicts a guaranteed damage/outcome. Explicit LearningState choices replace a status/weak move when a stronger damaging move is offered; free-slot learning is acknowledged normally, including while the battle waits before enemy2. Unsupported/no-damaging-move states and real blackouts stop natural acceptance with evidence rather than masking failure. Optional evolution is explicitly declined for this bounded Squirtle recipe.

Navigation replans after every real step and actual NPC observation. Eight new maps use source collision/terrain/forbidden pairs/one-way ledges, including intermediate and landing occupancy. Generic source warps use the pinned door-foot auto-step rules and padded interior coordinates. Bottom interior exits require an outward press. Header offsets are City→Route2 −10 / Route2→City +10, and Route2→Pewter +10 / Pewter→Route2 −10; the passed Pallet ±1 seam is unchanged. Out-of-slice exits fail closed.

The natural Continue receipt contains player location/facing, quest/trainer flags, bag/money, party HP/PP/progression, and checkpoint. The next process reads only that host receipt (hash/build/session verified), uses actual title CONTINUE input and requires exact observed restoration plus no repeated Brock battle/payout. It never reads or copies gameplay save contents. The existing runner retains its own durable-file hashing across stopped processes.

## Test results and commands

22 new host tests passed in **0.029s**: move/PP/type heuristic, learning decisions, forbidden shortcuts, all five source trainer approaches, exact gate/header projections, ledge occupancy/reversal, strict process schema, immutable receipt rejection, same-owner two-process success, failed journey cleanup and missing receipt failure. Host process doubles are limited to the ownership protocol; no fake Playdate/game runtime is used.

```sh
python3 /private/tmp/pokemon-brock-journey/test_brock_host.py \
  --project /Users/burbujamc/Developer/Pokemon-PlayDate \
  --build /private/tmp/pokemon-pewter-candidate-build-05 -v
```

Existing journey/parcel/dialog/restart compatibility: **29 tests passed in 2.869s**, no skips, with `PARCEL_BUNDLE_SOURCE` set to the identified build and the two staged host modules injected. Diagnostics compiled successfully against candidate03 at `/private/tmp/pokemon-brock-diagnostics-build-01`. These are compile/host results only.

After root integration/review, single-process entry:

```sh
python3 tools/harness/run.py --scenario \
  /private/tmp/pokemon-brock-journey/scenarios/brock-natural.json \
  --output /private/tmp/pokemon-brock-natural-UNIQUE
```

True restart entry uses `scenarios/brock-restart.json` instead. Root must run and inspect the integrated source before accepting either.

## Supplementary cases and limits

Five source trainer cases begin with a clearly labeled initial Squirtle level30 fixture only, then use actual trainer dialogue/input/parties, real battle outcomes, exact source payouts/flags and repeat interaction. Full-bag Brock starts with 20 ordinary slots, wins the actual battle, requires badge/defeat but no TM eligibility consumption, frees one slot through real TOSS, and retries TM without another battle/payout. Blackout starts with an explicitly labeled level1/HP1 fixture and requires an actual source trainer defeat, half money and checkpoint return without rewards. Seeded input is not a forced outcome; a different actual result fails.

The failed-sight case uses an actual source position just outside the first Forest trainer's range and requires no battle/flag/money/RNG change. It does **not** claim occupied-intermediate approach coverage: no such static source arrangement exists for these five trainers. Native domain contracts exercise changed collision/occupancy; an input-driven hostile occupancy scenario would require an explicitly approved fixture surface or actual wandering system, neither invented here.

The packet does not prove full campaign completion, physical-device performance, every Gen V effect, TM teaching, random nontrainer wandering, or seamless original map scrolling. Runtime time/action/encounter bounds deliberately fail with normal harness evidence. Source expansion and all protected art remain untouched.

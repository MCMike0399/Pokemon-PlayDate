#!/usr/bin/env python3
"""Compare the isolated native export with independent pinned Python previews.

Every RGBA channel participates, including RGB beneath alpha=0. Actor composites
are validated for presence/dimensions, but need separate visual review.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
from PIL import Image


def changed_pixels(a,b):
    if a.size!=b.size: raise ValueError(f'image dimensions differ: {a.size} vs {b.size}')
    return sum(x!=y for x,y in zip(a.convert('RGBA').getdata(),b.convert('RGBA').getdata()))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--runtime-data',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
    sys.path.insert(0,str(a.project.resolve()));from tools import generate_kanto_maps as g
    from tools import generate_overworld_sprites as sprites
    source=json.loads((a.candidate/'source-manifest.json').read_text());catalog=json.loads((a.run/'catalog.json').read_text())
    if catalog.get('source_revision')!=source['source_revision']:raise ValueError('catalog source revision mismatch')
    image_root=Path(catalog.get('image_root','.'))
    if image_root.is_absolute()or'..'in image_root.parts:raise ValueError('invalid catalog image root')
    images=a.run/image_root;paths=set()
    for item in catalog['images']:
        path=Path(item['path'])
        if path.is_absolute()or'..'in path.parts or item['path']in paths:raise ValueError('invalid or duplicate manifest image')
        paths.add(item['path'])
        with Image.open(images/path)as image:
            image.load()
            if image.size!=(item['width'],item['height']):raise ValueError('invalid native image dimensions')
    if len(paths)!=292:raise ValueError('expected292 complete native images')
    checks=[]
    def compare(path,expected,kind):
        if path not in paths:raise ValueError('required image missing from native manifest: '+path)
        with Image.open(images/path)as actual:count=changed_pixels(actual,expected)
        checks.append({'path':path,'kind':kind,'changed_rgba_pixels':count})
    def preview(path):
        raw=(a.candidate/path).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=source['artifacts'][path]:raise ValueError('candidate preview checksum mismatch: '+path)
        image=Image.open(io.BytesIO(raw));image.load();return image.convert('RGBA')
    descriptors=json.loads((a.runtime_data/'descriptors.json').read_text())['maps']
    for name,d in descriptors.items():
        source_image=preview('catalog/'+name+'-native.png');expected=Image.new('RGBA',(d['width']*32,d['height']*32),'black');expected.paste(source_image,(d['padding']*32,0))
        compare('pewter-'+name+'-terrain.png',expected,'source-terrain-with-runtime-padding')
        definition=json.loads((a.candidate/'maps'/f'{name}.json').read_text())
        collision=Image.new('RGBA',expected.size,'black');pixels=collision.load()
        # Unsupported source warps remain blocked, as declared by the runtime
        # sidecar. This check tests explicit collision independently of art.
        compact=json.loads((a.runtime_data/'compact.json').read_text())['maps'][name]
        for y,row in enumerate(definition['collision']):
            for x,value in enumerate(row):
                rx=x+d['padding'];blocked=str(y*d['width']+rx+1)in compact['blocked']
                if not value and not blocked:
                    for py in range(y*32,(y+1)*32):
                        for px in range(rx*32,(rx+1)*32):pixels[px,py]=(255,255,255,255)
        compare('pewter-'+name+'-collision.png',collision,'source-collision-and-explicit-unimplemented-blockers')
    source_sprites=json.loads((a.candidate/'sprites.json').read_text())['sprites']
    for name,strip in source_sprites.items():
        for frame in strip['frames']:
            compare(f'pewter-sprite-{name}-{frame}.png',preview(f'catalog/sprite-{name}-{frame}-image.png'),'source-sprite')
            compare(f'pewter-mask-{name}-{frame}.png',preview(f'catalog/sprite-{name}-{frame}-mask.png'),'source-mask')
    grids=json.loads((a.runtime_data/'tile-grids.json').read_text())['tiles']
    native_tiles={entry['stable_key']:entry['path']for entry in catalog['tiles']}
    for key,tile in grids.items():
        image=Image.open(io.BytesIO(g.render_map({'dimensions':{'cells':[1,1]},'grids':[{'id':1,'grid':tile['grid']}],'tile_ids':[[1]]})))
        compare(native_tiles[key],image,'canonical-tile')
    emote=json.loads((a.runtime_data/'emote.json').read_text());grid=emote['grid']
    image=Image.open(io.BytesIO(g.render_map({'dimensions':{'cells':[1,1]},'grids':[{'id':1,'grid':grid}],'tile_ids':[[1]]}))).convert('RGBA')
    mask=Image.frombytes('L',(32,32),sprites.mask_bytes(grid));image.putalpha(mask)
    compare('pewter-exclamation.png',image,'source-shock');compare('pewter-exclamation-mask.png',mask,'source-shock-mask')
    report={'ok':all(x['changed_rgba_pixels']==0for x in checks),'native_image_count':len(paths),'exact_comparisons':len(checks),'checks':checks,'uncompared_actor_composites':8}
    a.report.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({key:value for key,value in report.items()if key!='checks'}));return 0if report['ok']else 1
if __name__=='__main__':raise SystemExit(main())

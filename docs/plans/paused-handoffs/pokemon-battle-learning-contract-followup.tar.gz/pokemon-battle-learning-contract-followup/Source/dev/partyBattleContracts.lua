-- Real SDK Battle/Party/Session/Capture integration contracts.
PartyBattleContracts={}
local function equal(actual,wanted,label)
    assert(actual==wanted,(label or "value") .. ": expected " .. tostring(wanted) .. ", got " .. tostring(actual))
end
local function sameRNG(a,b)
    for _,key in ipairs({"algorithm","seed","state","rolls"}) do equal(a[key],b[key],key) end
end
local function own(mon,keys,pp)
    mon.moves,mon.pp={},{}
    for i,key in ipairs(keys) do mon.moves[i]=key;mon.pp[key]=pp or moveData[key].maxPP end
end
-- Production receipt and LearningState, including explicit refusal if a set
-- is full. No test deletes a queue or resumes an unresolved script.
local function resolveLearning(b)
    local receipt,mon=b:takeLearningRequest();assert(receipt,"missing learning receipt")
    local machine=StateMachine();local game={machine=machine}
    machine:register("base",State("base"));local learning=LearningState(game);machine:register("learning",learning);machine:change("base")
    assert(LearningState.open(game,mon,function() assert(b:resumeLearning(receipt)) end))
    local count=0
    while machine:is("learning") do
        count=count+1;assert(count<100,"production learning did not settle")
        if learning.phase=="message" then assert(learning.dialog.onComplete)();learning:handleInput()
        elseif learning.phase=="ask" then learning.menu.onSelect(2)
        elseif learning.phase=="stop" then learning.menu.onSelect(1)
        else error("unexpected learning phase "..learning.phase) end
    end
end
local function settle(b)
    local messages,count={},0
    while b:phase()=="script" do
        count=count+1;assert(count<500,"battle script failed to settle")
        messages[#messages+1]=b.message
        if b:getLearningSnapshot().pending then resolveLearning(b)
        else b.machine:get("script"):advance() end
    end
    return table.concat(messages,"|")
end
local function roster(...)
    local p=Party();for _,mon in ipairs({...}) do assert(p:add(mon)) end;return p
end
local function sessionWithStarter()
    local session=GameSession.newSession({itemDefinitions=ItemData.definitions,validateWorld=WorldDeltas.validate,
        resolveLocation=WorldDeltas.resolveLocation},{location={zone_id="reds_house_2f",x=5,y=3,facing="up"},seed=42})
    local p=Pokemon("charmander",5);assert(session:recruit(p))
    assert(session:setIntro({stage="done",starter="charmander",rivalStarter="squirtle",rivalOutcome=false}))
    return session,p
end
local function fresh(p,e,party,session,enemyParty,trainer)
    local b=Battle(p,e,trainer,{party=party,session=session,enemyParty=enemyParty})
    settle(b);return b
end
function PartyBattleContracts.run()
    local report={ok=true,passed=0,failed=0,tests={}}
    local savedRNG=RulesRNG.snapshot()
    local function test(name,fn)
        local ok,problem=pcall(fn)
        report.tests[#report.tests+1]={name=name,ok=ok,error=not ok and tostring(problem) or nil}
        if ok then report.passed=report.passed+1 else report.failed=report.failed+1;report.ok=false end
    end
    test("Legacy three-argument battles retain single-mon commands and two-item menu",function()
        local b=Battle(Pokemon("charmander",5),Pokemon("squirtle",5));settle(b)
        local scene=BattleScene(b);scene:enter()
        equal(table.concat(scene.mainMenu.options,","),"FIGHT,RUN")
        equal(b:chooseParty(1),false);equal(b:throwBall("masterBall"),false)
        equal(b:isAwaitingCommand(),true)
    end)
    test("Voluntary switch spends turn and clears supported battle transients",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",5)
        p.status,p.hp,p.statStages.atk,p.confusion,p.flinched="burn",1,4,2,true
        bench.statStages.atk=5;own(e,{"growl"},3)
        local party=roster(p,bench);local b=fresh(p,e,party)
        local before=RulesRNG.snapshot().rolls
        equal(b:chooseParty(2),true);settle(b)
        equal(party:active(),bench);equal(b.player,bench);equal(p.hp,1);equal(p.status,"burn")
        equal(p.statStages.atk,0);equal(p.confusion,nil);equal(p.flinched,false)
        equal(bench.statStages.atk,-1,"incoming stages reset before enemy Growl")
        equal(e.pp.growl,2);equal(RulesRNG.snapshot().rolls,before+2,"enemy choice and accuracy only")
    end)
    test("Invalid switches leave roster phase PP and RNG unchanged",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",5)
        bench.hp=0;local party=roster(p,bench);local b=fresh(p,e,party)
        local before=RulesRNG.snapshot();local hp,pp=p.hp,p.pp.scratch
        for _,index in ipairs({0,3,1.5,"2",1,2}) do
            equal(b:chooseParty(index),false);equal(party:active(),p);equal(b.player,p)
            equal(b:phase(),"command");equal(p.hp,hp);equal(p.pp.scratch,pp);sameRNG(RulesRNG.snapshot(),before)
        end
        b:runScript(function() b:say("Waiting") end)
        equal(b:chooseParty(2),false);sameRNG(RulesRNG.snapshot(),before)
    end)
    test("Sleep duration resets to its original roll on withdrawal with no reroll",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",5)
        p.status,p.statusTurns,p.sleepDuration="sleep",0,3;own(e,{"growl"},4)
        local party=roster(p,bench);local b=fresh(p,e,party)
        local before=RulesRNG.snapshot().rolls
        equal(b:chooseParty(2),true);settle(b)
        equal(p.status,"sleep");equal(p.statusTurns,3);equal(p.sleepDuration,3)
        equal(RulesRNG.snapshot().rolls,before+2)
        equal(b:chooseParty(1),true);settle(b)
        equal(b.player,p);equal(p.statusTurns,3,"incoming sleep is not decremented by enemy's turn")
    end)
    test("Player faint waits for residuals then forces usable replacement without defeat",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",50)
        p.hp=1;p.spe=1;e.spe=1000;e.status="burn";own(p,{"growl"},4);own(e,{"dragonRage"},3)
        local party=roster(p,bench);local b=fresh(p,e,party);local originalEnemyHP=e.hp
        local ended=0;b:on("battleEnd",function() ended=ended+1 end)
        equal(b:selectMove(1),true);local text=settle(b)
        equal(p.hp,0);equal(p.pp.growl,4);equal(e.pp.dragonRage,2)
        equal(e.hp,originalEnemyHP-math.max(1,e.maxHP//8),"enemy residual before replacement request")
        assert(text:find("burn",1,true));equal(b:phase(),"forcedSwitch");equal(b.outcome,nil);equal(ended,0)
        equal(b:selectMove(1),false);equal(b:tryRun(),false);equal(b:throwBall("pokeBall"),false)
        local before=RulesRNG.snapshot();equal(b:chooseParty(2),true);settle(b)
        equal(party:active(),bench);equal(b.player,bench);equal(b:phase(),"command")
        equal(e.pp.dragonRage,2,"forced replacement grants no second enemy attack")
        equal(bench.hp,bench.maxHP);sameRNG(RulesRNG.snapshot(),before)
    end)
    test("Only an all-fainted party ends defeat and engine never heals it",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",50)
        p.hp=1;bench.hp=0;p.spe=1;e.spe=1000;own(p,{"growl"},4);own(e,{"dragonRage"},3)
        local party=roster(p,bench);local b=fresh(p,e,party)
        equal(b:selectMove(1),true);settle(b)
        equal(b:phase(),"ended");equal(b.outcome,"defeat");equal(party:allFainted(),true)
        equal(p.hp,0);equal(bench.hp,0)
        local calls=0;b:on("battleEnd",function(won,kind) calls=calls+1;equal(won,false);equal(kind,"defeat") end)
        equal(b:emitEnd(),true);equal(b:emitEnd(),false);equal(calls,1)
    end)
    test("Enemy reserve continues after faint and only final member emits victory",function()
        local p,a,z=Pokemon("charmander",100),Pokemon("squirtle",5),Pokemon("bulbasaur",5)
        p.spe=1000;a.hp=1;z.hp=1;own(p,{"dragonRage"},4);own(a,{"growl"},3);own(z,{"growl"},3)
        local enemies=roster(a,z);local b=fresh(p,a,nil,nil,enemies,"RIVAL")
        local calls=0;b:on("battleEnd",function(won,kind) calls=calls+1;equal(won,true);equal(kind,"victory") end)
        equal(b:selectMove(1),true);local text=settle(b)
        equal(a.hp,0);equal(enemies:active(),z);equal(b.enemy,z);equal(b.outcome,nil);equal(b:phase(),"command")
        assert(text:find("RIVAL sent out BULBASAUR!",1,true));equal(calls,0);equal(z.pp.growl,3)
        equal(b:selectMove(1),true);settle(b);equal(b.outcome,"victory")
        equal(b:emitEnd(),true);equal(b:emitEnd(),false);equal(calls,1)
    end)
    test("Enemy reserve is not sent before surviving player's residual processing",function()
        local p,a,z=Pokemon("charmander",100),Pokemon("squirtle",5),Pokemon("bulbasaur",5)
        p.status="poison";p.hp=1;p.spe=1000;a.hp=1;own(p,{"dragonRage"},4);own(a,{"growl"},3)
        local enemies=roster(a,z);local b=fresh(p,a,nil,nil,enemies,"RIVAL")
        equal(b:selectMove(1),true);local text=settle(b)
        equal(p.hp,0);equal(b.outcome,"defeat");equal(b.enemy,a)
        assert(not text:find("sent out BULBASAUR",1,true),"battle already lost before reserve send-out")
    end)
    test("Caught terminal recruits same identity consumes exactly one and grants no XP",function()
        local session,p=sessionWithStarter();local e=Pokemon("pikachu",5)
        e.hp=1;e.status="sleep";e.statusTurns=0;e.sleepDuration=3
        assert(session:inventory():add("masterBall",2));local b=fresh(p,e,nil,session)
        local before=RulesRNG.snapshot();local xp=p.xp
        local ok,result=b:throwBall("masterBall");equal(ok,true);equal(result.caught,true)
        equal(session:inventory():quantity("masterBall"),1);equal(session:party():get(2),e);equal(b.caughtPokemon,e)
        equal(result.destination.destination,"party");equal(result.destination.index,2)
        equal(b:throwBall("masterBall"),false);equal(session:inventory():quantity("masterBall"),1)
        settle(b);equal(b:phase(),"ended");equal(b.outcome,"caught");equal(p.xp,xp)
        equal(e.hp,1);equal(e.status,"sleep");equal(e.statusTurns,0);equal(e.sleepDuration,3)
        sameRNG(RulesRNG.snapshot(),before)
        local calls=0;b:on("battleEnd",function(won,kind) calls=calls+1;equal(won,false);equal(kind,"caught") end)
        equal(b:emitEnd(),true);equal(b:emitEnd(),false);equal(calls,1)
    end)
    test("Failed ball throw consumes one and spends turn on enemy response",function()
        local session,p=sessionWithStarter();local e=Pokemon("rattata",5)
        e.hp,e.maxHP=20,20;own(e,{"growl"},3);assert(session:inventory():add("pokeBall",2))
        local b=fresh(p,e,nil,session);RulesRNG.seed(62594)
        local ok,result=b:throwBall("pokeBall");equal(ok,true);equal(result.caught,false)
        equal(result.shakeRolls[1],49802);equal(result.displayShakes,0)
        equal(session:inventory():quantity("pokeBall"),1);equal(session:party():count(),1)
        local rolled=RulesRNG.snapshot().rolls;settle(b)
        equal(e.pp.growl,2);equal(p.statStages.atk,-1);equal(b:phase(),"command");equal(b.outcome,nil)
        equal(RulesRNG.snapshot().rolls,rolled+2,"enemy selection and accuracy follow failed throw")
    end)
    test("Trainer ball refusal changes no phase bag target or RNG",function()
        local session,p=sessionWithStarter();local e=Pokemon("squirtle",5)
        assert(session:inventory():add("masterBall",1));local b=fresh(p,e,nil,session,nil,"RIVAL")
        local before=RulesRNG.snapshot();local ok,why=b:throwBall("masterBall")
        equal(ok,false);equal(why,"trainer-battle");equal(b:phase(),"command")
        equal(session:inventory():quantity("masterBall"),1);equal(session:party():count(),1);sameRNG(RulesRNG.snapshot(),before)
    end)
    test("Full selected box and party refuse without consumption or automatic rollover",function()
        local session,p=sessionWithStarter()
        for _=1,5 do assert(session:recruit(Pokemon("rattata",5))) end
        for _=1,20 do assert(session:recruit(Pokemon("pidgey",5))) end
        local e=Pokemon("mew",5);assert(session:inventory():add("masterBall",1));local b=fresh(p,e,nil,session)
        local before=RulesRNG.snapshot();local ok,why=b:throwBall("masterBall")
        equal(ok,false);equal(why,"storage-full");equal(session:inventory():quantity("masterBall"),1)
        equal(Party._owner(e),nil);equal(session:storage():activeBox(),1);equal(session:storage():count(2),0);sameRNG(RulesRNG.snapshot(),before)
        assert(session:storage():selectBox(2));equal(b:throwBall("masterBall"),true);settle(b)
        equal(session:party():count(),6);equal(session:storage():get(1,2),e);equal(session:storage():count(1),20)
        equal(session:pokedex().owned.mew,true)
    end)
    test("Invalid ball missing stock and exhausted RNG reject atomically",function()
        local session,p=sessionWithStarter();local e=Pokemon("rattata",5)
        e.hp,e.maxHP=20,20;local b=fresh(p,e,nil,session);local before=RulesRNG.snapshot()
        local ok,why=b:throwBall("potion");equal(ok,false);equal(why,"unsupported-ball");sameRNG(RulesRNG.snapshot(),before)
        ok,why=b:throwBall("pokeBall");equal(ok,false);equal(why,"insufficient-items");sameRNG(RulesRNG.snapshot(),before)
        assert(session:inventory():add("pokeBall",1))
        before.rolls=2147483646;RulesRNG.restore(before)
        ok,why=b:throwBall("pokeBall");equal(ok,false);equal(why,"rng-exhausted")
        equal(session:inventory():quantity("pokeBall"),1);equal(b:phase(),"command");sameRNG(RulesRNG.snapshot(),before)
        RulesRNG.seed(42)
    end)
    test("Scene exposes BAG POKEMON requests once and blocks duplicate command transitions",function()
        local session,p=sessionWithStarter();assert(session:recruit(Pokemon("pikachu",5)))
        local b=fresh(p,Pokemon("squirtle",5),nil,session)
        local scene=BattleScene(b);scene:enter()
        equal(table.concat(scene.mainMenu.options,","),"FIGHT,BAG,POKEMON,RUN");equal(scene.mainMenu.columns,2)
        local before=RulesRNG.snapshot()
        scene.mainMenu.onSelect(3)
        local request=scene:takeSelectionRequest();equal(request.kind,"party");equal(request.forced,false)
        equal(scene:takeSelectionRequest(),nil);equal(scene:requestSelection("bag"),false)
        local ok,why=b:selectMove(1);equal(ok,false);equal(why,"selection-open")
        sameRNG(RulesRNG.snapshot(),before);equal(scene:completeSelection(true),true);equal(b.selectionKind,nil)
        scene:enter();scene.mainMenu.onSelect(2);request=scene:takeSelectionRequest()
        equal(request.kind,"bag");equal(request.forced,false);equal(scene:completeSelection(true),true)
        equal(b:phase(),"command");sameRNG(RulesRNG.snapshot(),before)
    end)
    test("Forced Scene request is uncancellable and resolves only through a valid party choice",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",50)
        p.hp=1;p.spe=1;e.spe=1000;own(p,{"growl"},4);own(e,{"dragonRage"},3)
        local b=fresh(p,e,roster(p,bench));equal(b:selectMove(1),true);settle(b)
        local scene=BattleScene(b);scene.introPhase="ready";scene.introDrawing=false;scene:update()
        local request=scene:takeSelectionRequest();equal(request.kind,"party");equal(request.forced,true)
        scene:update();equal(scene:takeSelectionRequest(),nil,"repeated updates cannot request twice")
        equal(scene:completeSelection(true),false);equal(b:chooseParty(1),false);equal(scene:completeSelection(),false)
        local before=RulesRNG.snapshot();equal(b:chooseParty(2),true);equal(scene:completeSelection(),true);settle(b)
        equal(b.player,bench);equal(b.selectionKind,nil);sameRNG(RulesRNG.snapshot(),before)
    end)
    test("Sleep start records one original random roll and switching never rerolls",function()
        local p,e=Pokemon("charmander",5),Pokemon("squirtle",5)
        local b=fresh(p,e);RulesRNG.seed(42);b:setDirection("player")
        b:runScript(function() ApplyStatus(DEFENDER,"sleep"):apply(b) end);settle(b)
        equal(e.status,"sleep");equal(e.statusTurns,3);equal(e.sleepDuration,3)
        equal(RulesRNG.snapshot().rolls,1);e.statusTurns=0
        local before=RulesRNG.snapshot();e:onSwitchOut()
        equal(e.statusTurns,3);equal(e.sleepDuration,3);sameRNG(RulesRNG.snapshot(),before)
    end)
    test("Codec3 preserves every valid sleep-duration boundary and rejects codec2 explicitly",function()
        for duration=1,3 do
            for remaining=0,duration do
                local p=Pokemon("charmander",5)
                p.status,p.statusTurns,p.sleepDuration="sleep",remaining,duration
                local record=assert(PokemonCodec.encode(p));equal(record.version,3)
                local restored=assert(PokemonCodec.decode(record))
                equal(restored.statusTurns,remaining);equal(restored.sleepDuration,duration)
                local before=RulesRNG.snapshot();restored:onSwitchOut()
                equal(restored.statusTurns,duration);sameRNG(RulesRNG.snapshot(),before)
            end
        end
        local record=assert(PokemonCodec.encode(Pokemon("charmander",5)));record.version=2
        local restored,problem=PokemonCodec.decode(record);equal(restored,nil)
        assert(problem:find("unsupported%-pokemon%-record%-version"),problem)
        record.version=3;record.sleepDuration=1
        restored,problem=PokemonCodec.decode(record);equal(restored,nil);assert(problem:find("invalid%-sleep%-duration"),problem)
    end)
    test("Invalid sleep duration cannot partially switch or reset outgoing stages",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",5)
        p.status,p.statusTurns,p.sleepDuration="sleep",0,0;p.statStages.atk=4
        local party=roster(p,bench);local b=fresh(p,e,party);local before=RulesRNG.snapshot()
        local ok,problem=b:chooseParty(2);equal(ok,false);equal(problem,"invalid-sleep-duration")
        equal(b.player,p);equal(party:active(),p);equal(p.statStages.atk,4);sameRNG(RulesRNG.snapshot(),before)
    end)
    test("Wake medicine and full restore clear original sleep duration with counters",function()
        for _,item in ipairs({"awakening","fullHeal","fullRestore"}) do
            local p=Pokemon("charmander",5);p.status,p.statusTurns,p.sleepDuration="sleep",0,3
            local inventory=Inventory(ItemData.definitions);assert(inventory:add(item,1))
            equal(Items.use(inventory,item,p),true);equal(p.status,nil);equal(p.statusTurns,0);equal(p.sleepDuration,0)
            assert(PokemonCodec.encode(p))
        end
        local p=Pokemon("charmander",5);p.status,p.statusTurns,p.sleepDuration="sleep",1,3
        p:fullRestore();equal(p.sleepDuration,0);equal(p.statusTurns,0);equal(p.status,nil)
    end)
    test("Conscious participants share before recipient-level scaling with default1 compatibility",function()
        equal(Growth.battleAward(64,5,5,true),97)
        equal(Growth.battleAward(64,5,5,true,2),49)
        equal(Growth.battleAward(64,5,10,true,2),28)
        equal(Growth.battleAward(64,6,6,true,2),58)
        for _,count in ipairs({0,7,1.5,"2"}) do equal(pcall(Growth.battleAward,64,5,5,true,count),false) end
    end)
    test("Two real participants receive58 each and learn separately before terminal victory",function()
        local p,bench,unused,e=Pokemon("charmander",6),Pokemon("bulbasaur",6),Pokemon("squirtle",6),Pokemon("bulbasaur",6)
        e.hp=1;e.spe=1;bench.spe=1000;own(e,{"growl"},3);own(bench,{"dragonRage"},3)
        local party=roster(p,bench,unused);local b=fresh(p,e,party,nil,nil,"RIVAL")
        equal(b:chooseParty(2),true);settle(b)
        equal(b:selectMove(1),true);settle(b)
        equal(b.outcome,"victory");equal(p.xp,237);equal(bench.xp,237);equal(unused.xp,179)
        equal(p.level,7);equal(bench.level,7);equal(unused.level,6)
        equal(#p:getPendingMoveChoices(),0)
        equal(#bench:getPendingMoveChoices(),0)
        equal(#unused:getPendingMoveChoices(),0)
        equal(p:hasMove("ember"),true);equal(bench:hasMove("leechSeed"),true)
    end)
    test("Fainted participant is excluded from split and never revived by XP",function()
        local p,bench,e=Pokemon("charmander",6),Pokemon("bulbasaur",6),Pokemon("bulbasaur",6)
        p.hp=1;p.spe=1;e.spe=1000;own(p,{"growl"},4);own(e,{"dragonRage"},4);own(bench,{"dragonRage"},4)
        local party=roster(p,bench);local b=fresh(p,e,party,nil,nil,"RIVAL")
        equal(b:selectMove(1),true);settle(b);equal(b:phase(),"forcedSwitch")
        equal(b:chooseParty(2),true);settle(b);bench.spe=2000;e.hp=1
        equal(b:selectMove(1),true);settle(b)
        equal(b.outcome,"victory");equal(p.hp,0);equal(p.xp,179)
        equal(bench.xp,294,"sole conscious participant receives115 rather than58")
    end)
    test("Participation clears for each next opponent and prior bench does not share again",function()
        local p,bench,a,z=Pokemon("charmander",6),Pokemon("bulbasaur",6),Pokemon("bulbasaur",6),Pokemon("squirtle",6)
        a.hp,z.hp=1,1;a.spe,z.spe=1,1;bench.spe=1000
        own(a,{"growl"},4);own(z,{"growl"},4);own(bench,{"dragonRage"},4)
        local party,enemies=roster(p,bench),roster(a,z);local b=fresh(p,a,party,nil,enemies,"RIVAL")
        equal(b:chooseParty(2),true);settle(b);equal(b:selectMove(1),true);settle(b)
        equal(p.xp,237);equal(bench.xp,237);equal(b.enemy,z);equal(b.outcome,nil)
        equal(b:selectMove(1),true);settle(b)
        equal(b.outcome,"victory");equal(p.xp,237);equal(bench.xp,338,"new sole participant gets101")
        equal(#p:getPendingMoveChoices(),0,"first opponent learning resolved before enemy2")
        equal(p:hasMove("ember"),true,"learned Ember persists without a second award")
    end)
    test("Preexisting fainted active member requests replacement rather than blackout if reserve usable",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",5)
        p.hp=0;local party=roster(p,bench);local b=fresh(p,e,party)
        equal(b:phase(),"forcedSwitch");equal(b.outcome,nil);equal(p.hp,0)
        equal(b:chooseParty(2),true);settle(b);equal(b:phase(),"command");equal(b.player,bench)
    end)
    test("All424 generated moves carry pinned GenV target metadata including added Toxic",function()
        local count=0
        for key,move in pairs(moveData) do
            assert(type(move.targetId)=="number" and math.tointeger(move.targetId) and move.targetId>=1 and move.targetId<=14,"missing target metadata: " .. key)
            count=count+1
        end
        equal(count,424);equal(moveData.toxic.targetId,10);equal(moveData.recover.targetId,7);equal(moveData.tackle.targetId,10)
        equal(moveData.struggle.targetId,10);equal(moveData.perishSong.targetId,12)
        equal(moveData.reflect.targetId,4);equal(moveData.haze.targetId,12)
    end)
    test("Queued surviving enemy Recover executes after player confusion self-KO",function()
        local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",5)
        p.hp=1;p.confusion=1;p.spe=1000;e.hp=1;e.spe=1
        own(p,{"growl"},4);own(e,{"recover"},10)
        local b=fresh(p,e,roster(p,bench));RulesRNG.seed(42)
        equal(b:selectMove(1),true);local text=settle(b)
        equal(p.hp,0);equal(p.pp.growl,4);equal(e.pp.recover,9);equal(e.hp,10)
        assert(text:find("SQUIRTLE used RECOVER!",1,true),text)
        equal(b:phase(),"forcedSwitch");equal(b.outcome,nil);equal(RulesRNG.snapshot().rolls,3)
    end)
    test("Queued opponent attack fails after PP but sleeping gate blocks before PP when target fainted",function()
        for _,asleep in ipairs({false,true}) do
            local p,bench,e=Pokemon("charmander",5),Pokemon("pikachu",5),Pokemon("squirtle",5)
            p.hp=1;p.confusion=1;p.spe=1000;e.hp=1;e.spe=1
            if asleep then e.status,e.statusTurns,e.sleepDuration="sleep",1,2 end
            own(p,{"growl"},4);own(e,{"tackle"},3)
            local b=fresh(p,e,roster(p,bench));RulesRNG.seed(42)
            equal(b:selectMove(1),true);local text=settle(b)
            equal(p.hp,0);equal(p.pp.growl,4);equal(e.hp,1);equal(b:phase(),"forcedSwitch")
            equal(RulesRNG.snapshot().rolls,3,"no accuracy/damage roll against absent target")
            if asleep then
                equal(e.pp.tackle,3);equal(e.statusTurns,0);equal(e.sleepDuration,2)
                assert(text:find("fast asleep",1,true),text)
                assert(not text:find("no target",1,true),text)
            else
                equal(e.pp.tackle,2);assert(text:find("But there was no target!",1,true),text)
            end
        end
    end)
    RulesRNG.restore(savedRNG)
    return report
end

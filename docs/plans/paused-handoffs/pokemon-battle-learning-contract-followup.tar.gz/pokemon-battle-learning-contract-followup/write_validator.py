from pathlib import Path
base=Path('/private/tmp/pokemon-battle-learning/validate_staged.py');s=base.read_text()
s=s.replace("p.add_argument('--scenario');", "p.add_argument('--scenario');p.add_argument('--with-evolution',action='store_true',help='compose separately frozen evolution followup for sequencing proof');")
s=s.replace("stage=Path(__file__).resolve().parent", "stage=Path('/private/tmp/pokemon-battle-learning');followup=Path(__file__).resolve().parent")
marker="    main=output/'Source/main.lua';text=main.read_text();anchor='import \"dev/catalog\"'"
addition='''    followup_manifest=json.loads((followup/'manifest.json').read_text())
    for item in followup_manifest['files']:
        source=followup/item['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==item['sha256'],'followup drift'
        shutil.copyfile(source,output/item['path'])
    if a.with_evolution:
        evo=Path('/private/tmp/pokemon-evolution');evo_followup=Path('/private/tmp/pokemon-evolution-followup-01')
        evo_manifest=json.loads((evo_followup/'foundation-manifest.json').read_text())
        for item in evo_manifest['owned_files']:
            source=evo_followup/item['path']
            if not source.exists(): source=evo/item['path']
            assert hashlib.sha256(source.read_bytes()).hexdigest()==item['sha256'],'evolution packet drift'
            if item['path'] in ('Source/game/battleState.lua','Source/dev/fixtures.lua','Source/dev/partyBattleContracts.lua'):continue
            target=output/item['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        controller=output/'Source/game/battleState.lua';value=controller.read_text()
        if 'Evolution.afterBattle' not in value:
            value=value.replace('    local pokemon = game:getPlayerPokemon()', '    if Evolution then assert(Evolution.afterBattle(game.session,kind)) end\\n    local pokemon = game:getPlayerPokemon()',1)
        controller.write_text(value)
        fixtures=output/'Source/dev/fixtures.lua';value=fixtures.read_text().replace('game:offerLearning(game:getPlayerPokemon())','game:offerPartyProgression()');fixtures.write_text(value)
        party_contracts=output/'Source/dev/partyBattleContracts.lua';value=party_contracts.read_text().replace('equal(record.version,3)','equal(record.version,4)').replace('Codec3 preserves','Codec4 preserves');party_contracts.write_text(value)
        metadata['evolution_composition']=evo_manifest
    main=output/'Source/main.lua';text=main.read_text();anchor='import "dev/catalog"'
'''
s=s.replace(marker,addition.rstrip(),1)
s=s.replace("text=text.replace(anchor,'import \"dev/battleLearningContracts\"\\nContracts.register(\"battle-learning\", BattleLearningContracts.run)\\n'+anchor,1);main.write_text(text)",'''text=text.replace(anchor,'import "dev/battleLearningContracts"\\nContracts.register("battle-learning", BattleLearningContracts.run)\\n'+anchor,1)
    if a.with_evolution:
        text=text.replace(anchor,'import "game/evolutionState"\\nimport "dev/evolutionContracts"\\nContracts.register("evolution", EvolutionContracts.run)\\nimport "dev/battleLearningEvolutionContracts"\\nContracts.register("battle-learning-evolution", BattleLearningEvolutionContracts.run)\\n'+anchor,1)
        text=text.replace('machine:register("learning", LearningState(game))','machine:register("learning", LearningState(game))\\nmachine:register("evolution", EvolutionState(game))',1)
    main.write_text(text)
    diagnostics=output/'Source/dev/diagnostics.lua';text=diagnostics.read_text().replace('conditions = battle:getConditionsSnapshot(),','conditions = battle:getConditionsSnapshot(),\\n            learning = battle:getLearningSnapshot(),',1)
    if a.with_evolution:
        text=text.replace('party_ui = ui(', 'evolution = root:get("evolution"):getSnapshot(),\\n        party_ui = ui(',1)
    diagnostics.write_text(text)''',1)
s=s.replace("metadata['battle_learning_foundation']=manifest", "metadata['battle_learning_foundation']=manifest;metadata['battle_learning_followup']=followup_manifest")
s=s.replace("scenario=Path(a.scenario).resolve() if a.scenario else stage/'contracts.json'", "scenario=Path(a.scenario).resolve() if a.scenario else followup/'contracts.json'")
Path('/private/tmp/pokemon-battle-learning-contract-followup/validate_staged.py').write_text(s)

# Battle learning suspension — candidate, awaiting root execution

No live Source, Simulator, Data, art or map changed by this worker. The initial
five-file runtime packet remains frozen at `/private/tmp/pokemon-battle-learning`.
This separate packet adds the honest old-contract adaptation and two optional
cross-module evolution contracts. `manifest.json` contains all seven owned Lua
paths, base/candidate SHA256 values, native recipe hashes and validator hash.

## Source and sequencing

Primary B2W2 decompilation revision
`b279bbefa99bb2f6fbabcc95e4b6d3e939290353` is pinned by SHA256 in
`references/source-pins.json`; the three exact C files are included for replay.
[Battle client](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/btl_client.c)
EXP sequence case12 calls `BattleClient_LearnMoveSeq`; case13 calls
`SyncServerMonMoves` only afterward.
[Server](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/btl_server_flow.c)
`ServerControl_GiveExp` handles the actual recipients.
[Battle return](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov166/event_battle_return.c)
checks actual level gains for evolution after the battle result. Thus old-species
learning must finish before the next opponent, while evolution waits for return.
Current pinned production Squirtle learnset has move145 `bubble` exactly at7;
its level6 constructor lacks Bubble. The independent existing B2W2 learnset
validator remains the data oracle; this slice changes no learnset.

## Interface and owners

`handleFaint` yields typed `learning` after each accepted XP grant/level message.
The existing identity-based awardedEnemies guard still awards each opponent once.
All conscious actual recipients finish sequentially before residual continuation,
enemy replacement, terminal outcome or later command. The same coroutine resumes.
No new rules RNG, AI turn, enemy replacement or move replacement happens while
suspended. Unknown typed events fail explicitly.

`Battle:takeLearningRequest()` returns opaque receipt and actual Pokemon once.
`resumeLearning(receipt)` accepts only a claimed exact battle/script/coroutine
receipt whose pending choices are empty. Early, forged, foreign and stale calls
fail unchanged. `cancelPendingLearning()` invalidates the receipt and script on
forced exit. Script replacement and clearVolatiles also invalidate. Duplicate
completed owner callbacks do nothing; session replacement invalidates the old
battle instead of resuming it. `getLearningSnapshot()` returns detached
`{pending,claimed,species,remaining}`.

The new BattleState method polls after update/input, opens actual LearningState,
and resumes only the same controller/battle/session when it is top again. The
controller patch does not change finish/trainer payouts, story, return/evolution
or NPC behavior. Root must merge the narrow patch into its trainer controller.

`LearningState.open(game,mon,callback,{waitForRelease=true})` validates options
before push; unknown fields/nonboolean gate reject. The midbattle owner opts in.
A/B are ignored until both have been released, including update-opened overlays
that receive handleInput in the same frame. `input_blocked` is a read-only native
snapshot field. Old callers retain their previous default. Menus/dialogs/fonts
and existing replacement/refusal/PP decisions are unchanged.

## Synthetic fixture and diagnostics

Explicit whole-reset fixture adds `trainer_name` plus `enemy_party` array1..6,
requiring skipped intro and an explicit owned party. Every detached Pokemon,
known-move PP, HP, major status/sleep-duration, team schema and XP grant is checked
before any reset/stack/session/RNG mutation. Late bad members reject unchanged.
Enemy members must start conscious. Synthetic trainerID is
`fixture:trainer-team`; it never aliases a source trainer defeat/reward. Actual
BattleState receives the detached actual enemyParty. The synthetic marker only
records its own `fixtureDefeated` presentation result. Existing Harness command
validation already calls HarnessFixtures.validate; no duplicate parser was added.

Root diagnostic hook: `battle.learning = battle:getLearningSnapshot()`.
Learning snapshot already exposes `input_blocked`. The private validator includes
this hook; integrate it narrowly into root diagnostics.

## Verification and root commands

Compile-only passed `/private/tmp/pokemon-battle-learning-build-03`, with the
separately frozen evolution followup composed. Source SHA256:
`c92ec8eabaf919b460e90de70a4f964ae9dee10758d55cb6b64cb34d874cf70d`.
This is compile evidence, not an SDK execution claim. Initial five Source bytes
remain unchanged. New suites have18 battle-learning groups and2 optional
learning→evolution composition groups. Existing PartyBattleContracts now drives
actual receipts/LearningState and retains exact58/115/101 XP vectors; old deferred
queue assertions became learned-before-continuation assertions. Production has
no auto-resolve/defer compatibility switch.

Root-only SDK execution (default without --execute compiles only):

```sh
python3 /private/tmp/pokemon-battle-learning-contract-followup/validate_staged.py \
  --project "$PWD" --output /private/tmp/pokemon-battle-learning-sdk-final \
  --with-evolution --execute
```

Optional `--controller /private/tmp/pokemon-pewter-runtime-candidate-02/Source/game/battleState.lua`
merges only the narrow learning hunk on the separately reviewed trainer controller.
No other provider/world module is copied by that option. `--with-evolution`
verifies/copied only the14 manifest-owned frozen evolution files; controller and
fixture retain this packet's learning/fixture additions, with the narrow evolution
return/progression hook; old party tests retain their new honest UI settlement.
It imports/registers the2 evolution composition groups and the27 evolution groups.
Root should inspect generated Source and its fresh source-manifest/build identity.

Native scenarios are under `/private/tmp/pokemon-battle-learning/scenarios`:

- `battle-learning-two-enemy-bubble.json`: Squirtle6 at235XP learns Bubble7, held
  entry A cannot skip message, release completes, same battle uses Bubble vs enemy2.
- `battle-learning-two-enemy-replacement-back.json`: full Charmander set,
  held-entry refusal to autochoose, back/confirm/replacement retains other PP.
- `battle-learning-two-enemy-refusal.json`: explicit stop YES, old moves retained.
- `battle-learning-final-evolution.json`: final enemy learning completes before
  battleEnd; only afterward actual return opens evolution and evolves Charmander.

Use the same root runner with `--scenario <absolute.json> --execute`; final
scenario requires `--with-evolution`. Recipes are unexecuted proposals; fixed-seed
message timing must be checked in actual runtime. Root must inspect native images
and the Bubble use against enemy2. A later real Forest trainer journey supplements
synthetic deterministic fixtures. Existing evolution proof364/0 remains separate.

## Remaining scope

No ability, held-item or nature implementation is included. The user has chosen
all three; their source/architecture proposal follows this handoff. Existing
multi-level XP grants collect ordered move choices after the bulk grant/level
message rather than reproducing each cartridge level-stat popup; choices all
resolve before any further battle progression. No campaign or all-move completion
claim is implied.

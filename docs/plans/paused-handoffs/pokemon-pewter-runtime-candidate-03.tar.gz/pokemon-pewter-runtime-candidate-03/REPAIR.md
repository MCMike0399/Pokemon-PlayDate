# Native02 repair: separate candidate03

The frozen candidate02 and failed native02 evidence remain unchanged. Native02 reported356 passing and4 failing contracts; catalog did not run.

The unresolved-warp contract expected nil from getDoorAt, contrary to its existing fail-closed interface. Physical blockers still remain solid; the assertion now requires the exact unresolved source-warp ID for both Route2 and Pewter. No runtime behavior changed for this case.

Three mutation/cache cases failed because Zone:setTile resolved a stable string key through its currently materialized numeric TileRegistry before delegating to the immutable provider. Route2 does not initially allocate the padding-only adapter:pewter:void key, though that key is known to provider metadata. The provider already validates before allocation and rolls back native view rejection. Zone now passes stable string keys directly to that provider; numeric IDs retain registry validation. Authored and non-provider Zone behavior remains unchanged.

Existing mutation→eviction→codec→reload and reset tests remain intact. The native view-rejection case additionally rejects unknown string keys and numeric IDs without allocation/ledger mutation, then verifies lazy allocation rollback on view failure.

Compile-only build05 passed. Native22 added contracts and strict300-PNG catalog remain root-owned pending acceptance.

from pathlib import Path
root=Path('/private/tmp/pokemon-specimen-attributes/Source')
p=root/'data/pokemon.lua';s=p.read_text();s=s.replace('import "domain/growth"','import "domain/growth"\nimport "data/specimenData"\nimport "domain/specimen"',1)
s=s.replace('function Pokemon:init(species, level)\n    checkedLevel(level)\n    local data = pokemonData[species]','function Pokemon:init(species, level, attributes)\n    checkedLevel(level)\n    local attributes = Specimen.attributes(attributes)\n    local data = assert(pokemonData[species], "unknown-species")',1)
s=s.replace('    self.species = species\n    self.name','    self.natureId, self.abilitySlot, self.heldItem = attributes.natureId, attributes.abilitySlot, attributes.heldItem\n    self.species = species\n    self.name',1)
for target,base in [('atk','Atk'),('def','Def'),('spa','SpA'),('spd','SpD'),('spe','Spe')]:
 s=s.replace(f'self.{target} = calcStat(data.base{base}, level)',f'self.{target} = Specimen.stat(calcStat(data.base{base}, level), self.natureId, "{target}")',1)
 s=s.replace(f'self.{target} = calcStat(data.base{base}, self.level)',f'self.{target} = Specimen.stat(calcStat(data.base{base}, self.level), self.natureId, "{target}")',1)
marker='function Pokemon:isAlive()'
s=s.replace(marker,'''function Pokemon:attributes()
    return Specimen.attributes({natureId=self.natureId,abilitySlot=self.abilitySlot,heldItem=self.heldItem})
end
function Pokemon:ability()
    return Specimen.ability(self.species,self.abilitySlot)
end

'''+marker,1)
s=s.replace('function Pokemon:gainXP(amount)\n','function Pokemon:gainXP(amount)\n    self:attributes() -- Validate durable inputs before any XP/stats/choice mutation.\n',1)
p.write_text(s)
p=root/'domain/pokemonCodec.lua';s=p.read_text().replace('PokemonCodec = { VERSION = 4 }','PokemonCodec = { VERSION = 5 }',1)
s=s.replace('nextMoveChoiceId=true,pendingEvolution=true}','nextMoveChoiceId=true,pendingEvolution=true,natureId=true,abilitySlot=true,heldItem=true}',1)
s=s.replace('assert(record.version==PokemonCodec.VERSION or record.version==3,"unsupported-pokemon-record-version")','''assert(record.version==PokemonCodec.VERSION or record.version==4 or record.version==3,"unsupported-pokemon-record-version")
    local attributes
    if record.version==3 or record.version==4 then
        assert(record.natureId==nil and record.abilitySlot==nil and record.heldItem==nil,"legacy-specimen-fields")
        -- Deliberate unreleased legacy defaults, never historical reconstruction.
        attributes=Specimen.attributes(nil)
    else
        attributes=Specimen.attributes({natureId=record.natureId,abilitySlot=record.abilitySlot,heldItem=record.heldItem})
    end''',1)
s=s.replace('nextMoveChoiceId=record.nextMoveChoiceId,pendingEvolution=evolution}','nextMoveChoiceId=record.nextMoveChoiceId,pendingEvolution=evolution,\n        natureId=attributes.natureId,abilitySlot=attributes.abilitySlot,heldItem=attributes.heldItem}',1)
s=s.replace('nextMoveChoiceId=mon.nextMoveChoiceId,pendingEvolution=mon.pendingEvolution})','nextMoveChoiceId=mon.nextMoveChoiceId,pendingEvolution=mon.pendingEvolution,\n        natureId=mon.natureId,abilitySlot=mon.abilitySlot,heldItem=mon.heldItem})',1)
s=s.replace('local created,mon=pcall(Pokemon,data.species,data.level)','local created,mon=pcall(Pokemon,data.species,data.level,{natureId=data.natureId,abilitySlot=data.abilitySlot,heldItem=data.heldItem})',1)
p.write_text(s)
p=root/'domain/specimen.lua';s=p.read_text().replace('rngBefore=before,rngAfter=after}','rngBefore=before,rngAfter=after,rawRolls=after.rolls-before.rolls}',1);p.write_text(s)

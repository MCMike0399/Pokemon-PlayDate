import importlib.util,json,shutil,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import sys
TOOLS=Path(__file__).resolve().parents[1];sys.path.insert(0,str(TOOLS))
import generate_specimen_data as gen
ROOT=TOOLS.parent
ITEMS={
 'potion':{'symbol':'POTION','keyItem':False,'category':'medicine'},
 'pokeBall':{'symbol':'POKE_BALL','keyItem':False,'category':'ball'},
 'moonStone':{'symbol':'MOON_STONE','keyItem':False,'category':'evolution'},
 'townMap':{'symbol':'TOWN_MAP','keyItem':True,'category':'key'},
 'tm01':{'symbol':'TM_MEGA_PUNCH','keyItem':False,'category':'tm'},
 'hm01':{'symbol':'HM_CUT','keyItem':True,'category':'hm'},
 'expAll':{'symbol':'EXP_ALL','keyItem':False,'category':'item'}}
class GeneratorTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.raw=gen.load(ROOT/'references')
 def test_all151_literal_gen5_slots_and_duplicate_hidden_provenance(self):
  species,natures,names,held=gen.collect(self.raw,ITEMS)
  self.assertEqual(len(species),151);self.assertEqual(len(names),111)
  for dex,wanted in {1:[65,65,34],4:[66,66,94],7:[67,67,44],11:[61,61,61],12:[14,14,110],74:[69,5,8],94:[26,26,26],133:[50,91,107]}.items():self.assertEqual(species[dex-1],wanted)
 def test_25_natures_exact_order_signs_and_independent_showdown(self):
  import re
  natures=gen.collect(self.raw,ITEMS)[1];self.assertEqual(len(natures),25)
  self.assertEqual(natures[3],('Adamant',[1,0,-1,0,0]));self.assertEqual(natures[10],('Timid',[-1,0,0,0,1]))
  self.assertEqual(sum(not any(x[1]) for x in natures),5)
  source=self.raw['data_natures.ts'].decode();ps={}
  for key,body in re.findall(r'^\t(\w+): \{(.*?)\n\t\}',source,re.M|re.S):
   plus=re.search(r"plus: '(\w+)'",body);minus=re.search(r"minus: '(\w+)'",body);ps[key]=(plus[1] if plus else None,minus[1] if minus else None)
  for name,signs in natures:
   stats=['atk','def','spa','spd','spe'];self.assertEqual(ps[name.lower()],(next((stats[i] for i,x in enumerate(signs) if x==1),None),next((stats[i] for i,x in enumerate(signs) if x==-1),None)))
 def test_primary_holdability_excludes_key_tm_hm_and_distinct_exp_all(self):
  held=gen.collect(self.raw,ITEMS)[3]
  self.assertEqual(held,{'expAll':False,'hm01':False,'moonStone':81,'pokeBall':4,'potion':17,'tm01':False,'townMap':False})
 def test_missing_unknown_or_corrupt_source_fails_cache_preserved(self):
  with tempfile.TemporaryDirectory() as directory:
   target=Path(directory);manifest=json.loads(gen.MANIFEST.read_text());name=next(iter(manifest['files']))
   with self.assertRaisesRegex(gen.GenerationError,'missing'):gen.load(target)
   (target/name).write_bytes(b'corrupt')
   with self.assertRaisesRegex(gen.GenerationError,'checksum mismatch'):gen.load(target)
   self.assertEqual((target/name).read_bytes(),b'corrupt')
 def test_unknown_ability_malformed_nature_unmapped_item_fail(self):
  raw=dict(self.raw);binary=bytearray(raw['personal_b2w2']);binary[76+24]=0;raw['personal_b2w2']=bytes(binary)
  with self.assertRaisesRegex(gen.GenerationError,'unknown GenV'):gen.collect(raw,ITEMS)
  raw=dict(self.raw);raw['bw_src_system_poke_tool.c']=b'bad schema'
  with self.assertRaisesRegex(gen.GenerationError,'nature schema'):gen.collect(raw,ITEMS)
  items=dict(ITEMS);items['missing']={'symbol':'UNKNOWN_ITEM','keyItem':False,'category':'item'}
  with self.assertRaisesRegex(gen.GenerationError,'missing GenV item'):gen.collect(self.raw,items)
 def test_deterministic_cli_check_and_nonzero_on_drift(self):
  first=gen.render(self.raw,ITEMS);self.assertEqual(first,gen.render(self.raw,dict(reversed(list(ITEMS.items())))))
  with tempfile.TemporaryDirectory() as directory,patch.object(gen,'load_items',return_value={}),patch.object(gen,'collect_items',return_value=(ITEMS,{},{})):
   output=Path(directory)/'specimen.lua';args=['--cache',str(ROOT/'references'),'--items-cache',directory,'--output',str(output)]
   self.assertEqual(gen.main(args),0);self.assertEqual(gen.main(args+['--check']),0)
   output.write_text(first+'-- drift\n');self.assertEqual(gen.main(args+['--check']),1)
if __name__=='__main__':unittest.main()

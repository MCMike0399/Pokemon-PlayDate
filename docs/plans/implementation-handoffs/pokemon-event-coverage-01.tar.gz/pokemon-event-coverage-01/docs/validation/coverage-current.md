# Current whole-game coverage

This current snapshot observes **accepted main82cb207 correctness1091**, Source `44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc` (actual1091 SDK,0failed). Root accepted1091 SDK/host/compile/protected catalog/two-process SaveContinue; the current all3 natural Brock suite remains pending. The prior main950 and private1059 evidence is preserved as historical source-specific evidence. [Current data](coverage-current.json) follows [the schema](coverage.schema.json). It supersedes historical static reports **as a current status view**, without rewriting them or changing the [full goal](../plans/astra-full-game-goal.md).

Three layers stay independent:

| Layer | What acceptance means | What does not establish it |
|---|---|---|
| `campaign_path` | Actual connected progression, required transactions, safe returns and save/restart for that milestone | A map/party/move count, fixture teleport or source declaration |
| `regional_fidelity` | Source controls/geometry/NPCs/text/items/encounters/puzzles/art/audio adapted and independently reviewed for that region | A playable critical path or protected-pixel preservation alone |
| `full_mechanics` | Implemented rule portions and their exact source/SDK/native evidence, plus remaining full151 requirements | A generated field, nonempty effect, aggregate SDK count or absent conditional producer |

Each row names an owner, acceptance dependencies, **separate due milestone for each layer**, immutable source selector, implementation state, verification level, evidence IDs, limitations and optional private staging. `integrated` means the named production portion exists, never that its entire feature/competitive ruleset is complete. `sdk_scoped`/`native_scoped` remain bounded evidence. Source-only assertions, private proof, historical reports and future work cannot masquerade as accepted main milestones. No row currently claims milestone completion.

## Scheduling now

**Finish correctness of the already selected batch and safe NewGame recovery, then freeze actual natural Bulbasaur/Charmander/Squirtle→Brock on the integrated source. Do not expand that batch with Mirror Move or every optional grind-tail rule.** Required path/save-safety defects still block the gate. No intended move/species is removed, no artificial level cap is introduced, and the complete mechanics ledger remains required for the full release. Every newly accepted region must review its actual producer/dependency exposure; the final release due date is not permission to call an unsupported move a successful no-op.

After that freeze: source-authentic optional Route22 first BLUE, Moon/Cerulean/Bill, Vermilion/S.S. Anne/Cut/Flash, connected midgame, Surf/Strength/late gyms, League/Champion/credits/Hall of Fame, original postgame, then full rules/audio/polish/resource/device release closure. Original later Route22 BLUE stays at its actual late milestone. These are schedules, not reductions of scope.

## What this inventory contains

The original1501 map/system/mechanics rows retain all248 source map slots,425 current move keys,111 original151 normal/hidden ability IDs,151 species,125 current item definitions,38 previously indexed native held-item entries,375 audio source files and28 cross-cutting systems. **Those are inventory sizes, not implemented/playable totals.** The source inventory distinguishes222 ordinary named map slots,22 unused aliases,4 copy/alias slots,223 unique headers/object tables,805 warps,201 background declarations,918 object declarations and391 trainer-party rows including unused content. Hidden/unused declarations (including Route4 LASS31) are not automatically reachable fights.

Map rows point into immutable `kanto-inventory.json`; full source object/script/party/wild/mart/HM/trade/hidden manifests remain there. Source scripts need executable control-flow/reachability review, not only a call list. Unused aliases stay indexed without creating dead runtime NPCs. Debug test_zone is not a natural campaign destination. Actual production currently comprises protected authored Pallet/interiors plus4registered source maps and8provider maps; Route22/Moon private candidates are not installed by this report.

Coverage explicitly includes the whole remaining goal: Bill/ticket, all HMs and badge permissions, fishing/cycling/Safari, Tower ghosts/Snorlax, elevators/spinners/keys/teleports/boulder/current/quiz puzzles, remaining gyms/obedience, League/credits/playable return, Mewtwo/legends, audio/music/cries, naming/options, source availability/exclusives/event-only Mew, in-game trades/trade authorization, balancing, resources/long sessions and physical device. No Mew encounter, unavailable link hardware prerequisite or GenV held loot is invented. Original Blue natural availability remains distinct from technical151 support; broader availability/link policy stays explicit.

## Accepted main correctness and historical evidence

[Actual1091 SDK result](coverage-evidence/current1091-result.json), [summary](coverage-evidence/current1091-summary.json) and the current runtime registry pin Source `44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc` with exact build identity. Root reviewed and committed the combined correctness/Title source. Reward correctness and safe NewGame implementation are accepted in main with scoped SDK/host/compile/protected catalog/two-process SaveContinue evidence. Current all3 natural Brock/native recovery acceptance remains pending. No campaign milestone is accepted from1091 aggregate.

[Main950 evidence](observed-pewter-foundation/brock-integrated950.json), its [raw actual result](coverage-evidence/main950-result.json) and `runtime-move-coverage-main950.json` remain historical main evidence. [Actual1059 result](coverage-evidence/private1059-result.json), its [summary](coverage-evidence/private1059-summary.json) and separate private Bide registry remain unchanged. Earlier natural wins/restarts retain their own source identities and do not establish the pending current all3 freeze.

All48 curated scopes, capabilities, definitions and exact assertion proofs are retained. Current owner refresh is restricted to Bide's two previously reviewed1059 Roost query bodies and Sweet Scent's ModifyStat living-target guard, with its exact meaningful test rerun in1091. Ten unverified records are deliberately **stale**, not rehashed: nine declared technical source gaps share a changed performMove type-query owner; Helping Hand's source-only target query changed. Their declared gap/source-only scopes remain unpromoted. The full48 owner/assertion audit accompanies the private handoff. No extra Roost/PoisonFang family qualification or Route22/Mirror promotion is added.

## Correcting stale mechanics reports

`tools/verify_moves/content-gaps.json` is a historical419-move detector snapshot, not today's live mechanics truth. The [511-event refresh](coverage-evidence/exposure511.json) retains all earlier417 events/135 keys, but its broad34-row promotion is overridden by the [exact34-row erratum](coverage-evidence/promotion34.json):25 scoped implementations backed by meaningful named assertions,9 downgraded technical/conditional requirements. Historical files are unchanged.

The verifier now checks [reviewed runtime evidence](../../tools/references/runtime-move-coverage.json) against **named production bodies/fragments, exact meaningful test bodies and canonical tests loaded from the byte-hash-pinned actual SDK result; build/source identity, report completeness, counts and actual Boolean success must match**. Definition hashes are drift guards, not a producer oracle. Changing a meaningful owner/assertion/definition produces `runtime-evidence-stale`, not an invented missing-handler diagnosis or automatic success. Unrelated reward edits do not invalidate unchanged guard/charge/critical source regions. No generated `powerRule`, `damageRule` or `critStage` field alone qualifies a move.

| Former false missing claim | Actual reviewed owner and independent scope |
|---|---|
| Protect absent | `BattleConditions:protect/blocks/endRound`, real DSL dispatch and guard site; actual first-priority4 block plus consecutive/capped chance cases in accepted950 |
| Solar Beam / Skull Bash charge absent | `BattleConditions:charge`, real charge dispatcher and solar policy; actual charge/release/Defense+1/PP/RNG assertions |
| Critical modifier absent | `criticalStage` +literal denominators and calcDamage critical fragments; exact16-row family metadata +real critical endpoint assertions; this does **not** implement Razor Wind charge |
| Bide zero-power dispatch absent | `damageRule=bide` dispatcher +`BattleConditions:bide/bideHit`; actual public storage/release3rd/PP assertions. Current same Roost-composed bodies pass actual1091/Bide29; historical1059 remains separate |

Helping Hand's singles failure still awaits direct named SDK/native proof; its changed hasType query is explicitly stale until reviewed. Dig/GyroBall/HeavySlam/Magnitude/FuryCutter/self-KO/grounding/underground branches retain explicit technical gaps; their current shared unverified owner drift is reported stale, never silently qualified by aggregate tests. Source absence alone does not prove every other move complete or missing. The current full verifier still exits1 for known gaps/reviews; `runtime_semantics_complete` remains false. A scalar/learnset pass or corrected false-positive count is never full engine acceptance.

## Per-event declarations and unfinished regional work

The same canonical matrix now has **3642 rows**: original1501 rows plus2141 stable source-event rows. These are805 object-table warp declarations,201 background events,918 objects and217 direct `hidden_event`/`hidden_text_predef` coordinate declarations. The source is pinned `af519899719f0754965776faac0e836a3b906e6d`; each row retains source path/hash/line/macro arguments, stable event ID, map-slot dependency, owner and three separate deadlines/facets. `tools/build_event_coverage.py` reproducibly builds these rows; `tools/event_coverage.py` supplies exact declaration and evidence checks.

One unique object-table declaration produces one row. Its dependency list retains every map slot sharing the table, including unused and copy aliases; aliases do not inflate playable event counts. For example LANCES_ROOM events retain unused-map dependencies without exposing extra fights, while the directly declared `UNUSED_MAP_6F:hidden:1` retains its unused map identity. Hidden controls are not ordinary rendered actors. Hide/show flags, actual script state, collision, approach direction and reachable arrivals are **not** inferred from declarations. Script coordinate tables, indirect callbacks, connections and additional runtime control flow require separate execution/reachability work; this pass does not claim to enumerate every executed story transition from assembly.

All event facets default to indexed/unrun. Only three portions are partial/sdk_scoped after exact runtime binding/source declaration checks, current owner/assertion hashes and actual1091 canonical tests: Route1 potion gift once-only/capacity/stale-receipt behavior; Viridian clerk post-parcel shop callback lifecycle; Viridian nurse decline/heal/checkpoint/abort lifecycle. Regional fidelity remains partial/source_only for those three. Tests run controlled event entry; they do not prove natural interaction approach, source audio, every dialogue/transaction branch or full event/map completion. Binding JSON IDs, handler membership and rendered geometry alone never promote another event.

**Current visible-but-unhandled NPCs remain unfinished regional work.** Reviewed source-only observations identify PewterCity objects3/4, PewterGym object3 and PewterPokecenter object3 as instantiated source actors with absent interaction handlers; PewterCity object5 is conditional until Brock and its escort control is absent. ViridianCity objects2/3/6 similarly lack handlers, and5/7 depend on Pokedex visibility. These are production-source observations, not new native visibility witnesses. In protected authored Pallet, original source girl/fisher objects2/3 are absent from the actual roster; they are not falsely called rendered NPCs. Preserving the authored BLUE/art does not complete those source conversations. All remain indexed/unrun and retain their regional deadlines.

## Reproduce and validate

After root applies the narrow packet:

```
python3 tools/check_coverage_matrix.py --project "$PROJECT" --matrix "$PROJECT/docs/validation/coverage-current.json"
python3 -m unittest tools.tests.test_event_coverage tools.tests.test_current1091_refresh tools.tests.test_runtime_sdk_evidence tools.tests.test_move_verifier tools.tests.test_runtime_move_coverage tools.tests.test_coverage_matrix -v
python3 tools/verify_moves/main.py --cache "$PINNED_B2W2_CACHE" --output /private/tmp/current-move-report-UNIQUE.json
```

Rebuild/check event rows with `python3 tools/build_event_coverage.py --project "$PROJECT" --output "$PROJECT/docs/validation/coverage-current.json" --check`. The matrix validator checks exact event declarations/aliases/dependencies/owners/deadlines/facets, current Source identity, evidence hashes, complete immutable map/audio/move inventories, independent layer types, owners/dependencies/acyclicity and main/private separation. A stale source requires regeneration/review; never adjust expected hashes just to pass. The formal JSON schema documents shape; the standard-library validator supplies the cross-reference/source policies without a new dependency.

For separately labeled private Bide evidence, pass an explicit runtime tree and `--runtime-evidence tools/references/runtime-move-coverage-private1059.json` while selecting that tree's Pokemon/move files. The report covers only that registry's Bide subset; it does not claim the rest of the private engine is accepted from an empty proof set. The private source view must also contain the exact referenced private summary; root owns composition/publication.

Worker validation is host-only. No Simulator, live Source, generator, art, baseline or frozen packet was modified. Root still reviews/integrates, runs current SDK/native jobs, inspects images and accepts milestones. Simulator Lua heap/observer measurements do not prove hardware memory/FPS/audio/save behavior; physical Playdate remains explicitly unrun.

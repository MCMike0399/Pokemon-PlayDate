"""Expand current canonical matrix by pinned per-event declarations, read-only check supported."""
import argparse,hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tools.event_coverage import expand

def build(project):
 project=Path(project);path=project/'docs/validation/coverage-current.json';data=json.loads(path.read_text())
 data['snapshot'].update(commit='82cb207',acceptance_context='accepted-main-correctness1091')
 # Root accepted source44bd/1091 correctness, not the still-running all3 milestone.
 data['snapshot']['scope']='Whole original Blue campaign/postgame and original151 GenV mechanics; accepted main correctness1091 snapshot, no accepted current all3 Brock milestone.'
 if data['snapshot']['source_sha256']!='44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc':raise ValueError('event followup requires reviewed44bd source snapshot')
 proof=project/'tools/references/event-coverage-review.json'
 data['evidence']['event-review']={'path':'tools/references/event-coverage-review.json','sha256':hashlib.sha256(proof.read_bytes()).hexdigest(),'kind':'accepted','scope':'Exact source bindings/current source bodies +actual1091 named controlled assertions for three bounded event portions; remaining declarations unrun.'}
 data['evidence']['current1091']['kind']='accepted';data['evidence']['current1091']['scope']='Accepted main82cb207 Source44bd correctness1091 SDK; historical result build identifies precommit Source44bd. No accepted all3 natural Brock milestone.'
 for row in data['rows']:
  if row['id']in ('system:current-reward-correctness','system:safe-newgame-recovery'):
   note='Accepted main82cb207 Source44bd implementation and scoped1091 SDK correctness/recovery evidence; current all3 natural Brock milestone remains pending. No full engine or device claim.'
   row['notes']=note
   for key in ('campaign_path','regional_fidelity','full_mechanics'):row[key]['notes']=note
   row.pop('staged',None)
 data['limits']=[v for v in data['limits']if 'integrated-root-candidate'not in v]+['950/1059 remain historical scoped evidence. Current main82cb207 Source44bd correctness1091 accepted; current all3 natural Brock milestone pending.','Per-event rows cover indexed object-table warps/backgrounds/objects and direct hidden coordinate declarations only. Script-coordinate triggers/indirect tables/connections/hide-show control flow need separate source execution/reachability review; no generic call list is a gameplay event.']
 data['limits']=list(dict.fromkeys(data['limits']))
 return expand(project,data)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args();raw=json.dumps(build(a.project),indent=2)+'\n'
 if a.check:
  if a.output.read_text()!=raw:raise SystemExit('event matrix differs: review/rebuild explicitly')
 else:
  a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(raw)
if __name__=='__main__':main()

"""Pure source declaration inventory and conservative event evidence qualification.

Declarations do not prove reachability, handler existence, or full-map fidelity.
"""
import copy,hashlib,json,re
from pathlib import Path
from tools.verify_moves.runtime_coverage import evidence_path,executed_tests,region
from tools.verify_moves.fetch_pokeapi import SourceError

FACETS=('campaign_path','regional_fidelity','full_mechanics')
CATEGORIES=('warps','background_events','objects')

def read(project,path):return json.loads(evidence_path(Path(project),path).read_text())
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def declarations(inventory,pin):
 refs={f['path']:f['sha256']for f in pin['files']};result=[]
 maps=inventory['maps']
 for table,data in sorted(inventory['object_tables'].items()):
  slots=sorted((m for m in maps if m['object_table']==table),key=lambda m:(m['slot_kind']!='map',m['header_constant']!=m['constant'],m['id']))
  assert slots,'object declaration table has no indexed map'
  primary=slots[0]['constant'];aliases=[{'constant':m['constant'],'slot_kind':m['slot_kind']}for m in slots]
  for category in CATEGORIES:
   for index,event in enumerate(data[category],1):
    result.append({'event_id':f'pokered:{primary}:{category}:{index}','category':category,'index':index,'primary_map':primary,'object_table':table,'map_slots':aliases,'source_path':data['source'],'source_sha256':refs[data['source']],'line':event['line'],'declaration':copy.deepcopy(event),'declaration_sha256':digest(event),'visibility':'not-evaluated: hide/show flags, script state, collision and approach are separate requirements'})
 # Selected-Blue source manifest already removes version branches; no script VM.
 source='data/events/hidden_events.asm';context=None;indices={}
 for line in inventory['declarative_manifests_blue'][source]:
  code=line['code'].split(';',1)[0].strip()
  match=re.fullmatch(r'hidden_events_for\s+([A-Z0-9_]+)',code)
  if match:context=match.group(1);indices.setdefault(context,0);continue
  if code.startswith('db -1'):context=None
  match=re.fullmatch(r'(hidden_event|hidden_text_predef)\s+(.+)',code)
  if not match or context is None:continue
  args=[x.strip()for x in match.group(2).split(',')];assert len(args)==4
  slots=[m for m in maps if m['constant']==context];assert len(slots)==1
  indices[context]+=1;event={'macro':match.group(1),'args':args,'line':line['line']}
  result.append({'event_id':f'pokered:{context}:hidden:{indices[context]}','category':'hidden','index':indices[context],'primary_map':context,'object_table':None,'map_slots':[{'constant':context,'slot_kind':slots[0]['slot_kind']}],'source_path':source,'source_sha256':refs[source],'line':line['line'],'declaration':event,'declaration_sha256':digest(event),'visibility':'hidden coordinate control; not a rendered object or reachability witness'})
 assert len({r['event_id']for r in result})==len(result)
 return sorted(result,key=lambda r:r['event_id'])

def reviewed_claims(project,proof):
 """Exact reviewed binding+current owners+meaningful actual test, no ID oracle."""
 registry=read(project,'tools/references/runtime-move-coverage.json');summary=registry['accepted_summary'];accepted=read(project,summary['path'])
 if hashlib.sha256(evidence_path(Path(project),summary['path']).read_bytes()).hexdigest()!=summary['sha256']:raise SourceError('event accepted summary drift')
 canonical=executed_tests(Path(project),registry,summary,accepted)
 for id,claim in proof['qualified'].items():
  definition=read(project,claim['binding_definition'])
  found=[e for e in definition['events']['objects']if e['id']==id]
  if len(found)!=1 or digest(found[0])!=claim['binding_sha256']:raise SourceError('event binding differs')
  for owner in claim['owners']+claim['tests']:
   body=region(Path(project),owner)
   if body is None or hashlib.sha256(body.encode()).hexdigest()!=owner['sha256']:raise SourceError('event reviewed body changed')
  for test in claim['tests']:
   if canonical.get(test['accepted_name'])!={'name':test['accepted_name'],'ok':True}:raise SourceError('event actual canonical SDK test missing or failed')
   if not test['accepted_name'].endswith(': '+test['name']):raise SourceError('event assertion name differs')
  if not claim['owners']or not claim['tests']or not claim['scope']:raise SourceError('event claim lacks bounded proof')
 return proof['qualified']

def event_rows(project,matrix):
 inventory=read(project,'tools/references/kanto-inventory.json');pin=read(project,'tools/references/kanto-source.json');proof=read(project,'tools/references/event-coverage-review.json')
 assert inventory['revision']==pin['revision']==proof['source_revision']
 for owner in proof['observation_owners']:
  body=region(Path(project),owner)
  if body is None or hashlib.sha256(body.encode()).hexdigest()!=owner['sha256']:raise SourceError('event production observation body drift')
 assert proof['accepted_source_sha256']==matrix['snapshot']['source_sha256'],'event proof source context differs'
 qualified=reviewed_claims(project,proof);parents={r['source']['constant']:r for r in matrix['rows']if r['kind']=='map_slot'};rows=[]
 for decl in declarations(inventory,pin):
  parent=parents[decl['primary_map']];id=decl['event_id'];claim=qualified.get(id);observation=proof['observations'].get(id)
  notes='Declaration indexed only; current visibility, arrival/collision, script control flow and reachability are unqualified. Imported geometry or source ID never establishes an executable handler.'
  row={'id':'event:'+id,'kind':'source_event','title':id,'owner':'root','dependencies':['map:'+m['constant']for m in decl['map_slots']], 'due_milestone':copy.deepcopy(parent['due_milestone']),'source':decl,'notes':notes}
  for facet in FACETS:row[facet]={'implementation':'indexed','verification':'unrun','evidence':['kanto-inventory','kanto-pin'],'notes':notes}
  row['event_coverage']={'production':observation or {'state':'unreviewed','scope':'No per-event production audit or executed evidence claimed'},'qualification':claim['scope']if claim else None}
  if claim:
   binding=next(e for e in read(project,claim['binding_definition'])['events']['objects']if e['id']==id)
   args=decl['declaration']['args']
   if (binding['x'],binding['y'],binding['sprite'],binding['text_id'],binding['source_line'])!=(int(args[0]),int(args[1]),args[2],args[5],decl['line']):
    raise SourceError('reviewed runtime binding disagrees with pinned source declaration')
   # Bounded functionality only. Source words/art/all branches remain separate.
   for facet in ('campaign_path','full_mechanics'):row[facet]={'implementation':'partial','verification':'sdk_scoped','evidence':['current1091','event-review'],'notes':claim['scope']+' Controlled actual SDK case; not natural input/reachability or whole-event completion.'}
   row['regional_fidelity']={'implementation':'partial','verification':'source_only','evidence':['event-review','kanto-pin'],'notes':'Exact binding reviewed; complete source dialogue, art, audio, movement and all branches not accepted from scoped functionality test.'}
  if observation and observation['state']in ('rendered-handler-absent','conditionally-rendered-handler-absent','authored-roster-source-npc-absent'):
   row['regional_fidelity']['notes']='UNFINISHED REGIONAL WORK: '+observation['scope']
  rows.append(row)
 assert set(qualified)<={r['source']['event_id']for r in rows},'qualified event not declared'
 assert set(proof['observations'])<={r['source']['event_id']for r in rows},'production observation not declared'
 return rows

def expand(project,matrix):
 out=copy.deepcopy(matrix);out['rows']=[r for r in out['rows']if r['kind']!='source_event'];events=event_rows(project,out);out['rows'].extend(events)
 out['event_inventory_summary']={'total':len(events),'categories':{kind:sum(r['source']['category']==kind for r in events)for kind in CATEGORIES+('hidden',)},'qualified_scoped':sum(r['campaign_path']['verification']=='sdk_scoped'for r in events),'policy':'One row per unique object-table declaration, not per map alias; direct hidden coordinate declarations retain actual map ID. No script call/flag/connection is invented as an executed event.'}
 return out

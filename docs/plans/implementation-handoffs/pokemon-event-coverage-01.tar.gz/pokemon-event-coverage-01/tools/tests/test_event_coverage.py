"""Source per-event completeness and bounded evidence, never geometry-as-gameplay."""
import copy,json,shutil,tempfile,unittest
from pathlib import Path
from tools.verify_moves.parse_lua import ROOT
from tools.verify_moves.fetch_pokeapi import SourceError
from tools.check_coverage_matrix import validate
from tools.event_coverage import declarations,event_rows
from tools.build_event_coverage import build
class EventCoverageTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.data=json.loads((ROOT/'docs/validation/coverage-current.json').read_text());cls.events={r['id']:r for r in cls.data['rows']if r['kind']=='source_event'}
 def project(self):
  tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);p=Path(tmp.name)
  for d in ('Source','tools/references','docs/validation/coverage-evidence'):shutil.copytree(ROOT/d,p/d)
  # Accepted summary/current result resolve entirely inside this private project.
  shutil.copy2(ROOT/'docs/validation/coverage-current.json',p/'docs/validation/coverage-current.json')
  return p
 def test_exact_source_declarations_categories_and_stable_ids(self):
  self.assertEqual(len(self.events),2141)
  self.assertEqual(self.data['event_inventory_summary']['categories'],{'warps':805,'background_events':201,'objects':918,'hidden':217})
  for row in self.events.values():
   self.assertEqual(row['id'],'event:'+row['source']['event_id']);self.assertTrue(row['dependencies']);self.assertEqual(set(row['due_milestone']),{'campaign_path','regional_fidelity','full_mechanics'})
 def test_alias_tables_not_double_counted_or_exposed_as_unique_gameplay(self):
  row=self.events['event:pokered:LANCES_ROOM:objects:1']
  self.assertIn('map:UNUSED_MAP_6F',row['dependencies']);self.assertIn('map:LANCES_ROOM',row['dependencies'])
  self.assertFalse(any(id.startswith('event:pokered:UNUSED_MAP_6F:objects:')for id in self.events))
  hidden=self.events['event:pokered:UNUSED_MAP_6F:hidden:1'];self.assertEqual(hidden['source']['map_slots'][0]['slot_kind'],'unused_alias');self.assertEqual(hidden['campaign_path']['verification'],'unrun')
 def test_all_unqualified_events_stay_indexed_unrun(self):
  qualified={id for id,row in self.events.items()if row['campaign_path']['verification']=='sdk_scoped'}
  self.assertEqual(qualified,{'event:pokered:ROUTE_1:objects:1','event:pokered:VIRIDIAN_MART:objects:1','event:pokered:VIRIDIAN_POKECENTER:objects:1'})
  for id,row in self.events.items():
   if id not in qualified:
    for facet in ('campaign_path','regional_fidelity','full_mechanics'):self.assertEqual((row[facet]['implementation'],row[facet]['verification']),('indexed','unrun'))
   else:
    self.assertEqual(row['campaign_path']['implementation'],'partial');self.assertEqual(row['regional_fidelity']['verification'],'source_only')
 def test_rendered_npc_without_interaction_is_unfinished_not_complete(self):
  for map,index in [('PEWTER_CITY',3),('PEWTER_CITY',4),('PEWTER_GYM',3),('PEWTER_POKECENTER',3)]:
   row=self.events[f'event:pokered:{map}:objects:{index}'];self.assertEqual(row['event_coverage']['production']['state'],'rendered-handler-absent');self.assertIn('UNFINISHED',row['regional_fidelity']['notes']);self.assertEqual(row['campaign_path']['verification'],'unrun')
  self.assertEqual(self.events['event:pokered:PEWTER_CITY:objects:5']['event_coverage']['production']['state'],'conditionally-rendered-handler-absent')
  for i in (2,3):self.assertEqual(self.events[f'event:pokered:PALLET_TOWN:objects:{i}']['event_coverage']['production']['state'],'authored-roster-source-npc-absent')
 def test_event_omission_coordinate_alias_owner_due_and_fake_promotion_rejected(self):
  id='event:pokered:PEWTER_CITY:objects:3'
  for change in ('omit','coordinate','alias','owner','due','promote','hidden'):
   d=copy.deepcopy(self.data);row=next(r for r in d['rows']if r['id']==id)
   if change=='omit':d['rows'].remove(row)
   elif change=='coordinate':row['source']['declaration']['args'][0]='28'
   elif change=='alias':row['source']['map_slots'].append({'constant':'UNUSED_MAP_6F','slot_kind':'unused_alias'})
   elif change=='owner':row['owner']='rules'
   elif change=='due':row['due_milestone']['regional_fidelity']='postgame-release'
   elif change=='promote':row['campaign_path']['implementation']='integrated';row['campaign_path']['verification']='sdk_scoped'
   else:d['rows']=[r for r in d['rows']if r['id']!='event:pokered:UNUSED_MAP_6F:hidden:1']
   with self.subTest(change=change),self.assertRaises(AssertionError):validate(d,ROOT)
 def test_changed_handler_cannot_keep_event_qualification(self):
  p=self.project();f=p/'Source/game/eventState.lua';s=f.read_text();f.write_text(s.replace('function EventState:commit()','function EventState:commit()\n    error("controlled mutation")',1))
  with self.assertRaises(SourceError):event_rows(p,self.data)
 def test_source_id_with_fictitious_executed_test_cannot_promote(self):
  p=self.project();f=p/'tools/references/event-coverage-review.json';d=json.loads(f.read_text());d['qualified']['pokered:ROUTE_1:objects:1']['tests'][0]['accepted_name']='event-ui: invented passing source-id-only test';f.write_text(json.dumps(d))
  with self.assertRaises(SourceError):event_rows(p,self.data)
 def test_current_accepted_correctness_not_brock_milestone_and_deterministic_rebuild(self):
  self.assertEqual(self.data['snapshot']['acceptance_context'],'accepted-main-correctness1091');self.assertEqual(self.data['snapshot']['commit'],'82cb207');self.assertEqual(self.data['accepted_milestone_rows'],[])
  self.assertEqual(build(ROOT),self.data)
if __name__=='__main__':unittest.main()

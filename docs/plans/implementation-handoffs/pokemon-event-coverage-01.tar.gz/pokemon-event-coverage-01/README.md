# Per-event current coverage followup

Private-only patch against main82cb207, Source44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc. No Source, harness-driver, GitHEAD, Simulator/Data, mechanics, art, old packets or baseline writes. Root's active final journeys are not touched.

Apply only six manifest-listed patches and four new files. Full modified files are review copies; host-project/ is an independent private validation copy, NOT an application tree. Current matrix snapshot now labels accepted-main-correctness1091/base82cb207 per root's explicit committed acceptance. It retains zero accepted Brock milestones while the current all3 suite is pending. Existing1091 raw/summary,950/1059 history, all48 mechanic scopes/owner proofs and original full-goal layer/deadline/owner meanings are preserved.

The SAME canonical matrix has3642 rows: original1501 plus2141 source-event declarations (805warps,201backgrounds,918objects,217direct hidden coordinate controls). Every event has stable identity, source path/fileSHA/line/arguments, map dependency, root owner, separate campaign/fidelity/mechanics implementation+verification+evidence+deadline. Exactly one row represents each unique object-table declaration, with all alias map dependencies; direct hidden declarations retain their literal map ID. Unused/copy/hidden distinctions are not turned into reachable gameplay.

Pinned source revision remains af519899719f0754965776faac0e836a3b906e6d. source-pins.json records the exact existing inventory/pin hashes and224 consumed primary source-file references/checksums (223object tables+hidden_events.asm). There is no network/unpinned source fetch or generator/data rewrite. Macro declarations are read from the existing selected-Blue declarative manifest. No assembler/script interpreter/reachability solver is invented.

Conservative event facets default indexed/unrun. ONLY3 bounded portions get partial/sdk_scoped after independently checking their exact runtime object binding against pinned source coordinates/sprite/text/line, reviewed source/assertion bytes and canonical actual1091 passing tests: Route1 potion once/capacity/stale receipt; Viridian clerk post-parcel shop callback; Viridian nurse decline/heal/checkpoint/abort. They remain partial and regional fidelity is source_only, not full-event or full-map acceptance. Controlled EventState entry is not natural approach, source audio or every branch proof. SourceID/handler membership/geometry alone never promotes another event.

The explicit12 source-only unfinished NPC observations distinguish:
- PewterCity3/4,Gym3,Center3: instantiated source actors without interactive handlers.
- PewterCity5: conditionally visible before Brock; original escort control absent.
- ViridianCity2/3/6: instantiated source actors without handlers;5/7Pokedex-dependent presence without completed controls.
- PalletTown2/3: original girl/fisher missing from the authored roster, NOT falsely described as rendered. Protected authored BLUE remains untouched.

These observations are guarded by reviewed production-source regions/files and remain unrun event facets. No new native presence witness or new gameplay acceptance is claimed. Rendered props/actors and imported map readiness do not complete source interactions.

Tools/event_coverage.py exposes pure declaration expansion/evidence checks. tools/build_event_coverage.py rebuilds the existing canonical matrix or checks identical bytes. The strengthened validator recomputes exact event rows and rejects omitted declarations, altered coordinate/alias/owner/deadline/status/evidence, hidden/unused omission and unjustified promotion. Schema includes source_event/event_coverage/event_inventory_summary. Existing matrix tests update only actual rowcount/current accepted-correctness context; current all3Brock acceptance remains forbidden.

Validation:74 focused host tests PASS/0skip, final authoritative log host-tests-private.txt; exact deterministic build --check and matrix-check.json PASS. Eight new tests exercise declaration completeness/alias distinction/default-unrun behavior/real unfinished NPC mappings/coordinate+alias+owner+due+promotion mutants/changed handler/invented actual SDK name/current correctness-vs-Brock separation. Prior66 evidence-chain/source/assertion/verifier/matrix tests remain green. An initial wrong-working-directory host invocation is retained in host-tests.txt; it is not acceptance evidence and caused no Source/runtime writes. Worker ran no SDK/native/Simulator.

After root's active freeze ends and docs/tooling can be applied:

```
PYTHONDONTWRITEBYTECODE=1 /path/to/pillow-venv/bin/python -m unittest tools.tests.test_event_coverage tools.tests.test_current1091_refresh tools.tests.test_runtime_sdk_evidence tools.tests.test_runtime_move_coverage tools.tests.test_move_verifier tools.tests.test_coverage_matrix -v
python3 tools/build_event_coverage.py --project "$PROJECT" --output "$PROJECT/docs/validation/coverage-current.json" --check
python3 tools/check_coverage_matrix.py --project "$PROJECT" --matrix "$PROJECT/docs/validation/coverage-current.json"
```

Use the existing immutable B2W2 cache needed by verifier tests; no missing-input skips. Event check uses existing actual1091 bytes, not producer metadata or a fake SDK.

Remaining gaps: indexed declarations do not evaluate hide/show flags, source script state, approach/collision/arrival reachability, indirect script dispatch, coordinate-trigger tables, every text branch, connections, story prerequisites or audio. Those need source execution/control-flow and regional native acceptance later. Additional script events beyond the direct declaration categories are explicitly NOT certified complete. Route22/Moon remain separate private content; Mirror/other deferred mechanics are not promoted. Full campaign/events/original151/GenV/audio/device goals remain intact.

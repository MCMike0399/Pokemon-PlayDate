-- Retain session, Pokemon and Inventory identities; no callbacks after commit.
function GameSession:resolveTeaching(request,decision,slot)
    local plan,why=Teaching._commitPlan(self,request,decision,slot)
    if not plan then return false,why end
    if plan.bagData then
        local ok,problem=plan.bag:_replaceData(plan.bagData)
        if not ok then return false,problem end
        plan.pokemon.moves,plan.pokemon.pp=plan.moves,plan.pp
    end
    plan.request.status="complete"
    return true,plan.result
end

#!/usr/bin/env python3
"""Root-owned private SDK adapter; compile-only unless explicitly --execute."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--execute',action='store_true');p.add_argument('--scenario',type=Path);a=p.parse_args()
project=a.project.resolve();packet=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((packet/'manifest.json').read_text());original=harness.prepare

def prepare(project,sdk,output,session):
    metadata=original(project,sdk,output,session)
    for row in manifest['source_files']:
        path=row['path'];source=packet/path;live=project/path
        assert hashlib.sha256(source.read_bytes()).hexdigest()==row['sha256'],'packet drift '+path
        assert(hashlib.sha256(live.read_bytes()).hexdigest()if live.exists()else None)==row['base_sha256'],'owned base changed; review narrow merge '+path
        target=output/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted((output/'Source').rglob('*'))if x.is_file()and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    info.write_text(generated);values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        value=metadata[key];values.append('    '+key+' = '+('true'if value is True else json.dumps(value,ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['teaching_candidate']=manifest
    with(output/'teaching-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=None,output=str(a.output),scenario=str(a.scenario or packet/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

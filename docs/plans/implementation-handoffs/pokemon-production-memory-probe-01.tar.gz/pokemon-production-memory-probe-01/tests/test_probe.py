import importlib.util,json,tempfile,unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('production_probe_host',P/'probe.py');probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)
class ProbeTests(unittest.TestCase):
 def test_observation_preserves_every_original_main_line_and_call_order(self):
  original='import "CoreLibs/object"\nimport "dev/contracts"\nContracts.register("x",X.run)\nimport "game/fieldItems"\nimport "dev/autopilot"\ngame.saves:start()\nfunction playdate.update()\n    if Harness.isQuiescent then return end\n    updateGame()\nend\n'
  instrumented,inserted=probe.instrument_main(original);restored=[line for i,line in enumerate(instrumented.splitlines())if i not in set(inserted)]
  self.assertEqual(restored,original.splitlines());self.assertNotIn('if HarnessBuild.enabled',instrumented)
  self.assertLess(instrumented.index('ProductionProbe.afterFrame(game)'),instrumented.index('ProductionProbe.ready(game)'))
 def test_generated_false_is_lua_false_not_string_or_python_capital(self):
  self.assertEqual(probe.lua(False),'false');self.assertEqual(probe.lua(True),'true')
 def files(self,root):
  meta={'session_id':'s','build_id':'b','mode':'production','observer':'milestones','bundle_id':'probe.s','sdk_version':'3.1.2','frames':600}
  identity={'version':1,'run_id':'s','build_id':'b','mode':'production','observer':'milestones','bundle_id':'probe.s','sdk_version':'3.1.2','simulator':True,'lua_heap_only':True}
  samples=[{'label':label,'elapsed_ms':1,'lua_heap_kib':100}for label in ['frame300-full-gc:before','frame300-full-gc:after','final-full-gc:before','final-full-gc:after']]
  packets={'probe-ready.json':dict(identity,harness_enabled=False,input_functions_unchanged=True),'probe-startup.json':dict(identity,samples=[{'label':'startup-ready-before-publication','elapsed_ms':1,'lua_heap_kib':101}],sample_count=1),'probe-report.json':dict(identity,samples=samples,sample_count=4,frames=600,work={'count':600,'histogram':{'0':600}},gc_policy_changed=False,final_state={'harness_enabled':False,'input_functions_unchanged':True},observer_calibration={}), 'probe-done.json':dict(identity,complete=True,frames=600)}
  for name,packet in packets.items():(root/name).write_text(json.dumps(packet))
  return meta,packets
 def test_wrong_build_session_mode_and_simulator_identity_reject(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);meta,packets=self.files(root)
   for key in ['run_id','build_id','mode','observer','bundle_id','sdk_version']:
    wrong=dict(packets['probe-done.json']);wrong[key]='wrong'
    with self.assertRaises(RuntimeError):probe.validate_identity(wrong,meta)
   wrong=dict(packets['probe-done.json'],simulator=False)
   with self.assertRaises(RuntimeError):probe.validate_identity(wrong,meta)
 def test_production_input_wrapper_or_mailbox_cannot_pass_measurement(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);meta,packets=self.files(root);probe.verify(root,meta)
   (root/'request.json').write_text('{}')
   with self.assertRaisesRegex(RuntimeError,'harness artifacts'):probe.verify(root,meta)
   (root/'request.json').unlink();packets['probe-report.json']['final_state']['input_functions_unchanged']=False;(root/'probe-report.json').write_text(json.dumps(packets['probe-report.json']))
   with self.assertRaisesRegex(RuntimeError,'boundary violated'):probe.verify(root,meta)
 def test_missing_gc_or_incomplete_timing_and_producer_barrier_reject(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);meta,packets=self.files(root);packets['probe-report.json']['samples'].pop();(root/'probe-report.json').write_text(json.dumps(packets['probe-report.json']))
   with self.assertRaisesRegex(RuntimeError,'sample inventory'):probe.verify(root,meta)
   meta,packets=self.files(root);packets['probe-report.json']['work']['histogram']={'0':599};(root/'probe-report.json').write_text(json.dumps(packets['probe-report.json']))
   with self.assertRaisesRegex(RuntimeError,'timing inventory'):probe.verify(root,meta)
   meta,packets=self.files(root);packets['probe-done.json']['complete']=False;(root/'probe-done.json').write_text(json.dumps(packets['probe-done.json']))
   with self.assertRaisesRegex(RuntimeError,'producer barrier'):probe.verify(root,meta)
 def test_summary_keeps_sampled_peak_and_full_gc_as_separate_observations(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);meta,packets=self.files(root);report=probe.summarize(probe.verify(root,meta))
   self.assertEqual(report['observed_samples_peak_kib'],101);self.assertEqual(len(report['gc_observations']),4);self.assertIn('Not true peak',report['interpretation'])
if __name__=='__main__':unittest.main()

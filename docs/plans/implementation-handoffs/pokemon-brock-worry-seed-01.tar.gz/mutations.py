"""Controlled production-source mutants, executed only by the root-owned harness."""
from pathlib import Path
MUTATIONS={
 'native-contact':('Source/battle/effects.lua','local id=self:effectiveAbility(target)\n    if (id==9 or id==38)', 'local id=nativeAbility(target)\n    if (id==9 or id==38)'),
 'native-accuracy':('Source/battle/effects.lua','local ratio=4096;local a,d=handlers[self:effectiveAbility(attacker)],handlers[self:effectiveAbility(defender)]','local ratio=4096;local a,d=handlers[nativeAbility(attacker)],handlers[nativeAbility(defender)]'),
 'allow-sleep':('Source/battle/effects.lua','if self:effectiveAbility(mon)==15 and (status=="sleep" or status=="yawn")','if false and self:effectiveAbility(mon)==15 and (status=="sleep" or status=="yawn")'),
 'retain-switch':('Source/battle/effects.lua','    self.abilityOverrides[mon]=nil\n','    -- MUTANT retains outgoing override\n'),
 'post-accuracy-failure':('Source/battle/effects.lua','if move.attemptRule=="worrySeed" then return self:worrySeedAttempt(attacker,defender) end','if move.attemptRule=="worrySeed" then return true end'),
 'late-cure':('Source/battle/effects.lua','''    if wake then target.status,target.statusTurns,target.sleepDuration=nil,0,0 end
    self.battle:say(target.name.." acquired Insomnia!")''','''    self.battle:say(target.name.." acquired Insomnia!")
    if wake then target.status,target.statusTurns,target.sleepDuration=nil,0,0 end'''),
}
def apply(output,name):
 rel,before,after=MUTATIONS[name];path=Path(output)/rel;text=path.read_text()
 assert text.count(before)==1,'mutation context drift '+name
 path.write_text(text.replace(before,after,1))
 return {'id':name,'path':rel,'expected':'production SDK contract failure, not crash/success; root must inspect exact failing group'}

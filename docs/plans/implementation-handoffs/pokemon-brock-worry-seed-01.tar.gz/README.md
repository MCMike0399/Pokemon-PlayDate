# Worry Seed / Insomnia — staged, SDK/native acceptance pending

This packet implements the actual Bulbasaur grind-tail Worry Seed dependency without changing saved abilities. `BattleEffects:effectiveAbility(mon)` is the single query owner for all **19 existing battle-hook call sites**. An identity-keyed map stores only this battle's Worry Seed→Insomnia override. `Pokemon:ability()`, abilitySlot/nature/sex/held provenance, codec/evolution and field Specimen/Compound Eyes queries remain intrinsic and unchanged. There is no arbitrary setAbility API or Skill Swap/Transform producer.

`worrySeedAttempt(source,target)` is a pure internal eligibility query. `worrySeed(source,target)` is the bounded internal resolved-hit commit, fixed to Insomnia15. Both reject foreign/inactive/self/fainted/closed identities. Unknown/non-Gen5 ability IDs reject without mutation or RNG. These are DSL-owned rule helpers; the public battle command's existing phase/selection/PP guards remain authoritative. Legitimate failed Worry Seed attempts still spend PP, as Gen V requires.

The source-backed order is exact: Insomnia15/Truant54 fail before accuracy; Multitype121 fails at hit after accuracy. A hit replaces the effective ability and cures sleep immediately. Override and persistent cure commit together **before the first presentation yield**, preserving the acquired→woke message order while making cancellation safe. Sleep counters both reset0. Other major statuses and confusion remain unchanged. The shared status predicate blocks sleep before duration RNG; it also exposes the correct Yawn immunity predicate for a future real Yawn producer. Natural Insomnia entry cures sleep through the existing entry lifecycle.

All enabled old hooks now use the effective query: low-HP typed boosts, Guts/burn, Compound Eyes/Tangled Feet/Sand Veil accuracy, Sturdy/OHKO, Static/Poison Point receipts, Shield Dust, Keen Eye, Run Away, Rock Head, Arena Trap, Shed Skin, Captivate/Oblivious, Immunity, Own Tempo and Rivalry. Item-owned Light Ball remains independent. Overrides clear on actual withdrawal and battle close. Faint cleanup runs in handleFaint **after** contact callbacks, so a KO cannot reactivate overwritten Static/Poison Point for the final receipt.

## Integration

Frozen prerequisites: root integration02 +power-order01 +Rain01 +strict root producer v8. `manifest.json` pins Rain manifest, root producer and exact before/after hashes. Apply Rain first; then apply only our three `patches/*.patch` with `git apply -p0`. Copy only `Source/dev/worrySeedContracts.lua` and register:

```lua
import "dev/worrySeedContracts"
Contracts.register("worry-seed",WorrySeedContracts.run)
```

The other Source bodies are review contexts, **not whole-file overlays**. Separate proposed root-owned `root-hooks/diagnostics.patch` adds `battle.effective_abilities.{player,enemy}` beside unchanged intrinsic `ability_id`; root merges it for native recipes. No live Source/main/diagnostics/world/codec or art files were written.

Root's strict generated producer is `/private/tmp/pokemon-root-producer-v8/Source/battle/moves.lua`, SHA256 `09458befd8616a2e64ed5caa69eb672bcea6b7a556b43f565b18d358cb6d280b`. Relative to v7 only Worry's attemptRule and WorrySeedEffect change, no constructor delta. It includes the real Rain v7 dependency; this helper explicitly composes Rain, never invents its availability or an epoch fixture. `root-generator-request.json` records the exact row request. Root reports39 strict producer host tests pass, and independently replayed the actual PS probe with matching hash; those producer tests are root evidence, not worker runtime execution.

## Validation performed

- Actual pinned compiled Showdown `gen5customgame` real-input choices personally executed in `actual-showdown-01.json`; probe wrapped/delegated original PRNG and left rule callbacks unchanged. Original151 species/custom learnsets; illegal Truant/Multitype/Wonder Guard on Pikachu are labeled generic rule fixtures, not acquisition claims. Every attempt spends1 PP. PS defaults boosted PP16→15, whereas the preserved game row uses unboosted10→9; only the decrement is compared.
- Actual engine: Static and Wonder Guard replace; existing Insomnia/Truant skip accuracy; Multitype consumes accuracy then rejects; miss leaves Static; sleeping target wakes before its same-turn Splash; repeat fails; actual switch/return restores Static on the same original object.
- `audit_sources.py`:3 immutable C inputs +18 source/actually loaded engine hashes and exact root v8 producer verified. C Worry Seed early exclusions, Multitype/fainted ability-change guard, event-owner replacement and Insomnia guard/cure hooks agree with the maintained PS path. Primary URLs/commits/hashes are in `source-manifest.json`.
- `test_packet.py`:8 host groups PASS,0 skips (`host-tests-03.log`), including source ownership, all query migration, actual reference values and six exact mutation contexts.
- Actual SDK compile-only `/private/tmp/pokemon-brock-worry-seed-compile-04` PASS with real Rain dependency, strict root v8 and diagnostic hook. No fake SDK.
- Six controlled production-source mutant builds compile (`mutant-compile-02.json`); **none were executed**, so rejection remains a root requirement.

**22 new production SDK groups are authored and unrun**. They cover producer payload; PP/RNG/failure timing; misses; immediate sleep cure including remaining0; cancellation at first message; actual SleepPowder; natural Insomnia; non-sleep preservation; foreign/stale/closed/invalid IDs; every enabled old ability ID; actual old-hook suppression; independent Light Ball; final contact KO ordering; real party switch/return; and codec/native provenance after close. Existing original16 ability, sex, charge, power, held, capture and learning suites must remain green. No existing expectation was relaxed.

## Root commands and native evidence

```sh
python3 /private/tmp/pokemon-brock-worry-seed-01/test_packet.py
python3 /private/tmp/pokemon-brock-worry-seed-01/audit_sources.py --showdown /private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547 --producer /private/tmp/pokemon-root-producer-v8/Source/battle/moves.lua
python3 /private/tmp/pokemon-brock-worry-seed-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-worry-root-build --rain-stage /private/tmp/pokemon-brock-rain-01 --moves /private/tmp/pokemon-root-producer-v8/Source/battle/moves.lua --with-diagnostics
```

Default is compile-only. Root alone may add `--execute` with a fresh output path to run actual contracts. After Rain/v8/root diagnostics are integrated, the explicit Rain/moves options can be omitted only when the strict dependencies already match.

Three real-input recipes under `scenarios/` require actual PNGs: `worry-seed-static`, `worry-seed-sleep-cure`, `worry-seed-natural-insomnia`. Each uses a labeled trainer fixture, **legal default Bulbasaur31 Worry Seed slot4**, actual intro acknowledgements, actual menu inputs, PP/native/effective ability/status assertions and a required readable battle screenshot. These are controlled rule/UI qualifications, not a natural campaign completion claim. Run helper with `--execute --scenario STAGE/scenarios/NAME.json --with-diagnostics` and a fresh output. Their expected RNG totals are2 on hit and1 on Insomnia failure: one real enemy-AI choice plus1/0 accuracy, paused before enemy action. SDK direct resolveTurn cases deliberately isolate accuracy to1/0.

Negative qualification uses `--mutation NAME`, with each private output preserved. Names: `native-contact`, `native-accuracy`, `allow-sleep`, `retain-switch`, `post-accuracy-failure`, `late-cure`. Root must require actual **contract failure**, inspect the corresponding named group, and reject crashes/missing artifacts or an unexpected successful run. Compilation alone is not mutation qualification. Original candidate stays frozen.

## Explicit limits

Worry Seed and current sleep-producing DSL paths are implemented; this does not implement the still-unowned Rest or Yawn move lifecycles, global ability suppression, Skill Swap, Transform, new species/abilities' acquisition, or arbitrary raw Lua status-field mutations. The Yawn predicate is correct and exposed but no Yawn duration owner is invented. Unsupported old ability effects are not certified merely because Worry Seed can legally overwrite their Gen5 IDs. No native screenshots, SDK pass count or campaign completion is claimed before root execution/review.

Primary maintained source: [Worry Seed](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/moves.ts), [Insomnia](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/abilities.ts), [setAbility and switch reset](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/sim/pokemon.ts). Independent pinned decompilation: [move handlers](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/move_handlers.c), [ability handlers](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/ability_handlers.c), [ability-change owner](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/btl_server_flow.c). This is source-based qualification, not cartridge execution.

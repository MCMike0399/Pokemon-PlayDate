#!/usr/bin/env python3
"""Private SDK compile by default; root alone may request owned execution."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__)
for key in ('project','output'):p.add_argument('--'+key,required=True)
p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--rain-stage',type=Path);p.add_argument('--moves',type=Path);p.add_argument('--with-diagnostics',action='store_true');p.add_argument('--mutation',choices=['native-contact','native-accuracy','allow-sleep','retain-switch','post-accuracy-failure','late-cure']);a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def patch(output,path,strip=0):
 result=subprocess.run(['git','apply','-p'+str(strip),'--check',str(path)],cwd=output,capture_output=True,text=True)
 if result.returncode:
  reverse=subprocess.run(['git','apply','-p'+str(strip),'--reverse','--check',str(path)],cwd=output,capture_output=True,text=True)
  assert reverse.returncode==0,'patch conflict '+str(path)+': '+result.stderr;return
 subprocess.run(['git','apply','-p'+str(strip),str(path)],cwd=output,check=True)
def prepare(project,sdk,output,session):
 metadata=original(project,sdk,output,session);modules=[('worrySeedContracts','worry-seed','WorrySeedContracts')]
 if a.rain_stage:
  dep=manifest['rain_dependency'];assert sha(a.rain_stage/'manifest.json')==dep['manifest_sha256'],'Rain owner manifest drift'
  rain=json.loads((a.rain_stage/'manifest.json').read_text())
  for row in rain['source_files']:
   if row['path']in dep['engine_paths']:
    owner=a.rain_stage/row['patch'];assert sha(owner)==row['patch_sha256'],'Rain owner patch drift';patch(output,owner,1)
   elif row['path']==dep['contracts']:
    owner=a.rain_stage/row['path'];assert sha(owner)==row['sha256'];shutil.copy2(owner,output/row['path'])
  modules.append(('rainContracts','rain','RainContracts'))
 assert 'Class("WeatherEffect")'in(output/'Source/battle/dsl.lua').read_text(),'requires real v7 Rain dependency; pass --rain-stage or a fully composed project'
 assert 'conditions:rawPower' in(output/'Source/battle/battle.lua').read_text(),'requires accepted power-order dependency'
 for row in manifest['patches']:
  path=stage/row['path'];assert sha(path)==row['sha256'];patch(output,path)
 for row in manifest['new_source']:
  path=stage/row['path'];assert sha(path)==row['sha256'];shutil.copy2(path,output/row['path'])
 if a.moves:
  assert sha(a.moves)==manifest['producer']['sha256'],'strict root v8 producer drift';shutil.copy2(a.moves,output/'Source/battle/moves.lua')
 else:assert sha(output/'Source/battle/moves.lua')==manifest['producer']['sha256'],'requires strict root v8 producer; pass --moves'
 if a.with_diagnostics:
  for row in manifest['root_hooks']:
   path=stage/row['path'];assert sha(path)==row['sha256'];patch(output,path)
 if a.mutation:
  sys.path.insert(0,str(stage));from mutations import apply
  metadata['controlled_mutation']=apply(output,a.mutation)
 main=output/'Source/main.lua';text=main.read_text();anchor='import "dev/catalog"';assert text.count(anchor)==1
 for module,key,klass in modules:
  line='import "dev/'+module+'"'
  if line not in text:text=text.replace(anchor,line+'\nContracts.register("'+key+'",'+klass+'.run)\n'+anchor,1)
 main.write_text(text)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated);values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['worry_seed']=manifest
 with(output/'worry-seed-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

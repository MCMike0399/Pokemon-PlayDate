from pathlib import Path
import shutil,difflib
s=Path(__file__).resolve().parent;root=Path('/private/tmp/pokemon-brock-rain-01')
for name in ('effects.lua','dsl.lua','battle.lua'):
 shutil.copy2(root/'Source/battle'/name,s/'base/Source/battle'/name);shutil.copy2(root/'Source/battle'/name,s/'Source/battle'/name)
p=s/'Source/battle/effects.lua';t=p.read_text();t=t.replace('local function ability(mon)','local function nativeAbility(mon)',1)
# Every enabled battle hook resolves through its actual Battle owner.
import re
t=re.sub(r'(?<![\w:])ability\(', 'self:effectiveAbility(',t)
t=t.replace('handlers[20]={}','handlers[20],handlers[15]={},{}',1)
t=t.replace('self.closed=false;self.round=nil','self.closed=false;self.round=nil;self.abilityOverrides={}',1)
anchor='function BattleEffects:supported(id)'
methods='''-- Volatile identity-keyed ability changes never alter specimen slots/provenance.
function BattleEffects:effectiveAbility(mon)
    local override=self:active(mon) and self.abilityOverrides[mon]
    return override or nativeAbility(mon)
end
function BattleEffects:worrySeedAttempt(source,target)
    if not self:active(source) or not self:active(target) or source==target
        or not alive(source) or not alive(target) then return false,"stale-ability-target" end
    local id=self:effectiveAbility(target)
    if type(id)~="number" or not math.tointeger(id) or id<1 or id>164 then return false,"unsupported-ability" end
    if id==15 or id==54 then return false,"unchangeable-ability" end
    return true
end
function BattleEffects:worrySeed(source,target)
    local allowed,reason=self:worrySeedAttempt(source,target)
    if not allowed then return false,reason end
    -- GenV Multitype is checked after accuracy, at the actual ability-change hit.
    if self:effectiveAbility(target)==121 then return false,"unchangeable-ability" end
    local wake=target.status=="sleep"
    self.abilityOverrides[target]=15
    -- Commit the persistent cure before any presentation yield/cancellation.
    if wake then target.status,target.statusTurns,target.sleepDuration=nil,0,0 end
    self.battle:say(target.name.." acquired Insomnia!")
    if wake then self.battle:say(target.name.." woke up with Insomnia!") end
    return true
end
'''
assert t.count(anchor)==1;t=t.replace(anchor,methods+anchor,1)
t=t.replace('function BattleEffects:canAttempt(move,attacker,defender)\n','function BattleEffects:canAttempt(move,attacker,defender)\n    if move.attemptRule=="worrySeed" then return self:worrySeedAttempt(attacker,defender) end\n',1)
t=t.replace('function BattleEffects:statusImmunity(mon,status)\n','function BattleEffects:statusImmunity(mon,status)\n    if self:effectiveAbility(mon)==15 and (status=="sleep" or status=="yawn") then return "Insomnia" end\n',1)
t=t.replace('    if not self:active(mon) or not alive(mon) then return false end\n    if self:statusImmunity','    if not self:active(mon) or not alive(mon) then return false end\n    if mon.status=="sleep" and self:statusImmunity(mon,"sleep")=="Insomnia" then\n        mon.status,mon.statusTurns,mon.sleepDuration=nil,0,0\n        self.battle:say(mon.name.." woke up with Insomnia!")\n        return true\n    end\n    if self:statusImmunity',1)
t=t.replace('function BattleEffects:clear(mon)\n','function BattleEffects:clear(mon)\n    self.abilityOverrides[mon]=nil\n',1)
t=t.replace('function BattleEffects:close() self:endRound();','function BattleEffects:close() self.abilityOverrides={};self:endRound();',1)
assert 'local function nativeAbility(mon) return mon and mon.ability and mon:ability() or 0 end'in t
assert not re.search(r'(?<![\w:])ability\(',t)
p.write_text(t)
p=s/'Source/battle/dsl.lua';t=p.read_text();anchor='Class("FocusEnergyEffect")';body='''Class("WorrySeedEffect")
function WorrySeedEffect:apply(battle)
    local ok=battle.effects:worrySeed(battle.attacker,battle.defender)
    if not ok then battle:say("But it failed!") end
end

''';assert t.count(anchor)==1;t=t.replace(anchor,body+anchor,1);p.write_text(t)
p=s/'Source/battle/battle.lua';t=p.read_text()
for side in ('player','enemy'):
 old=f'if not self.{side}:isAlive() then self.conditions:clear(self.{side}) end'
 new=f'if not self.{side}:isAlive() then self.conditions:clear(self.{side});self.effects:clear(self.{side}) end'
 assert t.count(old)==1;t=t.replace(old,new)
p.write_text(t)
for p in (s/'base/Source/battle').glob('*.lua'):
 rel=p.relative_to(s/'base');new=s/rel
 (s/'patches'/('__'.join(rel.parts)+'.patch')).write_text(''.join(difflib.unified_diff(p.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(rel),tofile=str(rel),n=3)))
print('Prepared three narrow source patches')

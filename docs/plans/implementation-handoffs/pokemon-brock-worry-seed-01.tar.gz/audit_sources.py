#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--showdown',type=Path,required=True);p.add_argument('--producer',type=Path);a=p.parse_args();s=Path(__file__).resolve().parent
m=json.loads((s/'source-manifest.json').read_text())
for row in m['references']:assert hashlib.sha256((s/row['path']).read_bytes()).hexdigest()==row['sha256'],'C source drift '+row['path']
for row in m['compiled_engine_inputs']:assert hashlib.sha256((a.showdown/row['file']).read_bytes()).hexdigest()==row['sha256'],'PS source/engine drift '+row['file']
if a.producer:assert hashlib.sha256(a.producer.read_bytes()).hexdigest()==json.loads((s/'manifest.json').read_text())['producer']['sha256'],'strict root producer drift'
print('Verified 3 pinned C inputs + 18 compiled-engine/source inputs'+(' + strict root v8 producer'if a.producer else ''))

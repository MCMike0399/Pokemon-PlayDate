import hashlib,json,re,tempfile,unittest
from pathlib import Path
from mutations import MUTATIONS,apply
S=Path(__file__).resolve().parent
class PacketTests(unittest.TestCase):
 def test_all_packet_source_hashes(self):
  m=json.loads((S/'manifest.json').read_text())
  for r in m['patches']+m['new_source']+m['root_hooks']:self.assertEqual(hashlib.sha256((S/r['path']).read_bytes()).hexdigest(),r['sha256'])
 def test_actual_primary_eligibility_and_PP(self):
  j=json.loads((S/'actual-showdown-01.json').read_text());self.assertEqual([r['after']['ability']for r in j['rows']],['insomnia','insomnia','truant','multitype','insomnia','insomnia','static'])
  self.assertEqual([r['before']['pp']-r['after']['pp']for r in j['rows']],[1]*7)
  self.assertEqual([len([d for d in r['draws']if d['args']==[100]])for r in j['rows']],[1,0,0,1,1,1,1])
  self.assertEqual(j['unreplaceableGen5'],[{'id':'multitype','num':121}])
 def test_actual_immediate_cure_and_switch_restore(self):
  j=json.loads((S/'actual-showdown-01.json').read_text());r=j['rows'][5]
  self.assertEqual(r['before']['status'],'slp');self.assertEqual(r['after']['status'],'')
  cure=next(i for i,l in enumerate(r['log'])if l.startswith('|-curestatus|'))
  splash=next(i for i,l in enumerate(r['log'])if '|Splash|'in l);self.assertLess(cure,splash)
  self.assertEqual(j['lifecycle'][-1],{'stage':'return','ability':'static','sameIdentity':True})
 def test_all_enabled_queries_have_one_owner(self):
  text=(S/'Source/battle/effects.lua').read_text()
  self.assertEqual(text.count('mon:ability()'),1);self.assertEqual(text.count('nativeAbility('),2)
  self.assertFalse(re.search(r'(?<![\w:])ability\(',text))
  old=(S/'base/Source/battle/effects.lua').read_text()
  self.assertGreaterEqual(len(re.findall(r'(?<![\w:])ability\(',old)),18)
 def test_raw_specimen_fields_never_written(self):
  text=(S/'Source/battle/effects.lua').read_text()
  self.assertFalse(re.search(r'\.(abilitySlot|abilityProvenance|natureId|sexProvenance|heldItem)\s*=(?!=)',text))
  self.assertNotIn('Source/data/',str(list((S/'patches').glob('*'))));self.assertNotIn('Source/domain/',str(list((S/'patches').glob('*'))))
 def test_declared_new_contract_inventory(self):
  text=(S/'Source/dev/worrySeedContracts.lua').read_text();self.assertEqual(text.count(' test("'),22)
  for p in (S/'scenarios').glob('*.json'):
   d=json.loads(p.read_text());self.assertTrue(d['outputs']);self.assertIn('shot '+d['outputs'][0][:-4],d['commands'])
 def test_each_actual_source_mutant_has_exact_context(self):
  for name,(rel,before,after)in MUTATIONS.items():
   with tempfile.TemporaryDirectory()as d:
    target=Path(d)/rel;target.parent.mkdir(parents=True);original=(S/rel).read_text();target.write_text(original)
    self.assertEqual(original.count(before),1,name);record=apply(d,name);self.assertEqual(record['id'],name)
    self.assertEqual(target.read_text(),original.replace(before,after,1));self.assertNotEqual(original,target.read_text())
 def test_contact_native_query_mutant_breaks_single_owner_qualification(self):
  text=(S/'Source/battle/effects.lua').read_text();_,before,after=MUTATIONS['native-contact'];mutant=text.replace(before,after)
  self.assertEqual(text.count('nativeAbility('),2);self.assertEqual(mutant.count('nativeAbility('),3)
if __name__=='__main__':unittest.main(verbosity=2)

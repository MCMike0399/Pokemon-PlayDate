# Reviewable current coverage/report packet

Base main `d9f57ea`, Source `49832dd1c89953784f13c65a54f21a63771ae7b9b73ef16b405a8118932c8386`. Private1059 Source `7f2f4eda2d8e3d1fd0c0d2b63eb7ad4a824a290d7bf1e42ae421a9f16e8e2979` is separately labeled, never promoted into main. No live Source, Simulator/Data, generator, art/baseline or frozen packet edits.

Apply only manifest-listed patches/new files. `host-project/`, `private-source-view/`, research snapshots and builders are worker validation context, **not copy-over instructions**. Root-owned progress/goal hooks are separate optional documentation patches. Mirror implementation remains stopped before code: its fresh packet contains only the immutable approved baseline; no Mirror behavior is added here.

Deliverables:

- One `docs/validation/coverage-current.json` (1501 indexed rows) and `coverage.schema.json`, with independent path/fidelity/full-mechanics states, owners, evidence/dependencies and per-layer deadlines. Full original campaign/postgame/audio/naming/options/availability/trades/balance/resource/device scope retained.
- `coverage-current.md` explains current-batch correctness/safeNewGame→all3Brock freeze scheduling and full release requirements without dropping moves/species or adding a grindcap.
- Narrow verifier compare/main patches +new runtime_coverage.py and48-record main950 source/test registry. Exact reviewed handler regions/assertions and accepted SDK names replace false-missing guesses. No producer import or field-presence promotion. Unchanged Protect/charge/crit bodies remain recognized across unrelated private reward changes; actual changed evidence is stale, not missing/complete.
- Separate private1059/Bide29 registry +actual root result/summary. Only private Bide proof is refreshed; it cannot quietly qualify main or the rest of a private engine.
- Historical417/135, static419 and full34-row erratum retained unchanged; copied final evidence is byte-identical.25 scoped/9downgraded preserved. HelpingHand stays source-only verification-pending. No whole425/111 mechanics claim.

Validation:47 focused host tests PASS/0skip, including all existing move-verifier cases and meaningful owner/assertion/metadata/PP evidence mutants; layer/private/source/inventory/dependency rejection cases. Matrix exact rebuild/check passes. Main full425/151 verifier keeps exit1 intentionally:0 scalar/learnset failures,9 curated known gaps,93 review-required,37 scoped-evidence rows,285 runtime-unreviewed. `runtime_semantics_complete=false`. Counts are diagnostic partitions, never accepted gameplay totals. Private-source view independently qualifies Bide as `private-root-verified-not-main`. No new SDK/native was run.

Root review commands after applying this packet:

```
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest tools.tests.test_move_verifier tools.tests.test_runtime_move_coverage tools.tests.test_coverage_matrix -v
python3 tools/check_coverage_matrix.py --project "$PROJECT" --matrix "$PROJECT/docs/validation/coverage-current.json"
python3 tools/verify_moves/main.py --cache "$PINNED_B2W2_CACHE" --output /private/tmp/current-verifier-UNIQUE.json
```

The actual worker cache was `tools/verify_moves/cache/b2w2/2bf639e5572812a67d2b94903fdcb9d095f5aeb2`; standard tests require those immutable inputs and never silently skip. Existing `--fetch` may populate missing verified cache. The main CLI's expected current result is **nonzero1** while known gaps/reviews remain. Source/schema errors remain2. Tiny existing scalar fixtures preserve their data-only success contract, while fullruntime remains explicitly false.

`build.py` regenerates the matrix from explicit project/reference/exposure/erratum/held-index inputs; --check checks bytes and source pins without overwriting evidence. Source inventory itself remains indexed rather than treated as executable control-flow/reachability proof. Builders are private preparation aids, not a new runtime framework.

Root must integrate/rerun before calling this accepted current tooling. On later source changes, update only evidence that was actually rerun/reviewed. Do not replace declared hashes merely to turn a stale source green. Physical device remains unrun; no Simulator measurement proves device fit.

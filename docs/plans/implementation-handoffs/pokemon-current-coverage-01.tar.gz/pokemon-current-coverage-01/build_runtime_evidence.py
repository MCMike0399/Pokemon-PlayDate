"""Freeze reviewed owners/assertions, never use generated flags as an oracle."""
from pathlib import Path
import hashlib,json,re,sys
sys.dont_write_bytecode=True
P=Path('/Users/burbujamc/Developer/Pokemon-PlayDate');S=Path(__file__).resolve().parent
sys.path.insert(0,str(P));from tools.verify_moves.parse_lua import read_moves,Expression
sha=lambda b:hashlib.sha256(b).hexdigest()
def primitive(v):
 if isinstance(v,Expression):return v.text
 if isinstance(v,dict):return{k:primitive(x)for k,x in v.items()}
 if isinstance(v,list):return[primitive(x)for x in v]
 return v
moves=read_moves(P/'Source/battle/moves.lua');old=json.loads(Path('/private/tmp/pokemon-mirror-move-proposal-01/audit-erratum/final.json').read_text());result=Path('/private/tmp/pokemon-root-sides-sdk-01/00001-result.json');sdk=json.loads(result.read_text());tests=next(r['contracts']['tests']for r in sdk['results']if r.get('contracts'))
def owner(file,start):
 text=(P/file).read_text();lines=text.splitlines(keepends=True);indices=[i for i,line in enumerate(lines)if line.startswith(start)];assert len(indices)==1,start;i=indices[0]
 one=lines[i].rstrip().endswith(' end')
 if one:body=lines[i]
 else:
  j=next(j for j in range(i+1,len(lines))if lines[j].strip()=='end'and lines[j].startswith('end'));body=''.join(lines[i:j+1])
 return{'path':file,'start':start,'function_body':True,'one_line':one,'sha256':sha(body.encode())}
def exact(file,start):
 text=(P/file).read_text();lines=[line for line in text.splitlines(keepends=True)if line.lstrip().startswith(start)];assert len(lines)==1,start
 return{'path':file,'start':start,'exact_line':True,'sha256':sha(lines[0].encode())}
def fragment(file,start,end):
 text=(P/file).read_text();i=text.index(start);j=text.index(end,i+len(start));return{'path':file,'start':start,'end':end,'sha256':sha(text[i:j].encode())}
def case(file,name):
 path='Source/dev/'+file+'.lua';text=(P/path).read_text();matches=list(re.finditer(r'\btest\("([^"]+)"',text));m=next(x for x in matches if x[1]==name);i=matches.index(m)
 if i+1<len(matches):end=matches[i+1].group(0);endpos=matches[i+1].start()
 else:end='    return report';endpos=text.index(end,m.end())
 found=[t for t in tests if t['name']==name or t['name'].endswith(': '+name)];assert len(found)==1 and found[0]['ok']is True
 return{'path':path,'start':m.group(0),'end':end,'sha256':sha(text[m.start():endpos].encode()),'name':name,'accepted_name':found[0]['name'],'executed':found[0]}
common=[owner('Source/battle/battle.lua','function Battle:performMove('),owner('Source/battle/battle.lua','function Battle:resolveTurn(')]
calc=owner('Source/battle/battle.lua','function calcDamage(')
records={}
requirements={'protect':['protection','status-dispatch'],'solarBeam':['charge/weather'],'skullBash':['charge'],'electroBall':['variable-power-dispatch'],'endeavor':['fixed-damage-dispatch'],'focusEnergy':['status-dispatch'],'ragePowder':['intentional-singles-failure'],'rainDance':['status-dispatch'],'lightScreen':['status-dispatch'],'safeguard':['status-dispatch'],'tailwind':['status-dispatch'],'worrySeed':['status-dispatch'],'captivate':['status-dispatch']}
for row in old['rows']:
 key=row['move'];body=row['meaningful_case'];cases=[]
 if body:
  file=Path(body['file']).stem;cases=[case(file,body['name'])]
  for more in row.get('additional_meaningful_cases',[]):cases.append(case(Path(more['file']).stem,more['name']))
 caps=requirements.get(key,['ordinary-hit'])
 if key in('razorLeaf','slash','nightSlash','shadowClaw','stoneEdge'):caps=['critical-stage']
 state='verified_subset'if body else'source_gap'
 records[key]={'state':state,'capabilities':caps,'definition_sha256':sha(json.dumps(primitive(moves[key]),sort_keys=True,separators=(',',':')).encode()),'owners':common+[calc],'tests':cases,'scope':row['reason']}
# Explicit source owners and meaningful accepted cases for the corrections.
for key in('solarBeam','skullBash'):records[key]['owners'].append(owner('Source/battle/conditions.lua','function BattleConditions:charge('))
records['protect']['owners'].append(owner('Source/battle/conditions.lua','function BattleConditions:protect('))
criticalOwners=[calc,owner('Source/battle/effects.lua','function BattleEffects:criticalStage('),owner('Source/battle/effects.lua','function BattleEffects.criticalDenominator(')]
criticalCases=[case('brockMechanicsContracts','All16 generated high-critical moves add one; forcedcrit is never a stage6 clamp'),case('brockMechanicsContracts','Each critical stage passes and fails literal roll endpoints through actual damage')]
for key,row in moves.items():
 if row.get('critStage')==1 or row.get('willCrit'):
  item=records.setdefault(key,{'state':'verified_subset','capabilities':[],'definition_sha256':sha(json.dumps(primitive(row),sort_keys=True,separators=(',',':')).encode()),'owners':[],'tests':[],'scope':'Only high/forced critical metadata and shared damage-stage endpoints accepted; other move behavior remains independent.'})
  cap='forced-critical'if row.get('willCrit')else'critical-stage'
  if cap not in item['capabilities']:item['capabilities'].append(cap)
  item['owners']+=criticalOwners;item['tests']+=criticalCases
  if row.get('willCrit'):item['tests'].append(case('brockMechanicsContracts','Forced critical bypasses critical RNG and fixed damage cannot crit with Focus'))
records['bide']={'state':'verified_subset','capabilities':['fixed-damage-dispatch'],'definition_sha256':sha(json.dumps(primitive(moves['bide']),sort_keys=True,separators=(',',':')).encode()),'owners':common+[owner('Source/battle/conditions.lua','function BattleConditions:bide('),owner('Source/battle/conditions.lua','function BattleConditions:bideHit(')],'tests':[case('bideContracts','Actual public Bide stores2rounds releases3rd for160 and spends PP only once')],'scope':'Actual canonical Bide storage/release/PP assertion, not a zero-power no-op. Other scoped Bide tests/nativeC Protect policy retained.'}
records['helpingHand']={'state':'source_only','capabilities':[],'definition_sha256':sha(json.dumps(primitive(moves['helpingHand']),sort_keys=True,separators=(',',':')).encode()),'owners':common+[owner('Source/battle/battle.lua','function Battle:moveHasTarget(')],'tests':[],'scope':'Source explicitly rejects ally target3/15 in singles after PP; no exact direct HelpingHand SDK/native proof yet.'}
# Pin meaningful owned bodies/dispatch fragments, not unrelated whole files.
# A reward/XP implementation change cannot make unchanged Protect "missing".
B='Source/battle/battle.lua';E='Source/battle/effects.lua';C='Source/battle/conditions.lua';D='Source/battle/dsl.lua';M='Source/battle/moves.lua'
crit=[owner(E,'function BattleEffects:criticalStage('),owner(E,'function BattleEffects.criticalDenominator('),exact(E,'local critDenominators <const>'),fragment(B,'    -- Gen V critical stages','    -- Pick offensive/defensive stats'),fragment(B,'    if isCrit then\n        damage = damage * 2','    damage = math.floor(damage * RulesRNG'),exact(M,'self.critStage ='),exact(M,'self.willCrit =')]
for key,entry in records.items():
 if 'critical-stage'in entry['capabilities']or'forced-critical'in entry['capabilities']:entry['owners']=crit;continue
 if key=='protect':
  entry['owners']=[owner(C,'function BattleConditions:protect('),owner(C,'function BattleConditions.protectSucceeds('),owner(C,'function BattleConditions:blocks('),owner(C,'function BattleConditions:endRound('),owner(D,'function ProtectEffect:apply('),fragment(B,'    -- GenV TryHit protection follows','    -- Move-specific failure'),exact(M,'self.protectable ='),exact(M,'self.effects =')]
 elif key in('solarBeam','skullBash'):
  entry['owners']=[owner(C,'function BattleConditions:charge('),owner(E,'function BattleEffects.solarPolicy('),fragment(B,'    -- Charging is a TryMove','    -- BeforeMove gates'),exact(M,'self.chargeRule =')]
 elif key=='bide':entry['owners']=[owner(C,'function BattleConditions:bide('),owner(C,'function BattleConditions:bideHit('),exact(B,'if move.damageRule=="bide"'),exact(M,'self.damageRule =')]
 elif key=='feint':entry['owners']=[owner(C,'function BattleConditions:breakProtection('),owner(C,'function BattleConditions:blocks('),exact(M,'self.breaksProtect =')]
 elif key=='petalDance':entry['owners']=[owner(C,'function BattleConditions:landedMove('),owner(C,'function BattleConditions:moveFinished('),owner(C,'function BattleConditions:endRampage('),exact(M,'self.lockRule =')]
 elif key=='focusEnergy':entry['owners']=[owner(C,'function BattleConditions:focusEnergy('),owner(D,'function FocusEnergyEffect:apply(')]
 elif key in('lightScreen','safeguard','tailwind'):entry['owners']=[owner(C,'function BattleConditions:setSideCondition('),owner(C,'function BattleConditions:screenDamage('),owner(C,'function BattleConditions:preventsStatus('),owner(C,'function BattleConditions:speed(')]
 elif key in('electroBall','assurance'):entry['owners']=[owner(E,'function BattleEffects:movePower('),owner(B,'function Battle:effectiveMovePower('),owner(E,'function BattleEffects:damagedThisRound(')]
 elif key=='endeavor':entry['owners']=[owner(E,'function BattleEffects:fixedDamage('),owner(E,'function BattleEffects:canAttempt(')]
 elif key in('captivate','suckerPunch','ragePowder'):entry['owners']=[owner(E,'function BattleEffects:canAttempt('),owner(E,'function BattleEffects:pendingMove(')]
 elif key in('hurricane','thunder','rainDance'):entry['owners']=[owner(E,'function BattleEffects:accuracyBypassesCheck('),owner(E,'function BattleEffects:accuracy('),owner(E,'function BattleEffects:setWeather(')]
 elif key=='worrySeed':entry['owners']=[owner(E,'function BattleEffects:worrySeedAttempt('),owner(E,'function BattleEffects:worrySeed('),owner(E,'function BattleEffects:effectiveAbility(')]
 elif key=='sweetScent':entry['owners']=[owner(D,'function ModifyStat:apply(')]
 elif key=='helpingHand':entry['owners']=[owner(B,'function Battle:moveHasTarget('),owner(B,'function Battle:resolveTurn(')]
 else:entry['owners']=common # exact negative source review for9 retained gaps
# Direct dependencies of the stated PP/RNG assertions, not whole battle files.
for entry in records.values():
 entry['owners'] += [exact(M,'self.pp ='),exact(M,'self.maxPP ='),{'path':'Source/lib/rng.lua','whole_file':True,'sha256':sha((P/'Source/lib/rng.lua').read_bytes())}]
records['bide']['owners'] += [owner(D,'function DirectDamage:apply('),owner(E,'function BattleEffects:hit(')]
summary=P/'docs/validation/observed-pewter-foundation/brock-integrated950.json'
record={'schema':1,'scope':'reviewed-source-and-executed-SDK-subsets','accepted_summary':{'path':str(summary.relative_to(P)),'sha256':sha(summary.read_bytes()),'source_sha256':'49832dd1c89953784f13c65a54f21a63771ae7b9b73ef16b405a8118932c8386','sdk_passed':950},'sdk_result_sha256':sha(result.read_bytes()),'qualification':'Current sourcebody hashes +exact executed assertions, never generated metadata alone; metadata hash is drift guard only. Fullruntime semantics remains false.','moves':records}
out=S/'tools/references/runtime-move-coverage.json';out.write_text(json.dumps(record,indent=2)+'\n');print('curated records',len(records))
# Private acceptance is deliberately a separate registry; never merged into main.
private=Path('/private/tmp/pokemon-brock-integration-03');actual=Path('/private/tmp/pokemon-root-rewards-correction-sdk-02/00001-result.json');raw=json.loads(actual.read_text());contracts=next(r['contracts']for r in raw['results']if r.get('contracts'));expected='7f2f4eda2d8e3d1fd0c0d2b63eb7ad4a824a290d7bf1e42ae421a9f16e8e2979'
assert raw['build_id'].endswith(':'+expected)and contracts['passed']==1059 and contracts['failed']==0
folder=S/'docs/validation/coverage-evidence';folder.mkdir(parents=True,exist_ok=True);(folder/'private1059-result.json').write_bytes(actual.read_bytes())
summaryRecord={'schema':1,'source_sha256':expected,'sdk':{'passed':1059,'failed':0},'acceptance':'private-root-verified-not-main','actual_result':'docs/validation/coverage-evidence/private1059-result.json','actual_result_sha256':sha(actual.read_bytes()),'bide_suite':next(row for row in contracts['suites']if row['id']=='bide')}
summaryPath=folder/'private1059-summary.json';summaryPath.write_text(json.dumps(summaryRecord,indent=2)+'\n')
# Reuse the reviewed same Bide rule, refresh its exact changed Roost type-query
# body and exact29-case suite execution only. No other main claim is promoted.
P=private;tests=contracts['tests'];entry=records['bide'].copy();entry['owners']=[owner(C,'function BattleConditions:bide('),owner(C,'function BattleConditions:bideHit('),exact(B,'if move.damageRule=="bide"'),exact(M,'self.damageRule =')];entry['tests']=[case('bideContracts','Actual public Bide stores2rounds releases3rd for160 and spends PP only once')]
entry['owners'] += [owner(D,'function DirectDamage:apply('),owner(E,'function BattleEffects:hit('),exact(M,'self.pp ='),exact(M,'self.maxPP ='),{'path':'Source/lib/rng.lua','whole_file':True,'sha256':sha((P/'Source/lib/rng.lua').read_bytes())}]
new={'schema':1,'scope':'reviewed-source-and-executed-SDK-subsets','acceptance_context':'private-root-verified-not-main','accepted_summary':{'path':'docs/validation/coverage-evidence/private1059-summary.json','sha256':sha(summaryPath.read_bytes()),'source_sha256':expected,'sdk_passed':1059},'sdk_result_sha256':sha(actual.read_bytes()),'qualification':'Private changed Bide body+current actual29test suite, no main integration claim.','moves':{'bide':entry}}
(S/'tools/references/runtime-move-coverage-private1059.json').write_text(json.dumps(new,indent=2)+'\n')

"""Read reviewed source/test evidence; metadata alone never proves a rule.

A changed handler, definition or assertion makes a claim stale, not missing or
complete. The immutable accepted result is distinct from current source bytes.
"""
import hashlib,json
from pathlib import Path
from .parse_lua import Expression
from .fetch_pokeapi import SourceError

def primitive(value):
    if isinstance(value,Expression):return value.text
    if isinstance(value,dict):return{k:primitive(v)for k,v in value.items()}
    if isinstance(value,list):return[primitive(v)for v in value]
    return value

def definition_hash(row):
    return hashlib.sha256(json.dumps(primitive(row),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def region(project,proof):
    path=Path(proof['path'])
    if path.is_absolute()or'..'in path.parts:raise SourceError('unsafe runtime evidence path')
    raw=(project/path).read_text()
    if proof.get('function_body') is True:
        lines=raw.splitlines(keepends=True);indices=[i for i,line in enumerate(lines)if line.startswith(proof['start'])]
        if len(indices)!=1:return None
        i=indices[0]
        if proof.get('one_line') is True:return lines[i]
        ends=[j for j in range(i+1,len(lines))if lines[j].strip()=='end'and lines[j].startswith('end')]
        return ''.join(lines[i:ends[0]+1])if ends else None
    if proof.get('exact_line') is True:
        found=[line for line in raw.splitlines(keepends=True)if line.lstrip().startswith(proof['start'])]
        return found[0]if len(found)==1 else None
    if proof.get('whole_file') is True:return raw
    start=raw.find(proof['start']);end=raw.find(proof['end'],start+len(proof['start']))
    if start<0 or end<0:return None
    return raw[start:end]

def load_runtime_coverage(project,moves,evidence_file=None):
    project=Path(project);path=Path(evidence_file)if evidence_file else project/'tools/references/runtime-move-coverage.json'
    record=json.loads(path.read_text())
    if record.get('schema')!=1 or record.get('scope')!='reviewed-source-and-executed-SDK-subsets':raise SourceError('invalid runtime coverage schema')
    summary=record['accepted_summary'];p=Path(summary['path'])
    if p.is_absolute()or'..'in p.parts:raise SourceError('unsafe accepted summary path')
    raw=(project/p).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=summary['sha256']:raise SourceError('accepted runtime summary drift')
    data=json.loads(raw)
    if data.get('source_sha256')!=summary['source_sha256']or data.get('sdk',{}).get('passed')!=summary['sdk_passed']:raise SourceError('accepted runtime identity differs')
    out={}
    for key,entry in record['moves'].items():
        if key not in moves:continue
        problems=[];owner_checks=[];test_checks=[]
        if definition_hash(moves[key])!=entry['definition_sha256']:problems.append('move definition differs from reviewed row')
        for proof in entry['owners']:
            body=region(project,proof)
            current_hash=hashlib.sha256(body.encode()).hexdigest()if body is not None else None
            owner_checks.append({'path':proof['path'],'selector':proof.get('start','whole-file'),'declared_sha256':proof['sha256'],'current_sha256':current_hash,'equal':current_hash==proof['sha256']})
            if current_hash!=proof['sha256']:problems.append('handler body changed: '+proof['path']+' '+proof.get('start','whole-file'))
        for proof in entry['tests']:
            if proof.get('executed',{}).get('ok')is not True or proof['executed'].get('name')!=proof['accepted_name']:raise SourceError('invalid executed SDK claim')
            if not(proof['accepted_name']==proof['name']or proof['accepted_name'].endswith(': '+proof['name'])):raise SourceError('exact SDK test name differs')
            body=region(project,proof)
            current_hash=hashlib.sha256(body.encode()).hexdigest()if body is not None else None
            test_checks.append({'name':proof['name'],'declared_sha256':proof['sha256'],'current_sha256':current_hash,'equal':current_hash==proof['sha256']})
            if current_hash!=proof['sha256']:problems.append('SDK assertion body changed: '+proof['name'])
        state=entry['state']
        if state not in('verified_subset','source_only','source_gap'):raise SourceError('unknown runtime coverage state')
        if state=='verified_subset'and not entry['tests']:raise SourceError('verified runtime subset lacks meaningful executed test')
        if not entry['owners']:raise SourceError('runtime claim lacks reviewed source owner')
        out[key]={'state':'stale'if problems else state,'capabilities':entry['capabilities']if not problems else[],
                  'scope':entry['scope'],'reasons':problems,'owner_checks':owner_checks,'assertion_checks':test_checks,'evidence':{'registry':str(path),'registry_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'accepted_source_sha256':summary['source_sha256'],
                  'acceptance_context':record.get('acceptance_context','accepted-main950'),'sdk_result_sha256':record['sdk_result_sha256'],'tests':[p['accepted_name']for p in entry['tests']]}}
    return out

# Current whole-game coverage

This snapshot is based on main `d9f57ea`, Source `49832dd1c89953784f13c65a54f21a63771ae7b9b73ef16b405a8118932c8386` (950 SDK). [Current data](coverage-current.json) follows [the schema](coverage.schema.json). It supersedes historical static reports **as a current status view**, without rewriting them or changing the [full goal](../plans/astra-full-game-goal.md).

Three layers stay independent:

| Layer | What acceptance means | What does not establish it |
|---|---|---|
| `campaign_path` | Actual connected progression, required transactions, safe returns and save/restart for that milestone | A map/party/move count, fixture teleport or source declaration |
| `regional_fidelity` | Source controls/geometry/NPCs/text/items/encounters/puzzles/art/audio adapted and independently reviewed for that region | A playable critical path or protected-pixel preservation alone |
| `full_mechanics` | Implemented rule portions and their exact source/SDK/native evidence, plus remaining full151 requirements | A generated field, nonempty effect, aggregate SDK count or absent conditional producer |

Each row names an owner, acceptance dependencies, **separate due milestone for each layer**, immutable source selector, implementation state, verification level, evidence IDs, limitations and optional private staging. `integrated` means the named production portion exists, never that its entire feature/competitive ruleset is complete. `sdk_scoped`/`native_scoped` remain bounded evidence. Source-only assertions, private proof, historical reports and future work cannot masquerade as accepted main milestones. No row currently claims milestone completion.

## Scheduling now

**Finish correctness of the already selected batch and safe NewGame recovery, then freeze actual natural Bulbasaur/Charmander/Squirtle→Brock on the integrated source. Do not expand that batch with Mirror Move or every optional grind-tail rule.** Required path/save-safety defects still block the gate. No intended move/species is removed, no artificial level cap is introduced, and the complete mechanics ledger remains required for the full release. Every newly accepted region must review its actual producer/dependency exposure; the final release due date is not permission to call an unsupported move a successful no-op.

After that freeze: source-authentic optional Route22 first BLUE, Moon/Cerulean/Bill, Vermilion/S.S. Anne/Cut/Flash, connected midgame, Surf/Strength/late gyms, League/Champion/credits/Hall of Fame, original postgame, then full rules/audio/polish/resource/device release closure. Original later Route22 BLUE stays at its actual late milestone. These are schedules, not reductions of scope.

## What this inventory contains

The1501 rows retain all248 source map slots,425 current move keys,111 original151 normal/hidden ability IDs,151 species,125 current item definitions,38 previously indexed native held-item entries,375 audio source files and28 cross-cutting systems. **Those are inventory sizes, not implemented/playable totals.** The source inventory distinguishes222 ordinary named map slots,22 unused aliases,4 copy/alias slots,223 unique headers/object tables,805 warps,201 background declarations,918 object declarations and391 trainer-party rows including unused content. Hidden/unused declarations (including Route4 LASS31) are not automatically reachable fights.

Map rows point into immutable `kanto-inventory.json`; full source object/script/party/wild/mart/HM/trade/hidden manifests remain there. Source scripts need executable control-flow/reachability review, not only a call list. Unused aliases stay indexed without creating dead runtime NPCs. Debug test_zone is not a natural campaign destination. Actual production currently comprises protected authored Pallet/interiors plus4registered source maps and8provider maps; Route22/Moon private candidates are not installed by this report.

Coverage explicitly includes the whole remaining goal: Bill/ticket, all HMs and badge permissions, fishing/cycling/Safari, Tower ghosts/Snorlax, elevators/spinners/keys/teleports/boulder/current/quiz puzzles, remaining gyms/obedience, League/credits/playable return, Mewtwo/legends, audio/music/cries, naming/options, source availability/exclusives/event-only Mew, in-game trades/trade authorization, balancing, resources/long sessions and physical device. No Mew encounter, unavailable link hardware prerequisite or GenV held loot is invented. Original Blue natural availability remains distinct from technical151 support; broader availability/link policy stays explicit.

## Current main versus verified private work

[Main950 evidence](observed-pewter-foundation/brock-integrated950.json) remains the accepted-main source anchor. Earlier-source natural wins/restarts and native cases are labeled with their own source identities. They do not establish the pending current all3 freeze.

Private Source `7f2f4eda2d8e3d1fd0c0d2b63eb7ad4a824a290d7bf1e42ae421a9f16e8e2979` has [actual1059 SDK evidence](coverage-evidence/private1059-result.json), summarized [separately](coverage-evidence/private1059-summary.json). This includes the changed Roost/Bide query composition and29 passing Bide tests. A/Roost/context/B/correction are **private-root-verified, not main950 integration**. Safe NewGame recovery remains a gate. The private Bide registry is a separate explicit input; it never silently replaces main classification.

## Correcting stale mechanics reports

`tools/verify_moves/content-gaps.json` is a historical419-move detector snapshot, not today's live mechanics truth. The [511-event refresh](coverage-evidence/exposure511.json) retains all earlier417 events/135 keys, but its broad34-row promotion is overridden by the [exact34-row erratum](coverage-evidence/promotion34.json):25 scoped implementations backed by meaningful named assertions,9 downgraded technical/conditional requirements. Historical files are unchanged.

The verifier now checks [reviewed runtime evidence](../../tools/references/runtime-move-coverage.json) against **named production bodies/fragments, exact meaningful test bodies and exact executed SDK names**. Definition hashes are drift guards, not a producer oracle. Changing a meaningful owner/assertion/definition produces `runtime-evidence-stale`, not an invented missing-handler diagnosis or automatic success. Unrelated reward edits do not invalidate unchanged guard/charge/critical source regions. No generated `powerRule`, `damageRule` or `critStage` field alone qualifies a move.

| Former false missing claim | Actual reviewed owner and independent scope |
|---|---|
| Protect absent | `BattleConditions:protect/blocks/endRound`, real DSL dispatch and guard site; actual first-priority4 block plus consecutive/capped chance cases in accepted950 |
| Solar Beam / Skull Bash charge absent | `BattleConditions:charge`, real charge dispatcher and solar policy; actual charge/release/Defense+1/PP/RNG assertions |
| Critical modifier absent | `criticalStage` +literal denominators and calcDamage critical fragments; exact16-row family metadata +real critical endpoint assertions; this does **not** implement Razor Wind charge |
| Bide zero-power dispatch absent | `damageRule=bide` dispatcher +`BattleConditions:bide/bideHit`; actual public storage/release3rd/PP assertions. Private changed body has separate1059/Bide29 proof |

Helping Hand's singles failure is source-implemented but awaits direct named SDK/native proof. Dig/GyroBall/HeavySlam/Magnitude/FuryCutter/self-KO/grounding/underground branches retain explicit technical gaps. Source absence alone does not prove every other move complete or missing. The current full verifier still exits1 for known gaps/reviews; `runtime_semantics_complete` remains false. A scalar/learnset pass or corrected false-positive count is never full engine acceptance.

## Reproduce and validate

After root applies the narrow packet:

```
python3 tools/check_coverage_matrix.py --project "$PROJECT" --matrix "$PROJECT/docs/validation/coverage-current.json"
python3 -m unittest tools.tests.test_move_verifier tools.tests.test_runtime_move_coverage tools.tests.test_coverage_matrix -v
python3 tools/verify_moves/main.py --cache "$PINNED_B2W2_CACHE" --output /private/tmp/current-move-report-UNIQUE.json
```

The matrix validator checks current Source identity, evidence hashes, complete immutable map/audio/move inventories, independent layer types, owners/dependencies/acyclicity and main/private separation. A stale source requires regeneration/review; never adjust expected hashes just to pass. The formal JSON schema documents shape; the standard-library validator supplies the cross-reference/source policies without a new dependency.

For separately labeled private Bide evidence, pass an explicit runtime tree and `--runtime-evidence tools/references/runtime-move-coverage-private1059.json` while selecting that tree's Pokemon/move files. The report covers only that registry's Bide subset; it does not claim the rest of the private engine is accepted from an empty proof set. The private source view must also contain the exact referenced private summary; root owns composition/publication.

Worker validation is host-only. No Simulator, live Source, generator, art, baseline or frozen packet was modified. Root still reviews/integrates, runs current SDK/native jobs, inspects images and accepts milestones. Simulator Lua heap/observer measurements do not prove hardware memory/FPS/audio/save behavior; physical Playdate remains explicitly unrun.

#!/usr/bin/env python3
"""Build one source-hashed CURRENT matrix; source inventory is not playability."""
import argparse,collections,hashlib,json,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def build(project,reference,exposure,erratum,held_index,check_only=False):
 sys.path.insert(0,str(project));from tools.harness.run import fingerprint
 from tools.verify_moves.parse_lua import LuaParser,read_moves,read_table,Reader,tokens
 invpath=project/'tools/references/kanto-inventory.json';pinpath=project/'tools/references/kanto-source.json';inv=json.loads(invpath.read_text());pin=json.loads(pinpath.read_text())
 assert inv['revision']==pin['revision']=='af519899719f0754965776faac0e836a3b906e6d'
 for row in pin['files']:assert sha(reference/row['path'])==row['sha256'],'immutable Kanto source drift '+row['path']
 moves=read_moves(project/'Source/battle/moves.lua');pokemon=LuaParser(project/'Source/data/pokemon.lua').parse();assert len(moves)==425 and len(pokemon)==151
 evidence={}
 def evidencefile(id,path,scope,kind='accepted'):
  evidence[id]={'path':str(path.relative_to(project))if path.is_relative_to(project)else str(path.relative_to(S))if path.is_relative_to(S)else str(path),'sha256':sha(path),'kind':kind,'scope':scope}
 evidencefile('kanto-inventory',invpath,'All indexed Blue source slots/objects/scripts/audio; NOT runtime/reachability.', 'source')
 evidencefile('kanto-pin',pinpath,'Immutable archive+1385 consumed source checksums.','source')
 evidencefile('main950',project/'docs/validation/observed-pewter-foundation/brock-integrated950.json','950SDK/462host plus source-specific native/fault/catalog summaries. Aggregate is not whole-engine acceptance.')
 evidencefile('legacy-natural',project/'docs/validation/observed-pewter-foundation/brock-integrated873-input-evidence.json','Earlier-source actual input/restart evidence; not current all3freeze.')
 evidencefile('profile',project/'docs/validation/world-profile.md','Simulator Lua heap/observer caveats; no physical device proof.','measurement')
 folder=S/'docs/validation/coverage-evidence';folder.mkdir(parents=True,exist_ok=True)
 def pinned_copy(source,target):
  raw=source.read_bytes()
  if target.exists():assert target.read_bytes()==raw,'evidence drift; preserve old proof: '+str(target)
  else:assert not check_only,'check-only evidence missing: '+str(target);target.write_bytes(raw)
 pinned_copy(exposure,folder/'exposure511.json');pinned_copy(erratum,folder/'promotion34.json')
 evidencefile('private1059',folder/'private1059-summary.json','Private Source7f2f verified1059SDK/Bide29; not main950.','private_verified')
 evidencefile('runtime-scopes',S/'tools/references/runtime-move-coverage.json','48 curated source/test records; no fieldpresence oracle.','accepted')
 evidencefile('exposure-current',folder/'exposure511.json','511events/154keys, stagedRoute22 +950source; use 34rowerratum to correct promotions.','source')
 evidencefile('promotion-erratum',folder/'promotion34.json','All34 exact current Move rows;25 meaningful scoped SDK cases/9downgrades. Prior blanket promotion withdrawn.','correction')
 evidencefile('historical417',project/'docs/validation/prebrock-mechanics/prebrock-checklist.json','Historical417events/135keys only; not current completion.','historical')
 evidencefile('static-gaps-historical',project/'tools/verify_moves/content-gaps.json','Historical419move/static detector; false-missing Protect/charge/crit no longer authoritative.','historical')
 for id,rel in [('battle','Source/battle/battle.lua'),('effects','Source/battle/effects.lua'),('conditions','Source/battle/conditions.lua'),('dsl','Source/battle/dsl.lua'),('moves','Source/battle/moves.lua'),('sessionCodec','Source/domain/sessionCodec.lua'),('maps','Source/data/maps.lua')]:evidencefile('production-'+id,project/rel,'Exact reviewed main950 source; handler presence alone is not verification.','production')
 milestones={
 'foundation':{'order':0,'outcome':'Qualified harness, protected art and authoritative domain owners'},
 'brock-freeze':{'order':1,'outcome':'Current batch correctness +safeNewGame recovery, then current integrated naturalall3 Brock/evolution/badge/TM/blackout/actualrestart freeze'},
 'moon-cerulean-bill':{'order':2,'outcome':'Route22 optional firstBlue +Moon/fossils/Center/Cerulean/Misty/Nugget/Bill and source optional content'},
 'vermilion-cut':{'order':3,'outcome':'Vermilion/SSAnne/Surge/Cut/Flash/in-game-trade/field traversal prerequisites'},
 'midgame-kanto':{'order':4,'outcome':'RockTunnel/Lavender/Tower/Celadon/Rocket/Saffron/Silph/Fuchsia/Safari/cycling/fishing/gyms/routes'},
 'surf-late-gyms':{'order':5,'outcome':'Surf/Strength/Seafoam/Cinnabar/Mansion/fossils/Viridian/finalrival/badges/Route23/VictoryRoad'},
 'league-credits':{'order':6,'outcome':'EliteFour/Champion/HallOfFame/credits +safe playable return'},
 'postgame-release':{'order':7,'outcome':'Originalpostgame/Mewtwo/remaininglegends +full151 rules/availability/audio/polish/resources/device/finalrelease evidence'}
 }
 def facet(implementation='indexed',verification='source_only',evidence_ids=None,notes='Source indexed; behavior/reachability unreviewed.'):
  return{'implementation':implementation,'verification':verification,'evidence':evidence_ids or['kanto-inventory'],'notes':notes}
 rows=[]
 def row(id,kind,title,owner,due,deps=None,source=None,cp=None,rf=None,fm=None,notes='',staged=None):
  d={'id':id,'kind':kind,'title':title,'owner':owner,'dependencies':deps or[],'due_milestone':{'campaign_path':due,'regional_fidelity':due,'full_mechanics':'postgame-release'},'source':source or{},'campaign_path':cp or facet(),'regional_fidelity':rf or facet(),'full_mechanics':fm or facet(),'notes':notes}
  if staged:d['staged']=staged
  rows.append(d);return d
 integrated={'PALLET_TOWN','REDS_HOUSE_1F','REDS_HOUSE_2F','BLUES_HOUSE','OAKS_LAB','ROUTE_1','VIRIDIAN_CITY','VIRIDIAN_MART','VIRIDIAN_POKECENTER','ROUTE_2','VIRIDIAN_FOREST_SOUTH_GATE','VIRIDIAN_FOREST','VIRIDIAN_FOREST_NORTH_GATE','PEWTER_CITY','PEWTER_GYM','PEWTER_MART','PEWTER_POKECENTER'}
 def due_map(m):
  c=m['constant'];h=m.get('header_name')or''
  if c in integrated:return'brock-freeze'
  if c.startswith('CERULEAN_CAVE'):return'postgame-release'
  if c in('INDIGO_PLATEAU','INDIGO_PLATEAU_LOBBY','LORELEIS_ROOM','BRUNOS_ROOM','AGATHAS_ROOM','LANCES_ROOM','CHAMPIONS_ROOM','HALL_OF_FAME'):return'league-credits'
  if c.startswith(('SEAFOAM','CINNABAR','POKEMON_MANSION','VICTORY_ROAD'))or c in('VIRIDIAN_GYM','POWER_PLANT','ROUTE_23'):return'surf-late-gyms'
  if c.startswith(('MT_MOON','CERULEAN','BIKE_SHOP','BILLS_HOUSE'))or c in('ROUTE_3','ROUTE_4','ROUTE_22','ROUTE_22_GATE','ROUTE_24','ROUTE_25'):return'moon-cerulean-bill'
  if c.startswith(('SS_ANNE','VERMILION','DIGLETTS','ROUTE_2_','ROUTE_5','ROUTE_6','UNDERGROUND_PATH_ROUTE_5','UNDERGROUND_PATH_ROUTE_6'))or c in('POKEMON_FAN_CLUB','DAYCARE','UNDERGROUND_PATH_NORTH_SOUTH'):return'vermilion-cut'
  if c.startswith(('MUSEUM','PEWTER','VIRIDIAN_SCHOOL','VIRIDIAN_NICKNAME')):return'moon-cerulean-bill'
  if c in('ROUTE_19','ROUTE_20','ROUTE_21'):return'surf-late-gyms'
  return'midgame-kanto'
 for i,m in enumerate(inv['maps']):
  c=m['constant'];alias=m['slot_kind']=='unused_alias';due=due_map(m);obj=inv['object_tables'].get(m.get('object_table'),{});indexed={'warps':len(obj.get('warps',[])),'background_events':len(obj.get('background_events',[])),'objects':len(obj.get('objects',[]))}
  cp=facet();rf=facet();fm=facet('indexed','unreviewed',['kanto-inventory'],'Regional actual-producer mechanics audit due before this region is accepted; no broad whole-engine claim.')
  if c in integrated:
   cp=facet('integrated','native_scoped',['main950','legacy-natural'],'Connected current production slice; all3 current integrated Brock freeze still pending.')
   rf=facet('partial','native_scoped',['main950'],'Reviewed protected/native art and bounded source events; optional interiors/controls/audio/naming remain outside accepted subset.')
   fm=facet('partial','sdk_scoped',['main950','promotion-erratum'],'Authoritative owners +scoped rules tested; known unimplemented/conditional/full151 rules remain.')
  if alias:cp=rf=fm=facet('not_applicable','source_only',['kanto-inventory'],'Unused source alias is indexed, not forced into playable counts. Preserve source identity.')
  if c in('TRADE_CENTER','COLOSSEUM'):cp=facet('not_applicable','unreviewed',['kanto-inventory'],'Link/multiplayer separate product scope, not hidden campaign prerequisite. Availability policy remains explicit.')
  d=row('map:'+c,'map_slot',c,'root',due,['system:world-authority','system:save-continue','system:source-art'],{'inventory':'kanto-inventory','pointer':'/maps/'+str(i),'constant':c,'slot_id':m['id'],'slot_kind':m['slot_kind'],'header':m.get('header_source'),'object_table':m.get('object_table'),'script':m.get('script'),'indexed_controls':indexed},cp,rf,fm,'Indexed source object/party counts are not natural reachability or completion. Copy/alias slots require script/warp review; do not duplicate actors.')
  if c in integrated:d['due_milestone']['regional_fidelity']='moon-cerulean-bill'
  if c in('ROUTE_22','ROUTE_22_GATE'):d['staged']={'implementation':'private_frozen','verification':'compile_host_only','scope':'Route22 first-rival/Gate19SDK groups UNRUN; source/provenance94catalog additions unreviewed; later rival remains deferred'}
  if c.startswith('MT_MOON')or c in('ROUTE_3','ROUTE_4'):d['staged']={'implementation':'private_archived','verification':'unrun','scope':'Bounded source/runtime preparations; not current production or accepted maps.'}
  if c=='ROUTE_4':d['notes']+=' Original hidden/unused LASS31 remains indexed, not exposed as an available battle without hide/show+script proof.'
  if c=='ROUTE_22':d['due_milestone']['regional_fidelity']='surf-late-gyms';d['notes']+=' First optional rival due after Brockfreeze; second original late rival depends ViridianGym milestone, not a fake rematch flag.'
 def system(key,title,due,deps,impl='indexed',verify='unreviewed',notes='',ev=None,owner='root'):
  return row('system:'+key,'system',title,owner,due,deps,cp=facet(impl,verify,ev or['main950'],notes),rf=facet('partial'if impl=='integrated'else impl,verify,ev or['main950'],notes),fm=facet('partial'if impl=='integrated'else impl,verify,ev or['main950'],notes),notes=notes)
 system('harness','Owned harness/protocol/reset/press-hold-release/restart','foundation',[], 'integrated','native_scoped','Identified builds/locks/strict failures/true2process evidence; Source-specific scope retained.',['main950'],'harness')
 system('source-art','Protected RED/BLUE/Oak/Pallet +source transforms/masks/catalog','foundation',['system:harness'],'integrated','native_scoped','2494exact current baseline; new artifacts remain unreviewed until separate source/native acceptance.',['main950'])
 system('world-authority','One WorldDeltas/ImportedMaps owner, LRU2, stable tiles/actors/flags','foundation',['system:harness','system:source-art'],'integrated','sdk_scoped','Current8provider+4registeredsource maps; map counts do not prove campaign. No competing region controllers.')
 system('party-domain','Party6/Storage12x20/bag/money/specimen ownership','foundation',['system:harness'],'integrated','sdk_scoped','Domain invariants/transfer identity +nativePC accepted subset; no all-species battle claim.')
 system('battle-owner','Battle/Effects/Conditions/DSL singles command/receipt/turn ownership','foundation',['system:party-domain'],'integrated','sdk_scoped','950aggregate/scoped native; not complete425moves/111abilities.',['main950','promotion-erratum'],'rules')
 system('save-continue','VersionedSaveStore/session codecs/Continue/world/checkpoint','foundation',['system:world-authority','system:party-domain'],'integrated','native_scoped','Trueprocess restart/corruption preservation; accepted source identity/version scope retained.')
 system('safe-newgame-recovery','Safe NewGame replacement/recovery/cancellation','brock-freeze',['system:save-continue'],'partial','unreviewed','CURRENT BATCH BLOCKER: root owns narrow safe NewGame recovery; no implicit destructive overwrite. Must pass before all3freeze.')
 system('current-reward-correctness','Residual eligibility/XP/EV/current batch correctness','brock-freeze',['system:battle-owner','system:party-domain'],'partial','unreviewed','CURRENT BATCH BLOCKER: confirmed residual reward defect correction +selected A/B/PF correctness beforefreeze; staged/private proof is not main950 acceptance.',owner='rules')
 system('natural-all3-freeze','Current integrated natural Bulbasaur/Charmander/Squirtle→Brock','brock-freeze',['system:current-reward-correctness','system:safe-newgame-recovery','system:save-continue'],'partial','native_scoped','Earlier-source Charmander/Squirtle wins/restarts exist; current all3/evolution/TM/fullbag/blackout/save proof pending. No Mirror expansion into currentbatch.')
 system('original-progression','Source flags/story/optional rivals/key-item atomic transactions','moon-cerulean-bill',['system:world-authority','system:save-continue'],'partial','native_scoped','Parcel/Dex+firstBrock bounded; Route22 staged, later flags/scripts/key gates pending.')
 system('pokedex-availability','151technical support vsBlue natural/exclusives/static/gift/event availability','moon-cerulean-bill',['system:party-domain'],'partial','sdk_scoped','Record actual acquisition; original151technical support does not mean all151catchable in Blue. No inventedMew or hiddenability source. Original event-onlyMew/exclusives policy explicit.')
 system('npc-trades','Original in-game trades and trade-evolution authorization','vermilion-cut',['system:party-domain','system:original-progression'],'indexed','source_only','Trade hook exists, no current source trade UI/control. Implement originalNPC trades; no unavailable link hardware hidden prerequisite.',['kanto-inventory'])
 system('hm-cut','HM01Cut gift/Cascade permission/persistent tree traversal','vermilion-cut',['system:original-progression','system:world-authority'],'indexed','source_only','SourceCaptain gift and badge/knownmove/terrain prerequisites distinct. Do not infer fieldCut from combat move definition.',['kanto-inventory'])
 system('hm-flash','HM05Flash aide gift/Boulder permission/cave lighting','vermilion-cut',['system:original-progression','system:world-authority'],'indexed','source_only','Source owned-count condition/gift and field lighting remain required.',['kanto-inventory'])
 system('hm-fly','HM02Fly/Thunder permission/destination travel','midgame-kanto',['system:hm-cut','system:world-authority'],'indexed','source_only','Gift, knownmove, badge and visited destination state distinct; combatFly mechanics separate.',['kanto-inventory'])
 system('hm-surf-strength','HM03Surf/Soul +HM04Strength/Rainbow/puzzles','surf-late-gyms',['system:original-progression','system:world-authority'],'indexed','source_only','Safari gifts/GoldTeeth/Warden, boulders/holes/currents/encounters/warp/save required.',['kanto-inventory'])
 system('fishing-cycling-safari','Rods/fishing tables/bicycle/CyclingRoad/Safari rules','midgame-kanto',['system:original-progression','system:party-domain'],'indexed','source_only','Source fishing and Safari catch/timer/balls are separate producers, not ordinarygrass table reuse.',['kanto-inventory'])
 system('puzzles-key-blockers','Tower ghosts/Snorlax/spinners/elevators/keys/warps/quizzes/boulders','midgame-kanto',['system:original-progression','system:world-authority'],'indexed','source_only','Per-region source script owners, resets and persistence; topology alone never certifies puzzle.',['kanto-inventory'])
 system('gyms-obedience','Eight badges/leaders/puzzles/obedience/progression permissions','league-credits',['system:original-progression','system:battle-owner'],'partial','sdk_scoped','Brock sourceparty/badge/TM only; remaining7gyms and obedience gates remain. CombatGenV/worldBlue policies explicit.')
 system('league-credits','ConsecutiveElite4/Champion/HallOfFame/credits/playablereturn','league-credits',['system:gyms-obedience','system:save-continue'],'indexed','source_only','Championspeech is not completion; heal/blackout/reset/history/credits/save and postgame unlock required.',['kanto-inventory'])
 system('postgame-legends','CeruleanCave/Mewtwo/Articuno/Zapdos/Moltres/static flags','postgame-release',['system:league-credits'],'indexed','source_only','Source static/one-time encounter/reset/save semantics; legends may be optional earlier, Mewtwo requires HallOfFame. No inventedMew.',['kanto-inventory'])
 system('naming','Player/rival/nickname input +safe text/codec migration','moon-cerulean-bill',['system:save-continue'],'partial','source_only','Maintitle explicitlyRED/BLUE; no namingUI. Current fixed-name compatibility preserved until reviewed migration.',['production-sessionCodec'])
 system('options','Text speed/battle animation/style/audio/input options','moon-cerulean-bill',['system:harness'],'indexed','unreviewed','Original options inventory required; current debug/system menus are not source Options acceptance.',['kanto-inventory'])
 system('audio','Music/SFX/cries/original event playback/transitions','postgame-release',['system:source-art'],'indexed','source_only','375pinned audio files indexed; no current Playdate sound playback implementation located. No audio completion claim.',['kanto-inventory'])
 system('balance','Blue original encounters/teams with GenV stats/moves/traits difficulty','brock-freeze',['system:battle-owner','system:natural-all3-freeze'],'partial','native_scoped','All3viability/current reward correctness first; repeat byregion. No silent level/party/scalar nerfs or grindcap. Fullcampaign balance remains releasework.')
 system('resource','Measured startup/heap/frame/cache/longsession resource costs','postgame-release',['system:world-authority','system:harness'],'partial','source_only','Simulator measurements exist, observer/GC caveats explicit; retain no guessed hardwarebudget. Measure each region before optimization.',['profile'],'harness')
 system('device','Physical Playdate performance/memory/input/audio/save validation','postgame-release',['system:resource','system:audio'],'indexed','unreviewed','NOT RUN. Simulator Lua heap/frame timing is not physical-device fit/performance.',['profile'],'harness')
 system('release','PlayablePDX/source/generation/references/docs/allcampaign+postgame evidence','postgame-release',['system:device','system:postgame-legends','system:audio','system:naming','system:options'],'indexed','unreviewed','Fullgoal remains active. Milestone all3freeze does not certify regionalfidelity/fullmechanics layers.')
 # Correct only exact reviewed capability claims, never infer a whole move from empty effects.
 correction=json.loads(erratum.read_text());supported={r['move']:r for r in correction['rows']if r['meaningful_case']};withdrawn={r['move']:r for r in correction['rows']if not r['meaningful_case']}
 source950=json.loads((project/'docs/validation/observed-pewter-foundation/brock-integrated950.json').read_text());assert source950['source_sha256']==fingerprint(project)
 highcrit={k for k,m in moves.items()if m.get('critStage')==1};assert len(highcrit)==16
 exp=json.loads(exposure.read_text());known={r['move']:r for r in exp['moves']}
 for key,m in sorted(moves.items()):
  state=facet('indexed','unreviewed',['production-moves'],'Definition exists. Exact behavior/PP/RNG/lifecycle not inferred from membership or effects count.')
  if key in supported:state=facet('integrated','sdk_scoped',['main950','promotion-erratum'],'Exact named meaningful assertions scoped in34rowerratum; not exhaustive native/full-engine proof.')
  if key in withdrawn:state=facet('partial'if m['power']>0 else'indexed','source_only',['production-moves','promotion-erratum'],withdrawn[key]['reason'])
  if key in highcrit and key not in supported:state=facet('partial','sdk_scoped',['main950','production-effects'],'Exact16-row critStage1 metadata +shared critical stage/damage endpoints; remainingmove semantics unreviewed, not missing critical modifier.')
  if key=='bide':
   assert m.get('damageRule')=='bide';state=facet('integrated','sdk_scoped',['main950','production-conditions','production-battle'],'ActualBide storage/release3rd/PP/receipt/protection scopes; nativeC-vsPS policy explicit. Not missing-damage-dispatch.')
  if key=='protect':assert m.get('effects')and m.get('priority')==4
  if key in('solarBeam','skullBash'):assert m.get('chargeRule')==key
  if key in known and known[key]['status']in('semantic-gap-natural','conditional-semantic-gap','partial-source-order-review','source-implemented-singles-failure-unverified','staged-notaccepted','semantic-gap-technical-only'):
   state=facet('partial'if m['power']>0 or m.get('effects')or key=='helpingHand'else'indexed','source_only',['exposure-current','production-moves'],known[key]['remaining'])
  if key=='mirrorMove':state=facet('indexed','source_only',['production-moves'],'Known missing call/history behavior. Approved proposal/C-policy PRIVATE ONLY; implementation not started, explicitly excluded currentbatch.')
  cp=facet('indexed','source_only',['exposure-current'],'Actual natural/fixedtrainer availability retained with no cutoff. This layer does not imply mechanics completion.')
  d=row('move:'+key,'move',m['name'],'rules','postgame-release',['system:battle-owner'],{'canonical_key':key,'metadata':'production-moves'},cp,facet('not_applicable','unreviewed',['production-moves'],'Move mechanics are separate from regional art/content fidelity.'),state)
  d['due_milestone']['full_mechanics']='moon-cerulean-bill'if key in('mirrorMove','whirlwind','flatter','helpingHand')else'brock-freeze'if key=='poisonFang'else'postgame-release'
  d['capabilities']=[{'name':'high-critical-stage','state':'sdk_scoped','evidence':['main950','production-effects']}]if key in highcrit else[]
  if key in('protect','solarBeam','skullBash','bide'):d['capabilities'].append({'name':'declared-current-production-owner','state':'sdk_scoped','evidence':['main950','production-conditions','production-battle']})
  if key in known:d['source']['exposure']={'natural_player':known[key]['player_natural_key'],'fixed_trainer_initial':known[key]['actual_trainer_initial_key']}
  if key=='roost':d['staged']={'implementation':'private_root03','verification':'actual1059SDK','evidence':['private1059'],'scope':'A/Roost/context/B/correction private Source7f; not main950.'}
 slots=[tuple(map(int,m))for m in re.findall(r'\[(\d+)\] = \{first=(\d+),second=(\d+),hidden=(\d+)\}',(project/'Source/data/specimenData.lua').read_text())];abilities=sorted({v for _,a,b,h in slots for v in(a,b,h)});assert len(abilities)==111
 handlers={int(x)for x in re.findall(r'handlers\[(\d+)\]',(project/'Source/battle/effects.lua').read_text())}
 for id in abilities:
  hook=id in handlers
  d=row('ability:'+str(id),'ability','GenV ability nativeID'+str(id),'rules','postgame-release',['system:battle-owner','system:pokedex-availability'],{'native_id':id,'species_dex':[dex for dex,a,b,h in slots if id in(a,b,h)]},facet('indexed','source_only',['exposure-current'],'Normal/hidden availability is separate; no hidden acquisition invented.'),facet('not_applicable','unreviewed',['kanto-inventory'],'Regional availability owner must declare actual producer.'),facet('partial'if hook else'indexed','sdk_scoped'if hook else'unreviewed',['main950','production-effects']if hook else['kanto-inventory'],'Bounded registered hooks only, not completeability semantics.'if hook else'Indexed original151 ability union; fullbehavior pending. Field-only partial effects may exist independently.'))
  if id in(14,22,51):d['notes']='Current field distribution/suppression portions have separate owner/evidence; field hook is not full battle ability.'
 for key,p in sorted(pokemon.items(),key=lambda kv:kv[1]['dex']):
  row('species:'+key,'species',p['name'],'rules','postgame-release',['system:party-domain','system:pokedex-availability'],{'dex':p['dex'],'canonical_key':key},facet('indexed','source_only',['exposure-current'],'Technical151 support ≠ naturalBlue availability; see source encounter/gift/trade policy.'),facet('partial','native_scoped',['main950'],'302battle images exact; actual all151 encounter scenes/motion are not asserted.'),facet('partial','sdk_scoped',['main950'],'All151 codec/growth/ratio/learnset metadata scopes verified; not every move/ability/item combination.'))
 for current in rows:
  if current['id']=='move:bide':current['staged']={'implementation':'private_root03','verification':'actual1059SDK-Bide29','evidence':['private1059'],'scope':'Changed Roost type-query body verified privately; not main integration.'}
  if current['id']=='system:current-reward-correctness':current['staged']={'implementation':'private_root03','verification':'actual1059SDK','evidence':['private1059'],'scope':'B+correction+fixtureerratum; main remains950. SafeNewGame still pending.'}
 # Current item definitions are indexed separately from actions/acquisition.
 items=read_table(project/'Source/data/items.lua','ItemData')['definitions'];light=Reader(tokens('{'+(project/'Source/data/lightBall.lua').read_text().split('ItemData.definitions.lightBall={',1)[1])).table();items['lightBall']=light
 acquired={r['id']for r in exp['items']if r['id']not in('moonStone','hpUp','thunderStone')}
 for key,item in sorted(items.items()):
  present=key in acquired
  row('item:'+key,'item',key,'rules','postgame-release',['system:party-domain','system:original-progression'],{'canonical_key':key,'definition_file':'Source/data/lightBall.lua'if key=='lightBall'else'Source/data/items.lua'},facet('partial'if present else'indexed','source_only',['exposure-current'],'Actual source acquisition must be declared. Item definition is not availability.'),facet('indexed','source_only',['kanto-inventory'],'Original prices/stocks/text/itemgraphics checked regionally; no invented rewards.'),facet('partial'if present else'indexed','sdk_scoped'if present else'unreviewed',['main950']if present else['kanto-inventory'],'Bounded domain/field/battle owners for currently acquired items; not each combination verified.'if present else'Indexed definition, action/held/field producer needs review.'))
 heldSource=held_index;held=json.loads(heldSource.read_text());pinned_copy(heldSource,folder/'held-native-index.json');evidencefile('held-native-index',folder/'held-native-index.json','Previously pinned original151 personal nativeheld index; historical implementation comments ignored. Source indexing only.','source')
 for item in held['items']:
  implemented=item['gen5Id']==236
  row('held-native:'+str(item['gen5Id']),'held_native',item['gen5Symbol'],'rules','postgame-release',['system:pokedex-availability','system:party-domain'],{'native_id':item['gen5Id'],'canonical_key':item['canonicalId'],'inventory':'held-native-index'},facet('partial'if implemented else'indexed','source_only',['held-native-index'],'Ordinary GenV loot extension must be explicitly authorized at its actual source-species acquisition; no inventedBlue shop/gift.'),facet('not_applicable','unreviewed',['held-native-index'],'Held rules separate from world art; original availability still region-owned.'),facet('partial'if implemented else'indexed','sdk_scoped'if implemented else'unreviewed',['main950']if implemented else['held-native-index'],'LightBall bounded implementation accepted; other nativeheld effects/acquisition remain tracked.'if implemented else'Native source item retained, not claimed enabled/implemented.'))
 for i,a in enumerate(inv['audio_files']):
  row('audio:'+a['path'],'audio_source',a['path'],'root','postgame-release',['system:audio'],{'inventory':'kanto-inventory','pointer':'/audio_files/'+str(i),'sha256':a['sha256']},facet('not_applicable','source_only',['kanto-inventory'],'Audio does not establish campaign progression.'),facet('indexed','source_only',['kanto-inventory'],'Source indexed, native playback/conversion/mix not implemented/accepted.'),facet('not_applicable','unreviewed',['kanto-inventory'],'Not a battlemechanic.'))
 return{'schema_version':1,'snapshot':{'commit':'d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7','source_sha256':fingerprint(project),'policy_date':'2026-10-21','source_revision':inv['revision'],'scope':'WholeoriginalBluecampaign/postgame, original151, GenVmechanics. Snapshot not timeless live truth.'},'accepted_milestone_rows':[],'schedule':{'policy':'Currentbatch correctness+safeNewGame recovery then freezeall3Brock. Do not expand batch with Mirror/grindtail. No move deletion or artificial levelcap; pending fullmechanics remains release requirement.','gates':['system:current-reward-correctness','system:safe-newgame-recovery','system:natural-all3-freeze'],'layers_independent':True,'all_grind_rows_retained':True,'earlier_trigger':'Any known mandatory-path/save-safety defect blocks current gate. Every newly exposed region needs its own rules audit; release due is not permission for false successful no-ops.','due_is_schedule_not_waiver':True},'milestones':milestones,'owners':{'root':'Architecture/content/integration/finalnativeacceptance; bounded content assignment later','rules':'Rulesworker/domain responsibility underroot serialmerge','harness':'Ownedhostqualification/performanceproof underrootSimulatorownership'},'evidence':evidence,'source_inventory_summary':inv['summary'],'source_limits':inv['extraction_limits'],'rows':rows,'staged_source_snapshots':[{'source_sha256':'7f2f4eda2d8e3d1fd0c0d2b63eb7ad4a824a290d7bf1e42ae421a9f16e8e2979','evidence':'private1059','acceptance':'private-root-verified-not-main950','sdk_passed':1059,'bide_passed':29}], 'limits':['Source indexed counts ≠ naturalplayability; unused/hidden/unreferenced declarations stay distinguished.','Main950 versus private996 A/Roost/context versus futurePF/B/NewGame changes must not collapse.','104path-present/34promotion reports remain historical; exact34rowerratum overrides broad promotion.','No all425/111 fullmechanics, campaigncompletion or physicaldevice claim.']}
if __name__=='__main__':
 p=argparse.ArgumentParser();
 for key in('project','reference','exposure','erratum','held-index','output'):p.add_argument('--'+key,type=Path,required=True)
 p.add_argument('--check',action='store_true');a=p.parse_args();d=build(a.project.resolve(),a.reference.resolve(),a.exposure.resolve(),a.erratum.resolve(),a.held_index.resolve(),a.check);raw=(json.dumps(d,indent=2)+'\n').encode()
 if a.check:assert a.output.read_bytes()==raw,'currentcoverage drift'
 else:assert not a.output.exists(),'refuse overwrite snapshot';a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_bytes(raw)
 print(json.dumps({'rows':len(d['rows']),'kinds':dict(collections.Counter(r['kind']for r in d['rows']))}))

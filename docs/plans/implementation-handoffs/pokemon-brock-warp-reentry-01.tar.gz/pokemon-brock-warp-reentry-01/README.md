# Private Brock host warp reentry repair

Base82cb207/Source44bd; no production Lua change. The original Bulbasaur run remains FAILED. On actual recovery arrival at Forest1,0 the driver chose its already occupied warp as a zero-length route, emitted no input, then expected a transition. The repair compares executable alternate warp routes with an ordinary reversible off/back pair, retaining bottom-edge outward exits and strict source arrival checks. Occupancy, signs, other warps and one-way ledges remain guarded; actual navigate replans every step. No synthetic input, outcome or RNG/state changes.

Apply only3 manifest-owned paths/patches after the current root suite stops; never copy the private tools tree. With the documented host reference setup, PARCEL_BUNDLE_SOURCE points to a verified compiled bundle carrying exact source geometry. Run python -m unittest tools.tests.test_brock_warp_reentry -v and this targeted command (output retained in targeted-host-final.txt):

```sh
python -m unittest tools.tests.test_brock_warp_reentry tools.tests.test_brock_capture tools.tests.test_brock_policy tools.tests.test_brock_preparation tools.tests.test_brock_forced_switch tools.tests.test_brock_evolution_evidence tools.tests.test_parcel_journey -v
```

74 targeted host checks pass, including6 reentry regressions. reproduce.py runs the exact archived original method and must retain the original specific error; it is a host replay, no fake SDK. baseline/brock_journey.py is immutable82cb207 host code. Independent review is /private/tmp/pokemon-warp-independent-review-01; its proposed edge checks are now formal tests.

native-warp-return.json is UNRUN, root sole Simulator owner. After the active suite: run tools/harness/run.py --scenario <packet>/native-warp-return.json --output <new-private-dir>; inspect settled native shots and source coordinates. This proves real arrival suppression/return but not candidate method execution. Then run a FRESH full brock-restart-bulbasaur scenario through actual candidate driver, intro to Brock and real two-process SaveContinue. Retain all original loss/failure evidence. No campaign acceptance from host replay/counts. Main Source/HEAD/active suite driver remain untouched while this packet is private.

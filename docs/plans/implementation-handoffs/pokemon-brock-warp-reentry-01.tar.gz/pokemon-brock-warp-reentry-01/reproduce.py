"""Replay the original host-driver defect, never Playdate execution."""
import contextlib,importlib.util,sys,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from tools.harness.brock_journey import BrockJourney
spec=importlib.util.spec_from_file_location('frozen_brock',ROOT/'baseline/brock_journey.py')
baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
suite=unittest.defaultTestLoader.loadTestsFromName('tools.tests.test_brock_warp_reentry.WarpReentryTests.test_actual_recovery_arrival_requires_a_real_step_before_return')
with (ROOT/'original-replay.txt').open('w')as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log),patch.object(BrockJourney,'warp',baseline.BrockJourney.warp):
 result=unittest.TextTestRunner(verbosity=2).run(suite)
if len(result.errors)!=1 or 'step warp failed to activate'not in result.errors[0][1]:
 raise SystemExit('Original exact defect was not reproduced')
print('Original driver reproduced the exact failure. This is host evidence only.')

from pathlib import Path
import difflib,hashlib,json
P=Path(__file__).resolve().parent
base=json.loads((P/'baseline.json').read_text());B=P/'originals';overlays=[];patches=P/'patches';patches.mkdir(exist_ok=True)
for f in sorted((P/'Source').rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(P).as_posix();digest=hashlib.sha256(f.read_bytes()).hexdigest()
 if base['files'].get(rel)!=digest:
  overlays.append(rel)
  if rel in base['files']:
   before=(B/rel).read_text();after=f.read_text();patch=patches/(rel+'.patch');patch.parent.mkdir(parents=True,exist_ok=True);patch.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
assert not any(x.startswith(('Source/images/','Source/world/sprites/','Source/battle/'))for x in overlays)
assert (B/'Source/data/pokemon.lua').read_text().split('function calcStat')[0]==(P/'Source/data/pokemon.lua').read_text().split('function calcStat')[0]
manifest={'schema':1,'packet':'individuals-a-01','base_source_sha256':base['source_sha256'],'base_files':{rel:base['files'][rel]for rel in overlays if rel in base['files']and rel not in ['Source/main.lua','Source/dev/diagnostics.lua']},'overlay_files':[rel for rel in overlays if rel not in ['Source/main.lua','Source/dev/diagnostics.lua']], 'root_hook_files':['Source/main.lua','Source/dev/diagnostics.lua'],'after_files':{rel:hashlib.sha256((P/rel).read_bytes()).hexdigest()for rel in overlays},'files':{}}
for f in sorted(P.rglob('*')):
 if f.is_file()and f.name!='manifest.json'and'__pycache__'not in f.parts:
  rel=f.relative_to(P).as_posix()
  if not rel.startswith('Source/')or rel in overlays:manifest['files'][rel]=hashlib.sha256(f.read_bytes()).hexdigest()
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest());print('overlays',len(overlays))

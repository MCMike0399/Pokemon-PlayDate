#!/usr/bin/env python3
"""Compile-only by default. Only root may request actual SDK --execute."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
stage=Path(__file__).resolve().parent
mutations={
 'omit-iv':('Source/domain/individualStats.lua','2*base+iv[key]+ev[key]//4','2*base+ev[key]//4'),
 'quarter-floor':('Source/domain/individualStats.lua','ev[key]//4','ev[key]//3'),
 'ev252':('Source/domain/individualStats.lua','values(evs,255,"evs")','values(evs,252,"evs")'),
 'revive-zero':('Source/domain/individualStats.lua','if hp==0 then return 0 end','if hp==0 then return newMax end'),
 'missing-v7':('Source/domain/pokemonCodec.lua','IndividualStats.normalize(record.ivs,record.evs)','IndividualStats.normalize(record.ivs or IndividualStats.zero(),record.evs or IndividualStats.zero())'),
 'random-trainer':('Source/domain/specimen.lua','if individualKind=="random-normal-v1"then','if true then'),
}
def main():
 p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--case',choices=['contracts','intro-squirtle','intro-bulbasaur','intro-charmander','save-continue'],default='contracts');p.add_argument('--mutation',choices=sorted(mutations));p.add_argument('--with-field-receipt',action='store_true');a=p.parse_args()
 project=a.project.resolve();sys.path.insert(0,str(project));from tools.harness import run as runner
 from tools.harness.protocol import atomic_json
 manifest=json.loads((stage/'manifest.json').read_text());original=runner.prepare
 def prepare(project,sdk,output,session):
  for rel,digest in manifest['files'].items():assert hashlib.sha256((stage/rel).read_bytes()).hexdigest()==digest,'packet changed: '+rel
  for rel,digest in manifest['base_files'].items():assert hashlib.sha256((project/rel).read_bytes()).hexdigest()==digest,'base changed: '+rel
  meta=original(project,sdk,output,session)
  for rel in manifest['overlay_files']:
   destination=output/rel;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/rel,destination)
  # Root-owned shared hooks are inserted against unique current anchors. Never
  # overlay the old whole main/diagnostics or downgrade newer battle files.
  main=output/'Source/main.lua';text=main.read_text();anchor='import "data/pokemon"';assert text.count(anchor)==1
  text=text.replace(anchor,'import "data/individualData"\nimport "domain/individualStats"\n'+anchor)
  anchor='import "dev/specimenContracts"';assert text.count(anchor)==1
  text=text.replace(anchor,'import "dev/individualContracts"\nContracts.register("individual-stats-v1", IndividualContracts.run)\n'+anchor);main.write_text(text)
  diagnostics=output/'Source/dev/diagnostics.lua';text=diagnostics.read_text();anchor='        sex=mon:getSex(),sex_provenance=mon:attributes().sexProvenance,';assert text.count(anchor)==1
  diagnostics.write_text(text.replace(anchor,anchor+'\n        individuals=mon:individuals(),canonical_stats=mon:calculatedStats(),\n        actual_stats={maxHP=mon.maxHP,atk=mon.atk,def=mon.def,spa=mon.spa,spd=mon.spd,spe=mon.spe},'))
  if a.with_field_receipt:
   projection=json.loads((stage/'optional/field-receipt.json').read_text());path=output/'Source/domain/fieldEncounters.lua'
   assert hashlib.sha256(path.read_bytes()).hexdigest()==projection['base_sha256'],'field receipt base changed'
   text=path.read_text();assert text.count(projection['old'])==1;path.write_text(text.replace(projection['old'],projection['new']))
  if a.mutation:
   rel,old,new=mutations[a.mutation];path=output/rel;text=path.read_text();assert text.count(old)==1;path.write_text(text.replace(old,new))
  pdx=output/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(meta['original_pdxinfo'])
  meta['source_sha256']=runner.fingerprint(output);meta['build_id']=meta['revision']+':'+meta['source_sha256']
  atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted((output/'Source').rglob('*'))if x.is_file()and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
  pdx.write_text(generated)
  lines=[]
  for key in ['protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir']:
   value=meta[key];lines.append('    '+key+' = '+('true'if value is True else'false'if value is False else json.dumps(value))+',')
  (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(lines)+'\n}\n')
  meta.update(compiled_source_sha256=runner.fingerprint(output,exclude_generated=False),individual_packet_sha256=hashlib.sha256((stage/'manifest.json').read_bytes()).hexdigest(),individual_mutation=a.mutation)
  with(output/'individual-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),meta['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
  atomic_json(output/'build.json',meta);return meta
 runner.prepare=prepare;runner.PROJECT=project
 try:return runner.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(stage/'scenarios'/(a.case+'.json')),commands=[],build_only=not a.execute,timeout=180,ready_timeout=20,max_frames=3600))
 finally:runner.prepare=original
if __name__=='__main__':raise SystemExit(main())

# Frozen test/recipe erratum 01

Original B/correction and failed1057/2 native evidence unchanged. No production changes. Apply only exact old/new hunks in shared-hunks.json (the host recipe base is frozen B, not repository main).

Independent diagnosis confirms first poison-vs-later-burn terminal expectation stays byte-for-byte unchanged. The second case is one poison cohort: both members finish before matchup, enemyHP0, playerXP unchanged and allEV0. Medicine explicitly activates its actual session; existing test wrapper restores prior owner and stream. No stale-owner production bypass. Learning recipe awaits actual message dialog_ready bounded180 before readable screenshot, then retains actual acknowledgement/knownmove/twofoe/save assertions.

Compile and root native rerun required; no new runtime acceptance claimed. HUD native01 genuine gained/grew/Save evidence remains valid; early learningPNG is not readable-Ember acceptance. No true-processContinue claim.

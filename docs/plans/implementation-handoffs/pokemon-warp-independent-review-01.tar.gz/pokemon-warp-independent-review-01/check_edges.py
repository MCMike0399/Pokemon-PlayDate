import os,sys,json,copy
from pathlib import Path
sys.dont_write_bytecode=True
C=Path('/private/tmp/pokemon-brock-warp-reentry-01');sys.path.insert(0,str(C))
os.environ['PARCEL_BUNDLE_SOURCE']='/private/tmp/pokemon-root-brock-freeze82cb207-01/01-brock--brock-restart-bulbasaur'
from tools.tests.test_brock_warp_reentry import WarpReentryTests
from tools.harness.brock_journey import BrockJourney,MAPS,load_models
from tools.harness.protocol import ProtocolError
rows=[]
case=WarpReentryTests();j,visits=case.fixture();j.state['npcs']=[{'x':2,'y':0}];j.warp(MAPS['ViridianForestNorthGate'])
assert visits==[((1,1),None,1),((1,0),MAPS['ViridianForestNorthGate'],1)],visits
assert j.position()==(5,7);rows.append({'name':'occupied adjacent warp falls back to ordinary off-and-back','ok':True,'visits':visits})
j=BrockJourney(None,'/private/tmp',{});j.models,j.doors,_=load_models(Path(os.environ['PARCEL_BUNDLE_SOURCE']));j.state={'zone_id':MAPS['ViridianForestNorthGate'],'player':{'x':6,'y':7},'npcs':[]};visits=[];sent=[]
def navigate(goal,transition=None):
 route=j.model().path(j.position(),{goal},j.occupied(),allow_warps={goal}if transition else ());visits.append((goal,transition,len(route)));assert not route
j.navigate=navigate
def send(*commands):
 sent.extend(commands);assert commands==('press down','wait 15');j.state['zone_id']=MAPS['ViridianForest'];j.state['player'].update(x=1,y=0)
j.send=send;j.drain=lambda:None;j.warp(MAPS['ViridianForest'])
assert visits==[((6,7),MAPS['ViridianForest'],0)];assert sent==['press down','wait 15'];rows.append({'name':'standing on bottom edge mat still sends outward down without detour','ok':True,'visits':visits,'commands':sent})
j,visits=case.fixture(single=True);original=j.model().terrain_step
def one_way(point,direction):
 if point==(1,1)and direction=='up':return None
 return original(point,direction)
j.model().terrain_step=one_way
try:j.warp(MAPS['ViridianForestNorthGate'])
except ProtocolError as error:assert str(error).startswith('no reachable source warp')
else:raise AssertionError('non-reversible reentry accepted')
assert not visits;rows.append({'name':'non-reversible off-warp path rejected before input','ok':True})
Path('/private/tmp/pokemon-warp-independent-review-01/extra-host-results.json').write_text(json.dumps({'scope':'host decisions/stubs only, no SDK or game verdict','results':rows},indent=2)+'\n');print(json.dumps(rows))

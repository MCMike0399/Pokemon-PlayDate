# Independent host navigation review

No blocking algorithm defect found in the private warp delta. Candidate and live Source/driver were not edited. No Simulator/SDK/Data action was run. Original Bulbasaur suite remains FAILED; this is not a game or campaign acceptance verdict.

Read full private diff against live82cb207. Only BrockJourney.warp changes: move unchanged interior classification before candidate evaluation; replace zero-length step-warp candidate with a bounded reversible ordinary off/back plan; retain ranking of other reachable source warps; execute an off-step only when selected. Existing bottom-edge outward action and strict destination/coordinate check remain unchanged. No relaxed assertions, synthetic movement, skipped encounters, forced transitions or retry-as-pass.

Independent checks:

- Original live method reproduces exactly `step warp failed to activate` from the captured snapshot. original-method-red.txt preserves the expected red.
- The fixture's SHA matches original processes/0001/03234-result.json f4ae476c4a70f34c4ebf9f6258ec195ad93d4b1a41fdca14f6b2de2d37cb67aa. Every fixture state field equals the actual snapshot, including all NPCs/poses. Build82cb207/Source44bd preserved.
- Three submitted regressions independently PASS using identified immutable build/source-manifest geometry. These exercise host decisions through a navigation acknowledgement stub, not native Playdate movement.
- Three extra independent host-only checks PASS: occupying adjacent Forest warp(2,0) chooses reversible(1,1)→(1,0), landing Gate(5,7); standing Gate bottom mat(6,7) retains pressdown/wait15 without detour, landing Forest(1,0); a deliberately non-reversible off/back path is rejected before input. See check_edges.py and extra-host-results.json. Synthetic one-way edit belongs only to host branch coverage.
- Parent's71targeted pass report was read, not independently relabeled as a new run.

The new branch rejects destination occupancy including current moving-NPC origin/target reservations from occupied(), rejects other warp/sign reentry cells, requires both terrain steps to be ordinary walk (no one-way ledge trap), includes both real steps in grass/cell cost and compares that with nonempty routes to other source warps. navigate still replans against observed NPCs after each actual step. A real failed step/transition still raises. No global input/RNG/game owner change.

## Native recipe projection

Pinned af519899 source NorthGate has width10movement cells, runtime minimum13, pad1. Source warps(4,7)/(5,7) become runtime(5,7)/(6,7); both target Forest warp1(1,0). Forest warp1(1,0) targets Gate warp3→runtime(5,7); Forest warp2(2,0) targets Gate warp4→runtime(6,7). Source data hashes were checked by load_models against the actual compiled source-manifest.

Therefore native-warp-return.json is coordinate-correct: initial labeled Gate(6,7), outward DOWN→Forest(1,0), wait15 must not bounce, RIGHT ordinary actual step→Forest(2,0) warp→Gate(6,7). Source footprints(1,0),(2,0),(1,1) passable;(2,1) blocked/sign region explains the older approach trap. The proposed recipe is UNRUN. It tests real input/arrival suppression/side-step return; it does not itself call candidate BrockJourney.warp. A fresh full Bulbasaur run (or a narrow actual candidate-method journey) is still required to qualify host integration.

## Small nonblocking coverage improvements

1. Add an explicit bottom-edge-current-mat regression and adjacent-warp-occupied→off/back regression to the formal candidate tests; the three independent supplementary checks above show expected current behavior without changing the candidate.
2. The test's `single=True` filters events['warps'] but leaves Geometry.warps cached with the other warp. It currently proves a single candidate selection with the old other surface still blocked, not a fully coherent single-warp map. Either label it precisely or update both caches in that fixture. This is a test-model consistency improvement, not evidence that the observed Forest fix is wrong.
3. Add explicit settled/explore assertions after each native destination await and before native screenshots. Current world entry should satisfy them, but they make the semantic/render evidence requirement concrete. Preserve the real15frame idle no-bounce check and original failed run.

Recommendation: retain the narrow algorithm, qualify native-warp-return and then fresh full Bulbasaur under root's serialized owner after the current suite; do not promote host replay counts to a gameplay verdict.

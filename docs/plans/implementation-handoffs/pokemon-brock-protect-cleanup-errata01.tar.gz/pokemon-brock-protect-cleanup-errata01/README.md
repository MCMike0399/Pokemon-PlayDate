# Protect cleanup assertion erratum

The preserved native evidence is `/private/tmp/pokemon-root-protect-field-sdk-02/00001-result.json`: 922 passed / 2 failed / 924 total. Only the Protect failure is addressed here. The registered Protect suite has 33 groups (the textual `test(` count also includes its local function definition).

`Battle:handleFaint` clears the fainted member before returning `replacement`. `finishRound` calls `endOfRoundStatus`, whose `conditions:events()` invokes `self:of(mon)` before its alive check. That creates an empty member table. No guard, stall, move lock or other volatile remains. The original nil assertion after residual collection therefore checked a representation detail, not the intended cleanup behavior. No production defect has been demonstrated and no production source is changed.

The same group now verifies deletion immediately after actual handleFaint; an entirely empty table after actual finishRound; no move locks; deletion of the old identity on actual chooseParty; no inherited guard/stall/lock on the replacement; and completely empty member and side owners after actual clearVolatiles. The fainted identity is still HP0; this does not revive or bypass the real forced-switch path. Every other group is byte unchanged.

Compile only:
```sh
python3 /private/tmp/pokemon-brock-protect-cleanup-errata01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-protect-cleanup-compile-01
```
Root alone may add `--execute` with a fresh output path for the actual SDK contracts. This packet does not launch Simulator by default. Actual revised SDK result remains UNRUN until root executes it. Frozen Protect01 and the failed SDK evidence are untouched.

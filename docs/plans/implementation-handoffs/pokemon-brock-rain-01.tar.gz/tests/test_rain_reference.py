import hashlib,json,unittest
from pathlib import Path
S=Path(__file__).resolve().parents[1]
def rolls(seed,n):
 out=[]
 for _ in range(n):seed=seed*16807%2147483647;out.append(seed-1)
 return out
def dmg(level,power,attack,defense,variance,water=False,stab=True,effective=1):
 n=((2*level//5+2)*power*attack//defense)//50+2
 if water:n=(n*6144+2047)//4096
 n=n*variance//100
 if stab:n=n*3//2
 return n*effective
class RainReference(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.report=json.loads((S/'showdown-rain-observations.json').read_text())
 def test_actual_reference_replay_identical(self):self.assertEqual((S/'showdown-rain-observations.json').read_bytes(),(S/'showdown-rain-observations-replay.json').read_bytes())
 def test_primary_weather_odd_literals(self):
  row=next(x for x in self.report['rows']if x['case']=='damage-odd-rounding'and x['weather']=='raindance')
  self.assertEqual([(x['base'],x['water'],x['fire'])for x in row['weatherInputs']],[(1,1,0),(3,4,1),(5,7,2),(7,10,3),(9,13,4),(11,16,5),(13,19,6),(15,22,7)])
  self.assertEqual(row['damage'],dict(watergun=22,ember=5,tackle=18,dragonrage=40))
 def test_primary_duration_recast_and_replacement(self):
  first=self.report['rows'][0]['timeline'];self.assertEqual([x.get('duration',0)for x in first],[4,3,2,1,0]);self.assertEqual(first[1]['pp'][0][1],6)
  other=self.report['rows'][1]['timeline'];self.assertEqual([x['weather']for x in other],['raindance','sandstorm','raindance']);self.assertEqual([x['duration']for x in other],[4,4,4])
 def test_primary_odd_recovery(self):
  r=[x for x in self.report['rows']if x['case']=='synthesis-rounding'];self.assertEqual([x['maxHP']for x in r],[145,145,145]);self.assertEqual([x['netHPChange']for x in r],[72,36,27])
  self.assertIn('|37/145',r[1]['healEvents'][0]);self.assertIn('|37/145',r[2]['healEvents'][0]) # Sand's later9 chip is distinct.
 def test_actual_native_literal_vectors(self):
  # Water recipe seed1: firstAI,secondAI,accuracy73,crit10,variance86.
  r=rolls(1,5);self.assertEqual((r[2]%100+1,r[3]%16+1,r[4]%16+85),(73,10,86))
  self.assertEqual(dmg(37,90,40,230,86,water=True),12)
  # Accuracy recipes seed4: AI,crit4,variance91,secondary84(no status).
  r=rolls(4,4);self.assertEqual((r[1]%16+1,r[2]%16+85,r[3]%100),(4,91,84))
  self.assertEqual(dmg(50,120,55,165,91,effective=2),50)
  self.assertEqual(dmg(53,120,42,165,91),21)
 def test_sdk_seed2_secondary_and_rounding_literals(self):
  r=rolls(2,5);self.assertEqual(r[3]%100,15);self.assertEqual(r[1]%16+85,86)
  self.assertEqual(dmg(50,40,55,115,86,water=True),18)
 def test_only_three_generator_rows_requested(self):
  r=json.loads((S/'generator-request.json').read_text());self.assertEqual(set(r['row_changes']),{'rainDance','thunder','hurricane'});self.assertEqual(r['rule_epoch'],7)
 def test_reference_and_generated_pins(self):
  self.assertEqual(hashlib.sha256((S/'showdown-rain-observations.json').read_bytes()).hexdigest(),'b443ce0fe1a9600a37dcedab310bee4ade4d1b1d4dc03ddf71db43691270ca26')
  self.assertEqual(hashlib.sha256((S/'Source/battle/moves.lua').read_bytes()).hexdigest(),'a39c85b17b94b79ba534fb7dfe1e760393a4a0b5f37ec2417d8b9ac193c23e0d')
if __name__=='__main__':unittest.main()

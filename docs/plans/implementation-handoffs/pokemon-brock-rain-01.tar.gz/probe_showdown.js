const path=require('path');
const reference='/private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547';
const {Battle}=require(path.join(reference,'dist/sim'));
const ivs={hp:0,atk:0,def:0,spa:0,spd:0,spe:0};
function setup(a='Squirtle',d='Snorlax',moves=['raindance','watergun','ember','synthesis'],enemy=['splash','sandstorm'],level=50){
 const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,4],p1:{name:'USER',team:[{species:a,ability:a==='Squirtle'?'Torrent':'Overgrow',nature:'Hardy',ivs,evs:{},level,moves}]},p2:{name:'FOE',team:[{species:d,ability:'Immunity',nature:'Hardy',ivs,evs:{},level,moves:enemy}]}});
 if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');return b;
}
const state=b=>({turn:b.turn,weather:b.field.weather,duration:b.field.weatherState.duration,hp:[b.p1.active[0].hp,b.p2.active[0].hp],pp:b.p1.active[0].moveSlots.map(x=>[x.id,x.pp])});
const logs=b=>b.log.filter(x=>!x.startsWith('|t:|'));
const rows=[];
{
 const b=setup(),timeline=[];for(const [a,d]of[['move 1','move 1'],['move 1','move 1'],['move 2','move 1'],['move 2','move 1'],['move 2','move 1']]){b.makeChoices(a,d);timeline.push(state(b));}rows.push({case:'duration-same-weather-no-refresh',timeline,log:logs(b)});b.destroy();
}
{
 const b=setup(),timeline=[];for(const [a,d]of[['move 1','move 1'],['move 2','move 2'],['move 1','move 1']]){b.makeChoices(a,d);timeline.push(state(b));}rows.push({case:'rain-sand-rain-replacement',timeline,log:logs(b)});b.destroy();
}
// Literal damage hook qualification: valid IV0/EV0 Hardy stats, controlled
// noncritical move clones and 100% random factor. Actual PS getDamage still
// computes real formula/modifier hooks; no copied damage comparator.
for(const weather of['none','raindance','sandstorm']){
 const b=setup(),p=b.p1.active[0],d=b.p2.active[0];if(weather!=='none')b.field.setWeather(weather,p,b.dex.moves.get(weather));
 b.randomizer=x=>x;
 const damage={};for(const key of['watergun','ember','tackle','dragonrage']){const m=b.dex.getActiveMove(key);m.willCrit=false;damage[key]=b.actions.getDamage(p,d,m,true);}
 const weatherInputs=[1,3,5,7,9,11,13,15].map(n=>({base:n,water:b.priorityEvent('WeatherModifyDamage',p,d,b.dex.getActiveMove('watergun'),n),fire:b.priorityEvent('WeatherModifyDamage',p,d,b.dex.getActiveMove('ember'),n)}));
 rows.push({case:'damage-odd-rounding',weather,stats:{p:p.storedStats,d:d.storedStats},damage,weatherInputs,log:logs(b)});b.destroy();
}
for(const weather of['none','raindance','sandstorm']){
 const b=setup('Venusaur','Snorlax',['synthesis','splash'],['splash','sandstorm'],52);const p=b.p1.active[0];p.hp=1;if(weather!=='none')b.field.setWeather(weather,p,b.dex.moves.get(weather));const before=p.hp;b.makeChoices('move 1','move 1');rows.push({case:'synthesis-rounding',weather,maxHP:p.maxhp,netHPChange:p.hp-before,healEvents:logs(b).filter(x=>x.startsWith('|-heal|')),log:logs(b)});b.destroy();
}
for(const key of['thunder','hurricane'])for(const weather of['none','raindance']){
 const b=setup('Venusaur','Snorlax',[key,'splash']);const p=b.p1.active[0],d=b.p2.active[0];p.boosts.accuracy=-6;d.boosts.evasion=6;if(weather!=='none')b.field.setWeather(weather,p,b.dex.moves.get(weather));b.makeChoices('move 1','move 1');rows.push({case:'weather-accuracy-extreme-stages',move:key,weather,state:state(b),log:logs(b)});b.destroy();
}
process.stdout.write(JSON.stringify({reference:'9b136a8c8cdb860a8ab96fa063f906604e352547',format:'gen5customgame',fixture:'Hardy IV0 EV0 level50 (Synthesis case52); controlled illegal move sets for mechanism isolation, not acquisition. Odd-round damage explicitly disables crit and fixes randomizer100%; real turns use literal seed [1,2,3,4].',rows},null,2)+'\n');

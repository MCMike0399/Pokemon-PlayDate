#!/usr/bin/env python3
"""Private patch composition and compile; --execute is reserved to root owner."""
import argparse,hashlib,json,subprocess,sys,shutil
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--mutant',choices=['refresh','late-weather','rain-accuracy-roll','sand-leaks']);a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def apply(output,path):
 result=subprocess.run(['git','apply','-p1','--check',str(path)],cwd=output,capture_output=True,text=True)
 if result.returncode:
  inverse=subprocess.run(['git','apply','-p1','--reverse','--check',str(path)],cwd=output,capture_output=True,text=True)
  assert inverse.returncode==0,'shared source conflict '+str(path)+': '+result.stderr;return
 subprocess.run(['git','apply','-p1',str(path)],cwd=output,check=True)
def change(path,old,new):
 body=path.read_text();assert body.count(old)==1,'mutant anchor '+old;path.write_text(body.replace(old,new,1))
def prepare(project,sdk,output,session):
 for r in manifest['source_files']:
  assert sha(stage/r['path'])==r['sha256'],'source drift '+r['path'];assert sha(stage/r['patch'])==r['patch_sha256'],'patch drift '+r['patch']
 for rel,expected in manifest.get('packet_files',{}).items():assert sha(stage/rel)==expected,'packet drift '+rel
 metadata=original(project,sdk,output,session)
 # Requires the reviewed combined charge/sex/held/power base, never an old tree.
 b=(output/'Source/battle/battle.lua').read_text();effects=(output/'Source/battle/effects.lua').read_text()
 assert 'self.conditions:rawPower('in b and 'function BattleEffects:weatherId()'in effects,'requires integrated power-order + charge dependencies'
 for row in manifest['source_files']:
  if row['base_sha256']is None:
   target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/row['path'],target)
  else:
   if row['path']=='Source/battle/moves.lua':assert sha(output/row['path'])in(row['base_sha256'],row['sha256']),'unreviewed generated move epoch'
   apply(output,stage/row['patch'])
 if a.mutant=='refresh':change(output/'Source/battle/effects.lua','if self:weatherId()==id then self.battle:say("But it failed!");return false,"same-weather" end','if false then self.battle:say("But it failed!");return false,"same-weather" end')
 elif a.mutant=='late-weather':
  target=output/'Source/battle/battle.lua';body=target.read_text();line='    if effects then damage=effects:weatherDamage(move,damage) end\n';assert body.count(line)==1;body=body.replace(line,'',1);anchor='    damage = math.floor(damage * RulesRNG.random(85, 100) / 100)';assert body.count(anchor)==1;body=body.replace(anchor,line+anchor,1);target.write_text(body)
 elif a.mutant=='rain-accuracy-roll':change(output/'Source/battle/effects.lua','return move.weatherAccuracy==true and self:weatherId()=="raindance"','return false')
 elif a.mutant=='sand-leaks':change(output/'Source/battle/effects.lua','if self:weatherId()=="sandstorm" then events[#events+1]={kind="sand"','if self.weather then events[#events+1]={kind="sand"')
 main=output/'Source/main.lua';body=main.read_text();anchor='import "dev/catalog"';assert body.count(anchor)==1
 if 'import "dev/rainContracts"'not in body:body=body.replace(anchor,'import "dev/rainContracts"\nContracts.register("rain",RainContracts.run)\n'+anchor,1)
 main.write_text(body)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated);values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['rain']=manifest;metadata['fault_mutant']=a.mutant
 with(output/'rain-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

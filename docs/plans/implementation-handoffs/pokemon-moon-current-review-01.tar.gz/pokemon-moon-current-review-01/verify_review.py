#!/usr/bin/env python3
"""Read-only review identity verifier. Never invokes SDK/Simulator or applies code."""
import argparse,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verify(project):
 manifest=json.loads((P/'manifest.json').read_text())
 for rel,digest in manifest['files'].items():
  if sha(P/rel)!=digest:raise ValueError('review evidence drift: '+rel)
 observation=json.loads((P/'observations.json').read_text());h=hashlib.sha256()
 for f in sorted((project/'Source').rglob('*')):
  if f.is_file()and str(f.relative_to(project))!='Source/dev/harness_build.lua':h.update(str(f.relative_to(project)).encode()+b'\0'+f.read_bytes())
 if h.hexdigest()!=observation['base_source_sha256']:raise ValueError('current Source is no longer reviewed snapshot')
 expected=json.loads((P/'integrity-checks.json').read_text())['archive_hashes']
 for name,digest in expected.items():
  if sha(project/'docs/plans/implementation-handoffs'/('pokemon-mt-moon-'+name+'.tar.gz'))!=digest:raise ValueError('archive drift: '+name)
 return {'ok':True,'source_sha256':h.hexdigest(),'runtime_accepted':False,'patches_applied':False}
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--project',type=Path,required=True);args=parser.parse_args();print(json.dumps(verify(args.project.resolve())))

# Moon current review01

Read READINESS.md first, then merge-plan.json and acceptance-cases.json. This is preparation/review only. No integration, new game implementation, live/harness/HEAD write or Simulator/Data access. The old runtime validator must not be used on current Source. Five of seven archived full snapshots are stale; exact diffs preserve what changed and what must remain.

Inputs are the repository's frozen MtMoon slice/runtime archives, re-extracted privately here. Archive checksums and all323payload hashes verified. Current source/helpers/references are pinned in integrity-checks.json, current-source-manifest.json and cerulean-source-gap.json. Re-ran16runtimeJSON reproduction and independent original-source image/geometry oracle; those HOST checks do not accept art/gameplay. No SDK compiles/runtime or private test counts claimed as acceptance.

```
python3 /private/tmp/pokemon-moon-current-review-01/verify_review.py --project /Users/burbujamc/Developer/Pokemon-PlayDate
```

Review describes exact current owner seams, common newly exposed mechanics, 31proposed SDK/native/natural/SaveContinue/resource cases, and the missing source Cerulean arrival scope. Current firstgate1091SDK/529host/2494catalog evidence and active Brock suite remain root-owned, untouched. The import-gate packet remains frozen/unaccepted and is not included.

Root can authorize a coherent current-base batch after current Brock acceptance. Do not copy any archived shared Lua file or stale hostdriver wholesale; all current independent receipt, specimen, reward/cohort, learning/evolution, Mom/Daisy, personalPC, FieldBattle and TitleRecovery ownership must survive. No synthetic Cerulean rectangle, invented source trainer/reward/dialogue, inaccessibleLv31shortcut or test count-only workaround is recommended.

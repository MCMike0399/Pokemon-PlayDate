#!/usr/bin/env python3
"""Identified private overlay. Compile only by default; --execute reserved for root."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def once(text,anchor,new):
 assert text.count(anchor)==1,'import hook drift '+anchor;return text.replace(anchor,new,1)
def prepare(project,sdk,output,session):
 metadata=original(project,sdk,output,session)
 for item in manifest['source_files']:
  source=stage/item['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==item['sha256'],'packet drift '+item['path']
  live=project/item['path'];base=stage/'base'/item['path'];target=output/item['path'];target.parent.mkdir(parents=True,exist_ok=True)
  actual=hashlib.sha256(live.read_bytes()).hexdigest()if live.exists()else None
  if actual in (item['base_sha256'],item['sha256']):shutil.copy2(source,target)
  elif base.exists()and live.exists():
   result=subprocess.run(['git','merge-file','-p',str(source),str(base),str(live)],capture_output=True);assert result.returncode==0,'review Source merge '+item['path'];target.write_bytes(result.stdout)
  else:raise ValueError('Source ownership changed '+item['path'])
 for hook in manifest['hooks']:
  patch=stage/hook['patch'];assert hashlib.sha256(patch.read_bytes()).hexdigest()==hook['patch_sha256'];subprocess.run(['git','apply','--check',str(patch)],cwd=output,check=True);subprocess.run(['git','apply',str(patch)],cwd=output,check=True)
 main=output/'Source/main.lua';text=main.read_text();text=once(text,'import "data/items"','import "data/items"\nimport "data/lightBall"');text=once(text,'import "dev/catalog"','import "dev/traitContracts"\nContracts.register("specimen-sex-light-ball", TraitContracts.run)\nimport "dev/catalog"');main.write_text(text)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted((output/'Source').rglob('*'))if x.is_file()and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
 info.write_text(generated);values=[]
 for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
  v=metadata[key];values.append('    '+key+' = '+('true'if v is True else json.dumps(v,ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n');metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['traits_packet']=manifest
 with(output/'traits-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

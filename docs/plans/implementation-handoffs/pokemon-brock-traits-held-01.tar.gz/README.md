# Pre-Brock B2W2 sex and Light Ball candidate

Staged only. Root owns integration, Simulator, runtime Data and acceptance. Compile-only proof `/private/tmp/pokemon-brock-traits-compile-04` passed. Full host shadow `full-shadow-host-02.log`: 388 tests passed, zero skips (includes seven new source/generator groups). Twenty production SDK groups are authored, not executed by this worker. No runtime completion claim.

## Merge inventory

`manifest.json` pins candidate Source files and original-byte hashes. Apply the new generated `data/specimenTraits.lua`, `data/lightBall.lua`, narrow `domain/specimen.lua`/`domain/pokemonCodec.lua` changes and `data/pokemon.lua` hunk. Existing eight dev suites have explicit, reviewable protocol/schema migrations under `patches/contract-*.patch`; no assertions were deleted. New `dev/traitContracts.lua` covers the added domain behavior.

Shared-owner patches are separate: `patches/zone-encounter.patch` passes a validated physical-lead token into the existing detached whole encounter transaction; `patches/light-ball-effects.patch` adds the species/item attack modifier to `BattleEffects:attackStat`. No battle.lua, Story, GameSession, SessionCodec, fixtures, UI, main or diagnostics file is replaced. Root main adds `import "data/lightBall"` immediately after data/items, plus import/register TraitContracts. Pokemon's existing import chain loads specimenTraits after protected specimenData and before specimen. Keep root's Focus/seen and all other hooks.

`validate_staged.py --project /project --output /unique/build` overlays only manifest files, applies the two narrow hooks, imports/registers, fingerprints and compiles. Default is compile-only. `--execute` is reserved for root and uses the ordinary harness/lock/private bundle. It does not launch from this worker. `contracts.json` runs all registered suites, including the twenty new groups, so original suites remain testable. Mismatched Source merges or import anchors fail; no stale tree copy.

## Durable model and migration

`Pokemon:getSex()` returns male/female/genderless from validated attributes. All151 raw B2W2 sex ratio bytes are generated; 0/254/255 fixed categories differ from mixed thresholds31/63/127/191. Female means byte<ratio, not rounded percent. Counts6/19/10/91/6/6/13 match an independent PokeAPI gender-rate category projection. All72 original151 evolution edges preserve ratio. No art, roster, stats, move selection or ability-slot table changes.

Constructor defaults use species majority sex, male ties, explicitly labelled constructor-default. Explicit sex has explicit provenance. Generated provenance records `{version=1,kind='generated',protocol=2,origin,byte}` and must agree with species/byte. Returned attribute/provenance tables are detached. Fixed-sex/genderless mismatches, forged history/unknown keys and malformed provenance reject.

PokemonCodec6 supports legitimate3/4/5 records. Old records must not contain sex fields. Versions3/4 retain their already-approved Hardy/first/none defaults;5 preserves nature/slot/held item. Each receives valid deterministic majority sex and legacy-default provenance without any RNG call; no claim of reconstructed history. Names, selected moves/PP, HP/status/sleep, XP, pending choices/evolution remain intact. Version6 requires complete sex/provenance. SessionCodec1 is unchanged: it already delegates validation/construction to PokemonCodec and copies the new small primitive fields safely. Wide RNG/counters retain the existing decimal codec.

Creation protocol2 samples normal slot, independent nature, then uniform sex byte even for fixed/genderless species. Seed1 prefix first/23 remains, third byte216/state1622650073 is exact. No hidden acquisition. Only wild Pikachu adds a fourth API held sample. Receipts distinguish API samples/raw rejection rolls, before/after stream, sex byte and held roll/policy. Every sample runs on a detached stream, committing continuation once after construction and final context validation. Native MAX unchanged. Rejected origins/metadata/context and third/fourth sample exhaustion do not commit RNG. Entire trainer and encounter transactions remain outer owners; their explicit vectors change to three samples/member and six samples/Pikachu encounter (species+level+four attributes).

## Authoritative field held policy

`Specimen.planEncounter(session)` mints an opaque private token tied to the active session, its Party identity, actual physical slot1 Pokémon identity/species/ability-slot/ability and the unchanged global rules continuation. Production `Zone:rollEncounter(session)` creates it before any species/level samples; the factory validates it before sampling and before commit. Missing lead, inactive/foreign owner, substituted token, reordered/evolved/ability-changed lead or advanced global rules continuation reject. A fainted physical lead still applies Compound Eyes, matching native CreateEncountManager; active battle index is irrelevant. `createForSession(...,'wild')` automatically obtains this context. Explicit independent `create(...,rng)` samplers without a token deliberately mean ordinary unmodified encounters; they cannot stand in for production field sampling.

Pikachu personal held fields are `[0,236,0]`. Ordinary weights50/5/0 produce Light Ball only at rolls50..54, including empty common-slot weight. Compound Eyes weights60/20/0 produce it at60..79. No extra activation sample. Native ID236 maps through generation5 `item_game_indices.csv` to **PokeAPI item213**, identifier light-ball. Neither202 nor PokeAPI236 is Light Ball; no such mapping is shipped. Canonical runtime ID lightBall stores gen5Id236/pokeApiId213 explicitly, never a fabricated Blue numericId.

The protected Blue124 definition source and Blue49 holdability generator remain unchanged; two explicit loaded extensions produce125 definitions/50 holdable keys. Light Ball has no guessed buy/sell price, shop, gift or ordinary bag-use effect. Give/Take uses existing same-mon/Inventory ownership; unknown-price sale fails unchanged. Only Pikachu's loot is enabled. All other34 ordinary held items and later region loot remain pending, not silently certified.

## Battle modifier and primary evidence

Light Ball doubles effective physical Attack and special SpAttack for species pikachu only, after existing stat stages at the existing attack modifier hook. Raichu/other species get no benefit; durable stats/base power/PP and RNG stay unchanged. Native C item_handlers.c HandlerLightBall registers attack event0x3b and multiplies0x35 by FX32_CONST(2) after the exact Pikachu guard. Independent Showdown item handler has onModifyAtkPriority1/onModifySpAPriority1 and chainModify2; immutable GenV override does not replace Light Ball. Existing legitimate Pikachu abilities have no attack modifier, so no unsupported combined-ability ordering is implied. Actual calcDamage contracts expect physical14→27, special16→30 and burned physical13 at seeded variance100. Fixed damage never queries this attack stat. Fling/item theft, other held effects and broader ability field interactions are not certified by this slice.

Nineteen immutable source pins, including actual B2W2 personal binary/schema/C functions, PokeAPI species/items/native crosswalk and C+Showdown Light Ball handlers, are vendored under tools/references/traits. `tools/references/traits-sources.json` contains exact immutable URLs/SHA256. No moving master/download needed. Reproduce/check:

```sh
python tools/generate_specimen_traits.py --project /project --output /candidate --check
```

Source checks reject missing/corrupt inputs, wrong binary gender ratio, incorrect native crosswalk and changed generated output. Host checks prove all151 ratios and all72 graph edges. Protected old specimenData.lua/items.lua and art bytes are untouched.

## Root native qualification recipes

1. Run helper with `--execute` after reviewing/merging hooks. Require all existing suites plus twenty trait groups. Read actual JSON errors; compile/host success is not SDK acceptance.
2. Controlled real-input Forest fixture with physically first Butterfree (including fainted lead) and separate living active starter: cross actual grass step into seeded Pikachu; record generation receipt and actual caught enemy ID. Ordinary vs Compound Eyes distributions use deterministic boundary vectors in contracts, not a random frequency claim.
3. Capture the generated held Pikachu through actual battle ball command (SDK suite uses Master Ball only as a labelled capture fixture), assert exact same mon/sex/provenance/Light Ball. Party→Give/Take→bag ownership, full bag rejection, then save and actual owned-process restart/Continue; encode before/after and require no nature/slot/sex/held reroll. Source-derived actual Forest seeds are in native-forest-vectors.json:19525 ordinary heldRoll53;2583 heldRoll64 (Compound Eyes only). A separate SDK group exercises the actual isolated Blue Forest chance/slot producer and full seven-roll continuation; root still executes the real-input witness.
4. Controlled same Pikachu against neutral target, physical and special moves, before/after Take: capture damage/PP/RNG traces. Evolve via actual Thunder Stone, retain sex/provenance/held identity, confirm Raichu loses the Light Ball attack benefit. No new art is needed. Optional patches/diagnostics-traits-optional.patch adds read-only sex/provenance snapshot fields for root. Root UI/diagnostics may read getSex; this packet does not add speculative INFO layout.
5. Repeat rejection/stale token and malformed late party/storage payload cases, verifying both rules/world streams and current owner identities. Existing whole trainer late-failure and native counter-cap groups stay active after explicit vector migration.

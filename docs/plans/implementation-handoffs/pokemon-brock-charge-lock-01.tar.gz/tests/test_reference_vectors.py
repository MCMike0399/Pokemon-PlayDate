"""Independent integer arithmetic/reference integrity checks; not SDK execution."""
import hashlib,json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def damage(level,power,attack,defense,variance,stab_num=1,stab_den=1,type_num=1,type_den=1):
 base=((2*level//5+2)*power*attack//defense)//50+2
 return ((base*variance//100)*stab_num//stab_den)*type_num//type_den
class Vectors(unittest.TestCase):
 def test_literal_hardy_iv0_native_vectors(self):
  self.assertEqual(damage(44,120,62,55,89,3,2,1,2),35)
  self.assertEqual(damage(31,100,34,230,89),5)
  self.assertEqual(damage(32,120,69,55,88,3,2,1,2),28)
  self.assertEqual(damage(32,120,69,55,91,3,2,1,2),30)
 def test_level100_core_vectors(self):
  self.assertEqual(damage(100,120,205,225,88,3,2),121)
  self.assertEqual(damage(100,120,205,225,89,3,2),123)
  self.assertEqual(damage(100,60,205,225,89,3,2),61)
  self.assertEqual(damage(100,120,205,225,91,3,2),126)
 def test_real_learning_continuation_vector(self):
  self.assertEqual(damage(38,120,20,33,88,3,2),33)
  self.assertEqual(damage(39,120,20,25,95,3,2,1,2),24)
 def test_immutable_oracle_files(self):
  m=json.loads((ROOT/'oracle-manifest.json').read_text())
  for path,sha in m['files'].items():self.assertEqual(hashlib.sha256(Path(path).read_bytes()).hexdigest(),sha,path)
  self.assertEqual(hashlib.sha256((ROOT/'references/showdown-pinned.tar.gz').read_bytes()).hexdigest(),m['archive_sha256'])
 def test_generator_dependency_exact(self):
  self.assertEqual(hashlib.sha256((ROOT/'Source/battle/moves.lua').read_bytes()).hexdigest(),'5fa4b4be19637a43f170f0d0a3c61cc1ddca87673a4ea0865ba2507db884df27')
 def test_recipe_json_has_semantic_message_boundaries(self):
  for path in (ROOT/'scenarios').glob('*.json'):
   data=json.loads(path.read_text());self.assertGreater(len(data['commands']),30)
   self.assertTrue(any(isinstance(c,dict)and c.get('path')=='battle.waiting'for c in data['commands']))
if __name__=='__main__':unittest.main()

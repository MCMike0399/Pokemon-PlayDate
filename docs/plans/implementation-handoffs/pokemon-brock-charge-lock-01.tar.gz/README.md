Charge / rampage candidate, staged only
======================================

Scope: Gen V Solar Beam, Skull Bash and Petal Dance. No live Source, protected art, main hooks, Simulator process or runtime Data was changed by this worker. Root alone executes the runtime commands below. Implementation is not native acceptance.

The engine base is frozen `/private/tmp/pokemon-brock-bide-01` (it includes batch01 and its explicit zero-power erratum). Generated moves are root's epoch6 dependency, SHA256 `5fa4b4be19637a43f170f0d0a3c61cc1ddca87673a4ea0865ba2507db884df27`. Base metadata for its diff is root v5, retaining peer Captivate metadata. Exactly three rule fields and two constructor attributes differ; no original scalar/effect changes.

Integration is narrow: `patches/` compares the declared base to this candidate. Conditions owns transient charge/rampage identities; Battle uses its existing lexical validated continuation and current round receipt. No fake learned slot, persistent lock field, global event bus or competing RNG is introduced. A first charge consumes PP after existing status gates; release consumes none, even if the move was genuinely forgotten through LearningState. Charge preparation precedes opponent immunity. Skull Bash raises Defense once on preparation; release uses the current opponent slot. Petal duration is sampled only after its first successful HP receipt, before contact reactions; actual attempts decrement the lock. A final failed attempt fatigues; an early failed attempt ends quietly. A status-blocked final attempt fatigues at the late residual boundary, after Sandstorm; receiving sleep after a successful hit clears quietly. Exit/faint/withdraw discard the transient state.

`getConditionsSnapshot()` adds `charge_key`, `rampage_key`, `rampage_remaining`, `rampage_total`. Draw and pure observers do not advance them. Root can expose these existing snapshot fields without new ownership hooks. The normal BattleState/LearningState owner is exercised by actual XP/choice tests that forget Solar/Petal mid-lock.

Shared-owner merge cautions
--------------------------

Root is separately merging the peer Rivalry/Light Ball/status/OwnTempo packet and the independently proved MudSport rounding erratum. Do NOT copy this old standalone Effects basePower body over that work. Charge contributes only appended `weatherId()` / static `solarPolicy(weather)` and the weather predicate. In the combined Q12 body retain `ratio=chain(ratio,2048)` with condition `move.sandWeakened and select(2,BattleEffects.solarPolicy(self:weatherId()))==2048`. Preserve explicit attacker/defender arguments and the root early-zero guard for status/fixed moves. The peer rawPower→combined-Q12 seam is independent; no rounded Conditions compatibility facade should be restored.

Only Sandstorm has a real current producer. `solarPolicy` explicitly recognizes none/Sun/Rain/Sand/Hail for future weather owners; Sun skips charge, Rain/Sand/Hail halve power at release, and unknown later weather is rejected. The Sun SDK case injects the pure weather-query result, not a fake working Sun producer. Rain/Sun/Hail field producers and Power Herb acquisition/effects remain dependencies, not supported successful no-ops. OwnTempo20 fatigue prevention is mandatory composed proof through the shared status predicate and DSL pre-duration guard; `chargeOwnTempoContracts` fails if omitted.

Pinned source and independent evidence
-------------------------------------

Pokémon Showdown revision `9b136a8c8cdb860a8ab96fa063f906604e352547`, immutable archive SHA256 `4c02da77a874f07cfa4de163b3ac7a2553b4f390e7f717aa08afa487b20a7967`. `oracle-manifest.json` pins archive, lockfile, dispatcher, conditions, probe script and original mechanical report. Primary bodies: [lockedmove / twoturnmove](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/conditions.ts#L253), [Petal Dance](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/moves.ts#L13288), [Skull Bash](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/moves.ts#L16621), [Solar Beam](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/moves.ts#L17220), plus Gen5 Skull Bash power/PP override and inherited Gen6 confusion/Gen5 sleep conditions inside the pinned archive.

`probe_showdown.js` runs the actual compiled Gen5 PS Battle with explicit Hardy/EV0 sets; normalized IV31, speed and moves/PP are recorded. Default PS PPups3 means Petal maxPP16; this oracle proves dispatch/timing, not SDK base10 PP or IV0 damage. Only wall-clock `|t:|` records are removed. Raw PS confusion.time includes its decrement-before-check extra1; SDK remaining-turn values are not copied blindly. Root independently replayed the original report byte-for-byte: SHA256 `3220d22375cd33a86afb7e0eb5b7b2f2b08fd320b239f518c782ba8080580a99`. The extended probe adds actual Sandstorm to blocked final-turn fatigue and retains all mechanical logs.

The B2W2 reconstruction `fuddlesworth/pokebw2` revision `b279bbefa99bb2f6fbabcc95e4b6d3e939290353`, `bw_move_handlers.c` Thrash2812–2895 / Solar6735 / Skull6820, corroborates duration2–3 and weather/Defense rules but draws rampage duration before accuracy. The maintained PS dispatcher starts the successful self-effect after HP calculation and before contact. This packet deliberately follows PS's outcome/timing and first-miss sampling policy, as approved by root; it does NOT claim equivalent native RNG protocol or canonical reconstruction quality. Park–Miller itself is already an intentional RNG adaptation.

Root additionally independently probed Bide on the same compiled engine: `/private/tmp/pokemon-root-bide-reference-01.js` + `.json` confirms Ghost immunity, fixed20 ignoring Rock, Sturdy1 and one PP across3 attempts. This is a pointer to new independent evidence, not a modification of the frozen Bide packet.

Reproduction / pending acceptance
--------------------------------

Host: `python3 -m unittest discover -s /private/tmp/pokemon-brock-charge-lock-01/tests -v` — 6 PASS. Core SDK compiler build01 and shared-status/OwnTempo build04 PASS; no SDK tests were executed by this worker. Authored core module has30 groups, mandatory composed fatigue module1. Run root-only:

```sh
python3 /private/tmp/pokemon-brock-charge-lock-01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-brock-charge-sdk-01 --with-own-tempo --execute
```

Default omits `--execute` and only compiles. Helper overlays only declared owned candidate files onto CURRENT Source, registers the test modules privately, composes exact hash-pinned peer patches, refreshes source/build identities, and refuses drift. Its temporary exact basePower normalization solely lets the peer reviewed patch apply; it then reinstates the Solar policy condition while retaining their Q12 body. Root's final integrated rounding work still requires serial reviewed merge; `--merge-current` attempts a declared-base three-way merge and fails on conflicts rather than overwriting them.

Actual PS root is `references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547`; invoke `node /private/tmp/pokemon-brock-charge-lock-01/probe_showdown.js`. To rebuild from pinned tar in a fresh private directory: extract archive, `npm ci --ignore-scripts --omit=dev --no-audit --no-fund`, then `node build`. No server starts. Exclude node_modules and npm-cache from any handoff archive; immutable archive/lockfile/script suffice.

Three native recipes in `scenarios/` use naturally initialized slot4 Solar Beam (Bulbasaur44), Skull Bash (Squirtle31), Petal Dance (Venusaur32), each versus Metapod100's actual Harden. These are technical fixtures, not altered campaign acquisition. They await exact narration/waiting boundaries, record preparation and impact frames and assert PP/damage/RNG/lock completion. Root invokes the helper with `--scenario <absolute recipe> --execute`, or runs them after serial integration. Expected literal HP: Solar210→175, Skull210→205, Petal210→182→152; RNG5/5/10, PP9/14/9. Native screenshots/frame recipes remain UNRUN. Existing flash/critical shake path is retained; this packet adds no invented move art. Root must inspect frames and naturally accept campaign/multistarter/evolution/capture/Brock independently.

#!/usr/bin/env python3
"""Compile privately by default. Root alone may opt into Simulator --execute."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--with-own-tempo',action='store_true');p.add_argument('--merge-current',action='store_true');a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'foundation-manifest.json').read_text());original=harness.prepare

def prepare(project,sdk,output,session):
 for r in manifest['source_files']:assert sha(stage/r['path'])==r['sha256'],'packet drift '+r['path']
 for rel,expected in manifest['packet_files'].items():assert sha(stage/rel)==expected,'packet drift '+rel
 metadata=original(project,sdk,output,session);composed=[]
 for r in manifest['source_files']:
  rel=r['path'];source=stage/rel;target=output/rel;base=stage/'base'/rel;live=project/rel;target.parent.mkdir(parents=True,exist_ok=True)
  # Base overlay is declared frozen Bide. On current root checkpoint it is an
  # explicit candidate, not a claim that the old live engine is already Bide.
  if a.merge_current and live.exists() and base.exists():
   result=subprocess.run(['git','merge-file','-p',str(source),str(base),str(live)],capture_output=True);assert result.returncode==0,'source conflict '+rel;target.write_bytes(result.stdout)
  else:
   assert (sha(live)if live.exists()else None)in(r['checkpoint_sha256'],r['base_sha256'],r['sha256']),'unreviewed current source '+rel
   shutil.copyfile(source,target)
  composed.append({'path':rel,'live_sha256':sha(live)if live.exists()else None,'candidate_sha256':sha(target)})
 if a.with_own_tempo:
  dependency=Path('/private/tmp/pokemon-brock-sex-abilities-01');dep=manifest['own_tempo_dependency'];assert sha(dependency/'manifest.json')==dep['manifest_sha256'],'owner manifest drift'
  assert sha(dependency/'base/Source/battle/effects.lua')==dep['base_effects_sha256'],'owner base drift'
  # Exact reviewed shared owner patch composition, never full old Effects/DSL.
  patches=['effects.patch','dsl-status.patch','own-tempo-effects.patch','own-tempo-dsl.patch']
  for name in patches:
   patch=dependency/'patches'/name;assert sha(patch)==dep['patches'][name],'owner patch drift '+name
   if name=='effects.patch':
    target=output/'Source/battle/effects.lua';body=target.read_text()
    start=body.index('function BattleEffects:basePower(');end=body.index('function BattleEffects:weatherHeal(',start)
    expected=(stage/'Source/battle/effects.lua').read_text();i=expected.index('function BattleEffects:basePower(');j=expected.index('function BattleEffects:weatherHeal(',i)
    assert body[start:end]==expected[i:j],'unexpected shared basePower composition'
    old=(dependency/'base/Source/battle/effects.lua').read_text();i=old.index('function BattleEffects:basePower(');j=old.index('function BattleEffects:weatherHeal(',i)
    q=body.index('-- Canonical GenV query seam.');solar_methods=body[q:start]
    target.write_text(body[:q]+old[i:j]+body[end:])
   result=subprocess.run(['git','apply','--unsafe-paths',str(patch)],cwd=output,capture_output=True,text=True)
   assert result.returncode==0,'owner dependency conflict '+name+': '+result.stderr
   if name=='effects.patch':
    target=output/'Source/battle/effects.lua';body=target.read_text();old='if self.weather and move.sandWeakened then ratio=chain(ratio,2048) end';assert body.count(old)==1
    body=body.replace('function BattleEffects:basePower(',solar_methods+'function BattleEffects:basePower(',1)
    body=body.replace(old,'if move.sandWeakened and select(2,BattleEffects.solarPolicy(self:weatherId()))==2048 then ratio=chain(ratio,2048) end');target.write_text(body)
 main=output/'Source/main.lua';body=main.read_text();anchor='import "dev/catalog"';assert anchor in body
 modules=[('chargeLockContracts','charge-lock','ChargeLockContracts')]
 if a.with_own_tempo:modules.append(('chargeOwnTempoContracts','charge-own-tempo','ChargeOwnTempoContracts'))
 for module,key,table in modules:
  line='import "dev/'+module+'"'
  if line not in body:body=body.replace(anchor,line+'\nContracts.register("'+key+'",'+table+'.run)\n'+anchor,1)
 main.write_text(body)
 for row in manifest['metadata_count_patches']:
  path=output/row['path'];body=path.read_text()
  assert sha(stage/row['patch'])==row['patch_sha256']
  assert sha(path)in(row['base_sha256'],row['sha256']),'metadata assertion changed '+row['path']
  if path.name=='abilityContracts.lua':body=body.replace('for424 moves','for425 moves').replace('eq(n,424)','eq(n,425);eq(moveData.bide.targetId,7);eq(moveData.bide.damageRule,"bide")')
  else:body=body.replace('All424 generated','All425 generated').replace('equal(count,424)','equal(count,425);equal(moveData.bide.targetId,7);equal(moveData.bide.damageRule,"bide")')
  path.write_text(body)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated)
 values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['charge_lock']=manifest;metadata['composed_files']=composed
 with(output/'charge-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

const path=require('path');
const base=path.join(__dirname,'references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547');
const {Battle}=require(path.join(base,'dist/sim'));
function setup(n){const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,n],p1:{name:'USER',team:[{species:'Venusaur',ability:'Overgrow',nature:'Hardy',level:100,moves:['petaldance','splash']}]},p2:{name:'FOE',team:[{species:'Snorlax',ability:'Thick Fat',nature:'Hardy',level:100,moves:['splash','spore','headbutt']}]}});if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');return b;}
function fixture(b){return {format:'gen5customgame',source:'literal custom battle sets in probe_showdown.js; not species learn legality or availability proof',p1:mon(b.p1.active[0]),p2:mon(b.p2.active[0])};}
function mon(p){return {species:p.species.id,level:p.level,nature:p.getNature().name,gender:p.gender,ivs:p.set.ivs,evs:p.set.evs,hp:p.maxhp,storedStats:p.storedStats,speed:p.getActionSpeed(),moves:p.moveSlots.map(x=>({id:x.id,pp:x.pp,maxpp:x.maxpp}))};}
function view(b){const p=b.p1.active[0],s=p.volatiles.lockedmove;return {turn:b.turn,hp:p.hp,pp:p.moveSlots[0].pp,status:p.status,locked:s?{duration:s.duration,trueDuration:s.trueDuration,move:s.move}:null,confusion:p.volatiles.confusion?.time,log:b.log.filter(x=>!x.startsWith("|t:|"))};}
const rows=[];
for(const mode of ['flinchSand']){
 let found=new Set();
 for(let n=1;n<=200&&found.size<2;n++){
  const b=setup(n);b.makeChoices('move 1','move 1');const p=b.p1.active[0],e=b.p2.active[0],first=view(b),duration=p.volatiles.lockedmove?.trueDuration;
  if(!duration||found.has(duration))continue;
  const logStart=b.log.length;
  if(mode==='miss'){p.boosts.accuracy=-6;e.boosts.evasion=6;}
  if(mode==='flinch'||mode==='flinchSand')p.addVolatile('flinch');
  if(mode==='flinchSand')b.field.setWeather('sandstorm',e,b.dex.moves.get('sandstorm'));
  if(mode==='paralysis')p.setStatus('par',e,b.dex.moves.get('thunderwave'));
  if(mode==='sleepFixture')p.setStatus('slp',e,b.dex.moves.get('spore'));
  if(mode==='sleepMove')e.boosts.spe=6;
  b.makeChoices('move 1',mode==='sleepMove'?'move 2':'move 1');
  const logs=b.log.slice(logStart).filter(x=>!x.startsWith("|t:|"));
  if(mode==='miss'&&!logs.some(x=>x.includes('|-miss|')))continue;
  if(mode==='paralysis'&&!logs.some(x=>x.includes('|cant|')&&x.endsWith('|par')))continue;
  const second=view(b);second.log=logs;first.log=first.log.filter(x=>x.includes('Petal Dance')||x.includes('confusion'));
  rows.push({mode,seed:[1,2,3,n],fixture:fixture(b),first,second});found.add(duration);b.destroy();
 }
}
process.stdout.write(JSON.stringify({revision:'9b136a8c8cdb860a8ab96fa063f906604e352547',format:'gen5customgame',note:'PS default maxPPUps3 gives Petal maxPP16; this probe qualifies lock/status/event behavior, not SDK base10PP numerics. Normalized set IV/EV/nature/speed are reported percase. Only wallclock |t:| log entries are removed; all mechanical logs retained. Confusion time is rawPS state and includes its decrement-before-check convention.',rows},null,2)+'\n');

#!/usr/bin/env python3
"""Private patch composition and compile; --execute is reserved to root owner."""
import argparse,hashlib,json,subprocess,sys,shutil
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def apply(output,path):
 result=subprocess.run(['git','apply','-p1','--check',str(path)],cwd=output,capture_output=True,text=True)
 if result.returncode:
  inverse=subprocess.run(['git','apply','-p1','--reverse','--check',str(path)],cwd=output,capture_output=True,text=True)
  assert inverse.returncode==0,'shared source conflict '+str(path)+': '+result.stderr;return
 subprocess.run(['git','apply','-p1',str(path)],cwd=output,check=True)
def change(path,old,new):
 body=path.read_text();assert body.count(old)==1,'mutant anchor '+old;path.write_text(body.replace(old,new,1))
def prepare(project,sdk,output,session):
 for r in manifest['source_files']:
  assert sha(stage/r['path'])==r['sha256'],'source drift '+r['path'];assert sha(stage/r['patch'])==r['patch_sha256'],'patch drift '+r['patch']
 for rel,expected in manifest.get('packet_files',{}).items():assert sha(stage/rel)==expected,'packet drift '+rel
 metadata=original(project,sdk,output,session)
 dependency=Path('/private/tmp/pokemon-brock-roost-01')
 dm=json.loads((dependency/'manifest.json').read_text())
 assert sha(dependency/'manifest.json')=='96143a9260dc69c4e723b6b26d7232e1e2ec104bc352df69872325039ea7dba7','Roost dependency drift'
 for row in dm['source_files']:
  assert sha(dependency/row['path'])==row['sha256'] and sha(dependency/row['patch'])==row['patch_sha256'],'Roost bytes drift'
  if row['base_sha256']is None:
   target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(dependency/row['path'],target)
  else:apply(output,dependency/row['patch'])
 for row in manifest['source_files']:
  if row['base_sha256']is None:
   target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/row['path'],target)
  else:apply(output,stage/row['patch'])
 main=output/'Source/main.lua';body=main.read_text();anchor='import "dev/catalog"';assert body.count(anchor)==1
 if 'import "dev/roostContracts"'not in body:body=body.replace(anchor,'import "dev/roostContracts"\nContracts.register("roost",RoostContracts.run)\n'+anchor,1)
 if 'import "dev/roostPredicateContracts"'not in body:body=body.replace(anchor,'import "dev/roostPredicateContracts"\nContracts.register("roost-predicates",RoostPredicateContracts.run)\n'+anchor,1)
 main.write_text(body)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated);values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['roost']=manifest
 with(output/'fixture-repair-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

# Roost nested predicate context erratum

FrozenRoost01 untouched. Genuine compositional defect: For passes(mon,battle), but Not/AllOf/AnyOf dropped the optional battle. Nested HasType therefore read intrinsic types during Roost. Five existing method/forwarding lines now carry(subject,battle); all direct one-context and shortcircuit behavior retained. No new type framework, producer/scalar change or assertion removal.

Four new realBattle SDK groups cover nested Not/doubleNot/AllOf/AnyOf positive andnegative, direct intrinsic check compatibility, prior Battle-level combinations and shortcircuit noRNG, actual Roost expiry restoring predicate truth with raw types unchanged. Root registry adds4 beyondRoost25 (950+25+4=979 pendingactual).

Default realSDK compile-only helper composes exact frozenRoost thenonlythese2patches. Rootalone may add--execute withfreshoutput. SDK/native UNRUN. No liveSource, main or otherfrozenpacket writes.

# Confirmed New Game after damaged saves

Private candidate; root alone executes SDK/native jobs and integrates. No live Source, Simulator, runtime Data or protected art was touched by this worker.

## Evidence and frozen dependencies

- Original red packet: `/private/tmp/pokemon-title-save-baseline-01`, manifest `5427ebc97919772e2a0c796c40c7f10d45791bc13d3f6414c07dffd2272bbc64`.
- Root actual red: `/private/tmp/pokemon-root-title-save-baseline-sdk-01`: 1024 pass / 1 fail, precisely confirmed Title New Game -> first Save rejected `recovery-required`. NO preserves the session and bytes.
- Frozen implementation: `/private/tmp/pokemon-title-save-recovery-01`, manifest `70a35ffe3ea99ebe3f5ad35ec8a257cf3e6aa2a7fb3c7a6e371504ddf5642c30`. Six Source files: four production owners and two suites. Compile03 passed.
- Root actual implementation SDK01: `/private/tmp/pokemon-root-title-save-recovery-sdk-01`: 1086 pass / 1 fail. All 20 archive and 8 Title/GameSaves/PC groups passed, including the original red target. The remaining existing presentation test manually constructed a Title menu without `actions`; production enter/refresh supplies it. This followup supplies that fixture field and retains every image, pose, RNG and once-only assertion.
- This followup preserves the frozen implementation bytes. It composes three narrow patches: normal <=3-option Title layout, safe ASCII archive diagnostics, and the presentation fixture. It adds two binary-corrupt-sidecar SDK groups. Host/native tools are new private files only.

## Authority and exact bytes

Title YES calls `GameSaves:beginNewGame(seed)`. `SaveStore:prepareReplacement()` records the three current source-derived paths and exact bytes (including explicit missing files), without writing. The opaque one-shot ticket belongs to that store instance. GameSaves binds it to the newly installed actual session identity. Title NO, normal boot, Continue and a persisted receipt never create replacement authority.

Both field Save and trusted PC box Save use `GameSaves:_publishPayload()`. PC capture preconditions and rollback remain intact. A foreign session fails rather than using the old request. A stale observation fails without refreshing it. A failed archival/publication attempt retains its consumed request, so subsequent Save cannot fall through to normal publication. Restart exposes explicit recovery choices; the current adventure remains in memory until exit.

For a confirmed replacement, all present `prefix.a.json`, `.b.json`, `.candidate.json` are copied exactly and read back. Corrupt, future-schema, conflicting and distinct valid candidate bytes are all retained. No raw corrupt bytes enter JSON diagnostics. Only after the full archive and proposal verify, and the observed root files still match, does the receipt publish; only then may normal candidate/target publication begin. No file is deleted by SaveStore.

Envelope schema1 and Session schema1 do not change. The normal Save cap remains signed native MAX. A confirmed new adventure uses max valid observed sequence +1, or a new lineage at 1 when the observed maximum is MAX. Exact old-byte recognition prevents the old MAX lineage from replacing the new one during selection. This does not infer or migrate a session schema.

## Bounded archive format

For canonical decimal index N in 1..64, paths are derived entirely from the validated existing prefix:

```
prefix-archive-N.a.json
prefix-archive-N.b.json
prefix-archive-N.candidate.json
prefix-archive-N.proposal.json
prefix-archive-N.manifest.json
prefix-archive-N.receipt-pending.json -> .receipt.json
```

Missing original roles have no archive file. The manifest describes exactly three roles with `present`, length and FNV-1a checksum; it binds index, operation, a/b target and the valid proposed envelope. Sidecars have format `pokemon-playdate-save-archive`, version1, an exact JSON payload string and checksum. The receipt binds the manifest bytes and proposal bytes. Index strings must be canonical decimal. JSON paths are never trusted. Small sidecars and existing file/payload limits are checked. FNV is corruption detection, not authentication.

Indices append after the highest occupied index, including partial artifacts; holes are never reused. Capacity64 is an explicit safe-fail bound for replacement/repair/restore. No deletion, pruning, backup management UI or automatic authority recycling is implemented in this packet. Existing ordinary saves continue subject to the existing corruption/sequence gates.

The newest receipt and any newer manifest must validate; malformed newer evidence does not silently fall back to old authority. A receipt recognizes other root roles only when they exactly equal its verified archived bytes AND the exact planned target equals the verified proposal. New, changed or unsupported root artifacts remain visible and block normal publication. Missing/corrupt sidecars or archive files fail closed. A later ordinary save can rotate the original target after the old leftovers have been replaced. Published/progressed proposals are not offered as stale recovery choices; old raw MAX slots are not mistaken for new lineage progression.

## Explicit recovery

Existing live candidate/newer-than-published and published selection semantics remain. Before either repair overwrites counterparts, the same archive primitive retains them, including a different valid pending candidate. Explicit proposal/backup recovery first archives all current source bytes into a new index. It never overwrites the previous archive. Ambiguous same-sequence published backups do not manufacture a winner. There is no general history browser: only the current verified bundle's proposal/published/candidate choices are offered.

Normal Title composition is unchanged for <=3 options: menu `(16,50,192,92)`, player/money panel at the existing right coordinates, mon line y158 and attention text y154. Only expanded recovery menus move info below their actual bottom. Confirmation explains that old files are kept when Save is performed. Successful first Save adds a backup explanation. Failure says the adventure remains in memory and restart can review available recovery; it makes no blanket claim about ordinary false-ACK publication.

## Reproduce

Offline independent evidence-validator tests (no network, SDK, fake SDK or Simulator):

```
python3 -m unittest discover -s /private/tmp/pokemon-title-save-recovery-handoff01/tests -v
```

Compile composed candidate only (default does not touch runtime Data):

```
python3 /private/tmp/pokemon-title-save-recovery-handoff01/validate_native.py \
  --project /private/tmp/pokemon-brock-integration-03 \
  --output /private/tmp/pokemon-title-save-recovery-final-compile-02
```

Root SDK regression, including the 2 ASCII safety cases:

```
python3 /private/tmp/pokemon-title-save-recovery-handoff01/validate_native.py \
  --project /private/tmp/pokemon-brock-integration-03 \
  --scenario /private/tmp/pokemon-title-save-recovery-01/contracts.json \
  --output /private/tmp/pokemon-root-title-save-recovery-sdk-02 --execute
```

Root native actual Title -> YES -> ten original opening lines -> Pause Save -> backup explanation -> stopped process -> fresh Continue:

```
python3 /private/tmp/pokemon-title-save-recovery-handoff01/validate_native.py \
  --project /private/tmp/pokemon-brock-integration-03 \
  --output /private/tmp/pokemon-root-title-save-recovery-native-01 --execute
```

The native wrapper seeds only a fresh, exact UUID Data directory after the harness acquires its owner lock and before first launch. It refuses any preexisting file other than that lock. It writes three known damaged files, including NUL/non-UTF8 bytes, with immutable seed hashes. No gameplay fixture is used. All progress is actual input and semantic dialog readiness. The harness confirms process1 exit before process2 starts, preserves durable files, and records distinct PIDs. After both stopped generations are archived, the independent host verifier checks every original byte, manifest/receipt binding, exact proposal/target, unchanged durable saves across Continue, and emits `native-recovery-proof.json`. Missing proof, failure exit, unknown leftover or altered archive is not success.

Expected native images: corrupt Title, explicit archive confirmation, actual new adventure, saved message, backup explanation, restarted Continue and continued original bedroom. Root must inspect original typography, expanded layout when separately exercised, and the saved-frame/Continue composition. No native acceptance is inferred from compile or SDK contracts.

## Verification scope

Twenty core filesystem groups cover exact binary preservation, store-bound/one-shot/stale tickets, future schema/conflict, native MAX, unreadable source, short/corrupt archive/readback, before-receipt crashes, receipt-before-primary crash, torn candidate, post-publication false ACK, missing/corrupt receipts/archives, unknown new corruption/schema/candidate, strict sidecars, preserving distinct candidates on repair, candidate newer rule, backup restore, newer corrupt receipt/manifest, sparse/capped index and proposal menu eligibility.

Eight actual owner groups cover Title NO/YES, explicit-only authority, session replacement, stale confirmation, failed retry, PC first-save archival and PC rollback/retry. Two followup groups corrupt manifest/receipt with non-UTF8 binary bytes and require static ASCII diagnostics, valid JSON and unchanged primary files. Fault adapters wrap actual SDK filesystem calls; no memory-only filesystem stands in for production. Host tests qualify the independent artifact verifier, not Lua behavior.

The first followup helper invocation failed before compilation because `restarting` is imported inside the harness runner rather than exposed as `harness.restarting`; the helper now imports that actual module explicitly. No runtime launched. This failed attempt remains `/private/tmp/pokemon-title-save-recovery-final-compile-01` (if the harness had created an output). Compilation and host tests are worker-run. SDK01 figures above are root-run. Followup SDK/native acceptance and crash/restart screenshots remain root-run and unaccepted until actual results are recorded. This fixes a save correctness block; it does not complete the Brock campaign or full-game goal.

#!/usr/bin/env python3
"""Private patch composition and compile; --execute is reserved to root owner."""
import argparse,hashlib,json,subprocess,sys,shutil
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;core=Path('/private/tmp/pokemon-title-save-recovery-01');sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(core/'manifest.json')=='70a35ffe3ea99ebe3f5ad35ec8a257cf3e6aa2a7fb3c7a6e371504ddf5642c30','core packet changed'
manifest=json.loads((core/'manifest.json').read_text());original=harness.prepare
followup=json.loads((stage/'manifest.json').read_text())
for rel,expected in followup['files'].items():assert sha(stage/rel)==expected,'followup packet drift '+rel

def apply(output,path):
 result=subprocess.run(['git','apply','-p1','--check',str(path)],cwd=output,capture_output=True,text=True)
 if result.returncode:
  inverse=subprocess.run(['git','apply','-p1','--reverse','--check',str(path)],cwd=output,capture_output=True,text=True)
  assert inverse.returncode==0,'shared source conflict '+str(path)+': '+result.stderr;return
 subprocess.run(['git','apply','-p1',str(path)],cwd=output,check=True)
def change(path,old,new):
 body=path.read_text();assert body.count(old)==1,'mutant anchor '+old;path.write_text(body.replace(old,new,1))
def prepare(project,sdk,output,session):
 for r in manifest['source_files']:
  assert sha(core/r['path'])==r['sha256'],'source drift '+r['path'];assert sha(core/r['patch'])==r['patch_sha256'],'patch drift '+r['patch']
 for rel,expected in manifest.get('packet_files',{}).items():assert sha(core/rel)==expected,'packet drift '+rel
 metadata=original(project,sdk,output,session)
 for row in manifest['source_files']:
  if row['base_sha256']is None:
   target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(core/row['path'],target)
  else:
   composed=stage/row['path']
   if not(composed.exists() and sha(output/row['path'])==sha(composed)):apply(output,core/row['patch'])
 for rel in ('patches/title-layout.patch','patches/archive-ascii-error.patch','patches/presentation-title-fixture.patch'):apply(output,stage/rel)
 shutil.copyfile(stage/'Source/dev/titleArchiveSafetyContracts.lua',output/'Source/dev/titleArchiveSafetyContracts.lua')
 main=output/'Source/main.lua';body=main.read_text();anchor='import "dev/catalog"';assert body.count(anchor)==1
 for module,registry,owner in [('titleRecoveryProbe','title-recovery-probe','TitleRecoveryProbe'),('titleRecoveryContracts','title-recovery','TitleRecoveryContracts'),('titleArchiveSafetyContracts','title-archive-safety','TitleArchiveSafetyContracts')]:
  if 'import "dev/'+module+'"'not in body:
   body=body.replace(anchor,'import "dev/'+module+'"\nContracts.register("'+registry+'",'+owner+'.run)\n'+anchor,1)
 main.write_text(body)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated);values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['title_recovery']=manifest;metadata['title_recovery_followup']=followup
 with(output/'fixture-repair-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
from recovery_evidence import SEED,verify_run
from tools.harness import restarting
original_restart=restarting.run

def seeded_restart(args,scenario,metadata,output,data,owner,runner):
 restarting.check_owner(owner,data)
 assert metadata['bundle_id']=='com.poc.pokemon.harness.'+metadata['session_id'],'private bundle required'
 assert data.resolve()==Path(metadata['data_dir']).resolve(),'private Data mismatch'
 assert {p.name for p in data.iterdir()}=={'owner.lock'},'refuse to overwrite any preexisting private Data'
 for role,raw in SEED.items():
  path=data/('adventure.'+role+'.json')
  with path.open('xb')as stream:stream.write(raw)
 atomic_json(output/'seeded-artifacts.json',{role:{'length':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}for role,raw in SEED.items()})
 code=original_restart(args,scenario,metadata,output,data,owner,runner)
 if code==0:atomic_json(output/'native-recovery-proof.json',verify_run(output))
 return code
restarting.run=seeded_restart
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'scenarios/title-newgame-save-continue.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:
 harness.prepare=original
 restarting.run=original_restart
raise SystemExit(code)

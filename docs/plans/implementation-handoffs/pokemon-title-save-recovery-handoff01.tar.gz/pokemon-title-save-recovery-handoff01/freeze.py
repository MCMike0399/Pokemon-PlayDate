from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={str(p.relative_to(root)):sha(p)for p in sorted(root.rglob('*'))if p.is_file()and p.name!='manifest.json'and '__pycache__'not in p.parts}
rows=[]
core=Path('/private/tmp/pokemon-title-save-recovery-01')
for p in sorted((root/'Source').rglob('*.lua')):
 rel=p.relative_to(root);base=core/rel
 if not base.exists():base=Path('/private/tmp/pokemon-brock-integration-03')/rel
 rows.append({'path':str(rel),'sha256':sha(p),'base_sha256':sha(base)if base.exists()else None})
manifest={'core_manifest_sha256':sha(core/'manifest.json'),'source_files':rows,'files':files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(sha(root/'manifest.json'))

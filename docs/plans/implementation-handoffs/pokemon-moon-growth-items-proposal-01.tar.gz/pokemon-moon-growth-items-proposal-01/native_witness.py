#!/usr/bin/env python3
"""Compile unchanged pinned item functions against explicit control-flow IO stubs."""
from pathlib import Path
import subprocess,json,hashlib,tempfile
P=Path(__file__).resolve().parent

def body(raw,prefix):
 start=raw.find(prefix)
 while start>=0:
  brace=raw.find('{',start);semi=raw.find(';',start)
  if brace<semi or semi<0:break
  start=raw.find(prefix,start+len(prefix))
 assert start>=0,prefix
 depth=1;pos=brace+1
 while depth:
  if raw[pos]=='{':depth+=1
  elif raw[pos]=='}':depth-=1
  pos+=1
 return raw[start:pos]+'\n'
source=(P/'references/status_rcv.c').read_text();item=(P/'references/item.h').read_text();pml=(P/'references/pml_item.c').read_text()
params=item[item.index('typedef struct {'):item.index('} ItemParams;')+len('} ItemParams;')]
struct=item[item.index('struct ItemData {'):item.index('// PML_ItemGetParam\'s parameters')]
enums=item[item.index('enum {'):item.index('};',item.index('enum {'))+2]
pre='''#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
typedef unsigned char u8;typedef signed char s8;typedef unsigned short u16;typedef unsigned int u32;typedef int s32;typedef int BOOL;
#define TRUE 1
#define FALSE 0
#define NULL ((void*)0)
#define ITEM_WORK_VALUE 0
#define ITEM_WORK_PARAMS 1
#define SPECIES_SHEDINJA 292
typedef struct ItemData ItemData;
'''+params+struct+enums+'''
enum {PKM_PARAM_SPECIES,PKM_PARAM_LEVEL,PKM_PARAM_EXP,PKM_PARAM_HP,PKM_PARAM_MAX_HP,PKM_PARAM_STATUS,PKM_PARAM_HAPPINESS,PKM_PARAM_FORM,PKM_PARAM_EV_HP=10,PKM_PARAM_MOVE1_PP_UP=30,PKM_PARAM_MOVE1=40};
typedef struct {u32 values[50];u32 nextExp,nextMax;int friendshipCalls;} PartyPkm;
static ItemData hpup,candy;static PartyPkm *current;
static u32 PokeParty_GetParam(PartyPkm*p,u32 k,void*x){return p->values[k];}
static void PokeParty_SetParam(PartyPkm*p,u32 k,u32 v){p->values[k]=v;}
static void PokeParty_RecalcStats(PartyPkm*p){if(p->values[PKM_PARAM_EXP]==p->nextExp)++p->values[PKM_PARAM_LEVEL];u32 old=p->values[PKM_PARAM_MAX_HP],hp=p->values[PKM_PARAM_HP];p->values[PKM_PARAM_MAX_HP]=p->nextMax;if(hp)p->values[PKM_PARAM_HP]=hp+p->nextMax-old;}
static u32 PML_UtilGetPkmLvExp(u32 species,u32 form,u32 level){assert(level==current->values[PKM_PARAM_LEVEL]+1);return current->nextExp;}
static void *PML_ItemReadDataFile(u16 id,u32 type,u32 heap){return id==1?&hpup:&candy;}
static void GFL_HeapFree(void*p){}
static int GetStatusCond(PartyPkm*p){return 0;}
static int PokeParty_CheckPPNeedsReplenish(PartyPkm*p,u32 x){assert(0);return 0;}
static int PokeParty_AddPP(PartyPkm*p,u32 x,u32 y){assert(0);return 0;}
static u32 PML_MoveGetMaxPP(u32 x,u32 y){assert(0);return 0;}
static BOOL StatusRcv_PPUp(PartyPkm*p,u32 x,u32 y){assert(0);return 0;}
static BOOL StatusRcv_CanChangeFriendship(PartyPkm*p,void*d){assert(0);return 0;}
static BOOL StatusRcv_ChangeFriendship(PartyPkm*p,s32 f,s32 add,u16 item,u16 zone,u32 heap){p->friendshipCalls++;assert(add==5||add==3||add==2);return TRUE;}
static s32 PML_ItemGetBattleStat(ItemParams*,u32);
static s32 StatusRcv_AddEffort(s32,s32,s32,s32);
static void StatusRcv_RestoreHp(PartyPkm*,u32,u32,u32);
'''
functions=''.join([body(pml,'s32 PML_ItemGetParam('),body(pml,'static s32 PML_ItemGetBattleStat('),body(source,'BOOL StatusRcv_CanUseItem('),body(source,'BOOL StatusRcv_UseItem('),body(source,'static void StatusRcv_RestoreHp('),body(source,'static s32 StatusRcv_AddEffort(')])
# Literal initializers follow pinned JSON; names in reconstruction are not used
# to infer semantic roles: numeric param48 is verified through real getters.
init='''hpup.workType=candy.workType=1;
hpup.work.params.hpEVUp=1;hpup.work.params.hpEV=10;
candy.work.params.revive=1;candy.work.params.levelUp=1;
hpup.work.params.friendshipUp2=candy.work.params.friendshipUp2=1;
hpup.work.params.friendshipUp3=candy.work.params.friendshipUp3=1;
hpup.work.params.unk6_4=candy.work.params.unk6_4=1;
hpup.work.params.friendship1=candy.work.params.friendship1=5;
hpup.work.params.friendship2=candy.work.params.friendship2=3;
hpup.work.params.friendship3=candy.work.params.friendship3=2;
assert(PML_ItemGetParam(&hpup,48)==0);assert(PML_ItemGetParam(&hpup,52)==10);assert(PML_ItemGetParam(&candy,28)==1);
'''
main='''int main(void){'''+init+'''
struct {int ev,other,expected;} ev[]={{0,0,10},{90,0,100},{95,0,100},{99,0,100},{100,0,-1},{254,0,-1},{90,417,93},{99,410,100},{0,509,1},{0,510,-1}};
for(int i=0;i<10;i++){assert(StatusRcv_AddEffort(ev[i].ev,ev[i].other,10,0)==ev[i].expected);}
for(int kind=1;kind<=2;kind++)for(int fainted=0;fainted<=1;fainted++){
 PartyPkm p={0};current=&p;p.values[PKM_PARAM_SPECIES]=1;p.values[PKM_PARAM_LEVEL]=kind==1?100:6;p.values[PKM_PARAM_EXP]=kind==1?1059860:235;p.values[PKM_PARAM_HP]=fainted?0:(kind==1?195:16);p.values[PKM_PARAM_MAX_HP]=kind==1?200:21;p.values[PKM_PARAM_HAPPINESS]=70;p.nextMax=kind==1?202:23;p.nextExp=236;
 assert(StatusRcv_CanUseItem(&p,kind,0,0));assert(StatusRcv_UseItem(&p,kind,0,0,0));
 assert(p.values[PKM_PARAM_MAX_HP]==(kind==1?202:23));assert(p.values[PKM_PARAM_HP]==(fainted?(kind==2?2:0):(kind==1?197:18)));
 assert(p.values[PKM_PARAM_EXP]==(kind==2?236:1059860));assert(p.values[PKM_PARAM_EV_HP]==(kind==1?10:0));assert(p.friendshipCalls==1);
}
PartyPkm p={0};current=&p;p.values[PKM_PARAM_SPECIES]=1;p.values[PKM_PARAM_LEVEL]=100;p.values[PKM_PARAM_HP]=0;p.values[PKM_PARAM_MAX_HP]=200;p.values[PKM_PARAM_HAPPINESS]=70;p.nextMax=202;p.values[PKM_PARAM_EV_HP]=100;
assert(!StatusRcv_CanUseItem(&p,2,0,0));assert(!StatusRcv_CanUseItem(&p,1,0,0));assert(!StatusRcv_UseItem(&p,2,0,0,0));assert(!StatusRcv_UseItem(&p,1,0,0,0));assert(p.friendshipCalls==0);
printf("10 EV vectors +4 HP/control branches +2 cap failures PASS\\n");return 0;}
'''
# Verify literal item parameters against source JSON, not just copied C fixture.
h=json.loads((P/'references/hp_up.json').read_text());c=json.loads((P/'references/rare_candy.json').read_text())
assert h['effects']['hp_ev']==10 and h['effects']['hp_ev_up']and not h['effects']['friendship_up_1'];assert c['effects']['level_up']and c['effects']['revive'];assert not h['battle_pocket']and not c['battle_pocket']
for d in [h,c]:assert [d['effects'][k]for k in ['friendship_1','friendship_2','friendship_3']]==[5,3,2]
with tempfile.TemporaryDirectory(prefix='moon-item-witness-',dir='/private/tmp')as tmp:
 path=Path(tmp);(path/'witness.c').write_text(pre+functions+main)
 result=subprocess.run(['clang','-std=c11','-Wno-macro-redefined','-Wno-incompatible-pointer-types',str(path/'witness.c'),'-o',str(path/'witness')],text=True,capture_output=True)
 if result.returncode:raise RuntimeError(result.stderr)
 result=subprocess.run([str(path/'witness')],check=True,text=True,capture_output=True)
 (P/'witness-generated.c').write_text(pre+functions+main)
 print(result.stdout.strip());(P/'witness-results.json').write_text(json.dumps({'ok':True,'scope':'unchanged primaryC with controlled IO/stat-recalc/XP/friendship stubs, not SDK/native ROM execution','ev_literal_vectors':10,'hp_control_branches':4,'cap_failure_branches':2,'source_functions':[hashlib.sha256(x.encode()).hexdigest()for x in [functions]],'stdout':result.stdout},indent=2)+'\n')

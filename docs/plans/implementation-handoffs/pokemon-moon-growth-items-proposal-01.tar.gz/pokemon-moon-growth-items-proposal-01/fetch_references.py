#!/usr/bin/env python3
"""Recover pinned primary refs to a fresh directory; never fetch latest/master."""
from pathlib import Path
import argparse,hashlib,json,urllib.request
P=Path(__file__).resolve().parent
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 for name,record in json.loads((P/'sources.json').read_text())['sources'].items():
  with urllib.request.urlopen(record['url'],timeout=60)as response:raw=response.read()
  if hashlib.sha256(raw).hexdigest()!=record['sha256']:raise ValueError('pinned source drift: '+name)
  (a.output/name).write_bytes(raw)
 print('pinned references recovered; no implementation/native acceptance')

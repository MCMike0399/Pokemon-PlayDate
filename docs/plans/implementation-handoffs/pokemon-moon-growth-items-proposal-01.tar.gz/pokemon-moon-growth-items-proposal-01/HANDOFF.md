# Moon growth items proposal01

Read proposal.md, literal-vectors.json and acceptance.json. Research/transaction design only; implementation not authorized, current Brock/campaign batch unaffected. Existing Moon review, import gate, warp peer review and all live Source/HEAD/harness are untouched.

Strong primary finding: RareCandy fainted revival is an item-specific exception at status_rcv.c295–310, not a reason to change battle XP or default fainted stat recalculation. HPUp actual clamp523–546 grants partial EV through100/total510; application352–367 recalculates immediately. Current helper addEffort0..3 is NOT a vitamin implementation. Native item/field/UI/getter/struct bytes and original Blue pickup refs are pinned, including the guessed item-parameter-name discrepancy.

Reproduce host/reference witnesses only (no Simulator):
```
python3 /private/tmp/pokemon-moon-growth-items-proposal-01/native_witness.py
python3 /private/tmp/pokemon-moon-growth-items-proposal-01/check_vectors.py
```
Unchanged nativeC conditional witness:10EV +4HP/control +2cap cases PASS with declared IO stubs;600independentPKHeX/PokeAPI XP values +6literalXP cases +11literalHP cases PASS. These are not SDK, actualROM/UI or native gameplay acceptance. Primarydata friendship5/3/2 is documented as a current model gap; no unapproved schema/history default is invented.

Proposed production seams: new GrowthItems opaque request; appended GameSession.resolveGrowthItem; narrow current Pokemon shared growth planner/candy exception; Bag field-only routing and presentation through existing Learning/Evolution owners; explicit item metadata, no arbitrary callback transaction engine or fakeBattle. All candidate planning/Codec7/bag preflight precede retained publication; postcommit choice/evolution cancellation never refunds Candy. No schema change for level/EV behavior; pending choices remain durable, request does not.

Root must review/choose exact bounded subset (including explicit friendship gap) and authorize implementation after current acceptance. acceptance.json defines15proposedSDK cases/5native recipes/13meaningful faults, ALLUNRUN. Normal Save is not loosened to manufacture pending-overlay persistence; codec interruption proof is explicitly separate from actual2PID SaveContinue after real choices/evolution.

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
typedef unsigned char u8;typedef signed char s8;typedef unsigned short u16;typedef unsigned int u32;typedef int s32;typedef int BOOL;
#define TRUE 1
#define FALSE 0
#define NULL ((void*)0)
#define ITEM_WORK_VALUE 0
#define ITEM_WORK_PARAMS 1
#define SPECIES_SHEDINJA 292
typedef struct ItemData ItemData;
typedef struct {
    u8 sleepHeal : 1;
    u8 poisonHeal : 1;
    u8 burnHeal : 1;
    u8 freezeHeal : 1;
    u8 paralysisHeal : 1;
    u8 confusionHeal : 1;
    u8 infatuationHeal : 1;
    u8 guardSpec : 1;
    u8 revive : 1;
    u8 reviveAll : 1;
    u8 levelUp : 1;
    u8 evolve : 1;
    u8 attackStages : 4;
    u8 defenseStages : 4;
    u8 spAttackStages : 4;
    u8 spDefenseStages : 4;
    u8 speedStages : 4;
    u8 accuracyStages : 4;
    u8 critStages : 2;
    u8 ppUp : 1;
    u8 ppMax : 1;
    u8 ppRestore : 1;
    u8 ppRestoreAll : 1;
    u8 hpRestore : 1;
    u8 hpEVUp : 1;
    u8 attackEVUp : 1;
    u8 defenseEVUp : 1;
    u8 speedEVUp : 1;
    u8 spAttackEVUp : 1;
    u8 spDefenseEVUp : 1;
    u8 friendshipUp1 : 1;
    u8 friendshipUp2 : 1;
    u8 friendshipUp3 : 1;
    u8 unk6_4 : 1;
    s8 hpEV;
    s8 attackEV;
    s8 defenseEV;
    s8 speedEV;
    s8 spAttackEV;
    s8 spDefenseEV;
    u8 hpRestoreAmount;
    u8 ppRestoreAmount;
    s8 friendship1;
    s8 friendship2;
    s8 friendship3;
} ItemParams;struct ItemData {
    u16 price;
    u8 holdEffect;
    u8 holdParam;
    u8 pluckEffect;
    u8 flingEffect;
    u8 flingPower;
    u8 naturalGiftPower;
    u16 naturalGiftType : 5;
    u16 important : 1;
    u16 registrable : 1;
    u16 fieldPocket : 4;
    u16 battlePocket : 5;
    u8 fieldFunc;
    u8 battleFunc;
    u8 workType;
    // The item's kind, which the bag sorts by first
    u8 kind;
    u8 unkE;
    // The item's place in the bag's sort within its kind
    u8 sortIndex;
    union {
        u8 value;
        ItemParams params;
    } work;
};

enum {
    ITEM_PARAM_PRICE,
    ITEM_PARAM_HOLD_EFFECT,
    ITEM_PARAM_HOLD_PARAM,
    ITEM_PARAM_IMPORTANT,
    ITEM_PARAM_REGISTRABLE,
    ITEM_PARAM_FIELD_POCKET,
    ITEM_PARAM_FIELD_FUNC,
    ITEM_PARAM_BATTLE_FUNC,
    ITEM_PARAM_PLUCK_EFFECT,
    ITEM_PARAM_FLING_EFFECT,
    ITEM_PARAM_FLING_POWER,
    ITEM_PARAM_NATURAL_GIFT_POWER,
    ITEM_PARAM_NATURAL_GIFT_TYPE,
    ITEM_PARAM_BATTLE_POCKET,
    ITEM_PARAM_WORK_TYPE,
    ITEM_PARAM_KIND,
    ITEM_PARAM_UNK_E,
    ITEM_PARAM_SORT_INDEX,
    ITEM_PARAM_SLEEP_HEAL,
    ITEM_PARAM_POISON_HEAL,
    ITEM_PARAM_BURN_HEAL,
    ITEM_PARAM_FREEZE_HEAL,
    ITEM_PARAM_PARALYSIS_HEAL,
    ITEM_PARAM_CONFUSION_HEAL,
    ITEM_PARAM_INFATUATION_HEAL,
    ITEM_PARAM_GUARD_SPEC,
    ITEM_PARAM_REVIVE,
    ITEM_PARAM_REVIVE_ALL,
    ITEM_PARAM_LEVEL_UP,
    ITEM_PARAM_EVOLVE,
    ITEM_PARAM_ATTACK_STAGES,
    ITEM_PARAM_DEFENSE_STAGES,
    ITEM_PARAM_SP_ATTACK_STAGES,
    ITEM_PARAM_SP_DEFENSE_STAGES,
    ITEM_PARAM_SPEED_STAGES,
    ITEM_PARAM_ACCURACY_STAGES,
    ITEM_PARAM_CRIT_STAGES,
    ITEM_PARAM_PP_UP,
    ITEM_PARAM_PP_MAX,
    ITEM_PARAM_PP_RESTORE,
    ITEM_PARAM_PP_RESTORE_ALL,
    ITEM_PARAM_HP_RESTORE,
    ITEM_PARAM_HP_EV_UP,
    ITEM_PARAM_ATTACK_EV_UP,
    ITEM_PARAM_DEFENSE_EV_UP,
    ITEM_PARAM_SPEED_EV_UP,
    ITEM_PARAM_SP_ATTACK_EV_UP,
    ITEM_PARAM_SP_DEFENSE_EV_UP,
    ITEM_PARAM_FRIENDSHIP_UP_1,
    ITEM_PARAM_FRIENDSHIP_UP_2,
    ITEM_PARAM_FRIENDSHIP_UP_3,
    ITEM_PARAM_UNK_51,
    ITEM_PARAM_HP_EV,
    ITEM_PARAM_ATTACK_EV,
    ITEM_PARAM_DEFENSE_EV,
    ITEM_PARAM_SPEED_EV,
    ITEM_PARAM_SP_ATTACK_EV,
    ITEM_PARAM_SP_DEFENSE_EV,
    ITEM_PARAM_HP_RESTORE_AMOUNT,
    ITEM_PARAM_PP_RESTORE_AMOUNT,
    ITEM_PARAM_FRIENDSHIP_1,
    ITEM_PARAM_FRIENDSHIP_2,
    ITEM_PARAM_FRIENDSHIP_3,
};
enum {PKM_PARAM_SPECIES,PKM_PARAM_LEVEL,PKM_PARAM_EXP,PKM_PARAM_HP,PKM_PARAM_MAX_HP,PKM_PARAM_STATUS,PKM_PARAM_HAPPINESS,PKM_PARAM_FORM,PKM_PARAM_EV_HP=10,PKM_PARAM_MOVE1_PP_UP=30,PKM_PARAM_MOVE1=40};
typedef struct {u32 values[50];u32 nextExp,nextMax;int friendshipCalls;} PartyPkm;
static ItemData hpup,candy;static PartyPkm *current;
static u32 PokeParty_GetParam(PartyPkm*p,u32 k,void*x){return p->values[k];}
static void PokeParty_SetParam(PartyPkm*p,u32 k,u32 v){p->values[k]=v;}
static void PokeParty_RecalcStats(PartyPkm*p){if(p->values[PKM_PARAM_EXP]==p->nextExp)++p->values[PKM_PARAM_LEVEL];u32 old=p->values[PKM_PARAM_MAX_HP],hp=p->values[PKM_PARAM_HP];p->values[PKM_PARAM_MAX_HP]=p->nextMax;if(hp)p->values[PKM_PARAM_HP]=hp+p->nextMax-old;}
static u32 PML_UtilGetPkmLvExp(u32 species,u32 form,u32 level){assert(level==current->values[PKM_PARAM_LEVEL]+1);return current->nextExp;}
static void *PML_ItemReadDataFile(u16 id,u32 type,u32 heap){return id==1?&hpup:&candy;}
static void GFL_HeapFree(void*p){}
static int GetStatusCond(PartyPkm*p){return 0;}
static int PokeParty_CheckPPNeedsReplenish(PartyPkm*p,u32 x){assert(0);return 0;}
static int PokeParty_AddPP(PartyPkm*p,u32 x,u32 y){assert(0);return 0;}
static u32 PML_MoveGetMaxPP(u32 x,u32 y){assert(0);return 0;}
static BOOL StatusRcv_PPUp(PartyPkm*p,u32 x,u32 y){assert(0);return 0;}
static BOOL StatusRcv_CanChangeFriendship(PartyPkm*p,void*d){assert(0);return 0;}
static BOOL StatusRcv_ChangeFriendship(PartyPkm*p,s32 f,s32 add,u16 item,u16 zone,u32 heap){p->friendshipCalls++;assert(add==5||add==3||add==2);return TRUE;}
static s32 PML_ItemGetBattleStat(ItemParams*,u32);
static s32 StatusRcv_AddEffort(s32,s32,s32,s32);
static void StatusRcv_RestoreHp(PartyPkm*,u32,u32,u32);
s32 PML_ItemGetParam(ItemData *data, u32 param) {
    switch (param) {
    case ITEM_PARAM_PRICE:
        return data->price * 10;
    case ITEM_PARAM_HOLD_EFFECT:
        return data->holdEffect;
    case ITEM_PARAM_HOLD_PARAM:
        return data->holdParam;
    case ITEM_PARAM_IMPORTANT:
        return data->important;
    case ITEM_PARAM_REGISTRABLE:
        return data->registrable;
    case ITEM_PARAM_FIELD_POCKET:
        return data->fieldPocket;
    case ITEM_PARAM_FIELD_FUNC:
        return data->fieldFunc;
    case ITEM_PARAM_BATTLE_FUNC:
        return data->battleFunc;
    case ITEM_PARAM_PLUCK_EFFECT:
        return data->pluckEffect;
    case ITEM_PARAM_FLING_EFFECT:
        return data->flingEffect;
    case ITEM_PARAM_FLING_POWER:
        return data->flingPower;
    case ITEM_PARAM_NATURAL_GIFT_POWER:
        return data->naturalGiftPower;
    case ITEM_PARAM_NATURAL_GIFT_TYPE:
        return data->naturalGiftType;
    case ITEM_PARAM_BATTLE_POCKET:
        return data->battlePocket;
    case ITEM_PARAM_WORK_TYPE:
        return data->workType;
    case ITEM_PARAM_KIND:
        return data->kind;
    case ITEM_PARAM_UNK_E:
        return data->unkE;
    case ITEM_PARAM_SORT_INDEX:
        return data->sortIndex;
    default:
        switch (data->workType) {
        case ITEM_WORK_VALUE:
            return data->work.value;
        case ITEM_WORK_PARAMS:
            return PML_ItemGetBattleStat(&data->work.params, param);
        }
        return 0;
    }
}
static s32 PML_ItemGetBattleStat(ItemParams *params, u32 param) {
    switch (param) {
    case ITEM_PARAM_SLEEP_HEAL:
        return params->sleepHeal;
    case ITEM_PARAM_POISON_HEAL:
        return params->poisonHeal;
    case ITEM_PARAM_BURN_HEAL:
        return params->burnHeal;
    case ITEM_PARAM_FREEZE_HEAL:
        return params->freezeHeal;
    case ITEM_PARAM_PARALYSIS_HEAL:
        return params->paralysisHeal;
    case ITEM_PARAM_CONFUSION_HEAL:
        return params->confusionHeal;
    case ITEM_PARAM_INFATUATION_HEAL:
        return params->infatuationHeal;
    case ITEM_PARAM_GUARD_SPEC:
        return params->guardSpec;
    case ITEM_PARAM_REVIVE:
        return params->revive;
    case ITEM_PARAM_REVIVE_ALL:
        return params->reviveAll;
    case ITEM_PARAM_LEVEL_UP:
        return params->levelUp;
    case ITEM_PARAM_EVOLVE:
        return params->evolve;
    case ITEM_PARAM_ATTACK_STAGES:
        return params->attackStages;
    case ITEM_PARAM_DEFENSE_STAGES:
        return params->defenseStages;
    case ITEM_PARAM_SP_ATTACK_STAGES:
        return params->spAttackStages;
    case ITEM_PARAM_SP_DEFENSE_STAGES:
        return params->spDefenseStages;
    case ITEM_PARAM_SPEED_STAGES:
        return params->speedStages;
    case ITEM_PARAM_ACCURACY_STAGES:
        return params->accuracyStages;
    case ITEM_PARAM_CRIT_STAGES:
        return params->critStages;
    case ITEM_PARAM_PP_UP:
        return params->ppUp;
    case ITEM_PARAM_PP_MAX:
        return params->ppMax;
    case ITEM_PARAM_PP_RESTORE:
        return params->ppRestore;
    case ITEM_PARAM_PP_RESTORE_ALL:
        return params->ppRestoreAll;
    case ITEM_PARAM_HP_RESTORE:
        return params->hpRestore;
    case ITEM_PARAM_HP_EV_UP:
        return params->hpEVUp;
    case ITEM_PARAM_ATTACK_EV_UP:
        return params->attackEVUp;
    case ITEM_PARAM_DEFENSE_EV_UP:
        return params->defenseEVUp;
    case ITEM_PARAM_SPEED_EV_UP:
        return params->speedEVUp;
    case ITEM_PARAM_SP_ATTACK_EV_UP:
        return params->spAttackEVUp;
    case ITEM_PARAM_SP_DEFENSE_EV_UP:
        return params->spDefenseEVUp;
    case ITEM_PARAM_FRIENDSHIP_UP_1:
        return params->friendshipUp1;
    case ITEM_PARAM_FRIENDSHIP_UP_2:
        return params->friendshipUp2;
    case ITEM_PARAM_FRIENDSHIP_UP_3:
        return params->friendshipUp3;
    case ITEM_PARAM_UNK_51:
        return params->unk6_4;
    case ITEM_PARAM_HP_EV:
        return params->hpEV;
    case ITEM_PARAM_ATTACK_EV:
        return params->attackEV;
    case ITEM_PARAM_DEFENSE_EV:
        return params->defenseEV;
    case ITEM_PARAM_SPEED_EV:
        return params->speedEV;
    case ITEM_PARAM_SP_ATTACK_EV:
        return params->spAttackEV;
    case ITEM_PARAM_SP_DEFENSE_EV:
        return params->spDefenseEV;
    case ITEM_PARAM_HP_RESTORE_AMOUNT:
        return params->hpRestoreAmount;
    case ITEM_PARAM_PP_RESTORE_AMOUNT:
        return params->ppRestoreAmount;
    case ITEM_PARAM_FRIENDSHIP_1:
        return params->friendship1;
    case ITEM_PARAM_FRIENDSHIP_2:
        return params->friendship2;
    case ITEM_PARAM_FRIENDSHIP_3:
        return params->friendship3;
    }
    return 0;
}
BOOL StatusRcv_CanUseItem(PartyPkm *pkm, u16 item, u16 pos, u32 heapId) {
    void *data;
    u32 status;
    u32 hp;
    int i;
    s32 atkEffort;
    s32 defEffort;
    s32 speedEffort;
    s32 spAtkEffort;
    s32 spDefEffort;
    s32 hpEffort;
    s32 noLimit;
    s32 effort;

    data = PML_ItemReadDataFile(item, 0, heapId);
    if (PML_ItemGetParam(data, 14) != 1) {
        GFL_HeapFree(data);
        return FALSE;
    }

    status = GetStatusCond(pkm);
    if (PML_ItemGetParam(data, 18) != 0 && status == 2) {
        GFL_HeapFree(data);
        return TRUE;
    }
    if (PML_ItemGetParam(data, 19) != 0 && status == 5) {
        GFL_HeapFree(data);
        return TRUE;
    }
    if (PML_ItemGetParam(data, 20) != 0 && status == 4) {
        GFL_HeapFree(data);
        return TRUE;
    }
    if (PML_ItemGetParam(data, 21) != 0 && status == 3) {
        GFL_HeapFree(data);
        return TRUE;
    }
    if (PML_ItemGetParam(data, 22) != 0 && status == 1) {
        GFL_HeapFree(data);
        return TRUE;
    }

    hp = PokeParty_GetParam(pkm, PKM_PARAM_HP, NULL);
    if ((PML_ItemGetParam(data, 26) != 0 || PML_ItemGetParam(data, 27) != 0) && PML_ItemGetParam(data, 28) == 0) {
        if (hp == 0) {
            GFL_HeapFree(data);
            return TRUE;
        }
    } else if (PML_ItemGetParam(data, 41) != 0 && hp != 0 && hp < PokeParty_GetParam(pkm, PKM_PARAM_MAX_HP, NULL)) {
        GFL_HeapFree(data);
        return TRUE;
    }

    if (PML_ItemGetParam(data, 28) != 0 && PokeParty_GetParam(pkm, PKM_PARAM_LEVEL, NULL) < 100) {
        GFL_HeapFree(data);
        return TRUE;
    }

    if ((PML_ItemGetParam(data, 37) != 0 || PML_ItemGetParam(data, 38) != 0) &&
        PokeParty_GetParam(pkm, PKM_PARAM_MOVE1_PP_UP + pos, NULL) < 3 &&
        PML_MoveGetMaxPP(PokeParty_GetParam(pkm, PKM_PARAM_MOVE1 + pos, NULL), 0) >= 5) {
        GFL_HeapFree(data);
        return TRUE;
    }

    if (PML_ItemGetParam(data, 39) != 0 && PokeParty_CheckPPNeedsReplenish(pkm, pos) == TRUE) {
        GFL_HeapFree(data);
        return TRUE;
    }
    if (PML_ItemGetParam(data, 40) != 0) {
        for (i = 0; i < 4; i++) {
            if (PokeParty_CheckPPNeedsReplenish(pkm, i) == TRUE) {
                GFL_HeapFree(data);
                return TRUE;
            }
        }
    }

    hpEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP, NULL);
    atkEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 1, NULL);
    defEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 2, NULL);
    speedEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 3, NULL);
    spAtkEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 4, NULL);
    spDefEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 5, NULL);
    noLimit = PML_ItemGetParam(data, 48);

    if (PML_ItemGetParam(data, 42) != 0) {
        effort = PML_ItemGetParam(data, 52);
        if (effort > 0 && PokeParty_GetParam(pkm, PKM_PARAM_SPECIES, NULL) != SPECIES_SHEDINJA) {
            if ((hpEffort < 100 || noLimit != 0) && hpEffort < 255 &&
                hpEffort + atkEffort + defEffort + speedEffort + spAtkEffort + spDefEffort < 510) {
                GFL_HeapFree(data);
                return TRUE;
            }
        } else if (effort < 0) {
            if (hpEffort > 0) {
                GFL_HeapFree(data);
                return TRUE;
            }
            if (StatusRcv_CanChangeFriendship(pkm, data) == TRUE) {
                GFL_HeapFree(data);
                return TRUE;
            }
        }
    }
    if (PML_ItemGetParam(data, 43) != 0) {
        effort = PML_ItemGetParam(data, 53);
        if (effort > 0) {
            if ((atkEffort < 100 || noLimit != 0) && atkEffort < 255 &&
                hpEffort + atkEffort + defEffort + speedEffort + spAtkEffort + spDefEffort < 510) {
                GFL_HeapFree(data);
                return TRUE;
            }
        } else if (effort < 0) {
            if (atkEffort > 0) {
                GFL_HeapFree(data);
                return TRUE;
            }
            if (StatusRcv_CanChangeFriendship(pkm, data) == TRUE) {
                GFL_HeapFree(data);
                return TRUE;
            }
        }
    }
    if (PML_ItemGetParam(data, 44) != 0) {
        effort = PML_ItemGetParam(data, 54);
        if (effort > 0) {
            if ((defEffort < 100 || noLimit != 0) && defEffort < 255 &&
                hpEffort + atkEffort + defEffort + speedEffort + spAtkEffort + spDefEffort < 510) {
                GFL_HeapFree(data);
                return TRUE;
            }
        } else if (effort < 0) {
            if (defEffort > 0) {
                GFL_HeapFree(data);
                return TRUE;
            }
            if (StatusRcv_CanChangeFriendship(pkm, data) == TRUE) {
                GFL_HeapFree(data);
                return TRUE;
            }
        }
    }
    if (PML_ItemGetParam(data, 45) != 0) {
        effort = PML_ItemGetParam(data, 55);
        if (effort > 0) {
            if ((speedEffort < 100 || noLimit != 0) && speedEffort < 255 &&
                hpEffort + atkEffort + defEffort + speedEffort + spAtkEffort + spDefEffort < 510) {
                GFL_HeapFree(data);
                return TRUE;
            }
        } else if (effort < 0) {
            if (speedEffort > 0) {
                GFL_HeapFree(data);
                return TRUE;
            }
            if (StatusRcv_CanChangeFriendship(pkm, data) == TRUE) {
                GFL_HeapFree(data);
                return TRUE;
            }
        }
    }
    if (PML_ItemGetParam(data, 46) != 0) {
        effort = PML_ItemGetParam(data, 56);
        if (effort > 0) {
            if ((spAtkEffort < 100 || noLimit != 0) && spAtkEffort < 255 &&
                hpEffort + atkEffort + defEffort + speedEffort + spAtkEffort + spDefEffort < 510) {
                GFL_HeapFree(data);
                return TRUE;
            }
        } else if (effort < 0) {
            if (spAtkEffort > 0) {
                GFL_HeapFree(data);
                return TRUE;
            }
            if (StatusRcv_CanChangeFriendship(pkm, data) == TRUE) {
                GFL_HeapFree(data);
                return TRUE;
            }
        }
    }
    if (PML_ItemGetParam(data, 47) != 0) {
        effort = PML_ItemGetParam(data, 57);
        if (effort > 0) {
            if ((spDefEffort < 100 || noLimit != 0) && spDefEffort < 255 &&
                hpEffort + atkEffort + defEffort + speedEffort + spAtkEffort + spDefEffort < 510) {
                GFL_HeapFree(data);
                return TRUE;
            }
        } else if (effort < 0) {
            if (spDefEffort > 0) {
                GFL_HeapFree(data);
                return TRUE;
            }
            if (StatusRcv_CanChangeFriendship(pkm, data) == TRUE) {
                GFL_HeapFree(data);
                return TRUE;
            }
        }
    }

    GFL_HeapFree(data);
    return FALSE;
}
BOOL StatusRcv_UseItem(PartyPkm *pkm, u16 item, u16 pos, u16 zoneId, u32 heapId) {
    void *data;
    BOOL changed = FALSE;
    BOOL hasEffect;
    u32 status;
    u32 newStatus;
    s32 spAtkEffort;
    s32 spDefEffort;
    s32 noLimit;
    s32 add;
    s32 hpEffort;
    s32 hp;
    s32 atkEffort;
    s32 maxHp;
    s32 defEffort;
    s32 speedEffort;
    s32 level;
    int i;
    s32 friendship;
    s32 effort;

    data = PML_ItemReadDataFile(item, 0, heapId);
    if (PML_ItemGetParam(data, 14) != 1) {
        GFL_HeapFree(data);
        return changed;
    }

    hasEffect = FALSE;
    status = PokeParty_GetParam(pkm, PKM_PARAM_STATUS, NULL);
    newStatus = status;
    if (PML_ItemGetParam(data, 18) != 0) {
        newStatus = 0;
        hasEffect = TRUE;
    }
    if (PML_ItemGetParam(data, 19) != 0) {
        newStatus = 0;
        hasEffect = TRUE;
    }
    if (PML_ItemGetParam(data, 20) != 0) {
        newStatus = 0;
        hasEffect = TRUE;
    }
    if (PML_ItemGetParam(data, 21) != 0) {
        newStatus = 0;
        hasEffect = TRUE;
    }
    if (PML_ItemGetParam(data, 22) != 0) {
        newStatus = 0;
        hasEffect = TRUE;
    }
    if (status != newStatus) {
        PokeParty_SetParam(pkm, PKM_PARAM_STATUS, newStatus);
        changed = TRUE;
    }

    hp = PokeParty_GetParam(pkm, PKM_PARAM_HP, NULL);
    maxHp = PokeParty_GetParam(pkm, PKM_PARAM_MAX_HP, NULL);
    if ((PML_ItemGetParam(data, 26) != 0 || PML_ItemGetParam(data, 27) != 0) && PML_ItemGetParam(data, 28) == 0) {
        if (hp == 0) {
            StatusRcv_RestoreHp(pkm, hp, maxHp, PML_ItemGetParam(data, 58));
            changed = TRUE;
        }
        hasEffect = TRUE;
    } else if (PML_ItemGetParam(data, 41) != 0) {
        if (hp < maxHp) {
            StatusRcv_RestoreHp(pkm, hp, maxHp, PML_ItemGetParam(data, 58));
            changed = TRUE;
        }
        hasEffect = TRUE;
    }

    level = PokeParty_GetParam(pkm, PKM_PARAM_LEVEL, NULL);
    if (PML_ItemGetParam(data, 28) != 0) {
        if (level < 100) {
            PokeParty_SetParam(pkm, PKM_PARAM_EXP,
                               PML_UtilGetPkmLvExp(PokeParty_GetParam(pkm, PKM_PARAM_SPECIES, NULL),
                                                   PokeParty_GetParam(pkm, PKM_PARAM_FORM, NULL), level + 1));
            PokeParty_RecalcStats(pkm);
            // A fainted Pokémon gets back the HP its maximum rose by
            if (hp == 0) {
                u32 newMaxHp = PokeParty_GetParam(pkm, PKM_PARAM_MAX_HP, NULL);

                StatusRcv_RestoreHp(pkm, hp, newMaxHp, newMaxHp - maxHp);
            }
            changed = TRUE;
        }
        hasEffect = TRUE;
    }

    if (PML_ItemGetParam(data, 29) != 0) {
        hasEffect = TRUE;
    }

    if (PML_ItemGetParam(data, 37) != 0) {
        if (StatusRcv_PPUp(pkm, pos, 1) == TRUE) {
            changed = TRUE;
        }
        hasEffect = TRUE;
    } else if (PML_ItemGetParam(data, 38) != 0) {
        if (StatusRcv_PPUp(pkm, pos, 3) == TRUE) {
            changed = TRUE;
        }
        hasEffect = TRUE;
    }

    if (PML_ItemGetParam(data, 39) != 0) {
        if (PokeParty_AddPP(pkm, pos, PML_ItemGetParam(data, 59)) == TRUE) {
            changed = TRUE;
        }
        hasEffect = TRUE;
    } else if (PML_ItemGetParam(data, 40) != 0) {
        for (i = 0; i < 4; i++) {
            if (PokeParty_AddPP(pkm, i, PML_ItemGetParam(data, 59)) == TRUE) {
                changed = TRUE;
            }
        }
        hasEffect = TRUE;
    }

    hpEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP, NULL);
    atkEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 1, NULL);
    defEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 2, NULL);
    speedEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 3, NULL);
    spAtkEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 4, NULL);
    spDefEffort = PokeParty_GetParam(pkm, PKM_PARAM_EV_HP + 5, NULL);
    noLimit = PML_ItemGetParam(data, 48);

    if (PML_ItemGetParam(data, 42) != 0) {
        add = PML_ItemGetParam(data, 52);
        if (add > 0 && PokeParty_GetParam(pkm, PKM_PARAM_SPECIES, NULL) == SPECIES_SHEDINJA) {
            GFL_HeapFree(data);
            return FALSE;
        }
        effort = StatusRcv_AddEffort(hpEffort, atkEffort + defEffort + speedEffort + spAtkEffort + spDefEffort, add,
                                     noLimit);
        if (effort != -1) {
            hpEffort = effort;
            PokeParty_SetParam(pkm, PKM_PARAM_EV_HP, hpEffort);
            PokeParty_RecalcStats(pkm);
            changed = TRUE;
        }
        if (add > 0) {
            hasEffect = TRUE;
        }
    }
    if (PML_ItemGetParam(data, 43) != 0) {
        add = PML_ItemGetParam(data, 53);
        effort = StatusRcv_AddEffort(atkEffort, hpEffort + defEffort + speedEffort + spAtkEffort + spDefEffort, add,
                                     noLimit);

        if (effort != -1) {
            atkEffort = effort;
            PokeParty_SetParam(pkm, PKM_PARAM_EV_HP + 1, atkEffort);
            PokeParty_RecalcStats(pkm);
            changed = TRUE;
        }
        if (add > 0) {
            hasEffect = TRUE;
        }
    }
    if (PML_ItemGetParam(data, 44) != 0) {
        add = PML_ItemGetParam(data, 54);
        effort = StatusRcv_AddEffort(defEffort, hpEffort + atkEffort + speedEffort + spAtkEffort + spDefEffort, add,
                                     noLimit);

        if (effort != -1) {
            defEffort = effort;
            PokeParty_SetParam(pkm, PKM_PARAM_EV_HP + 2, defEffort);
            PokeParty_RecalcStats(pkm);
            changed = TRUE;
        }
        if (add > 0) {
            hasEffect = TRUE;
        }
    }
    if (PML_ItemGetParam(data, 45) != 0) {
        add = PML_ItemGetParam(data, 55);
        effort = StatusRcv_AddEffort(speedEffort, hpEffort + atkEffort + defEffort + spAtkEffort + spDefEffort, add,
                                     noLimit);

        if (effort != -1) {
            speedEffort = effort;
            PokeParty_SetParam(pkm, PKM_PARAM_EV_HP + 3, speedEffort);
            PokeParty_RecalcStats(pkm);
            changed = TRUE;
        }
        if (add > 0) {
            hasEffect = TRUE;
        }
    }
    if (PML_ItemGetParam(data, 46) != 0) {
        add = PML_ItemGetParam(data, 56);
        effort = StatusRcv_AddEffort(spAtkEffort, hpEffort + atkEffort + defEffort + speedEffort + spDefEffort, add,
                                     noLimit);

        if (effort != -1) {
            spAtkEffort = effort;
            PokeParty_SetParam(pkm, PKM_PARAM_EV_HP + 4, spAtkEffort);
            PokeParty_RecalcStats(pkm);
            changed = TRUE;
        }
        if (add > 0) {
            hasEffect = TRUE;
        }
    }
    if (PML_ItemGetParam(data, 47) != 0) {
        add = PML_ItemGetParam(data, 57);
        effort = StatusRcv_AddEffort(spDefEffort, hpEffort + atkEffort + defEffort + speedEffort + spAtkEffort, add,
                                     noLimit);

        if (effort != -1) {
            spDefEffort = effort;
            PokeParty_SetParam(pkm, PKM_PARAM_EV_HP + 5, spDefEffort);
            PokeParty_RecalcStats(pkm);
            changed = TRUE;
        }
        if (add > 0) {
            hasEffect = TRUE;
        }
    }

    if (changed == FALSE && hasEffect == TRUE) {
        GFL_HeapFree(data);
        return FALSE;
    }

    friendship = PokeParty_GetParam(pkm, PKM_PARAM_HAPPINESS, NULL);
    if (friendship < 100) {
        if (PML_ItemGetParam(data, 49) != 0) {
            StatusRcv_ChangeFriendship(pkm, friendship, PML_ItemGetParam(data, 60), item, zoneId, heapId);
            GFL_HeapFree(data);
            return changed;
        }
    } else if (friendship >= 100 && friendship < 200) {
        if (PML_ItemGetParam(data, 50) != 0) {
            StatusRcv_ChangeFriendship(pkm, friendship, PML_ItemGetParam(data, 61), item, zoneId, heapId);
            GFL_HeapFree(data);
            return changed;
        }
    } else if (friendship >= 200 && friendship <= 255) {
        if (PML_ItemGetParam(data, 51) != 0) {
            StatusRcv_ChangeFriendship(pkm, friendship, PML_ItemGetParam(data, 62), item, zoneId, heapId);
            GFL_HeapFree(data);
            return changed;
        }
    }

    GFL_HeapFree(data);
    return changed;
}
static void StatusRcv_RestoreHp(PartyPkm *pkm, u32 hp, u32 maxHp, u32 amount) {
    if (maxHp == 1) {
        amount = 1;
    } else if (amount == 255) {
        amount = maxHp;
    } else if (amount == 254) {
        amount = maxHp / 2;
    } else if (amount == 253) {
        amount = maxHp / 4;
    }
    hp += amount;
    if (hp > maxHp) {
        hp = maxHp;
    }
    PokeParty_SetParam(pkm, PKM_PARAM_HP, hp);
}
static s32 StatusRcv_AddEffort(s32 effort, s32 total, s32 add, s32 noLimit) {
    if (effort == 0 && add < 0) {
        return -1;
    }
    if (effort == 255 && add > 0) {
        return -1;
    }
    if (effort >= 100 && noLimit == 0 && add > 0) {
        return -1;
    }
    if (effort + total >= 510 && add > 0) {
        return -1;
    }
    effort += add;
    if (add > 0 && effort > 100 && noLimit == 0) {
        effort = 100;
    } else if (effort < 0) {
        effort = 0;
    }
    if (effort + total > 510) {
        effort = 510 - total;
    }
    return effort;
}
int main(void){hpup.workType=candy.workType=1;
hpup.work.params.hpEVUp=1;hpup.work.params.hpEV=10;
candy.work.params.revive=1;candy.work.params.levelUp=1;
hpup.work.params.friendshipUp2=candy.work.params.friendshipUp2=1;
hpup.work.params.friendshipUp3=candy.work.params.friendshipUp3=1;
hpup.work.params.unk6_4=candy.work.params.unk6_4=1;
hpup.work.params.friendship1=candy.work.params.friendship1=5;
hpup.work.params.friendship2=candy.work.params.friendship2=3;
hpup.work.params.friendship3=candy.work.params.friendship3=2;
assert(PML_ItemGetParam(&hpup,48)==0);assert(PML_ItemGetParam(&hpup,52)==10);assert(PML_ItemGetParam(&candy,28)==1);

struct {int ev,other,expected;} ev[]={{0,0,10},{90,0,100},{95,0,100},{99,0,100},{100,0,-1},{254,0,-1},{90,417,93},{99,410,100},{0,509,1},{0,510,-1}};
for(int i=0;i<10;i++){assert(StatusRcv_AddEffort(ev[i].ev,ev[i].other,10,0)==ev[i].expected);}
for(int kind=1;kind<=2;kind++)for(int fainted=0;fainted<=1;fainted++){
 PartyPkm p={0};current=&p;p.values[PKM_PARAM_SPECIES]=1;p.values[PKM_PARAM_LEVEL]=kind==1?100:6;p.values[PKM_PARAM_EXP]=kind==1?1059860:235;p.values[PKM_PARAM_HP]=fainted?0:(kind==1?195:16);p.values[PKM_PARAM_MAX_HP]=kind==1?200:21;p.values[PKM_PARAM_HAPPINESS]=70;p.nextMax=kind==1?202:23;p.nextExp=236;
 assert(StatusRcv_CanUseItem(&p,kind,0,0));assert(StatusRcv_UseItem(&p,kind,0,0,0));
 assert(p.values[PKM_PARAM_MAX_HP]==(kind==1?202:23));assert(p.values[PKM_PARAM_HP]==(fainted?(kind==2?2:0):(kind==1?197:18)));
 assert(p.values[PKM_PARAM_EXP]==(kind==2?236:1059860));assert(p.values[PKM_PARAM_EV_HP]==(kind==1?10:0));assert(p.friendshipCalls==1);
}
PartyPkm p={0};current=&p;p.values[PKM_PARAM_SPECIES]=1;p.values[PKM_PARAM_LEVEL]=100;p.values[PKM_PARAM_HP]=0;p.values[PKM_PARAM_MAX_HP]=200;p.values[PKM_PARAM_HAPPINESS]=70;p.nextMax=202;p.values[PKM_PARAM_EV_HP]=100;
assert(!StatusRcv_CanUseItem(&p,2,0,0));assert(!StatusRcv_CanUseItem(&p,1,0,0));assert(!StatusRcv_UseItem(&p,2,0,0,0));assert(!StatusRcv_UseItem(&p,1,0,0,0));assert(p.friendshipCalls==0);
printf("10 EV vectors +4 HP/control branches +2 cap failures PASS\n");return 0;}

"""Independent literal expectations checked against pinned personal/XP tables."""
from pathlib import Path
import json,re,csv
P=Path(__file__).resolve().parent
pkhex=(P/'references/Experience.cs').read_text();personal=(P/'references/personal_b2w2').read_bytes()
tables={int(m[1]):[int(x)for x in re.findall(r'\d+',m[2])]for m in re.finditer(r'Growth(\d) =>\s*\[(.*?)\];',pkhex,re.S)}
csvxp={(int(r['growth_rate_id']),int(r['level'])):int(r['experience'])for r in csv.DictReader((P/'references/experience.csv').open())}
mapping={0:2,1:5,2:6,3:4,4:3,5:1}
for group,rows in tables.items():
 assert len(rows)==100
 for level,xp in enumerate(rows,1):assert csvxp[mapping[group],level]==xp,(group,level)
# Four actual original151 growth groups and exact next threshold, not currentXP+full span.
xp_cases=[(1,6,235,7,236),(25,9,800,10,1000),(129,5,200,6,270),(35,10,1000,11,1064),(4,15,2534,16,2535),(1,99,1030000,100,1059860)]
for dex,level,xp,target,expected in xp_cases:
 group=personal[dex*0x4c+0x15];assert tables[group][target-1]==expected
 assert tables[group][level-1]<=xp<expected
# These are manually stated expectations; calculator just checks against pinned bases.
hp_cases=[(1,5,0,0,19),(1,5,0,10,19),(1,100,0,0,200),(1,100,0,10,202),(1,50,0,95,116),(1,50,0,100,117),(1,6,0,0,21),(1,7,0,0,23),(4,15,0,0,36),(4,16,0,0,38),(5,16,0,0,44)]
for dex,level,iv,ev,expected in hp_cases:
 base=personal[dex*0x4c];actual=((2*base+iv+ev//4)*level)//100+level+10;assert actual==expected,(dex,level,actual,expected)
(P/'literal-vectors.json').write_text(json.dumps({'source':'pinned PKHeX personal/Experience plus independent PokeAPI experience tables, original151','all_six_growth_tables_crosschecked':600,'rare_candy_thresholds':[{'dex':d,'from_level':l,'current_xp':x,'to_level':t,'expected_xp':e}for d,l,x,t,e in xp_cases],'hp_stats':[{'dex':d,'level':l,'iv_hp':i,'ev_hp':v,'expected_max_hp':e}for d,l,i,v,e in hp_cases],'native_semantic_hp_cases':[{'item':'hpUp','dex':1,'level':5,'ev_before':0,'ev_after':10,'hp_before':19,'hp_after':19,'consumed':True},{'item':'hpUp','dex':1,'level':100,'ev_before':0,'ev_after':10,'max_before':200,'max_after':202,'hp_before':195,'hp_after':197},{'item':'hpUp','dex':1,'level':100,'hp_before':0,'hp_after':0},{'item':'rareCandy','dex':1,'level_before':6,'level_after':7,'xp_before':235,'xp_after':236,'max_before':21,'max_after':23,'hp_before':0,'hp_after':2},{'item':'rareCandy','dex':4,'level_before':15,'level_after':16,'xp_before':2534,'xp_after':2535,'max_before':36,'max_after':38,'hp_before':0,'hp_after':2,'after_accepted_charmeleon_max':44,'after_accepted_charmeleon_hp':8,'after_cancelled_evolution_hp':2}],'status_preserved':True,'RNG_rolls_added':0,'native_runtime_executed':False},indent=2)+'\n')
print('600 independent XP table values +6 literal threshold cases +11 literal HP cases PASS')

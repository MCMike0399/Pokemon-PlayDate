#!/usr/bin/env python3
"""Private compile by default; only root explicitly executes the owned harness."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');a=p.parse_args()
s=Path(__file__).resolve().parent;project=Path(a.project).resolve();sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((s/'manifest.json').read_text());original=harness.prepare;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def prepare(project,sdk,output,session):
 metadata=original(project,sdk,output,session)
 for row in manifest['patches']:
  path=s/row['path'];assert sha(path)==row['sha256'],'patch drift'
  result=subprocess.run(['git','apply','-p0','--check',str(path)],cwd=output,capture_output=True,text=True)
  if result.returncode:
   reverse=subprocess.run(['git','apply','-p0','--reverse','--check',str(path)],cwd=output,capture_output=True,text=True);assert reverse.returncode==0,'patch conflict '+result.stderr
  else:subprocess.run(['git','apply','-p0',str(path)],cwd=output,check=True)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated);values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n');metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['status_contract_errata']=manifest
 with(output/'errata-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(s/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

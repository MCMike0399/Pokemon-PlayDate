# Five fixture-direction failures — separate frozen test-only errata

Root's actual integrated SDK result `/private/tmp/pokemon-brock-composed-sdk-01/00001-result.json` reports five owned status/sex component failures: two SexAbility groups and three OwnTempo groups. All fail because fresh `Battle` intentionally leaves `attacker`/`defender` unset. The tests directly invoke `ApplyStatus(DEFENDER,...)` or `ModifyStat(DEFENDER,...)` inside runScript, bypassing the production `resolveTurn` entry that sets real direction.

Production trace: `Target:resolve` reads battle.defender; `Battle:resolveTurn` begins with `self:setDirection(turn.side)` before the DSL. The real Toxic and ConfuseRay command tests already pass. There is no evidence for a production fallback. This packet changes **only explicit component test setup**: setDirection("player") and assert attacker==actual player/defender==actual enemy at six source call sites covering those five groups. Every existing status, stat, PP, RNG and expected value remains byte-identical after removing the added setup. No new groups, engine/DSL/domain changes, fallback or no-op.

Apply the two `patches/*.patch` using `git apply -p0` in the root integration worktree. Both suites are already registered; no main/import changes. Full Source/dev bodies are review context only. `manifest.json` pins exact before/after and original failure-result hashes. The original sex/OwnTempo/Worry packets remain unchanged.

Worker checks:3 host tests PASS/0skip; private actual SDK compile-only `/private/tmp/pokemon-brock-status-contract-errata-compile-01` PASS. **SDK rerun pending root**, no Simulator/Data/live Source access. Root should rerun the complete integrated suites and require these exact five original names to pass. This packet does not repair or claim acceptance for the other12 failures in the855pass/17fail result.

```sh
python3 /private/tmp/pokemon-brock-status-contract-errata-01/test_packet.py
python3 /private/tmp/pokemon-brock-status-contract-errata-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-status-direction-root-build
```

Default is compile-only. Root may explicitly add `--execute` with a fresh output path. The native result also contains all22 Worry groups passing; this is SDK evidence only, not its still-pending native UI screenshot acceptance.

Route22 remains reference/proposal work, with no runtime implementation started during this repair.

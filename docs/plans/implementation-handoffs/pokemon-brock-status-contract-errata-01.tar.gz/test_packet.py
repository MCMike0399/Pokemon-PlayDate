import hashlib,json,re,unittest
from pathlib import Path
S=Path(__file__).resolve().parent
class ErrataTests(unittest.TestCase):
 def test_only_explicit_direction_setup_changes(self):
  for name in ('sexAbilityContracts.lua','ownTempoContracts.lua'):
   old=(S/'base/Source/dev'/name).read_text();new=(S/'Source/dev'/name).read_text()
   normalized=new.replace(';b:setDirection("player");eq(b.attacker,p);eq(b.defender,e)','').replace(';b:setDirection("player");eq(b.attacker,b.player);eq(b.defender,b.enemy)','')
   self.assertEqual(old,normalized);self.assertEqual(old.count(' test("'),new.count(' test("'))
  self.assertEqual(sum(p.read_text().count('b:setDirection("player")')for p in (S/'Source/dev').glob('*.lua')),6)
 def test_immutable_patch_inventory(self):
  m=json.loads((S/'manifest.json').read_text());self.assertEqual(m['added_groups'],0);self.assertEqual(m['affected_groups'],5)
  self.assertEqual(len(m['patches']),2)
  for r in m['patches']:self.assertEqual(hashlib.sha256((S/r['path']).read_bytes()).hexdigest(),r['sha256'])
  self.assertFalse((S/'Source/battle').exists());self.assertFalse((S/'Source/domain').exists())
 def test_reported_native_failures_are_exact_owned_five(self):
  j=json.loads(Path('/private/tmp/pokemon-brock-composed-sdk-01/00001-result.json').read_text());rows=j['results'][0]['contracts']['tests']
  errors=[r for r in rows if not r['ok']and r['name'].startswith(('sex-abilities:','own-tempo:'))]
  self.assertEqual(len(errors),5)
  for r in errors:self.assertIn('nil value',r['error']);self.assertIn('battle/dsl.lua:',r['error'])
  worry=[r for r in rows if r['name'].startswith('worry-seed:')];self.assertEqual(len(worry),22);self.assertTrue(all(r['ok']for r in worry))
if __name__=='__main__':unittest.main(verbosity=2)

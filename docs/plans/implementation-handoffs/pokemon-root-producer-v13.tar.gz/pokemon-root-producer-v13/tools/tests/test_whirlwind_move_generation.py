"""Exact Whirlwind v13 migration; independent scalar and historical oracles."""
import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from tools import move_producer_contract as c
from tools.tests.test_move_producer_contract import gen,ROOT

EFFECT='ForceSwitchEffect(DEFENDER)'
def fixture():
 return dict(moves=[dict(id='18',identifier='whirlwind',type_id='1',pp='20',damage_class_id='1',power='',accuracy='100',target_id='10',priority='-6',effect_chance='',generation_id='1')],move_changelog=[],move_meta=[dict(move_id='18',meta_ailment_id='0',ailment_chance='0',flinch_chance='0',stat_chance='0',healing='0',drain='0',min_hits='',max_hits='')],move_meta_stat_changes=[],types=[dict(id='1',identifier='normal')])
def prior():
 row=c.read_rows((ROOT/'Source/battle/moves.lua').read_text())['whirlwind']
 prefix,_=c.split_payload(row)
 return '-- move-producer-contract: 12\n    whirlwind = '+prefix+' },\n'
def generate(text,path):
 source=path/'input.lua';output=path/'output.lua';source.write_text(text)
 with patch.object(gen,'MOVES_INPUT',str(source)),patch.object(gen,'MOVES_LUA',str(output)),patch.object(gen,'EXTRA_MOVE_KEYS',[]):gen.generate_moves(fixture(),True)
 return output.read_text()

class WhirlwindProducerTests(unittest.TestCase):
 def test_exact_v12_payload_migration_and_idempotence_preserves_every_scalar(self):
  with tempfile.TemporaryDirectory()as tmp:
   p=Path(tmp);old=c.read_rows(prior())['whirlwind'];text=generate(prior(),p);row=c.read_rows(text)['whirlwind']
   self.assertEqual(c.producer_epoch(text),13)
   self.assertEqual(c.split_payload(row)[0],c.split_payload(old)[0])
   self.assertEqual(c.payload(row),{'effects':['ForceSwitchEffect ( DEFENDER )'],'secondaries':[]})
   f=c.fields(row)
   for key,value in dict(power=0,accuracy=100,pp=20,targetId=10,priority=-6,type='normal',category='status',contact=False,hasSecondary=False,ohko=False,protectable=True,breaksProtect=False).items():
    self.assertIs(type(f[key]),type(value));self.assertEqual(f[key],value)
   self.assertEqual(generate(text,p),text)
 def test_current_rollback_wrong_target_extra_effect_and_scalars_reject_before_write(self):
  with tempfile.TemporaryDirectory()as tmp:
   p=Path(tmp);text=generate(prior(),p)
   changes=[(', effects = { '+EFFECT+' }',''),(EFFECT,'ForceSwitchEffect(ATTACKER)'),(EFFECT,'NoEffect()'),(EFFECT,EFFECT+', NoEffect()'),('priority = -6','priority = -5'),('accuracy = 100','accuracy = 0'),('pp = 20','pp = 21'),('targetId = 10','targetId = 7'),('protectable = true','protectable = false'),('hasSecondary = false','hasSecondary = true')]
   for old,new in changes:
    self.assertIn(old,text);(p/'output.lua').write_text('PRESERVE')
    with self.subTest(change=(old,new)),self.assertRaisesRegex(ValueError,'unexpected changes'):generate(text.replace(old,new,1),p)
    self.assertEqual((p/'output.lua').read_text(),'PRESERVE')
 def test_historical_legacy_projection_and_current_epoch_rollback_detection(self):
  text=(ROOT/'Source/battle/moves.lua').read_text();rows=c.read_rows(text);self.assertEqual(c.producer_epoch(text),13)
  self.assertEqual(c.digest(json.dumps(c.legacy_rows(rows,13),sort_keys=True,separators=(',',':')).encode()),'ad40fd9b5592a4ffeb88dcfc9243cc56034b2f4ea5b2da6bb3f2a8c129da45ea')
  changed=dict(rows);changed['whirlwind']=c.read_rows(prior())['whirlwind']
  self.assertEqual(c.digest(json.dumps(c.legacy_rows(changed,12),sort_keys=True,separators=(',',':')).encode()),'ad40fd9b5592a4ffeb88dcfc9243cc56034b2f4ea5b2da6bb3f2a8c129da45ea')
  with self.assertRaisesRegex(ValueError,'unowned move effect'):c.legacy_rows(changed,13)
 def test_old_epoch_does_not_authorize_arbitrary_payload_or_scalar_repair(self):
  with tempfile.TemporaryDirectory()as tmp:
   p=Path(tmp)
   for changed in [prior().replace('priority = -6','priority = -5'),prior().replace(' },\n',', effects = { NoEffect() } },\n')]:
    with self.subTest(input=changed),self.assertRaisesRegex(ValueError,'unexpected changes'):generate(changed,p)
 def test_exact_pre_metadata_input_migrates_but_undeclared_old_payload_rejects(self):
  with tempfile.TemporaryDirectory()as tmp:
   p=Path(tmp);row=c.read_rows(prior())['whirlwind'];legacy='    whirlwind = '+c.drop_fields(row,('targetId',)+c.PRODUCER_FIELDS)+'\n'
   self.assertEqual(c.producer_epoch(legacy),0)
   self.assertEqual(c.read_rows(generate(legacy,p)),c.read_rows(generate(prior(),p)))
   for changed in [legacy.replace('accuracy = 100','accuracy = 99'),legacy.replace(' },\n',', effects = { NoEffect() } },\n')]:
    with self.subTest(input=changed),self.assertRaisesRegex(ValueError,'unexpected changes'):generate(changed,p)

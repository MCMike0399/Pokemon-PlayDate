#!/usr/bin/env python3
"""Replay actual pinned engine and qualify literal branch observations only."""
import argparse,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--ps-root',type=Path);a=p.parse_args();root=Path(__file__).resolve().parent
source=json.loads((root/'sources.json').read_text());ps=a.ps_root or Path(source['ps_root'])
for key,row in source['files'].items():
 if key.startswith('PS/'):
  assert hashlib.sha256((ps/key[3:]).read_bytes()).hexdigest()==row['sha256'],key
raw=subprocess.check_output(['node',str(root/'probe.js'),str(ps)])
assert raw==(root/'observations.json').read_bytes(),'mechanical actualPS replay differs'
report=json.loads(raw);cases={c['name']:c for c in report['cases']};assert len(cases)==47
actor=lambda step,side,species:next(p for p in step['after'][side]if p['species']==species)
logs=lambda step:'\n'.join(step['log'])
for move,fast,slow in [('disable',[3,2,1,None,None,None],[4,3,2,1,None,None]),('encore',[2,1,None,None,None,None],[3,2,1,None,None,None])]:
 for order,expected in [('before',fast),('after',slow)]:
  c=cases[f'{move} duration {order} target action'];got=[s['after']['p2'][0]['volatiles'].get(move,{}).get('duration')for s in c['steps'][1:]]
  assert got==expected,(move,order,got)
 for tail in ['no history fails','last move zero PP fails']:
  step=cases[move+' '+tail]['steps'][-1];assert move not in step['after']['p2'][0]['volatiles'];assert '|-fail|'in logs(step)
 step=cases[move+' repeat does not refresh']['steps'][-1];assert step['after']['p2'][0]['volatiles'][move]['duration']==(2 if move=='disable'else 1)
 step=cases[move+' Protect blocks actual payload']['steps'][-1];assert move not in step['after']['p2'][0]['volatiles']
 for tail in ['bypasses actual Substitute','Ghost status immunity does not apply']:
  step=cases[move+' '+tail]['steps'][-1];assert move in step['after']['p2'][0]['volatiles']
step=cases['disable before confusion and paralysis']['steps'][-1];assert '|cant|'in logs(step)and'|Disable|'in logs(step);assert len(step['random32'])==1
step=cases['encore duration before target action']['steps'][1];assert step['choices'][1]=='move 2';assert step['after']['p2'][0]['lastMove']=='splash'
assert '|-fail|'in logs(cases['encore cannot encore struggle']['steps'][-1])
assert cases['encore and disable same move force struggle']['steps'][-1]['after']['p2'][0]['lastMove']=='struggle'
assert 'encore'not in cases['encore ends when last selected PP exhausted']['steps'][-1]['after']['p2'][0]['volatiles']
assert cases['disable existing bide continuation']['steps'][-1]['after']['p1'][0]['pp'][0]['pp']==15
assert '|cant|p1a: Snorlax|Disable|Bide'in logs(cases['disable existing bide continuation']['steps'][-1])
charge=cases['charge doubles next electric base power and consumes']['steps'];assert charge[0]['after']['p1'][0]['boosts']['spd']==1
assert 'charge'in charge[0]['after']['p1'][0]['volatiles'] and 'charge'not in charge[1]['after']['p1'][0]['volatiles']
assert [s['after']['p2'][0]['hp']for s in charge]==[430,415,408]
assert cases['charge baseline ordinary electric']['steps'][0]['after']['p2'][0]['hp']==423
for name in ['charge consumed by next non-electric action','charge consumed by electric status','charge immune electric attempt consumes','charge protected electric attempt consumes','charge full paralysis aborted action consumes','charge sleep aborted action consumes']:
 assert 'charge'not in cases[name]['steps'][1]['after']['p1'][0]['volatiles'],name
par=cases['charge full paralysis aborted action consumes']['steps'][1];assert '|cant|p1a: Voltorb|par'in logs(par);assert par['after']['p1'][0]['pp'][1]['pp']==48
assert 'charge'in cases['charge itself asleep does not consume existing buffer']['steps'][1]['after']['p1'][0]['volatiles']
assert cases['charge repeats capped SpD and does not stack power']['steps'][-1]['after']['p2'][0]['hp']==415
normal=cases['pursuit ordinary power40']['steps'][0];sw=cases['pursuit voluntary intercept power80 target old actor']['steps'][0]
assert actor(normal,'p1','snorlax')['hp']==205;assert actor(sw,'p1','snorlax')['hp']==193;assert actor(sw,'p1','pikachu')['hp']==95
ko=cases['pursuit intercept KO invalidates planned replacement']['steps'];assert ko[0]['after']['request']=='switch';assert actor(ko[0],'p1','snorlax')['hp']==0
assert actor(ko[1],'p1','pikachu')['active'];assert ko[1]['random32']==[];assert ko[0]['after']['p2'][0]['pp']==ko[1]['after']['p2'][0]['pp']
assert '|[miss]'in logs(cases['pursuit evasion ordinary may miss']['steps'][0]);assert '[miss]'not in logs(cases['pursuit switching always hits despite stages']['steps'][0])
splash=cases['Splash named intentional inaction PP/no RNG']['steps'][0];assert splash['random32']==[];assert splash['after']['p1'][0]['hp']==17
assert splash['after']['p1'][0]['pp'][0]['pp']==63;assert splash['after']['p1'][0]['lastMove']=='splash';assert splash['log'].count('|-nothing')==2
metadata=json.loads((root/'encore-eligibility.json').read_text());assert len(metadata['moves'])==425
assert {x['key']for x in metadata['excluded']}=={'mimic','mirrorMove','transform','encore','struggle'}
print(json.dumps({'ok':True,'actual_PS_cases':47,'observations_sha256':hashlib.sha256(raw).hexdigest(),'native_C':'read-only source evidence; not executed'},indent=2))

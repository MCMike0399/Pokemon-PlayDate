#!/usr/bin/env python3
"""Private patch composition and compile; --execute is reserved to root owner."""
import argparse,hashlib,json,subprocess,sys,shutil
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--mutant',choices=['rapidspin-wipes','wind-after-para','block-self','screen-min1','skip-zero-contact','skip-zero-lock','skip-zero-rage']);a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def apply(output,path):
 result=subprocess.run(['git','apply','-p1','--check',str(path)],cwd=output,capture_output=True,text=True)
 if result.returncode:
  inverse=subprocess.run(['git','apply','-p1','--reverse','--check',str(path)],cwd=output,capture_output=True,text=True)
  assert inverse.returncode==0,'shared source conflict '+str(path)+': '+result.stderr;return
 subprocess.run(['git','apply','-p1',str(path)],cwd=output,check=True)
def change(path,old,new):
 body=path.read_text();assert body.count(old)==1,'mutant anchor '+old;path.write_text(body.replace(old,new,1))
def prepare(project,sdk,output,session):
 for r in manifest['source_files']:
  assert sha(stage/r['path'])==r['sha256'],'source drift '+r['path'];assert sha(stage/r['patch'])==r['patch_sha256'],'patch drift '+r['patch']
 for rel,expected in manifest.get('packet_files',{}).items():assert sha(stage/rel)==expected,'packet drift '+rel
 metadata=original(project,sdk,output,session)
 dependency=Path(manifest['protect_dependency']['manifest']).parent
 assert sha(dependency/'manifest.json')==manifest['protect_dependency']['sha256'],'Protect dependency drift'
 dm=json.loads((dependency/'manifest.json').read_text())
 for row in dm['source_files']:
  assert sha(dependency/row['path'])==row['sha256'],'Protect source drift '+row['path']
  assert sha(dependency/row['patch'])==row['patch_sha256'],'Protect patch drift'
  if row['path']=='Source/battle/moves.lua' and sha(output/row['path'])==manifest['producer_sha256']:continue
  if row['base_sha256']is None:
   target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(dependency/row['path'],target)
  else:apply(output,dependency/row['patch'])
 # Compose the separate test-only cleanup boundary correction; never replace
 # production source or the preserved failed native evidence.
 cleanup=Path(manifest['protect_cleanup_dependency']['manifest']).parent
 assert sha(cleanup/'manifest.json')==manifest['protect_cleanup_dependency']['sha256'],'Protect cleanup dependency drift'
 cm=json.loads((cleanup/'manifest.json').read_text())
 for row in cm['source_files']:
  assert sha(cleanup/row['path'])==row['sha256'] and sha(cleanup/row['patch'])==row['patch_sha256'],'Protect cleanup drift'
  apply(output,cleanup/row['patch'])
 for row in manifest['source_files']:
  if row['base_sha256']is None:
   target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/row['path'],target)
  else:
   if row['path']=='Source/battle/moves.lua':assert sha(output/row['path'])in(row['base_sha256'],row['sha256']),'unreviewed generated move epoch'
   apply(output,stage/row['patch'])
 if a.mutant=='rapidspin-wipes':change(output/'Source/battle/conditions.lua','side.spikes,side.toxicSpikes,side.stealthRock,side.order,side.hazardOrigins=nil,nil,nil,nil,nil','self.sides[self:side(user)]={}')
 elif a.mutant=='wind-after-para':
  target=output/'Source/battle/battle.lua';text=target.read_text();line='    if conditions then speed=conditions:speed(pokemon,speed) end\n';assert text.count(line)==1;text=text.replace(line,'',1);anchor='    return math.max(1,speed)';assert text.count(anchor)==1;target.write_text(text.replace(anchor,line+anchor,1))
 elif a.mutant=='block-self':change(output/'Source/battle/conditions.lua','if not origin or not origin.source or origin.source==mon then return false end','if not origin or not origin.source then return false end')
 elif a.mutant=='screen-min1':change(output/'Source/battle/battle.lua','damage=effects.battle.conditions:screenDamage(attacker,defender,move,damage,isCrit)','damage=math.max(1,effects.battle.conditions:screenDamage(attacker,defender,move,damage,isCrit))')
 elif a.mutant=='skip-zero-contact':change(output/'Source/battle/effects.lua','receipt.contact and receipt.before>0','receipt.contact and receipt.removed>0')
 elif a.mutant=='skip-zero-lock':change(output/'Source/battle/battle.lua','            self.conditions:landedMove(move)','            if receipt.removed>0 then self.conditions:landedMove(move) end')
 elif a.mutant=='skip-zero-rage':change(output/'Source/battle/battle.lua','            self.conditions:rageHit(defender)','            if receipt.removed>0 then self.conditions:rageHit(defender) end')
 main=output/'Source/main.lua';body=main.read_text();anchor='import "dev/catalog"';assert body.count(anchor)==1
 for module,key,table in [('protectContracts','protect','ProtectContracts'),('sideContracts','sides','SideContracts')]:
  if 'import \"dev/'+module+'\"'not in body:body=body.replace(anchor,'import \"dev/'+module+'\"\nContracts.register(\"'+key+'\",'+table+'.run)\n'+anchor,1)
 main.write_text(body)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated);values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['sides']=manifest;metadata['fault_mutant']=a.mutant
 with(output/'sides-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

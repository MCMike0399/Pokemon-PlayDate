import hashlib,json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class ReferenceVectors(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.rows=json.loads((ROOT/'showdown-sides-observations.json').read_text())['rows']
 def cases(self,name): return [x for x in self.rows if x['case']==name]
 def test_frozen_previous_personally_replayed_report(self):
  self.assertEqual(hashlib.sha256((ROOT/'showdown-sides-observations-before-zero-rage.json').read_bytes()).hexdigest(),'633112ce7171b6666f067e7493ea66b6144e2699ab2ba4ebd769e7d06b031839')
 def test_repeat_actual_engine_result(self):
  self.assertEqual((ROOT/'showdown-sides-observations.json').read_bytes(),(ROOT/'showdown-sides-observations-replay.json').read_bytes())
 def test_no_refresh_duration_timelines(self):
  for row in self.cases('duration-no-refresh'):
   duration=4 if row['key']=='tailwind' else 5
   self.assertEqual([x[0].get(row['key'],{}).get('duration',0) for x in row['timeline']], [max(0,duration-i-1) for i in range(6)])
 def test_independent_final_damage_literals(self):
  plain,screen=self.cases('final-screen-damage')
  self.assertEqual(plain['damage'],dict(watergun=15,tackle=18,dragonrage=40,criticalWaterGun=30))
  self.assertEqual(screen['damage'],dict(watergun=7,tackle=18,dragonrage=40,criticalWaterGun=30))
 def test_actual_zero_hit_contact_and_rage(self):
  zero=self.cases('real-zero-Swift-hit')[0];self.assertEqual((zero['hp'],zero['maxhp']),(180,180))
  hit=self.cases('real-zero-contact-rampage')[0];self.assertEqual(hit['hp'],180);self.assertEqual(hit['locked']['trueDuration'],1)
  self.assertIn({'n':3,'den':10,'effect':'static'},hit['chance'])
  rage=self.cases('real-zero-hit-builds-Rage')[0];self.assertEqual((rage['enemyHP'],rage['enemyMaxHP'],rage['enemyAttackStage'],rage['playerHP']),(33,33,1,29))
 def test_safeguard_exact_source_eligibility(self):
  for row in self.cases('status-confusion'):
   if row['safeguard']:self.assertFalse(row['status']);self.assertNotIn('confusion',row)
   elif row['key']=='sleeppowder':self.assertEqual(row['status'],'slp')
   else:self.assertEqual(row['confusion'],1)
  self.assertEqual([x['status'] for x in self.cases('ToxicSpikes-entry')],['psn',''])
  static=self.cases('Static-origin-blocked')[0];self.assertEqual(static['status'],'');self.assertTrue(static['chance'][0]['result'])
 def test_tailwind_before_paralysis_floor(self):
  self.assertEqual({(x['par'],x['wind']):x['speed'] for x in self.cases('pure-Speed-order')},{(False,False):7,(False,True):14,(True,False):1,(True,True):3})
 def test_frozen_gen5_action_queue_contrasts_actual_gen8(self):
  old,new=self.cases('queue-start-order')
  for row,expected in [(old,['p1a: Pidgeot','p2a: Sandshrew','p1b: Snorlax']),(new,['p1a: Pidgeot','p1b: Snorlax','p2a: Sandshrew'])]:
   actors=[x.split('|')[2] for x in row['log'] if x.startswith('|move|')][:3];self.assertEqual(actors,expected)
 def test_paired_side_timer_tie_independent_of_active_speed(self):
  row=self.cases('both-side-duration-callback-order')[0]
  ties=[x for x in row['calls'] if x['args']==[0,2] and x['where']==['at PRNG.shuffle','at Battle.speedSort','at Battle.fieldEvent']]
  self.assertEqual(len(ties),1)
if __name__=='__main__':unittest.main()

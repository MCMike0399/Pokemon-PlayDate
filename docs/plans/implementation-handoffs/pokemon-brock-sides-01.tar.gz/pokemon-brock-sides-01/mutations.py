#!/usr/bin/env python3
"""Compile seven bounded faults by default; root alone opts into SDK execution."""
import argparse,json,subprocess,sys
from pathlib import Path
S=Path(__file__).resolve().parent
expected={
 'rapidspin-wipes':'sides: RapidSpin removes only hazards and bindings while preserving all side timers',
 'wind-after-para':'sides: Actual shared effectiveSpeed doubles BEFORE GenVparalysisfloor with minimum1',
 'block-self':'sides: Source-self sleep and late residual fatigue pass Safeguard with explicit provenance',
 'screen-min1':'sides: Natural Pikachu100 screen vs Sandshrew11 Swift is actual successful0HP hit',
 'skip-zero-contact':'sides: ZeroHP contact hit starts real rampage and samples Static with no HP ledger',
 'skip-zero-lock':'sides: ZeroHP contact hit starts real rampage and samples Static with no HP ledger',
 'skip-zero-rage':'sides: Successful zeroHP Swift builds living Rage receiver while HP ledgers stay unchanged',
}

p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--execute',action='store_true');p.add_argument('--sdk');a=p.parse_args();output=Path(a.output);output.mkdir(parents=True,exist_ok=False);report=[]
for name,witness in [('control',None),*expected.items()]:
 run=output/name;cmd=[sys.executable,str(S/'validate_staged.py'),'--project',a.project,'--output',str(run)]
 if name!='control':cmd+=['--mutant',name]
 if a.execute:cmd+=['--execute']
 if a.sdk:cmd+=['--sdk',a.sdk]
 result=subprocess.run(cmd,capture_output=True,text=True);(output/(name+'.log')).write_text(result.stdout+result.stderr)
 row={'variant':name,'returncode':result.returncode,'runtime':a.execute}
 if not a.execute:
  if result.returncode:raise RuntimeError(name+' compile failed; see log')
  row['compiled']=True
 else:
  found=[]
  for path in sorted(run.glob('[0-9][0-9][0-9][0-9][0-9]-result.json')):
   for entry in json.loads(path.read_text()).get('results',[]):
    if entry.get('contracts'):found.append((path,entry['contracts']))
  if len(found)!=1:raise RuntimeError(name+': expected exactly1 numbered contract report, got'+str(len(found)))
  path,r=found[0];failed={x['name']for x in r['tests']if not x['ok']}
  if name=='control':assert result.returncode==0 and r['ok']and not failed,'control failed'
  else:assert result.returncode!=0 and not r['ok']and witness in failed,(name,witness,failed)
  row.update(qualified=True,evidence=str(path),passed=r['passed'],failed=r['failed'],failed_tests=sorted(failed))
 report.append(row)
(output/'qualification.json').write_text(json.dumps({'runtime_executed':a.execute,'results':report},indent=2)+'\n')
print(output/'qualification.json')

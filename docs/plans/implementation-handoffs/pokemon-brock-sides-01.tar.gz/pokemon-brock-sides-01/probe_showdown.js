const path=require('path');const ref='/private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547';const {Battle}=require(path.join(ref,'dist/sim'));
const ivs={hp:0,atk:0,def:0,spa:0,spd:0,spe:0};
const abilities={Squirtle:'Torrent',Snorlax:'Immunity',Pikachu:'Static',Bulbasaur:'Overgrow',Venusaur:'Overgrow',Butterfree:'Compound Eyes',Pidgeot:'Keen Eye',Pidgey:'Keen Eye',Sandshrew:'Sand Veil',Magikarp:'Swift Swim',Slowpoke:'Own Tempo'};
const set=(species,level,moves,ability)=>({species,level,moves,ability:ability||abilities[species],ivs,evs:{},nature:'Hardy'});
function setup(p=set('Squirtle',50,['lightscreen','safeguard','tailwind','splash']),e=set('Snorlax',50,['splash']),seed=4,format='gen5customgame'){
 const b=new Battle({formatid:format,seed:[1,2,3,seed],p1:{name:'USER',team:Array.isArray(p)?p:[p]},p2:{name:'FOE',team:Array.isArray(e)?e:[e]}});if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');return b;
}
const logs=b=>b.log.filter(x=>!x.startsWith('|t:|'));
const sides=b=>b.sides.map(s=>Object.fromEntries(Object.entries(s.sideConditions).map(([k,v])=>[k,{duration:v.duration}])));
const rows=[];
for(const key of['lightscreen','safeguard','tailwind']){
 const b=setup(),timeline=[];const index=['lightscreen','safeguard','tailwind'].indexOf(key)+1;
 for(let turn=0;turn<6;turn++){b.makeChoices('move '+(turn<2?index:4),'move 1');timeline.push(sides(b));}
 rows.push({case:'duration-no-refresh',key,timeline,log:logs(b)});b.destroy();
}
for(const screen of[false,true]){
 const b=setup(),p=b.p1.active[0],d=b.p2.active[0];if(screen)d.side.addSideCondition('lightscreen',d,b.dex.moves.get('lightscreen'));b.randomizer=n=>n;
 const damage={};for(const key of['watergun','tackle','dragonrage']){const m=b.dex.getActiveMove(key);m.willCrit=false;damage[key]=b.actions.getDamage(p,d,m,true);}
 const m=b.dex.getActiveMove('watergun');m.willCrit=true;damage.criticalWaterGun=b.actions.getDamage(p,d,m,true);
 rows.push({case:'final-screen-damage',screen,damage,stats:{p:p.storedStats,d:d.storedStats},log:logs(b)});b.destroy();
}
{
 const b=setup(set('Pikachu',100,['lightscreen']),set('Sandshrew',11,['swift']));b.randomizer=n=>Math.floor(n*85/100);const original=b.randomChance.bind(b);b.randomChance=(n,d)=>d===16&&n===1?false:original(n,d);
 b.makeChoices('move 1','move 1');rows.push({case:'real-zero-Swift-hit',control:'Actual turn, noncritical, explicitly fixed variance85%; natural levels/moves',hp:b.p1.active[0].hp,maxhp:b.p1.active[0].maxhp,sides:sides(b),log:logs(b)});b.destroy();
}
{
 const b=setup(set('Bulbasaur',5,['petaldance']),set('Pikachu',100,['lightscreen']));const p=b.p1.active[0],d=b.p2.active[0];p.boosts.spa=-6;b.randomizer=n=>Math.floor(n*85/100);const original=b.randomChance.bind(b),chance=[];b.randomChance=(n,den)=>{chance.push({n,den,effect:b.effect?.id});return den===16&&n===1?false:original(n,den)};
 b.makeChoices('move 1','move 1');rows.push({case:'real-zero-contact-rampage',control:'Illegal PetalDance5 only for mechanism isolation, actual mon stats+SpA-6, fixed variance85%, critfalse; real Static ability/events',hp:d.hp,maxhp:d.maxhp,locked:p.volatiles.lockedmove?{duration:p.volatiles.lockedmove.duration,trueDuration:p.volatiles.lockedmove.trueDuration}:null,status:p.status,chance,log:logs(b)});b.destroy();
}
for(const key of['sleeppowder','confuseray'])for(const safeguard of[false,true]){
 const b=setup(set('Butterfree',50,[key]),set('Snorlax',50,['splash']));if(safeguard)b.p2.addSideCondition('safeguard',b.p2.active[0],b.dex.moves.get('safeguard'));b.makeChoices('move 1','move 1');const d=b.p2.active[0];rows.push({case:'status-confusion',key,safeguard,status:d.status,confusion:d.volatiles.confusion?.time,log:logs(b)});b.destroy();
}
{
 const b=setup(set('Venusaur',100,['petaldance']),set('Snorlax',100,['splash']),1);const p=b.p1.active[0];b.p1.addSideCondition('safeguard',p,b.dex.moves.get('safeguard'));const timeline=[];
 for(let i=0;i<3;i++){b.makeChoices('move 1','move 1');timeline.push({confusion:p.volatiles.confusion?.time,locked:p.volatiles.lockedmove?.trueDuration,sides:sides(b)});if(p.volatiles.confusion)break;}
 rows.push({case:'self-fatigue-allowed',timeline,log:logs(b)});b.destroy();
}
for(const safeguard of[false,true]){
 const b=setup(set('Squirtle',50,['splash']),set('Snorlax',50,['splash']));const p=b.p1.active[0],e=b.p2.active[0];if(safeguard)b.p1.addSideCondition('safeguard',p,b.dex.moves.get('safeguard'));
 b.p1.addSideCondition('toxicspikes',e,b.dex.moves.get('toxicspikes'));b.singleEvent('SwitchIn',b.dex.conditions.get('toxicspikes'),b.p1.sideConditions.toxicspikes,p);
 rows.push({case:'ToxicSpikes-entry',safeguard,status:p.status,log:logs(b)});b.destroy();
}
for(let seed=1;seed<30;seed++){
 const b=setup(set('Butterfree',50,['tackle']),set('Pikachu',50,['splash']),seed),p=b.p1.active[0];b.p1.addSideCondition('safeguard',p,b.dex.moves.get('safeguard'));const chance=[],original=b.randomChance.bind(b);b.randomChance=(n,d)=>{const result=original(n,d);if(b.effect?.id==='static')chance.push({n,d,result});return result};b.makeChoices('move 1','move 1');
 if(chance.some(x=>x.result)){rows.push({case:'Static-origin-blocked',seed,status:p.status,chance,log:logs(b)});b.destroy();break;}b.destroy();
}
for(const par of[false,true])for(const wind of[false,true]){
 const b=setup();const p=b.p1.active[0];p.storedStats.spe=7;if(par)p.setStatus('par');if(wind)b.p1.addSideCondition('tailwind',p,b.dex.moves.get('tailwind'));
 rows.push({case:'pure-Speed-order',control:'Deliberate baseSpeed7 boundary',par,wind,speed:p.getActionSpeed()});b.destroy();
}
for(const format of['gen5doublescustomgame','gen8doublescustomgame']){
 const b=setup([set('Pidgeot',100,['tailwind']),set('Snorlax',50,['tackle'])],[set('Sandshrew',40,['tackle']),set('Magikarp',5,['splash'])],4,format);
 b.makeChoices('move 1, move 1 1','move 1 2, move 1');rows.push({case:'queue-start-order',format,scope:'Reference-only doubles contrast to prove Gen5 frozen queue; production remains singles',log:logs(b)});b.destroy();
}
for(const ability of['Own Tempo','Insomnia','Immunity']){
 const move=ability==='Own Tempo'?'confuseray':ability==='Insomnia'?'sleeppowder':'toxic';
 const b=setup(set('Butterfree',50,[move]),set('Slowpoke',50,['splash'],ability));const d=b.p2.active[0];b.p2.addSideCondition('safeguard',d,b.dex.moves.get('safeguard'));b.makeChoices('move 1','move 1');rows.push({case:'ability-with-Safeguard',ability,move,status:d.status,confusion:d.volatiles.confusion?.time,log:logs(b)});b.destroy();
}
{
 const b=setup(set('Squirtle',50,['lightscreen','splash']),set('Snorlax',50,['lightscreen','splash']));const calls=[],next=b.prng.random.bind(b.prng);b.prng.random=function(...args){const value=next(...args);calls.push({args,value,event:b.event?.id,effect:b.effect?.id,where:(new Error().stack).split('\n').slice(2,5).map(x=>x.trim().split(' (')[0])});return value};
 b.makeChoices('move 1','move 1');rows.push({case:'both-side-duration-callback-order',sides:sides(b),calls,log:logs(b)});b.destroy();
}
{
 const b=setup(set('Pidgey',41,['tailwind']),set('Rattata',33,['splash'],'Run Away'));const p=b.p1.active[0],e=b.p2.active[0];p.setStatus('psn');e.setStatus('psn');b.makeChoices('move 1','move 1');rows.push({case:'Tailwind-residual-Speed-order',speeds:[p.getActionSpeed(),e.getActionSpeed()],log:logs(b)});b.destroy();
}
{
 const b=setup(set('Sandshrew',11,['swift']),set('Onix',14,['rage'],'Rock Head'));const p=b.p1.active[0],e=b.p2.active[0];p.boosts.spa=-6;e.boosts.spd=6;e.side.addSideCondition('lightscreen',e,b.dex.moves.get('lightscreen'));b.makeChoices('move 1','move 1');rows.push({case:'real-zero-hit-builds-Rage',control:'Natural move/levels, bounded SpA-6/SpD+6 and preinstalled opponent screen as explicit mechanism fixture',enemyHP:e.hp,enemyMaxHP:e.maxhp,enemyAttackStage:e.boosts.atk,playerHP:p.hp,log:logs(b)});b.destroy();
}
process.stdout.write(JSON.stringify({reference:'9b136a8c8cdb860a8ab96fa063f906604e352547',fixture:'Hardy IV0 EV0, original151 species; custom move sets/explicit controls stated percase. Only wallclock|t:| removed.',rows},null,2)+'\n');

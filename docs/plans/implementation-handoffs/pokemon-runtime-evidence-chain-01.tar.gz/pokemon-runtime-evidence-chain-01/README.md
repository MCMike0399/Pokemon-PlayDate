# Actual SDK evidence-chain followup

Apply after frozen `/private/tmp/pokemon-current-coverage-01` manifest `79a4fc4313db3db1df36c8301ac4ce7f6ca26491c34baef272e22fdbd338522c`. That packet remains unchanged. This followup changes host evidence validation only; no Source, generator, mechanics, art, Simulator or Data access.

Apply the four manifest-listed patches, then add the two new files. Full modified files are review copies; `host-project/` is private test context, never copy it over a checkout. The matrix patch changes only its `runtime-scopes` registry SHA; all1501 indexed rows/statuses and all48 curated main records (plus the separate private Bide record) remain identical. Original owner/assertion/definition hashes and scopes are untouched.

The loader now loads the pinned raw actual SDK result before qualifying any curated record: contained relative path, exact bytes SHA, protocol/success, exact build ID/source suffix and accepted summary source, exactly one successful complete contracts report, exact passed/failed totals, unique canonical actual test names/Boolean success, and named-suite inventory/count/totals. Every embedded executed claim must equal its actual canonical test. Forged embedded success cannot supply absent/failed actual evidence. Wrong or incomplete raw evidence raises SourceError; current owner/assertion changes still report stale rather than missing.

The immutable actual main950 result is newly vendored as `docs/validation/coverage-evidence/main950-result.json`, SHA `338ebb0072b427ecaf36346192c97bed862688fb6db97fac4711cd07640fe669`, copied byte-for-byte from `/private/tmp/pokemon-root-sides-sdk-01/00001-result.json`. Its build is `1c40818cce099f8c4463ba5073b95cc1fafb4502:49832dd1c89953784f13c65a54f21a63771ae7b9b73ef16b405a8118932c8386`,950passed/0failed. Private1059 reuses the frozen packet's existing actual result, SHA `f91e54116879025173d91904495f0e1f00b2b4a428a3ebdae78359b773220b0e`; its distinct build/source and private acceptance context remain explicit.

Both original actual reports contain20 core assertions outside named suites: main950 has67 suites totaling930, private1059 has75 totaling1039. The loader verifies the full950/1059 actual test inventory and separately pins those observed suite inventories; it does not fabricate suite membership. Raw replies have quiescent=false because contracts finish before the separate harness terminal barrier. This loader does not claim to replace that journey/quiescence qualification or prove native/device behavior.

Validation:61 focused portable host tests PASS,0skip (the prior47 plus14 actual-evidence cases). Tests include real raw-result mutation/repinning, fake embedded success, nonexistent canonical name, actual failed case, wrong source/build, changed raw SHA, missing/duplicate report, incomplete tests/suites, duplicate names, returned error and traversal/symlink escape. Existing current owner/metadata/assertion stale tests and unrelated-edit preservation still pass. No SDK/native execution was performed by this worker.

After applying, run:

```
PYTHONDONTWRITEBYTECODE=1 /path/to/pillow-venv/bin/python -m unittest tools.tests.test_runtime_sdk_evidence tools.tests.test_runtime_move_coverage tools.tests.test_move_verifier tools.tests.test_coverage_matrix -v
```

Use the existing immutable B2W2 CSV cache required by the original verifier; no missing-input skips. Worker used `/private/tmp/pokemon-validation-venv/bin/python` and the frozen packet's private host context.

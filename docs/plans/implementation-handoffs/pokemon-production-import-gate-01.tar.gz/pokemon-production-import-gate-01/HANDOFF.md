# Private production import-execution gate01

NOT integrated into B+Title/current campaign batch. Original resource probe01/evidence unchanged. Only candidate Source/main.lua differs from immutable7f2f4eda baseline; every other module/asset is identical. Exact full-main SHA guards in shared-hunks.json/patches. Root must narrow-rebase after campaign freeze; old main must never overwrite future Title changes.

The existing dev/harness_build import runs first. Only dev imports, Contracts registrations and the catalog exporter registration are wrapped at their existing positions. Six interleaved genuine late imports stay unconditional/in order: townMapState, fieldItems, fieldBattle, homeRest, itemPCState, fieldEncounters. Production installs only existing Harness fields beforeFrame/afterFrame/isQuiescent, using a local no-op. Debug/system menu, physical input, saves and game loop tail are byte-identical. Enabled import/registration order is exact except earlier build configuration. No global manager, cache/art/feature rewrite or device optimization.

Observer Lua, workload Lua and both scalar-query fragments are byte-identical to measured resource01. Main-hook revision unconditional-input-baseline-v1 captures real input functions before any conditional dev import. This SAME hook runs in fresh baseline and candidate builds; old measurements are historical context, not a same-hook before/after pair. build.json comparison_instrumentation pins all observer/workload/query hashes and hookrevision; variant source hashes are in manifest.json. Baseline/candidate PDZ bytes and prototype/native residency are distinct from skipped execution; no savings claim before native measurements.

## Compile and root-only measurement

```
python3 -m unittest discover -s /private/tmp/pokemon-production-import-gate-01/tests -v
```
Matching controlled pair:
```
python3 /private/tmp/pokemon-production-import-gate-01/probe.py --variant baseline --output /private/tmp/UNIQUE-before --mode production --observer milestones --workload controlled --frames 1800 --timeout 120
python3 /private/tmp/pokemon-production-import-gate-01/probe.py --variant candidate --output /private/tmp/UNIQUE-after --mode production --observer milestones --workload controlled --frames 1800 --timeout 120
```
Default COMPILE ONLY. Root appends --execute and runs SERIAL under original global owner lock. Repeat fresh matching pairs for production idle600, production controlled imports1800 and harness controlled milestones1800. The observer/workload/schema/SDK/packet must match; compare tool rejects stale/failed/reused/different-instrumentation evidence:
```
python3 /private/tmp/pokemon-production-import-gate-01/tools/compare_gate.py /private/tmp/ROOT-before /private/tmp/ROOT-after > /private/tmp/ROOT-gate-comparison.json
```
26 host guards currently cover actual enabled/disabled import inventories, exact real-game tail/assets, nonvacuous input guard, deliberate dev-global leaks, strict restart identities/state/save bytes and comparison failure modes. Source compiles are not runtime acceptance.

Historical root resource01: production idle222msstartup/11028.19KiBpostGC; controlled217ms/11430.45KiBfinal, mean0.712ms/max39ms work, mapentry38ms max, battle13/14ms; global182entries/145renderedimages plateau, LRU2/oneview, cycle2→3+43.5KiB. Detailed imports269msstartup/11452.97KiBfinal; Hcontrolled250ms/11515.70KiB/mean6.84ms/max67. The30FPS budget is33.333ms; a39ms work spike exceeds that single-frame budget despite low mean. These are sampled/instrumented Simulator Lua metrics, NOT actual device/native allocation or guaranteed FPS. No cache-policy fix is included.

## Full enabled qualification (root only)

Use uninstrumented candidate project so the normal generated config enables the full development path:
```
python3 /private/tmp/pokemon-production-import-gate-01/candidate/tools/harness/suite.py --only contracts-catalog qualification --output /private/tmp/ROOT-gate-enabled --job-timeout 240
```
Root verifies exact same75 suite registration IDs and all actual SDK tests, catalog859pair qualifier/1718PNGs, primary source and protected catalog comparisons; counts alone do not accept. Run actual three intros, fieldmenus/PCrestart/motionSaveContinue and representative Brock route against this private candidate before considering later narrow rebase. Normal runtime uses existing build/session/owner protocol. No test disabled or assertion relaxed.

## Production actual physical-input/true restart recipe

The existing probe owner has one bounded extension: --processes 2 is permitted ONLY production/manual mode. It holds the same global/Data owner across two real PIDs and the exact same UUID Data directory. After each done barrier it confirms owned exit, archives evidence, deletes ONLY five prior probe publication files, and launches the same identified bundle. Adventure save files remain in place; no save copy/restore occurs. Second boot must start at actual Title, final settled world/state must match prior final state, save byte SHAs must remain identical and PIDs must differ. Any failure fails the whole run. No gameplay input is synthesized.

```
python3 /private/tmp/pokemon-production-import-gate-01/probe.py --variant candidate --output /private/tmp/ROOT-production-physical --mode production --observer milestones --workload manual --frames 1800 --timeout 120 --processes 2 --execute
```
Root physically uses Simulator controls (repeat same steps on a fresh baseline variant):

1. First boot: dismiss Oak; physically open Debug via system menu and choose existing Skip Intro for this bounded smoke ONLY. This is actual production Debug/input/save verification, not natural campaign acceptance. Enter Party/Bag, return; walk a known path in bedroom, face the real PC, use RED'S PC to withdraw initialPotion1 (optional if time permits, then same baseline steps). Return to bedroom coordinate/facing selected for this comparison. Use B→actual SAVE option→YES, capture readable saved dialog using native Simulator screenshot command, dismiss and leave settled world. Capture native world; stop all inputs before1800-frame producer barrier.
2. Runner owns first PID termination and second PID launch with untouched same Data. Root captures actual Title/Continue selection using native Simulator screenshot command, selects Continue with real A, then supplies no more inputs. Stay in bedroom (no wandering actors) so both RNG streams and player pose remain exact. Final probe image is native world, inspect400×240 actual PNG and state. No fabricated images or title image relabeled world.
3. Inspect production-restarts.json and per-process receipts, original adventure slot SHA equality, exact player/zone/party/inventory/money/PCPotion/rules+world streams. Missing Save, no Title, failed Continue, changedsavebytes, reusedPID or moved post-Continue state fails strict validation. Verify no synthetic wrappers/mailbox publications. Record operator timestamps/actions and external native screenshots; recipe is UNRUN until root executes.

Production/manual pair runs take about2×60s plus startup; deadline120s is per process. No copied saves or gameplay fixture in manual mode. Root's actual inputs are required; a successful API-controlled workload is not a substitute.

# Frozen world presentation repair

Manifest SHA256:3d8d5ece5555c0042c554662b1b1f5c3436ac184e304509ae18fa7701840675d.
Compile-only PASS `/private/tmp/pokemon-world-presentation-build-02`. Native pending; five added SDK groups, expected589 total against root's584. No live Source/Simulator/Data changes by worker.

Root-only execution:

```
/private/tmp/pokemon-validation-venv/bin/python /private/tmp/pokemon-world-presentation/validate_staged.py --project /Users/burbujamc/Developer/Pokemon-PlayDate --output /private/tmp/pokemon-world-presentation-native-01 --execute
```

The validator uses current normal runner/catalog qualification and identifies immutable staged source. It overlays only the two base-pinned existing files plus new dev/presentationContracts.lua, appending test registration only in the staged build. Existing main584 catalog/ability imports are preserved exactly. Production integration is the two narrow patches under patches/ plus test registration at root's chosen dev import seam; never overwrite old full main snapshots. Existing WorldView, Player, actor, event and battle files are untouched.

OverworldState now owns a visit record tied to actual WorldView, zone, player, session and root base stack. Successful entry binds it; resume requests presentation; root pop signals cover nested overlay resumes such as Party→Pause. Exit invalidates before restoring suspended callback flags. Disposed/replaced views, changed sessions, absent base owner and exited visits cannot flush.

Main adds exactly one call after handleInput and before draw. The flush does nothing unless that live visit has a pending entry/resume request. For this one pass it applies camera, records actual native update-enable flags, disables enabled callbacks, marks full display dirty, calls SDK combined sprite redraw and restores every flag. No Player/NPC/timer/RNG update occurs. On native draw error, original flags and prior draw offset are restored, error propagates and the request remains reviewable/retryable. No unconditional per-frame enumeration/freeze is introduced. Draw remains unchanged. All existing sprite update calls stay at their exact positions; a successful ordinary pass merely marks that visit already presented, preventing a duplicate pass.

Five SDK groups:

- Actual TitleState drawing is replaced by exact full native world framebuffer at a real Codec-restored NPC midstep3, with identical actor DTO, native image pointer/position, both RNG streams and Player state. Exhaustive400×240 samples compare native output to map+actor composition oracle; this checks composition/cadence, not a new independent art-source claim.
- Real PauseState plus nested cover/pop: uncovered world repaints before overlay/root draw, and final pop restores world immediately without advancing actors. Five flat PNGs retain Title-before, entry-midstep, overlay-before, nested-resume and overlay-resume evidence.
- Native sprite callback pass gives exactly eight Player updates; seven additional draws/flush checks each frame are inert and add no second native pass. This isolated case intentionally avoids unrelated main-view tile animation/frame timers.
- Controlled native draw callback error proves callbacks never run, mixed enabled flags and draw offset restore, model/streams remain exact and a removed fault allows one successful retry.
- Disposed view/session replacement/exit reject stale work; exiting from a paused visit restores original Player flag and preserves an originally disabled NPC.

Contracts use real SDK sprites, tilemap, private TileRegistry-backed WorldView, Player/NPC, domain Codec and production visit-binding/flush methods. They do not replace the main global active WorldView or mock SDK globals. Original native sprite membership/flags, SpriteFactory keys, Root RNG owner/stream, Story/currentZone/draw offset/framebuffer are restored after each case; exact count and global tile-ID assertions remain. The full true Title→Continue disk/process recipe is still root-owned integration acceptance.

Important host followup: the previous frozen composed packet correctly labels PNG02 as prior Title for the pre-fix source. With this repair, PNG02 should instead be an actual installed-world image at savedtick3. Do not carry the old unconditional Title note into final acceptance of the fixed build; root should change that note/assertion to require exact source foreground equality for PNG02. PNG03 post-update/tick4 source-pose proof remains valid. The original successful semantic proof and old Title image remain historical evidence.

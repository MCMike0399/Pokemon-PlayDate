import csv,hashlib,json,re,unittest
from pathlib import Path
S=Path(__file__).resolve().parents[1];M=2147483647

def draws(seed,spans):
 values=[];states=[]
 for lo,hi in spans:
  span=hi-lo+1;limit=((M-1)//span)*span
  while True:
   seed=seed*16807%M
   if seed-1<limit:break
  states.append(seed);values.append(lo+(seed-1)%span)
 return values,states

def damage(lv,power,attack,defense,var,stab=False,resist=False):
 n=((2*lv//5+2)*power*attack//defense)//50+2;n=n*var//100
 if stab:n=n*3//2
 if resist:n=n//2
 return n
class ProtectReference(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.report=json.loads((S/'showdown-protect-observations.json').read_text());cls.rows=cls.report['rows']
 def test_actual_reference_replays_byte_exact(self):self.assertEqual((S/'showdown-protect-observations.json').read_bytes(),(S/'showdown-protect-observations-replay.json').read_bytes())
 def test_actual_gen5_counter_events_and_last_actor(self):
  r=next(r for r in self.rows if r['case']=='actual-Protect-forced-success-event-denominators');self.assertEqual(r['chances'],[[1,x]for x in [2,4,8,16,32,64,128,4294967296,4294967296]])
  self.assertEqual([x[0]['stall']['counter']for x in r['timeline']],[2,4,8,16,32,64,128,256,256,256])
  r=next(r for r in self.rows if r['case']=='last-queued-Protect-fails');self.assertEqual(r['chances'],[]);self.assertIsNone(r['state'][1]['stall'])
 def test_actual_feint_break_phase_preserves_stall_and_miss_immunity_do_not_break(self):
  rows=[r for r in self.rows if r['case']=='Feint-order']
  r=next(x for x in rows if x['target']=='Squirtle'and not x['missFixture']);hit=next(x for x in r['calls']if x['move']=='feint');self.assertEqual(hit,dict(move='feint',before=True,after=False,stall=2))
  for r in rows:
   if r['target']=='Gastly'or r['missFixture']:self.assertFalse(any(x['move']=='feint'for x in r['calls']))
 def test_retained_actual_PS_Bide_bypass_is_an_explicit_disagreement(self):
  r=next(r for r in self.rows if r['case']=='Bide-release-vs-Protect');self.assertEqual(r['first'][1]['hp'],220);self.assertEqual(r['release'][1]['hp'],200)
  self.assertTrue(any('Protect' in line for line in r['log']));self.assertFalse(any('|-activate|'in line and 'move: Protect'in line for line in r['log']))
 def test_independent_flag_mapping_confirms_Bide_protect_bit(self):
  flags={r['id']:r['identifier']for r in csv.DictReader((S/'references/move_flags.csv').read_text().splitlines())};self.assertEqual(flags['4'],'protect')
  bide=[flags[r['move_flag_id']]for r in csv.DictReader((S/'references/move_flag_map.csv').read_text().splitlines())if r['move_id']=='117'];self.assertEqual(set(bide),{'contact','protect'})
 def test_all425_effective_gen5_flags_match_generated_boolean_metadata(self):
  rows=json.loads((S/'projected-gen5-protect-metadata.json').read_text())['rows'];self.assertEqual(len(rows),425);self.assertEqual(sum(x['protectable']for x in rows),332)
  source=(S/'Source/battle/moves.lua').read_text();data={m.group(1):m.group(2)for m in re.finditer(r'^    ([A-Za-z0-9_]+) = Move\{(.*)\},?$',source,re.M)}
  for r in rows:
   for flag in ['protectable','breaksProtect']:
    value=re.search(r'\b'+flag+r' = (true|false)',data[r['key']]);self.assertIsNotNone(value,r['key']);self.assertEqual(value.group(1)=='true',r[flag],(r['key'],flag))
 def test_real_rare_success_and_full_public_before_AI_vectors(self):
  self.assertEqual(draws(1917364174,[(0,65535),(0,65535)]),([65535,65535],[65536,1101463552]))
  self.assertEqual(draws(2129965031,[(1,1),(0,65535),(0,65535)]),([1,65535,65535],[1917364174,65536,1101463552]))
  for counter in [2,4,8,16,32,64,128]:self.assertEqual(draws(1475608308,[(1,1),(1,counter)])[0],[1,1])
 def test_probability_mapping_is_correlated_not_native_uniform32(self):
  # The probability claim is NOMINAL 1/2^32 for two ideal independent16bit
  # values. Our real PM stream is deterministic and doesn't have2^32 states.
  candidates=[]
  for first in range(65536,2147418113,65536):
   second=first*16807%M
   while second-1>=2147418112:second=second*16807%M
   if (second-1)%65536==65535:candidates.append(first)
  self.assertEqual(candidates,[65536]) # Explicit correlation evidence; NOT1/2^32 over all PM states.
 def test_native_literal_vectors(self):
  # Protect fails at second roll, then Tackle consumes accuracy/crit/variance.
  v,_=draws(2,[(1,1),(1,2),(1,100),(1,16),(85,100)]);self.assertEqual(v,[1,2,99,4,89]);self.assertEqual(damage(5,50,10,33,v[-1],stab=True),3)
  self.assertEqual(damage(34,30,42,33,88),11);self.assertEqual(damage(34,30,42,33,86),11)
  self.assertEqual(damage(22,40,27,33,88,stab=True,resist=True),5);self.assertEqual(damage(22,40,27,33,97,stab=True,resist=True),5)
if __name__=='__main__':unittest.main()

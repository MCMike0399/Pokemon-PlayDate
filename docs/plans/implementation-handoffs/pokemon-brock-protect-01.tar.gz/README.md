Protect / Feint candidate — explicit reference resolution
=======================================================

Staged only, no live Source, art, maps, Simulator process or runtime Data changes. Rain01 and the failed61980 SDK source remain preserved. Root's actual SDK fixture-repair followup is a different packet; this candidate does not smuggle those test edits or new weather behavior into its engine diff.

Scope is naturally reachable GenV Protect (Squirtle22 /Wartortle24 /Blastoise24) and Pikachu Feint34. Delayed evolution makes these grind-tail moves actual requirements before Brock; no campaign level cap is imposed. Detect and Endure remain explicitly pending library producers; neither empty payload is claimed supported and no blanket guard-family acceptance is implied. Wide/Quick Guard, doubles, bypass abilities, Z/Max moves, Substitute, Future Sight and other unimplemented producers are separate full-goal dependencies. No new encounters/items/rewards/abilities were invented.

Declared baseline and integration
---------------------------------

Base snapshots are root's read-only `/private/tmp/pokemon-brock-integration-02`: actual Rain+charge+combined Rivalry/MudSport power+Light Ball+OwnTempo+Worry/Insomnia v8, compile06. Battle/Conditions/DSL hunks are narrow. There is NO Effects replacement, no new ability lookup, no change to effectiveAbility ownership and no interference with IV/nature/sex/held/save schemas. Root's epoch9 generated data SHA256 is `4541d3de12315d8c1c8aadb084c7f342b878c3d3609bb5052cab0a586a3db2d3`; root owns all producer changes. Exactly Protect's payload changes; every425 scalar/secondary and earlier rule is retained, with two sourced booleans on all425 rows. Immutable old metadata/oracle artifacts are not rewritten.

`project_metadata.js` actually queries pinned compiled PS Dex.mod('gen5') for all425 move identities/targets, flags.protect and breaksProtect. It produces332 protectable rows; only Feint breaks protection. No category/power/target heuristic substitutes for flags. Original projection SHA is `f34ec52d6a209a9228d6abb701a40e0e47dc12f8c6b9c8e49db8e0aeab108f45`; root independently replayed it and normalized the immutable artifact to SHA `66c23d6bd5e78ecfae62a656e0c0612c793dc902be41d48fc351cf1bd900d462`. `generator-request.json` records the exact epoch9 request, preserving v8 Worry metadata.

Battle-local implementation
----------------------------

Conditions owns identity-keyed current-turn protection and `{counter,remaining}` stall state. `ProtectEffect()` delegates to this owner after normal status/PP gates. Pending selected opposing action eligibility comes from the existing battle round receipt; the last queued actor and enemy-only medicine/switch responses fail Protect before its chance sample. Initial success is guaranteed; consecutive successes double the counter2→4→8→16→32→64→128→256, with normal PP spent on each actual attempt, including failure. The two-turn stall lifetime expires after a failed/other/blocked turn, rather than accumulating forever. Ordinary public validation remains unchanged.

Incoming protection is checked after GenV type immunity and before move-specific gates, accuracy, hit count, HP changes, stages, self drops, statuses, secondaries and contact receipts. Blocked damage does not become a zero-damage successful hit; no Rage/Assurance/contact/Bide receipt is created. Residual poison/burn/seed/weather and explicitly unprotectable Ghost Curse bypass this incoming-move guard. Rain's always-hit policy cannot bypass Protect. First-turn charge preparation still occurs; its actual release can be blocked. Early rampage block ends quietly; final block causes the already shared real fatigue effect/OwnTempo query. Normal finishRound clears one-turn protection and ticks stall once after residuals; switch/faint/forced exit clear the existing volatile owner. No durable fake move/slot/state is created, and draw/persistence never advances a guard.

Feint retains GenV power30, priority+2, Normal typing, target10,100accuracy and **non-contact** metadata. It can damage unprotected targets (unlike the older conditional-only behavior). It bypasses the guard, then removes actual protection **after successful accuracy and before HP hit**. Miss/Normal-Ghost immunity/status prevention cannot break it. GenV's stall counter survives the break; modern generation6 counter clearing is intentionally not copied. The ordinary damage/contact/secondary receipt path remains authoritative.

`getConditionsSnapshot()` adds `protect`, `stall_counter`, `stall_remaining` per side. Existing root diagnostics already expose that snapshot; root needs only the private contract import/registry, not a new state owner or fixture field.

Rare counter: real vector, explicit RNG limitation
-------------------------------------------------

Pinned Gen5 stall uses1/2,1/4,…1/128, then counter>=256 calls randomChance(1,2^32). The candidate does NOT lower the cap or always fail. Its static `BattleConditions.protectSucceeds(counter)` uses one uniform integer sample through128; at256 it draws BOTH16bit values on a detached RulesRNG Stream and commits only after both succeed. Both65535 selects the nominal single pair among2^32 ideal pairs. Seed1917364174 gives real states65536→1101463552 and actual values65535/65535. Canonical decimal wire restore and continuation are tested; roll-counter exhaustion on the second sample cannot partially commit the first.

This is a **deterministic Park–Miller adaptation**, not two statistically independent samples, not native GameFreak32bit entropy, and not exact cartridge seed/probability equivalence. The period has only2147483646 states. The host audit explicitly enumerates admissible first maxima: only state65536 yields the next maximum, proving the correlation rather than hiding it. Thus1/2^32 describes the intended two16bit acceptance mapping, not an exact frequency over all PM starting states. Root explicitly approved this bounded adaptation without changing the RNG algorithm; retain this limitation in the fidelity ledger.

A real public battle SDK case also reaches the cap through eight actual Protect actions (no counter injection), reseeding controlled test rounds to1475608308 for their known successful second draw. The ninth public attempt uses seed2129965031: enemy AI choice reaches1917364174, then the rare pair succeeds; PP1 remains, HP unchanged, counter stays256 and exactly3 rules draws finish at1101463552. These reseeds are fixture controls, not a claim about ordinary campaign odds.

Primary sources and the Bide exception
--------------------------------------

Pinned maintained reference: PS `9b136a8c8cdb860a8ab96fa063f906604e352547`, immutable archive SHA `4c02da77a874f07cfa4de163b3ac7a2553b4f390e7f717aa08afa487b20a7967`. [Protect](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/moves.ts#L13958), [Gen5 stall override](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/mods/gen5/conditions.ts#L24), [Feint](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/moves.ts#L5176), [Gen5 Feint flags](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/mods/gen5/moves.ts#L227), [ordinary hit-step ordering](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/sim/battle-actions.ts#L612) and [post-accuracy break](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/sim/battle-actions.ts#L818). Gen5 swaps type immunity before TryHit, then accuracy follows; Protect has priority3 within TryHit.

C reconstruction: `fuddlesworth/pokebw2` commit `b279bbefa99bb2f6fbabcc95e4b6d3e939290353`. `bw_move_handlers.c`4346–4444 handles Protect/stall,4780–4835 Feint,4446–4600 Bide. `bw_btl_server_flow.c`2030–2110 shows first two Bide stores returning early via event result2 while release continues ordinary execution;2097–2103 removes type immunity, then protection/no-effect targets before accuracy;2296–2321 checks native moveflag3 +Protect turnflag7 and removes the target unless event0x2e allows a break. Feint registers0x2e; Bide does not. Feint's misleadingly named ResetProtectCounter body removes side effects9/10, not the personal stall counter.

**Actual PS differs for Bide release.** Its Bide body constructs a partial move with explicit protect/contact flags, but calls actions.tryMoveHit directly. That helper is documented for side/field moves and uses TryHitSide→moveHit, bypassing ordinary target TryHit. The retained actual compiled PS report shows two NightShade5 hits followed by20 release damage through active Protect (target220→200). This is NOT reported as equivalent or a passing oracle for this interaction. The controlled opponent's current level is set5 solely for NightShade amount; normalized stats stay level50, explicitly disclosed in the fixture record.

Root approved a source-resolved **intentional exception**: use native-C normal dispatch plus the independently declared protection flag to block Bide release. Pinned PokeAPI `2bf639e5572812a67d2b94903fdcb9d095f5aeb2` raw move_flag_map.csv independently lists move117 contact1/protect4 (native flag indexes are zero-based, with flag3 used by the protection dispatcher). PS's own effective flags also declare protect1. No retail NARC flag table was fetched and the C reconstruction was not executed; this is not cartridge/emulator equivalence. Preserve the actual PS bypass report, source chain, explicit approved resolution and literal expected-block SDK/native cases in the ledger. Frozen prior Bide01 bytes are unchanged.

Independent actual reference probe
----------------------------------

`node /private/tmp/pokemon-brock-protect-01/probe_showdown.js` runs the actual built pinned PS Gen5 Battle under the charge packet's reference directory. Fixtures use Hardy/IV0/EV0/level50 and controlled custom moves/abilities; they do not prove acquisition. Explicitly labeled randomChance overrides force success/failure to expose actual denominator events, counter/reset/last-actor behavior; ordinary Feint/miss/immunity/rampage cases use real seeded randomness. A read-only wrapper records actual break-hook before/after states. Only wall-clock `|t:|` lines are filtered. Replay is byte-identical. Package-lock/archive/file hashes and the retained C/raw-data files are in `primary-pins.json`; exclude node_modules/npm-cache from archives and rebuild from the pinned archive as in charge01 if needed.

Qualification and root commands
-------------------------------

34 actual-SDK groups authored. Nine independent host/reference/vector checks PASS. Private control+five fault variants compile; SDK/native execution remains **UNRUN** by this worker. Compiler success is not runtime acceptance.

```sh
python3 -m unittest discover -s /private/tmp/pokemon-brock-protect-01/tests -v
python3 /private/tmp/pokemon-brock-protect-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-brock-protect-sdk-01 --execute
python3 /private/tmp/pokemon-brock-protect-01/mutations.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-brock-protect-mutants-sdk-01 --execute
```

Root alone uses `--execute`; default compiles privately. The validator applies exact hash-pinned narrow patches to CURRENT Source and refuses conflicts, requires actual Worry/rawPower dependencies, privately registers the new suite, and refreshes all build/source identity bytes after fault injection. The mutant runner requires one numbered contract report, green control and exact named failed assertions; compile failure/crash alone never qualifies. Faults move protection after accuracy, reset the streak, clear GenV stall on Feint, always fail the rare cap, and omit the source-resolved Bide guard.

Three native recipes are prepared, **UNRUN**. Protect-chain uses naturally initialized Squirtle22 slot4 vs Rattata5 Tackle (other actual PP disabled): success/failed second attempt/reset success, HP51→48 on failure, PP9→8→7, exact rules1/5/1 with explicit reseeds. Feint uses naturally initialized Pikachu34 slot4 vs Squirtle22's real Protect: target51→40→29, PP9→8, preserved stall2→4, rules4/5. Bide-vs-Protect first teaches original TM34 through actual Bag→Party→full-four Learning replacement (forgets Protect), consumes exactly one physical TM and preserves inherited10PP, then uses actual two WaterGun5 hits from enemy Squirtle22. Only after the second real hit does a declared PP fixture enable the opponent's naturally known Protect; it never forges HP/XP/victory. Release20 is blocked per the approved native-C policy: target51 unchanged, player41, BidePP9, rules9. Captures record native guard/break/impact states; no generic new shield art replaces protected sprites or composition.

Root must execute/review those frames and real campaign regressions. This packet does not establish natural multistarter/evolution/capture/Brock acceptance or complete all111 abilities/full moves.

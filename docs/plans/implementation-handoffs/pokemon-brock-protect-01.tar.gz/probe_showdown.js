const path=require('path');const root='/private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547';const {Battle}=require(path.join(root,'dist/sim'));
const ivs={hp:0,atk:0,def:0,spa:0,spd:0,spe:0};
function setup(a='Squirtle',d='Snorlax',moves=['protect','splash'],other=['tackle','splash'],seed=4){
 const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,seed],p1:{name:'USER',team:[{species:a,ability:'Torrent',nature:'Hardy',ivs,evs:{},level:50,moves}]},p2:{name:'FOE',team:[{species:d,ability:'Immunity',nature:'Hardy',ivs,evs:{},level:50,moves:other}]}});if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');return b;
}
const log=b=>b.log.filter(x=>!x.startsWith('|t:|'));
const state=b=>[b.p1.active[0],b.p2.active[0]].map(p=>({species:p.species.id,hp:p.hp,status:p.status,pp:p.moveSlots.map(x=>[x.id,x.pp]),protect:!!p.volatiles.protect,stall:p.volatiles.stall?{counter:p.volatiles.stall.counter,duration:p.volatiles.stall.duration}:null,locked:p.volatiles.lockedmove?{duration:p.volatiles.lockedmove.duration,trueDuration:p.volatiles.lockedmove.trueDuration}:null,confusion:p.volatiles.confusion?.time}));
const rows=[];
{
 const b=setup(),chances=[],timeline=[];b.randomChance=(n,d)=>{chances.push([n,d]);return true};
 for(let i=0;i<10;i++){b.makeChoices('move 1','move 2');timeline.push(state(b));}
 rows.push({case:'actual-Protect-forced-success-event-denominators',control:'Only randomChance forced true, enemySplash; real turns/volatile/event/PP code executes',chances,timeline,log:log(b)});b.destroy();
}
{
 const b=setup(),chances=[],timeline=[];b.randomChance=(n,d)=>{chances.push([n,d]);return false};
 for(let i=0;i<4;i++){b.makeChoices('move 1','move 2');timeline.push(state(b));}
 rows.push({case:'actual-Protect-forced-stall-fail-reset',control:'Only randomChance forced false, enemySplash',chances,timeline,log:log(b)});b.destroy();
}
{
 const b=setup('Squirtle','Snorlax',['protect'],['protect']),chances=[];b.randomChance=(n,d)=>{chances.push([n,d]);return true};b.makeChoices('move 1','move 1');rows.push({case:'last-queued-Protect-fails',chances,state:state(b),log:log(b)});b.destroy();
}
for(const target of['Squirtle','Gastly'])for(const miss of[false,true]){
 const b=setup('Pikachu',target,['feint','splash'],['protect','splash']);const p=b.p1.active[0],d=b.p2.active[0];if(miss){p.boosts.accuracy=-6;d.boosts.evasion=6;}
 const calls=[],original=b.actions.hitStepBreakProtect;b.actions.hitStepBreakProtect=function(targets,pokemon,move){const before=!!d.volatiles.protect;const result=original.call(this,targets,pokemon,move);calls.push({move:move.id,before,after:!!d.volatiles.protect,stall:d.volatiles.stall?.counter});return result;};
 b.makeChoices('move 1','move 1');rows.push({case:'Feint-order',target,missFixture:miss,calls,state:state(b),log:log(b)});b.destroy();
}
for(const seed of[1,2]){
 const b=setup('Venusaur','Snorlax',['petaldance','splash'],['splash','protect'],seed);b.makeChoices('move 1','move 1');const first=state(b);b.makeChoices('move 1','move 2');rows.push({case:'Petal-vs-Protect',seed,first,second:state(b),log:log(b)});b.destroy();
}
{
 const b=setup('Squirtle','Snorlax',['bide'],['nightshade','protect']);b.p2.active[0].level=5;
 b.makeChoices('move 1','move 1');b.makeChoices('move 1','move 1');const first=state(b);b.makeChoices('move 1','move 2');rows.push({case:'Bide-release-vs-Protect',fixture:'Opponent.level is set5 solely for NightShade5+5; normalized stats remain level50. Controlled formula fixture, not specimen/acquisition proof',first,release:state(b),log:log(b)});b.destroy();
}
for(const move of['solarbeam','skullbash']){
 const b=setup('Squirtle','Snorlax',[move],['protect']);b.randomChance=(n,d)=>true;
 b.makeChoices('move 1','move 1');const first=state(b);b.makeChoices('move 1','move 1');rows.push({case:'charge-vs-Protect',move,control:'Stall chance forced true for target on second turn; real charge/hit dispatch',first,release:state(b),log:log(b)});b.destroy();
}
process.stdout.write(JSON.stringify({reference:'9b136a8c8cdb860a8ab96fa063f906604e352547',format:'gen5customgame',fixture:'Hardy IV0 EV0 level50, source ability values deliberately controlled custom sets. Conditional randomChance overrides explicitly labeled. Mechanical logs retained; wallclock|t:| omitted.',rows},null,2)+'\n');

const fs=require('fs'),path=require('path');
const reference='/private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547';
const {Dex}=require(path.join(reference,'dist/sim/dex'));const dex=Dex.mod('gen5');
const source='/private/tmp/pokemon-root-producer-v7/Source/battle/moves.lua';
const keys=[...fs.readFileSync(source,'utf8').matchAll(/^    ([A-Za-z0-9_]+) = Move\{/gm)].map(x=>x[1]);
const rows=keys.map(key=>{const move=dex.moves.get(key);if(!move.exists||move.gen>5)throw Error(key);return {key,id:move.id,num:move.num,target:move.target,protectable:!!move.flags.protect,breaksProtect:!!move.breaksProtect};});
process.stdout.write(JSON.stringify({reference:'9b136a8c8cdb860a8ab96fa063f906604e352547',generation:5,source,rows},null,2)+'\n');

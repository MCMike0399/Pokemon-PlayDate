import unittest,json
from pathlib import Path
S=Path(__file__).resolve().parents[1]
def sample(seed,spans):
 values=[];states=[]
 for low,high in spans:
  seed=seed*16807%2147483647;states.append(seed);values.append(low+(seed-1)%(high-low+1))
 return values,states
class Fixtures(unittest.TestCase):
 def test_real_status_gate_ranges(self):
  self.assertEqual(sample(3,[(1,4)])[0],[1]);self.assertEqual(sample(1,[(1,5)])[0],[2])
  self.assertEqual(sample(1,[(1,100)])[0],[7]);self.assertEqual(sample(1,[(1,4)])[0],[3]) # Old fixture incorrectly called this blocked.
  self.assertEqual(sample(3,[(1,100)])[0],[21]);self.assertEqual(sample(3,[(1,5)])[0],[1]) # Old frozen fixture actually THAWS.
 def test_literal_speed_tie_draw_states(self):
  values,states=sample(2,[(1,1),(1,2),(1,1),(1,2)]);self.assertEqual(states,[33614,564950498,1097816499,1969887316]);self.assertEqual(values,[1,2,1,2])
  self.assertEqual(sample(2,[(1,1),(1,1)])[1],states[:2])
 def test_thunder_status_gate_and_hurricane_duration_gate(self):
  v,st=sample(2,[(1,1),(1,16),(85,100),(1,100),(1,4)])
  self.assertEqual(v,[1,2,87,16,1]);self.assertEqual(st[-1],140734213)
  v,st=sample(2,[(1,1),(1,16),(85,100),(1,100),(1,4),(1,2)])
  self.assertEqual(v,[1,2,87,16,1,2]);self.assertEqual(st[-1],940422544)
 def test_no_runtime_rule_or_data_file_changes(self):
  m=json.loads((S/'manifest.json').read_text());self.assertEqual(m['engine_changes'],[])
  self.assertEqual({r['path']for r in m['source_files']},{'Source/dev/'+x+'.lua'for x in ['brockMoveBatchContracts','bideContracts','chargeLockContracts','rainContracts']})
 def test_no_test_groups_removed(self):
  counts={}
  for f in (S/'Source/dev').glob('*.lua'):
   before=(S/'base/Source/dev'/f.name).read_text().count('test("');after=f.read_text().count('test("');self.assertGreaterEqual(after,before);counts[f.name]=after-before
  self.assertEqual(counts,{'brockMoveBatchContracts.lua':0,'bideContracts.lua':0,'chargeLockContracts.lua':1,'rainContracts.lua':0})
if __name__=='__main__':unittest.main()

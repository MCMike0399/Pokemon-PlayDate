#!/usr/bin/env python3
"""Independent Pillow/source-byte oracle and conservative source geometry audit.

Does not import the generator. Actor-free reachability is an over-approximation,
not input-driven playability. Exact source art/masks and hostile mutations fail.
"""
from __future__ import annotations
import argparse,hashlib,json,re
from collections import deque
from pathlib import Path
from PIL import Image,ImageChops
ROOT=Path(__file__).resolve().parents[1]
SHADES={255:'.',170:'1',85:'2',0:'#'}
LIGHT=(0xbb,0xff,0xee,0xff,0xbb,0xff,0xee,0xff)
DARK=(0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa)
MAPS=('CeruleanCity',)
def check(condition,message):
 if not condition:raise ValueError(message)
def raster(grid):
 im=Image.new('RGBA',(32,32))
 for y in range(32):
  for x in range(32):
   shade=grid[y//2][x//2]
   v=255 if shade=='.' else 0 if shade=='#' else 255 if (LIGHT if shade=='1' else DARK)[y%8]&(128>>(x%8)) else 0
   im.putpixel((x,y),(v,v,v,255))
 return im

def opacity(grid):
 # Independent outside-component union: repeated region expansion rather than
 # generator queue implementation, enclosing white cells remain opaque.
 outside={(x,y) for y in range(16) for x in range(16) if (x in (0,15) or y in (0,15)) and grid[y][x]=='.'}
 while True:
  expanded=outside|{(x,y) for y in range(16) for x in range(16) if grid[y][x]=='.' and any((a,b) in outside for a,b in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)))}
  if expanded==outside:break
  outside=expanded
 return bytes(0 if (x//2,y//2) in outside else 255 for y in range(32) for x in range(32))

def exact_image(actual,expected,label):
 actual=actual.convert(expected.mode)
 check(actual.size==expected.size,label+' dimensions')
 if actual.tobytes()!=expected.tobytes():
  difference=ImageChops.difference(actual,expected)
  channels=difference.split();union=channels[0]
  for channel in channels[1:]:union=ImageChops.lighter(union,channel)
  binary=union.point(lambda value:255 if value else 0)
  raise ValueError(label+' pixel/mask mismatch count='+str(binary.histogram()[255])+' bbox='+str(binary.getbbox()))

def source_maps(reference,candidate,pin):
 # All bytes are checked against archive-derived immutable pins before use.
 def raw(path):
  check(path in pin['files'],'unverified source '+path)
  data=(reference/path).read_bytes();check(hashlib.sha256(data).hexdigest()==pin['files'][path],'source drift '+path);return data
 for path in pin['files']:raw(path)
 constants={m[0]:(int(m[1]),int(m[2])) for m in re.findall(r'^\s*map_const\s+(\w+),\s*(\d+),\s*(\d+)',raw('constants/map_constants.asm').decode(),re.M)}
 # Preserve original maps.asm aliases: several headers can share a .blk.
 layouts={};pending=[]
 for line in raw('maps.asm').decode().splitlines():
  match=re.match(r'(\w+)_Blocks::?',line)
  if match:pending.append(match[1])
  inc=re.search(r'INCBIN "([^"]+)"',line)
  if inc:
   for name in pending:layouts[name]=inc[1]
   pending=[]
 collisions={};pending=[]
 for line in raw('data/tilesets/collision_tile_ids.asm').decode().splitlines():
  match=re.match(r'(\w+)_Coll::',line)
  if match:pending.append(match[1])
  values=re.match(r'\s*coll_tiles\s+([^;]+)',line)
  if values:
   allowed={int(x.strip().replace('$','0x'),0) for x in values[1].split(',')}
   for name in pending:collisions[name]=allowed
   pending=[]
 defs={};count=0;grids=0;native_pixels=0
 for name in MAPS:
  d=json.loads((candidate/'maps'/f'{name}.json').read_text());defs[name]=d
  check(d['name']==name,'map name mismatch')
  header=raw('data/maps/headers/'+name+'.asm').decode()
  match=re.search(r'map_header\s+'+name+r',\s*(\w+),\s*(\w+)',header);check(match is not None,'header missing')
  constant,tileset=match.groups();bw,bh=constants[constant];w,h=bw*2,bh*2
  check(d['id']=='pokered:'+constant and d['dimensions']['cells']==[w,h] and d['tileset']['constant']==tileset,'header dimensions/identity mismatch')
  layout=raw(layouts[name]);check(len(layout)==bw*bh,'layout length')
  check(d['tileset']['name']=='Overworld' and d['tileset']['graphics']=='gfx/tilesets/overworld.png' and d['tileset']['blockset']=='gfx/blocksets/overworld.bst','tileset source tuple')
  check(d['runtime_adapter']['integrated'] is False and d['runtime_adapter']['npc_images_rendered'] is False,'runtime acceptance falsely declared')
  check([e['id']for e in d['grids']]==list(range(1,len(d['grids'])+1)),'map-local grid IDs')
  blocks=raw(d['tileset']['blockset']);sheet=Image.open(__import__('io').BytesIO(raw(d['tileset']['graphics']))).convert('L')
  check(set(sheet.getdata())<=set(SHADES),'unknown tile palette')
  sheets_w=sheet.width//8;expected_native=Image.new('RGBA',(w*32,h*32));expected_ref=Image.new('L',(w*16,h*16));memo={}
  for y in range(h):
   for x in range(w):
    block=layout[(y//2)*bw+x//2];quad=(y%2)*2+x%2;base=block*16+(quad//2)*8+(quad%2)*2
    ids=[blocks[base],blocks[base+1],blocks[base+4],blocks[base+5]]
    check(d['source_refs'][y][x]==[(y//2)*bw+x//2,block,quad],'cell source layout/block/quadrant provenance')
    check(1<=d['tile_ids'][y][x]<=len(d['grids']),'invalid local grid ID')
    entry=d['grids'][d['tile_ids'][y][x]-1]
    check(entry['source_tile_ids']==ids,f'{name} cell {x},{y} quadrant IDs')
    grid=[]
    for py in range(16):
     row=''
     for px in range(16):
      tile=ids[(py//8)*2+px//8];row+=SHADES[sheet.getpixel(((tile%sheets_w)*8+px%8,(tile//sheets_w)*8+py%8))]
     grid.append(row)
    check(entry['grid']==grid,f'{name} cell {x},{y} source grid')
    check(entry['stable_id']=='pokered:OVERWORLD:cell:'+'-'.join(f'{value:02x}'for value in ids),'stable source tile key')
    check(entry['canonical_shade_sha256']==hashlib.sha256(bytes('.12#'.index(c)for row in grid for c in row)).hexdigest(),'canonical shade hash')
    check(entry['terrain']=={'foot_tile':ids[2],'land_passable':ids[2]in collisions['Overworld'],'grass':ids[2]==0x52,'counter':False,'water_candidate':ids[2]==0x14,'warp_tile':ids[2]in(0x1b,0x58)},'source terrain tuple')
    check(d['collision'][y][x]==(0 if ids[2] in collisions[d['tileset']['name']] else 1),f'{name} collision {x},{y}')
    key=tuple(ids)
    if key not in memo:
     memo[key]=raster(grid)
     tiny=Image.new('L',(16,16));tiny.putdata([next(v for v,c in SHADES.items() if c==char) for row in grid for char in row]);memo[key+('ref',)]=tiny
    expected_native.paste(memo[key],(x*32,y*32));expected_ref.paste(memo[key+('ref',)],(x*16,y*16));count+=1
  exact_image(Image.open(candidate/'catalog'/f'{name}-native.png'),expected_native,name+' native')
  exact_image(Image.open(candidate/'catalog'/f'{name}-reference.png'),expected_ref,name+' reference')
  grids+=len(d['grids']);native_pixels+=w*h*32*32
 return defs,{'cells':count,'map_grid_rows':grids,'map_pngs':2,'native_pixels':native_pixels}

def source_sprites(reference,candidate,pin):
 data=json.loads((candidate/'sprites.json').read_text());frames=0
 for name,strip in data['sprites'].items():
  raw=(reference/strip['source']).read_bytes();check(hashlib.sha256(raw).hexdigest()==pin['files'][strip['source']]==strip['sha256'],'sprite pin mismatch')
  source=Image.open(__import__('io').BytesIO(raw)).convert('L');check(source.width==16 and source.height in (16,48,96),'sprite dimensions')
  check(len(strip['frames'])==source.height//16,'sprite frame count')
  for index,grid in strip['frames'].items():
   expected_grid=[''.join(SHADES[source.getpixel((x,int(index)*16+y))] for x in range(16)) for y in range(16)]
   check(grid==expected_grid,'source sprite grid '+name+'/'+index)
   alpha=opacity(grid);image=raster(grid);image.putalpha(Image.frombytes('L',(32,32),alpha))
   exact_image(Image.open(candidate/'catalog'/f'sprite-{name}-{index}-raw.png'),image,name+'/'+index+' rawRGBA')
   exact_image(Image.open(candidate/'catalog'/f'sprite-{name}-{index}-mask.png'),Image.frombytes('L',(32,32),alpha),name+'/'+index+' mask')
   frames+=1
 return {'strips':len(data['sprites']),'frames':frames,'rgba_and_mask_pngs':frames*2}


def macros(text,name):
 return [(number,[x.strip()for x in match[1].split(',')])for number,line in enumerate(text.splitlines(),1)if(match:=re.fullmatch(r'\s*'+re.escape(name)+r'\s+([^;]+?)(?:\s*;.*)?',line))]
def number(value):return int(value[1:],16)if value.startswith('$')else int(value)
def source_geometry(reference,name):
 constants={m[0]:(int(m[1]),int(m[2]))for m in re.findall(r'^\s*map_const\s+(\w+),\s*(\d+),\s*(\d+)',(reference/'constants/map_constants.asm').read_text(),re.M)}
 header=(reference/f'data/maps/headers/{name}.asm').read_text();constant=re.search(r'map_header\s+\w+,\s*(\w+),',header)[1];bw,bh=constants[constant]
 layouts={};pending=[]
 for line in(reference/'maps.asm').read_text().splitlines():
  m=re.match(r'(\w+)_Blocks::?',line)
  if m:pending.append(m[1])
  inc=re.search(r'INCBIN "([^"]+)"',line)
  if inc:
   for label in pending:layouts[label]=inc[1]
   pending=[]
 layout=(reference/layouts[name]).read_bytes();blocks=(reference/'gfx/blocksets/overworld.bst').read_bytes()
 collision_text=(reference/'data/tilesets/collision_tile_ids.asm').read_text().split('Overworld_Coll::',1)[1]
 permitted={number(v.strip())for v in re.search(r'coll_tiles\s+([^;\n]+)',collision_text)[1].split(',')}
 foot=[];collision=[]
 for y in range(bh*2):
  fr=[];cr=[]
  for x in range(bw*2):
   b=layout[y//2*bw+x//2];offset=b*16+(y%2)*8+(x%2)*2;f=blocks[offset+4];fr.append(f);cr.append(0 if f in permitted else 1)
  foot.append(fr);collision.append(cr)
 text=(reference/f'data/maps/objects/{name}.asm').read_text()
 return {'id':'pokered:'+constant,'name':name,'width':bw*2,'height':bh*2,'foot':foot,'collision':collision,'objects':macros(text,'object_event'),'warps':macros(text,'warp_event'),'background_events':macros(text,'bg_event')}

def boundary_and_paths(reference,candidate):
 city=source_geometry(reference,'CeruleanCity');route=source_geometry(reference,'Route4');d=json.loads((candidate/'west-connection.json').read_text())
 check('connection west, Route4, ROUTE_4, 4'in(reference/'data/maps/headers/CeruleanCity.asm').read_text(),'source City connection tuple')
 check('connection east, CeruleanCity, CERULEAN_CITY, -4'in(reference/'data/maps/headers/Route4.asm').read_text(),'source Route4 connection tuple')
 pairs=[(number(args[1]),number(args[2]))for _,args in macros((reference/'data/tilesets/pair_collision_tile_ids.asm').read_text(),'db')if len(args)==3 and args[0]=='OVERWORLD']
 expected=[]
 for direction,source,target in [('east',route,city),('west',city,route)]:
  for y in range(source['height']):
   x=source['width']-1 if direction=='east'else 0;tx=0 if direction=='east'else target['width']-1;ty=y+(8 if direction=='east'else-8)
   row={'direction':direction,'source_map':source['id'],'source_xy':[x,y],'target_map':target['id'],'target_xy':[tx,ty],'overlap':0<=ty<target['height']}
   row['geometry_passable']=False
   if row['overlap']:
    a,b=source['foot'][y][x],target['foot'][ty][tx];allowed=(a,b)not in pairs and(b,a)not in pairs
    row.update(source_foot=a,target_foot=b,source_land=source['collision'][y][x]==0,target_land=target['collision'][ty][tx]==0,pair_allowed=allowed)
    row['geometry_passable']=row['source_land']and row['target_land']and allowed
   expected.append(row)
 check(d['rows']==expected and d['route4_east_to_city_y_add']==8 and d['city_west_to_route4_y_add']==-8,'directed boundary source/collision mapping')
 # Independent graph: explicit edge sets, then iterative reachability (not the
 # generator's BFS/parent traversal). Freeze source actors and block interiors.
 symbols=[args[0]for _,args in macros((reference/'data/maps/objects/CeruleanCity.asm').read_text(),'const_export')]
 toggles={s:v for _,(s,v)in macros((reference/'data/maps/toggleable_objects.asm').read_text(),'toggle_object_state')}
 visible={i for i,symbol in enumerate(symbols,1)if toggles.get(symbol,'ON')!='OFF'}
 blocked={}
 for data in (route,city):
  cells={(number(a[0]),number(a[1]))for _,a in data['warps']}
  cells|={(number(a[0]),number(a[1]))for i,(_,a)in enumerate(data['objects'],1)if data is route or i in visible}
  blocked[data['name']]=cells
 blocked['CeruleanCity']|={(30,7),(30,9),(20,6),(21,6)}
 ledges={(args[0],number(args[1]),number(args[2]))for _,args in macros((reference/'data/tilesets/ledge_tiles.asm').read_text(),'db')if len(args)==4 and args[0].startswith('SPRITE_FACING_')}
 maps={x['name']:x for x in (route,city)};edges={};vectors=[('SPRITE_FACING_UP',0,-1),('SPRITE_FACING_DOWN',0,1),('SPRITE_FACING_LEFT',-1,0),('SPRITE_FACING_RIGHT',1,0)]
 for name,data in maps.items():
  for y in range(data['height']):
   for x in range(data['width']):
    node=(name,x,y);out=[];a=data['foot'][y][x]
    for facing,dx,dy in vectors:
     tx,ty=x+dx,y+dy;target=data
     if not 0<=tx<data['width']or not 0<=ty<data['height']:
      if name=='Route4'and dx==1 and x==89:target=city;tx,ty=0,y+8
      elif name=='CeruleanCity'and dx==-1 and x==0:target=route;tx,ty=89,y-8
      else:continue
      if not 0<=ty<target['height']:continue
     b=target['foot'][ty][tx]
     if target is data and(facing,a,b)in ledges:
      tx,ty=x+dx*2,y+dy*2
      if not 0<=tx<data['width']or not 0<=ty<data['height']:continue
     elif(a,b)in pairs or(b,a)in pairs:continue
     if target['collision'][ty][tx]==0 and(tx,ty)not in blocked[target['name']]:out.append((target['name'],tx,ty))
    edges[node]=set(out)
 witness=json.loads((candidate/'directed-arrival-witness.json').read_text());check(witness['city_initial_visible_source_indices']==sorted(visible),'initial visibility in graph')
 for variant in witness['variants']:
  start=('Route4',*variant['source_start_xy']);check(start in(('Route4',24,5),('Route4',24,6)),'unsupported arrival fixture')
  reached={start};front={start}
  while front:
   new=set().union(*(edges[n]for n in front))-reached;reached|=new;front=new
  check(variant['reachable_city_west_arrival_y']==sorted(y for n,x,y in reached if n=='CeruleanCity'and x==0),'directed reachable City arrivals')
  check(variant['reachable_cells']=={name:sum(n==name for n,x,y in reached)for name in maps},'reachable cells differ')
  path=[tuple(n)for n in variant['path_to_center_exterior']];check(path and path[0]==start and path[-1]==('CeruleanCity',19,18),'center EXTERIOR witness endpoint')
  check(all(b in edges[a]for a,b in zip(path,path[1:])),'invalid directed witness step')
 check(len(witness['variants'])==2 and sorted(witness['variants'][0]['reachable_city_west_arrival_y'])==[18,19],'literal arrival over-claim')
 return {'directed_boundary_rows':len(expected),'static_land_pairs_each_direction':8,'source_actor_constrained_arrival_city_y':[18,19],'center_exterior_paths_checked':2,'source_interpreter_or_playability_claim':False}

def tuples_and_controls(reference,candidate):
 data=json.loads((candidate/'maps/CeruleanCity.json').read_text());objects=(reference/'data/maps/objects/CeruleanCity.asm').read_text();requirements=json.loads((candidate/'event-requirements.json').read_text())
 expected_counts={'warps':10,'background_events':6,'objects':11}
 for kind,macro in [('warps','warp_event'),('background_events','bg_event'),('objects','object_event')]:
  source=macros(objects,macro);check(len(data['events'][kind])==len(source)==expected_counts[kind],'source declaration inventory')
  for i,((line,args),event)in enumerate(zip(source,data['events'][kind]),1):
   observed=[str(event['x']),str(event['y'])]
   if kind=='warps':observed +=[event['destination']['map'],str(event['destination']['warp_index'])]
   elif kind=='background_events':observed +=[event['text_id']]
   else:observed +=[event['sprite'],event['movement'],event['range_or_facing'],event['text_id']]+event['extra']
   check(observed==args and event['source_line']==line and event['source_index']==i and event['id']==f'pokered:CERULEAN_CITY:{kind}:{i}','source event tuple changed')
  for event in requirements['events']:
   check(event['runtime_status'].startswith('UNIMPLEMENTED'),'false event runtime qualification')
 check(data['source_map_id']==3,'source map constant ordinal')
 check(len(requirements['events'])==27,'control inventory omission')
 # Every target is an exact primary header/object tuple; no interior readiness.
 targets={'CERULEAN_TRASHED_HOUSE':'CeruleanTrashedHouse','CERULEAN_TRADE_HOUSE':'CeruleanTradeHouse','CERULEAN_POKECENTER':'CeruleanPokecenter','CERULEAN_GYM':'CeruleanGym','BIKE_SHOP':'BikeShop','CERULEAN_MART':'CeruleanMart','CERULEAN_CAVE_1F':'CeruleanCave1F','CERULEAN_BADGE_HOUSE':'CeruleanBadgeHouse'}
 warp_requirements=[e for e in requirements['events']if e['kind']=='warps']
 for event,requirement in zip(data['events']['warps'],warp_requirements):
  constant=event['destination']['map'];name=targets[constant];header=(reference/f'data/maps/headers/{name}.asm').read_text()
  check(re.search(r'map_header\s+'+name+r',\s*'+constant+r',',header)is not None,'target header alias/constant')
  path=f'data/maps/objects/{name}.asm';rows=macros((reference/path).read_text(),'warp_event');line,args=rows[event['destination']['warp_index']-1]
  check(requirement['target_object_source']==path and requirement['target_source']=={'args':args,'line':line},'target warp primary tuple')
 sprite_data=json.loads((candidate/'sprites.json').read_text());wanted={e['sprite']for e in data['events']['objects']}
 metadata=re.findall(r'^\s*overworld_sprite (\w+),\s*(\d+)\s*;\s*(SPRITE_\w+)',(reference/'data/sprites/sprites.asm').read_text(),re.M)
 graphics=dict(re.findall(r'^(\w+)::\s+INCBIN "([^"]+)"',(reference/'gfx/sprites.asm').read_text(),re.M));check(set(sprite_data['mapping'])==wanted,'sprite constant mapping inventory')
 for label,count,constant in metadata:
  if constant not in wanted:continue
  path=graphics[label].replace('.2bpp','.png');name=Path(path).stem;actual=sprite_data['mapping'][constant]
  check((actual['source_label'],actual['source'],actual['name'],actual['standing_tiles'])==(label,path,name,int(count)),'sprite source alias tuple')
  strip=sprite_data['sprites'][name];height=strip['size'][1];check(strip['standing']==({'down':0,'up':1,'left':2}if height>=48 else{'down':0})and strip['walking']==({'down':3,'up':4,'left':5}if height==96 else{}),'source frame ordering')
 check(requirements['conditional_actors']['rival']['initially_visible']is False and requirements['conditional_actors']['rocket']['initially_visible']is True,'BLUE/Rocket initial visibility')
 check(requirements['conditional_actors']['guards']['initial']=={'index6':False,'index11':True},'guard initial positions')
 check(requirements['conditional_actors']['cave_blocker']['initially_visible']is True,'postgame cave blocker')
 check(requirements['random_dialogue']['objects7']['ranges']==[{'bytes':[180,255],'label':'Sonicboom'},{'bytes':[100,179],'label':'Punch'},{'bytes':[0,99],'label':'Withdraw'}],'random dialogue180/100 source branch')
 check(requirements['random_dialogue']['objects8']['ranges']==[{'bytes':[180,255],'label':'TookASnooze'},{'bytes':[120,179],'label':'Loafing'},{'bytes':[60,119],'label':'TurnedAway'},{'bytes':[0,59],'label':'IgnoredOrders'}],'random dialogue180/120/60 source branch')
 check('fly_warp CERULEAN_CITY,   19, 18'in(reference/'data/maps/special_warps.asm').read_text(),'source Center exterior warp point')

 check(requirements['walkers']==['pokered:CERULEAN_CITY:objects:'+str(i)for i in(4,5,9)],'three source walkers')
 symbols=[a[0]for _,a in macros(objects,'const_export')];toggles={a[0]:a[1]for _,a in macros((reference/'data/maps/toggleable_objects.asm').read_text(),'toggle_object_state')}
 object_rows=[e for e in requirements['events']if e['kind']=='objects']
 for i,row in enumerate(object_rows):check(row['source_symbol']==symbols[i]and row['initial_visibility']==toggles.get(symbols[i],'not-toggleable/default-visible'),'source conditional actor visibility')
 check([i+1 for i,s in enumerate(symbols)if toggles.get(s)=='OFF']==[1,6],'literal initial hidden actors')
 bills=(reference/'scripts/BillsHouse.asm').read_text().split('BillsHouseBillSSTicketText:',1)[1];check(bills.index('call GiveItem')<bills.index('jr nc, .bag_full')<bills.index('SetEvent EVENT_GOT_SS_TICKET')<bills.index('TOGGLE_CERULEAN_GUARD_1'),'ticket/guard gate source order')
 check('successful S_S_TICKET grant'in requirements['conditional_actors']['guards']['shift'],'guard threshold falsely simplified')
 script=(reference/'scripts/CeruleanCity.asm').read_text()
 for label,xy in [('CeruleanCityCoords1',[[30,7],[30,9]]),('CeruleanCityCoords2',[[20,6],[21,6]])]:
  block=script.split(label+':',1)[1].split('\n\n',1)[0];check([[number(x),number(y)]for _,(x,y)in macros(block,'dbmapcoord')]==xy==requirements['coordinate_triggers'][label],'source script trigger cells')
 raw_text=(reference/'text/CeruleanCity.asm').read_text();dialogue=json.loads((candidate/'dialogue.json').read_text())['texts']
 wanted=set(re.findall(r'^(_\w+)::',raw_text,re.M))|{'_MartSignText','_PokeCenterSignText','_FoundHiddenItemText','_HiddenItemBagFullText'}
 check(set(dialogue)==wanted,'source text-label inventory differs')
 for label,record in dialogue.items():
  lines=(reference/record['source']).read_text().splitlines();start=next(i for i,line in enumerate(lines)if line.startswith(label+'::'));expected=[]
  for index in range(start+1,len(lines)):
   line=lines[index]
   if re.match(r'^_\w+::',line):break
   line=line.split(';',1)[0].strip()
   if not line:continue
   m=re.fullmatch(r'(text|line|cont|para|next)\s+"(.*)"',line)
   if m:expected.append({'op':m[1],'text':m[2],'source_line':index+1})
   elif line.startswith('text_ram '):expected.append({'op':'text_ram','symbol':line.split()[1],'source_line':index+1})
   else:expected.append({'op':'control','source':line,'source_line':index+1})
  check(record['recipe']==expected,'text recipe changed: '+label)
 hidden=[];context=None
 for index,line in enumerate((reference/'data/events/hidden_events.asm').read_text().splitlines(),1):
  marker=macros(line,'hidden_events_for')
  if marker:context=marker[0][1][0]
  if context=='CERULEAN_CITY':
   for _,args in macros(line,'hidden_event'):hidden.append({'source_line':index,'source_xy':[number(args[0]),number(args[1])],'handler_source':args[2],'argument_source':args[3]})
 check(len(hidden)==len(requirements['hidden_events'])==1,'source hidden item inventory')
 for actual in requirements['hidden_events']:
  check(all(actual[k]==v for k,v in hidden[0].items())and actual['id']=='pokered:CERULEAN_CITY:hidden:1'and actual['runtime_status'].startswith('UNIMPLEMENTED'),'source hidden item tuple/acceptance')
 check(hidden[0]['source_xy']==[15,8]and hidden[0]['argument_source']=='RARE_CANDY','literal hidden RareCandy source')
 alias=json.loads((candidate/'source-aliases.json').read_text());rows=macros((reference/'constants/map_constants.asm').read_text(),'map_const');constant_ids={args[0]:i for i,(_,args)in enumerate(rows)};pointers=[args[0]for _,args in macros((reference/'data/maps/map_header_pointers.asm').read_text(),'dw')]
 copy_id=constant_ids['CERULEAN_TRASHED_HOUSE_COPY'];check(copy_id==69 and pointers[copy_id]=='CeruleanTrashedHouse_h','source alias pointer')
 check(alias['candidate_map_aliases']==[]and alias['indexed_related_unimplemented_alias_slots']==[{'id':69,'constant':'CERULEAN_TRASHED_HOUSE_COPY','slot_kind':'copy_or_alias','header_name':'CeruleanTrashedHouse','object_table':'CeruleanTrashedHouse'}],'source alias distinction omitted or promoted')
 inventory=json.loads((candidate/'inventory.json').read_text());check(inventory['maps']==['CeruleanCity']and inventory['runtime_installed']is False and inventory['catalog_reviewed']is False and inventory['campaign_ready']is False,'false City scope/acceptance')
 teams=json.loads((candidate/'trainer-parties.json').read_text())['variants'];expected=[[(18,'PIDGEOTTO'),(15,'ABRA'),(15,'RATTATA'),(17,s)]for s in('SQUIRTLE','BULBASAUR','CHARMANDER')]+[[(17,'MACHOP'),(17,'DROWZEE')]]
 check([[(m['level'],m['species_source'])for m in t['party']]for t in teams]==expected,'original trainer rosters changed')
 check([t['payout']for t in teams]==[595,595,595,510],'source payouts changed')
 return {'source_event_tuples':27,'hidden_item_controls':1,'source_alias_slots':1,'source_script_coordinate_arrays':2,'literal_roster_variants':4,'text_recipes':len(dialogue),'runtime_installed':False}

def check_all(reference,archive,candidate,pin):
 import io,tarfile
 check(pin['revision']=='af519899719f0754965776faac0e836a3b906e6d','source revision differs')
 expected_archive='e571972fc926dcb65d94fc989299d38109590aa945ed657bf215eac8561afd05';raw=archive.read_bytes();check(hashlib.sha256(raw).hexdigest()==expected_archive==pin['archive_sha256'],'immutable source archive SHA mismatch')
 found={}
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as stream:
  for member in stream.getmembers():
   if member.isfile():
    name='/'.join(Path(member.name).parts[1:])
    if name in pin['files']:found[name]=hashlib.sha256(stream.extractfile(member).read()).hexdigest()
 check(found==pin['files'],'source pins differ from immutable archive bytes')
 manifest=json.loads((candidate/'source-manifest.json').read_text());check(manifest['source_revision']==pin['revision']and manifest['consumed_source_files']==pin['files'],'consumed source manifest differs')
 definitions,maps=source_maps(reference,candidate,pin);sprites=source_sprites(reference,candidate,pin);controls=tuples_and_controls(reference,candidate);geometry=boundary_and_paths(reference,candidate)
 actual={str(p.relative_to(candidate))for p in candidate.rglob('*')if p.is_file()}
 check(actual==set(manifest['artifacts'])|{'source-manifest.json'},'candidate artifact inventory differs')
 for path,digest in manifest['artifacts'].items():check(hashlib.sha256((candidate/path).read_bytes()).hexdigest()==digest,'candidate metadata/artifact SHA drift: '+path)
 return {'ok':True,'pinned_archive_verified':True,'primary_inputs':len(pin['files']),'maps':maps,'sprites':sprites,'controls':controls,'geometry':geometry,'runtime_native_acceptance':False}
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--reference',type=Path,required=True);parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--candidate',type=Path,required=True);parser.add_argument('--pin',type=Path,required=True);args=parser.parse_args();print(json.dumps(check_all(args.reference,args.archive,args.candidate,json.loads(args.pin.read_text())),indent=2))

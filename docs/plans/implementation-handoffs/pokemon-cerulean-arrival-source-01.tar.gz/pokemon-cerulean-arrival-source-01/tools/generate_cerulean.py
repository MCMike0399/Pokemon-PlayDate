#!/usr/bin/env python3
"""ONE source-only City candidate, pinned archive/extracted bytes; no runtime/network."""
import argparse,hashlib,importlib.util,io,json,re,sys,tarfile
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
from PIL import Image
STAGE=Path(__file__).resolve().parents[1]
REV='af519899719f0754965776faac0e836a3b906e6d'
ARCHIVE='e571972fc926dcb65d94fc989299d38109590aa945ed657bf215eac8561afd05'
HELPERS=('tools/generate_kanto_maps.py','tools/generate_viridian_slice.py','tools/generate_overworld_sprites.py')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def jb(data):return (json.dumps(data,indent=2,sort_keys=True,ensure_ascii=False)+'\n').encode()
def load(project,name,path):
 spec=importlib.util.spec_from_file_location(name,project/path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def archive_pins(path):
 raw=Path(path).read_bytes()
 if sha(raw)!=ARCHIVE:raise ValueError('immutable source archive SHA256 mismatch')
 pins={}
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as archive:
  for entry in archive.getmembers():
   if not entry.isfile():continue
   name=PurePosixPath(entry.name)
   if name.is_absolute()or'..'in name.parts:raise ValueError('unsafe archive member')
   relative='/'.join(name.parts[1:])
   if relative in pins:raise ValueError('duplicate source archive member')
   pins[relative]=sha(archive.extractfile(entry).read())
 return pins

def block(text,label):
 m=re.search(r'^'+re.escape(label)+r':{1,2}\s*$',text,re.M)
 if not m:raise ValueError('missing label '+label)
 tail=text[m.end():];end=re.search(r'^\w+:',tail,re.M);return tail[:end.start()]if end else tail

def roster(g,text,label,index):
 rows=g.records(block(text,label),'db');args=rows[index-1]['args'];assert args[-1]=='0'
 pairs=[(g.integer(args[i]),args[i+1])for i in range(1,len(args)-1,2)]if args[0].upper()=='$FF'else[(g.integer(args[0]),s)for s in args[1:-1]]
 return [{'species_source':species,'level':level}for level,species in pairs]

def render_sprite(g,mask,grid):
 raw=g.render_map({'dimensions':{'cells':[1,1]},'grids':[{'id':1,'grid':grid}],'tile_ids':[[1]]})
 image=Image.open(io.BytesIO(raw)).convert('RGBA');alpha=Image.frombytes('L',(32,32),mask.mask_bytes(grid));image.putalpha(alpha)
 return image,alpha

def boundary(city,route):
 pairs={tuple(p)for p in city['directional_rules']['forbidden_tile_pairs']};rows=[]
 def foot(d,x,y):return d['grids'][d['tile_ids'][y][x]-1]['terrain']['foot_tile']
 for direction,origin,target,count,offset in [('east',route,city,18,8),('west',city,route,36,-8)]:
  for y in range(count):
   x=origin['dimensions']['cells'][0]-1 if direction=='east'else 0;tx=0 if direction=='east'else target['dimensions']['cells'][0]-1;ty=y+offset
   row={'direction':direction,'source_map':origin['id'],'source_xy':[x,y],'target_map':target['id'],'target_xy':[tx,ty],'overlap':0<=ty<target['dimensions']['cells'][1]}
   if row['overlap']:
    a,b=foot(origin,x,y),foot(target,tx,ty);pair=any(p in pairs for p in ((a,b),(b,a)))
    row.update(source_foot=a,target_foot=b,source_land=origin['collision'][y][x]==0,target_land=target['collision'][ty][tx]==0,pair_allowed=not pair)
    row['geometry_passable']=row['source_land']and row['target_land']and not pair
   else:row['geometry_passable']=False
   rows.append(row)
 return {'schema':1,'source_headers':['data/maps/headers/Route4.asm','data/maps/headers/CeruleanCity.asm'],'route4_east_to_city_y_add':8,'city_west_to_route4_y_add':-8,'rows':rows,'scope':'actor-free static land/pair-collision directed boundary only; not source engine execution, actor/script/HM/runtime acceptance'}

def directed_witness(city,route,requirements):
 from collections import deque
 maps={'Route4':route,'CeruleanCity':city};blocked={}
 visible={e['source_index'] for e in requirements['events']if e['kind']=='objects'and e['initial_visibility']!='OFF'}
 for name,d in maps.items():
  cells={(e['x'],e['y'])for e in d['events']['warps']}
  cells|={(e['x'],e['y'])for e in d['events']['objects']if name=='Route4'or e['source_index']in visible}
  if name=='CeruleanCity':cells|={(30,7),(30,9),(20,6),(21,6)}
  blocked[name]=cells
 directions={'up':(0,-1),'down':(0,1),'left':(-1,0),'right':(1,0)}
 labels={'up':'SPRITE_FACING_UP','down':'SPRITE_FACING_DOWN','left':'SPRITE_FACING_LEFT','right':'SPRITE_FACING_RIGHT'}
 def foot(d,x,y):return d['grids'][d['tile_ids'][y][x]-1]['terrain']['foot_tile']
 def neighbors(node):
  name,x,y=node;d=maps[name];w,h=d['dimensions']['cells'];a=foot(d,x,y)
  for direction,(dx,dy)in directions.items():
   nx,ny=x+dx,y+dy;target=name
   if not(0<=nx<w and 0<=ny<h):
    if name=='Route4'and direction=='right'and x==89:target,nx,ny='CeruleanCity',0,y+8
    elif name=='CeruleanCity'and direction=='left'and x==0:target,nx,ny='Route4',89,y-8
    else:continue
    if not 0<=ny<maps[target]['dimensions']['cells'][1]:continue
   td=maps[target];b=foot(td,nx,ny)
   if target==name and any(r['facing']==labels[direction]and r['standing_foot_tile']==a and r['target_foot_tile']==b for r in d['directional_rules']['ledges']):
    nx,ny=x+dx*2,y+dy*2
    if not(0<=nx<w and 0<=ny<h):continue
   elif any((a,b)==tuple(p)or(b,a)==tuple(p)for p in d['directional_rules']['forbidden_tile_pairs']):continue
   if td['collision'][ny][nx]==0 and(nx,ny)not in blocked[target]:yield(target,nx,ny)
 variants=[]
 for xy in ((24,5),(24,6)):
  start=('Route4',*xy);seen={start};previous={};queue=deque([start])
  while queue:
   node=queue.popleft()
   for target in neighbors(node):
    if target not in seen:seen.add(target);previous[target]=node;queue.append(target)
  end=('CeruleanCity',19,18);path=[]
  if end in seen:
   cursor=end
   while cursor!=start:path.append(list(cursor));cursor=previous[cursor]
   path.append(list(start));path.reverse()
  variants.append({'source_start_xy':list(xy),'start_policy':'exact source Route4 warp3 cell'if xy==(24,5)else'one-cell exterior advance candidate; source engine/traversal review still required','reachable_city_west_arrival_y':sorted(y for name,x,y in seen if name=='CeruleanCity'and x==0),'reachable_cells':{name:sum(n==name for n,x,y in seen)for name in maps},'city_center_exterior_xy':[19,18],'path_to_center_exterior':path})
 return {'schema':1,'scope':'Conservative source geometry graph with frozen declared initial actors, all interior warp cells blocked, both known City script-trigger arrays blocked, no outside exits except westRoute4; no source interpreter/AI/story/encounter/native acceptance','variants':variants,'city_initial_visible_source_indices':sorted(visible),'blocked_city_script_cells':[[30,7],[30,9],[20,6],[21,6]],'ladders_and_warps_executed':False,'runtime_installed':False}

def build(project,reference,archive):
 project=Path(project);pins=archive_pins(archive)
 deps=json.loads((STAGE/'generator-dependencies.json').read_text())
 for name,digest in deps['project_files'].items():
  if sha((project/name).read_bytes())!=digest:raise ValueError('reviewed decoder dependency drift: '+name)
 g=load(project,'cerulean_map','tools/generate_kanto_maps.py');sg=load(project,'cerulean_sprites','tools/generate_viridian_slice.py');mask=load(project,'cerulean_masks','tools/generate_overworld_sprites.py')
 ref=g.Reference(reference,pins);city=g.decode_map(ref,'CeruleanCity');route=g.decode_map(ref,'Route4')
 assert city['dimensions']['cells']==[40,36]and city['dimensions']['blocks']==[20,18]
 assert {k:len(v)for k,v in city['events'].items()}=={'warps':10,'background_events':6,'objects':11}
 assert len([e for e in city['events']['objects']if e['movement']=='WALK'])==3
 out={'maps/CeruleanCity.json':g.json_bytes(city),'catalog/CeruleanCity-native.png':g.render_map(city),'catalog/CeruleanCity-reference.png':g.render_map(city,False)}
 # Sprite identities come from source tables/INCBIN aliases, never guessed art.
 wanted={e['sprite']for e in city['events']['objects']};rows=re.findall(r'^\s*overworld_sprite (\w+),\s*(\d+)\s*;\s*(SPRITE_\w+)',ref.text('data/sprites/sprites.asm'),re.M);graphics=dict(re.findall(r'^(\w+)::\s+INCBIN "([^"]+)"',ref.text('gfx/sprites.asm'),re.M));ref.bytes('constants/sprite_constants.asm')
 mapping={};strips={};preview=[]
 for label,count,constant in rows:
  if constant not in wanted:continue
  path=graphics[label].replace('.2bpp','.png');name=Path(path).stem;strip=sg.sprite_data(ref,name)
  assert int(count)==min(len(strip['frames']),3)*4;mapping[constant]={'source_label':label,'source':path,'name':name,'standing_tiles':int(count),'runtime_status':'unimplemented; preserve existing shared art; BLUE must reuse protected standing/EventArt legacy phase, not these raw previews'};strips[name]=strip
 for name,strip in strips.items():
  for index,grid in strip['frames'].items():
   image,alpha=render_sprite(g,mask,grid)
   for kind,value in [('raw',image),('mask',alpha)]:
    buf=io.BytesIO();value.save(buf,format='PNG');out[f'catalog/sprite-{name}-{index}-{kind}.png']=buf.getvalue()
   preview.append({'source_id':strip['id']+':frame:'+index,'path':f'sprite-{name}-{index}-raw.png','mask':f'sprite-{name}-{index}-mask.png','phase':'explicit source phase0, reference only; no protected/runtime art replacement'})
 assert set(mapping)==wanted
 out['sprites.json']=jb({'schema':1,'source_revision':REV,'mapping':mapping,'sprites':strips});out['catalog/sprite-inventory.json']=jb({'images':preview,'review_status':'unreviewed HOST source previews; no native catalog/acceptance'})
 script=ref.text('scripts/CeruleanCity.asm');script2=ref.text('scripts/CeruleanCity_2.asm')
 texts={label:{'source':'text/CeruleanCity.asm','recipe':recipe}for label,recipe in sg.text_recipes(ref.text('text/CeruleanCity.asm')).items()}
 needed=set(re.findall(r'\btext_far\s+(_\w+)',script))|{'_MartSignText','_PokeCenterSignText','_FoundHiddenItemText','_HiddenItemBagFullText'}
 for source in ('data/text/text_1.asm','data/text/text_2.asm','data/text/text_3.asm','data/text/text_4.asm','data/text/text_5.asm'):
  for label,recipe in sg.text_recipes(ref.text(source)).items():
   if label in needed:texts.setdefault(label,{'source':source,'recipe':recipe})
 assert not needed-set(texts),'missing required source words'
 out['dialogue.json']=jb({'schema':1,'source_revision':REV,'texts':texts,'runtime_status':'unimplemented; all controls/branches preserved as requirements'})
 pointers={r['args'][1]:r['args'][0]for r in g.records(script,'dw_const')if len(r['args'])==2 and r['args'][1].startswith('TEXT_')}
 objsyms=[r['args'][0]for r in g.records(ref.text('data/maps/objects/CeruleanCity.asm'),'const_export')]
 toggles={r['args'][0]:r['args'][1]for r in g.records(ref.text('data/maps/toggleable_objects.asm'),'toggle_object_state')}
 events=[]
 for kind,collection in city['events'].items():
  for e in collection:
   item={'id':e['id'],'kind':kind,'source_index':e['source_index'],'xy':[e['x'],e['y']],'source_line':e['source_line'],'runtime_status':'UNIMPLEMENTED; do not turn into generic no-op/dialogue'}
   if kind=='warps':
    destination=e['destination'];constant=destination['map'];name=next(n for n,v in g.map_constants(ref).items()if n==constant)
    # Constant→object header uses the already indexed primary table identity.
    inventory=json.loads((project/'tools/references/kanto-inventory.json').read_text());m=next(m for m in inventory['maps']if m['constant']==constant)
    header_path=m['header_source'];header=g.records(ref.text(header_path),'map_header');assert len(header)==1 and header[0]['args'][1]==constant
    target=ref.text('data/maps/objects/'+m['object_table']+'.asm');warps=g.records(target,'warp_event');assert 1<=destination['warp_index']<=len(warps)
    target_row=warps[destination['warp_index']-1];item.update(destination=destination,target_source=target_row,target_object_source='data/maps/objects/'+m['object_table']+'.asm',status='indexed target tuple only; interior not decoded/registered/playable')
   else:
    pointer=pointers[e['text_id']];body=block(script,pointer)if re.search(r'^'+pointer+r':',script,re.M)else''
    item.update(source_text_id=e['text_id'],script_pointer=pointer,far_text_labels=re.findall(r'\btext_far\s+(_\w+)',body),control_calls=sorted(set(re.findall(r'\b(?:call|jp|farcall|predef|predef_jump)\s+(\w+)',body))))
    if kind=='objects':
     symbol=objsyms[e['source_index']-1];item.update(source_symbol=symbol,sprite=e['sprite'],movement=e['movement'],range_or_facing=e['range_or_facing'],initial_visibility=toggles.get(symbol,'not-toggleable/default-visible'))
   events.append(item)
 # Read all directly relevant source prerequisites without pretending to implement them.
 extras=('scripts/BillsHouse.asm','scripts/HallOfFame.asm','constants/toggle_constants.asm','constants/event_constants.asm','constants/pokemon_constants.asm','engine/events/pokecenter.asm','data/maps/special_warps.asm','data/items/marts.asm','macros/scripts/maps.asm','engine/overworld/player_state.asm','engine/overworld/ledges.asm','engine/overworld/hidden_events.asm','data/events/hidden_events.asm','data/sprites/facings.asm','engine/events/hidden_items.asm','data/events/hidden_item_coords.asm','data/maps/map_header_pointers.asm','data/maps/map_header_banks.asm')
 for source in extras:ref.bytes(source)
 parties=g.blue_text(ref.text('data/trainers/parties.asm'));money=ref.text('data/trainers/pic_pointers_money.asm');ref.bytes('constants/trainer_constants.asm')
 teams=[{'class':'OPP_RIVAL1','index':n,'rival_starter_source':starter,'party':roster(g,parties,'Rival1Data',n),'runtime_status':'scripted encounter unimplemented'}for n,starter in [(7,'SQUIRTLE'),(8,'BULBASAUR'),(9,'CHARMANDER')]]
 teams.append({'class':'OPP_ROCKET','index':5,'party':roster(g,parties,'RocketData',5),'runtime_status':'guarded Rocket encounter/TM28 full-bag retry unimplemented'})
 for team in teams:
  pic='Rival1Pic'if team['class']=='OPP_RIVAL1'else'RocketPic';price=next(g.integer(r['args'][1])for r in g.records(money,'pic_money')if r['args'][0]==pic);assert price%100==0;team['base_money']=price//100;team['payout']=price//100*team['party'][-1]['level']
 requirements={'schema':1,'runtime_installed':False,'campaign_ready':False,'events':events,'coordinate_triggers':{'CeruleanCityCoords1':[[30,7],[30,9]],'CeruleanCityCoords2':[[20,6],[21,6]]},'conditional_actors':{'rival':{'index':1,'initially_visible':False,'trigger':'bridge20/21,6 until EVENT_BEAT_CERULEAN_RIVAL; show/approach/battle/cleanup'},'rocket':{'index':2,'initially_visible':True,'trigger':'30,7 or30,9 until thief defeated; TM_DIG gift success hides Rocket; full bag retry must remain'},'guards':{'initial':{'index6':False,'index11':True},'shift':'successful S_S_TICKET grant in BillsHouse OR CeruleanHideRocket; NOT merely EVENT_MET_BILL'},'cave_blocker':{'index':10,'initially_visible':True,'removed':'scripts/HallOfFame.asm hides TOGGLE_CERULEAN_CAVE_GUY'}},'walkers':[e['id']for e in city['events']['objects']if e['movement']=='WALK'],'random_dialogue':{'objects7':{'source':'hRandomAdd','ranges':[{'bytes':[180,255],'label':'Sonicboom'},{'bytes':[100,179],'label':'Punch'},{'bytes':[0,99],'label':'Withdraw'}]},'objects8':{'source':'hRandomAdd','ranges':[{'bytes':[180,255],'label':'TookASnooze'},{'bytes':[120,179],'label':'Loafing'},{'bytes':[60,119],'label':'TurnedAway'},{'bytes':[0,59],'label':'IgnoredOrders'}]}},'script_flags':city['script']['events_referenced'],'script_states':city['script']['states_referenced'],'all_scripts_interiors_future_exits':'UNIMPLEMENTED, physical source-qualified boundaries/diagnostics required before runtime access','audio':'music/rival/city/cry/SFX not implemented or qualified by this candidate'}
 hidden=[];current=None
 for line,text in enumerate(ref.text('data/events/hidden_events.asm').splitlines(),1):
  marker=g.records(text,'hidden_events_for')
  if marker:current=marker[0]['args'][0]
  for row in g.records(text,'hidden_event'):
   if current=='CERULEAN_CITY':
    x,y,handler,arg=row['args'];hidden.append({'id':'pokered:CERULEAN_CITY:hidden:'+str(len(hidden)+1),'source_line':line,'source_xy':[g.integer(x),g.integer(y)],'handler_source':handler,'argument_source':arg,'runtime_status':'UNIMPLEMENTED hidden-item atomic retry/receipt and item effect; no generic no-op'})
 requirements['hidden_events']=hidden
 requirements['default_script_precedence']=['Rocket coordinate encounter guard','BLUE bridge coordinate encounter guard']
 out['event-requirements.json']=jb(requirements);out['trainer-parties.json']=jb({'schema':1,'source':'data/trainers/parties.asm','variants':teams,'scope':'original species/levels/payout inventory only, no GenV battle/stat/create policy implementation'})
 layouts=g.bindings(ref.text('maps.asm'),'Blocks');groups={}
 for name,path in layouts.items():groups.setdefault(path,[]).append(name)
 indexed=json.loads((project/'tools/references/kanto-inventory.json').read_text());related=[{key:m[key]for key in ('id','constant','slot_kind','header_name','object_table')}for m in indexed['maps']if m['constant']=='CERULEAN_TRASHED_HOUSE_COPY']
 out['source-aliases.json']=jb({'indexed_related_unimplemented_alias_slots':related,'candidate_map_aliases':[name for name in groups[next(path for name,path in layouts.items()if name=='CeruleanCity')]if name!='CeruleanCity'],'referenced_interior_block_aliases':[{'block_source':path,'headers':sorted(names),'runtime_status':'unimplemented interior/alias, not a second accepted City'}for path,names in sorted(groups.items())if any(name in ('CeruleanTrashedHouse','CeruleanBadgeHouse')for name in names)and len(names)>1]})
 out['west-connection.json']=jb(boundary(city,route))
 out['directed-arrival-witness.json']=jb(directed_witness(city,route,requirements))
 out['inventory.json']=jb({'schema':1,'source_revision':REV,'maps':['CeruleanCity'],'dimensions':[40,36],'events':{k:len(v)for k,v in city['events'].items()},'walkers':3,'hidden_events':len(hidden),'sprite_strips':len(strips),'source_frames':len(preview),'text_labels':len(texts),'unique_grids':len(city['grids']),'runtime_installed':False,'catalog_reviewed':False,'campaign_ready':False,'connection_dependency_only':'Route4 decoded for directed boundary; not published as a new map or registered here'})
 out['source-manifest.json']=jb({'schema':1,'source_revision':REV,'archive_sha256':ARCHIVE,'project_helpers':deps['project_files'],'consumed_source_files':dict(sorted(ref.consumed.items())),'artifacts':{p:sha(b)for p,b in sorted(out.items())},'status':'source candidate only; not source control-flow execution/native/runtime acceptance'})
 return out

def publish(output,files,check=False):
 output=Path(output)
 if check:
  actual={str(p.relative_to(output))for p in output.rglob('*')if p.is_file()};assert actual==set(files),'candidate file inventory differs'
  for path,data in files.items():assert (output/path).read_bytes()==data,'candidate artifact changed: '+path
 else:
  if output.exists():raise ValueError('fresh nonexistent output directory required')
  for path,data in files.items():p=output/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--archive',type=Path,required=True);group=p.add_mutually_exclusive_group(required=True);group.add_argument('--output',type=Path);group.add_argument('--check',type=Path);a=p.parse_args()
 destination=a.output or a.check
 if destination.resolve().is_relative_to((a.project/'Source').resolve()):raise ValueError('Source writes forbidden')
 result=build(a.project,a.reference,a.archive);publish(destination,result,bool(a.check));print(json.dumps({'ok':True,'artifacts':len(result),'mode':'check'if a.check else'candidate','runtime_installed':False}))

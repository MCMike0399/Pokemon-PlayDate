"""Real immutable source/candidate pixel and geometry mutants; no SDK substitute."""
import copy,hashlib,importlib.util,json,os,shutil,sys,tempfile,unittest
from pathlib import Path
from PIL import Image
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parents[1]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
GEN=load('cerulean_producer',STAGE/'tools/generate_cerulean.py');ORACLE=load('cerulean_independent',STAGE/'tools/check_source.py')
class CeruleanSourceTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  for key in ('CERULEAN_PROJECT','POKERED_REFERENCE','POKERED_ARCHIVE'):
   if not os.environ.get(key):raise RuntimeError('required explicit immutable input '+key+' missing; no hidden skips')
  cls.project=Path(os.environ['CERULEAN_PROJECT']);cls.reference=Path(os.environ['POKERED_REFERENCE']);cls.archive=Path(os.environ['POKERED_ARCHIVE']);cls.candidate=Path(os.environ.get('CERULEAN_CANDIDATE',str(STAGE/'generated-04')));cls.pin=json.loads((STAGE/'source-pin.json').read_text())
 def candidate_copy(self):
  temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);p=Path(temp.name)/'candidate';shutil.copytree(self.candidate,p);return p
 def reject(self,p,pattern=None):
  if pattern:
   with self.assertRaisesRegex(ValueError,pattern):ORACLE.check_all(self.reference,self.archive,p,self.pin)
  else:
   with self.assertRaises((ValueError,KeyError,IndexError,AssertionError)):ORACLE.check_all(self.reference,self.archive,p,self.pin)
 def mutate_json(self,p,name,change):
  f=p/name;d=json.loads(f.read_text());change(d);f.write_text(json.dumps(d))
 def test_all_actual_source_bytes_grids_frames_masks_metadata_and_directed_paths(self):
  result=ORACLE.check_all(self.reference,self.archive,self.candidate,self.pin)
  self.assertEqual(result['maps']['cells'],1440);self.assertEqual(result['maps']['native_pixels'],1474560);self.assertEqual(result['sprites']['frames'],39);self.assertEqual(result['geometry']['source_actor_constrained_arrival_city_y'],[18,19]);self.assertFalse(result['runtime_native_acceptance'])
 def test_archive_and_extracted_reference_mutations_fail_before_generation(self):
  with tempfile.TemporaryDirectory()as tmp:
   tmp=Path(tmp);bad=tmp/'changed.tar.gz';raw=bytearray(self.archive.read_bytes());raw[-1]^=1;bad.write_bytes(raw)
   with self.assertRaisesRegex(ValueError,'archive SHA256 mismatch'):GEN.build(self.project,self.reference,bad)
   ref=tmp/'source'
   for name in self.pin['files']:
    dest=ref/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(self.reference/name,dest)
   f=ref/'maps/CeruleanCity.blk';raw=bytearray(f.read_bytes());raw[0]^=1;f.write_bytes(raw)
   with self.assertRaisesRegex(ValueError,'source checksum mismatch'):GEN.build(self.project,ref,self.archive)
 def test_exact_reproduction_and_protected_live_source_unchanged(self):
  sys.path.insert(0,str(self.project));from tools.harness.run import fingerprint
  before=fingerprint(self.project);self.assertEqual(before,'44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc')
  artifacts=GEN.build(self.project,self.reference,self.archive);GEN.publish(self.candidate,artifacts,True);self.assertEqual(fingerprint(self.project),before)
 def test_unknown_artifact_or_changed_grid_is_not_silently_accepted(self):
  p=self.candidate_copy();f=p/'extra.txt';f.write_text('unreviewed')
  with self.assertRaisesRegex(AssertionError,'file inventory'):GEN.publish(p,GEN.build(self.project,self.reference,self.archive),True)
  f.unlink();self.mutate_json(p,'maps/CeruleanCity.json',lambda d:d['grids'][0]['grid'].__setitem__(0,('#'if d['grids'][0]['grid'][0][0]!='#'else'.')+d['grids'][0]['grid'][0][1:]));self.reject(p,'source grid')
 def test_one_native_map_pixel_mutation_reports_exact_bbox_and_count(self):
  p=self.candidate_copy();f=p/'catalog/CeruleanCity-native.png';im=Image.open(f).convert('RGBA');r,g,b,a=im.getpixel((7,9));im.putpixel((7,9),(255-r,255-g,255-b,a));im.save(f)
  self.reject(p,r'count=1 bbox=\(7, 9, 8, 10\)')
 def test_one_mask_pixel_mutation_reports_exact_bbox_and_count(self):
  p=self.candidate_copy();f=p/'catalog/sprite-blue-0-mask.png';im=Image.open(f).convert('L');im.putpixel((0,0),255-im.getpixel((0,0)));im.save(f)
  self.reject(p,r'count=1 bbox=\(0, 0, 1, 1\)')
 def test_invisible_RGB_mutation_still_fails_strict_source_RGBA(self):
  p=self.candidate_copy();f=p/'catalog/sprite-blue-0-raw.png';im=Image.open(f).convert('RGBA');r,g,b,a=im.getpixel((0,0));self.assertEqual(a,0);im.putpixel((0,0),(255-r,255-g,255-b,a));im.save(f)
  self.reject(p,r'count=1 bbox=\(0, 0, 1, 1\)')
 def test_source_collision_and_layout_provenance_mutations_fail(self):
  for mutation in ('collision','source_refs'):
   with self.subTest(mutation=mutation):
    p=self.candidate_copy()
    def change(d):
     if mutation=='collision':d['collision'][18][0]=1-d['collision'][18][0]
     else:d['source_refs'][0][0][0]+=1
    self.mutate_json(p,'maps/CeruleanCity.json',change);self.reject(p)
 def test_warp_destination_and_source_sprite_alias_not_invented(self):
  p=self.candidate_copy();self.mutate_json(p,'maps/CeruleanCity.json',lambda d:d['events']['warps'][0]['destination'].__setitem__('warp_index',2));self.reject(p,'source event tuple')
  p=self.candidate_copy();self.mutate_json(p,'sprites.json',lambda d:d['mapping']['SPRITE_BLUE'].__setitem__('name','rocket'));self.reject(p,'sprite source alias')
 def test_conditional_blue_guards_walkers_and_dialogue_probabilities_preserved(self):
  for mutation in ('blue','walkers','random','guard'):
   with self.subTest(mutation=mutation):
    p=self.candidate_copy()
    def change(d):
     if mutation=='blue':d['conditional_actors']['rival']['initially_visible']=True
     elif mutation=='walkers':d['walkers'].pop()
     elif mutation=='random':d['random_dialogue']['objects7']['ranges'][0]['bytes'][0]=179
     else:d['conditional_actors']['guards']['shift']='EVENT_MET_BILL alone'
    self.mutate_json(p,'event-requirements.json',change);self.reject(p)
 def test_connection_offset_and_false_upper_arrival_do_not_pass(self):
  p=self.candidate_copy();self.mutate_json(p,'west-connection.json',lambda d:d.__setitem__('route4_east_to_city_y_add',9));self.reject(p,'directed boundary')
  p=self.candidate_copy();self.mutate_json(p,'directed-arrival-witness.json',lambda d:d['variants'][0]['reachable_city_west_arrival_y'].append(12));self.reject(p,'directed reachable')
 def test_hidden_rare_candy_and_interior_alias_cannot_be_dropped_or_promoted(self):
  p=self.candidate_copy();self.mutate_json(p,'event-requirements.json',lambda d:d['hidden_events'].clear());self.reject(p,'hidden item inventory')
  p=self.candidate_copy();self.mutate_json(p,'source-aliases.json',lambda d:d['indexed_related_unimplemented_alias_slots'].clear());self.reject(p,'source alias distinction')
 def test_source_words_rosters_and_no_runtime_promotion_are_independent(self):
  p=self.candidate_copy();self.mutate_json(p,'dialogue.json',lambda d:d['texts']['_CeruleanCitySignText']['recipe'][0].__setitem__('text','invented city'));self.reject(p,'text recipe')
  p=self.candidate_copy();self.mutate_json(p,'trainer-parties.json',lambda d:d['variants'][0]['party'][0].__setitem__('level',19));self.reject(p,'trainer rosters')
  p=self.candidate_copy();self.mutate_json(p,'inventory.json',lambda d:d.__setitem__('campaign_ready',True));self.reject(p,'false City')
if __name__=='__main__':unittest.main()

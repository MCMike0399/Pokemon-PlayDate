# Cerulean arrival — frozen source preparation only

Base main82cb207 /Source44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc. **Use generated-04 only**; earlier candidates/checker diagnostics remain historical. Applies nothing to runtime. No Source/main/provider/controller/Zone/actor/session/harness/Simulator/Data/Git/art/baseline writes. Frozen question/matrix/Moon/proposal packets remain untouched. This is ONE City source candidate, not accepted Cerulean, healing, Misty, Bill or a new registered region.

## Exact candidate inventory

| Source surface | Candidate |
|---|---|
| City header/layout | CERULEAN_CITY nativeID3;20×18blocks/360layout bytes;40×36movement cells;640×576original pixels;1280×1152native-size HOST preview |
| Geometry |1440source cells;66map-local canonical quadrant grids;exact foot-tile collision/grass/counter/water/warp tuples |
| Events |10warps,6background events,11objects;all27source tuples preserved;1hidden RareCandy control15,8 |
| Actors |11declared, initial9visible;BLUE hidden, Rocket visible, guard1hidden/guard2visible, Cave blocker visible;3walkers objects4/5/9 |
| Source art |7strips/39frames;78strictRGBA+mask previews plus2terrain previews;source phase0/reference only |
| Text/teams |31exact original source recipes;3BLUE rival-starter variants7/8/9 +Rocket5 exact species/levels/payouts |
| Output |91deterministic candidate artifacts;no runtime registration or catalog promotion |

The full immutable original archive SHA256 was checked first: `e571972fc926dcb65d94fc989299d38109590aa945ed657bf215eac8561afd05`, revision `af519899719f0754965776faac0e836a3b906e6d`. Every79 consumed extracted input hashes against the actual archive bytes, not merely a self-reported pin. source-pin.json and generated-04/source-manifest.json list them. generator-dependencies.json pins three unchanged proven project decoders/mask helpers and the existing immutable Kanto inventory used for target-header identity. Eight prerequisite references (including overlap with the generation inputs) are separately qualified against the same archive; they do not claim those interiors generated.

`tools/generate_cerulean.py` reuses existing source map decoder, original four-shade sprite extraction and border flood-fill mask workflow. It fails unknown/missing/checksum-mismatched input, verifies source header/sprite/INCBIN/frame tuples, publishes only an explicit fresh output directory and has read-only --check exact regeneration. No unpinned master, network, palette threshold guesses, redraws or missing-art fallbacks. Route4 is decoded solely for west-boundary/source arrival analysis and is NOT republished as another map here.

`tools/check_source.py` is independent of the generator/project helper imports. It reconstructs each City source cell from raw block bytes, quadrants, original Pillow-decoded sheet and bottom-left collision; checks source refs/stable keys/terrain metadata; builds both expected terrain images; independently reconstructs all39sprite grids/phase0 pixels/outside-component masks; checks exact source event/text/targetwarp/conditional/alias tuples and literal trainer/branch values. Strict RGBA includes invisible RGB: one transparent RGB mutation still fails. Pixel/mask failures report exact changed-pixel count and bbox. No normalization or baseline rewrite.

## Directed arrival, not a fake rectangle

Source headers encode Route4east offset-4blocks and Citywest offset+4blocks: Route4y→Cityy+8 and reverse Cityy→Route4y-8. west-connection.json contains all54boundary rows (18east/36west); eight static land/pair-compatible cells each direction exist. That count is NOT eight natural approaches.

The source graph in directed-arrival-witness.json starts at actual Moon-exit Route4warp3(24,5), with separately labeled one-cell-down candidate(24,6). It freezes all declared initial actors, honors directional ledges/pair collision, closes all interior warp cells and both known City script-trigger arrays, and allows only this Route4↔City boundary. **Only Citywest y18/19 (Route4east y10/11) are reached.** Upper y12 and lower static strips are not promoted into shortcuts. Two independently checked paths reach City Center EXTERIOR(19,18):95nodes from exact warp cell,94from the down-advance candidate. This matches the original fly/blackout warp point but enables no healing checkpoint. The graph is conservative static geometry; no source interpreter, NPC wandering, battle/encounter/cutscene/time/warp playback or natural-input acceptance. Actual cave-mouth advance policy/native arrival still requires root traversal proof.

## Conditional content stays intact and unimplemented

All scripts/interiors/future exits remain UNIMPLEMENTED. Imported geometry must never become successful no-op dialogue or an empty invented City. Candidate data preserves northRoute24/southRoute5/eastRoute9 declarations, all10interior target tuples, source bridge/rocket triggers and aliases. A future bounded arrival adapter must physically source-qualify/block/diagnose unfinished controls, not silently expose them.

- BLUE object1 initiallyOFF; bridge20/21,6 shows/approaches him until EVENT_BEAT_CERULEAN_RIVAL. All3original four-mon teams retained: Pidgeotto18/Abra15/Rattata15 +rivalstarter17, payout595. Source sprite coordinates store +4 via object_event: raw mapX25 is canonical sourcex21, not worldx25. Departure paths depend on playerx20/21. Actual win/loss/cleanup/music and source text branches remain unimplemented.
- Rocket object2 initiallyON at30,8; default triggers30,7/30,9. Team5 is Machop17/Drowzee17,payout510. Flag/TM28DIG/fullbag retry/once/guard swap/hide are source requirements, not generic trainer-text flattening.
- Guard1object6 initiallyOFF, guard2object11ON. The guard shift in BillsHouse happens after SUCCESSFUL S_S_TICKET GiveItem/flag, NOT merely EVENT_MET_BILL; fullbag failure does not shift. CeruleanHideRocket also performs the swap. Cave blocker object10 remains until HallOfFame's explicit hide.
- Three actual walkers4/5/9 retain source selector/range/art. NPC7/Slowbro8 flavor branches read hRandomAdd with exact180/100 and180/120/60 byte thresholds. Those are source byte intervals, not a newly certified independent RNG policy. Printed Sonicboom/Punch/Withdraw are flavor text, not applied battle moves.
- Hidden RareCandy15,8 remains an explicit unimplemented atomic pickup/once/fullbag/source receipt+item-effect dependency. No item is granted here.
- CERULEAN_TRASHED_HOUSE_COPY native slot69 points to original TrashedHouse header/objects. source-aliases.json retains the distinct unimplemented copy slot; no phantom second City/interior is instantiated. City itself has no block alias.

Existing RED/BLUE/Oak/Pallet remain untouched. protected-source-inputs.json records321selected source/art inputs and verifies whole Source is still exact44bd before/after generation. Raw BLUE phase0 previews are source references only: future runtime must reuse protected existing BLUE standing and approved legacy-phase walking resolver, NEVER replace it with the raw faithful-gray source preview to make comparisons green. Current shared NPC styles and source palettes/masks likewise need explicit reuse. No candidate PNG is called nativeSDK-reviewed or part of the accepted2494catalog.

## Required next outcomes

prerequisites.json and prerequisite-references.json separate meaningful access from terrain. Root chooses the coherent runtime scope after Brock.

- Arrival needs one closed ImportedContent/ImportedMaps authority, explicit location/actor/tile ownership, actual connection/native pose/SaveContinue/resource proof and safe unfinished-control boundaries. No competing world factory or preload-all-maps controller.
- Healing/PC requires actual CeruleanPokecenter geometry/source actors/text/hiddenPC, an explicit HealingComposition whitelist only after source machine/112cell/anchor+native review, existing authoritative heal/checkpoint/directPC owners and actual cancellation/fullrestore/save cases. Only a successful guarded heal may update the source19,18checkpoint.
- Mart requires the interior/clerk/source prices and original stock (POKE_BALL,POTION,REPEL,ANTIDOTE,BURN_HEAL,AWAKENING,PARLYZ_HEAL), with qualified field Repel effects before successful-use claims.
- Misty requires actual Gym/trainers/text/Cascade badge/TM11Bubblebeam fullbag retry and trusted real terminal/XP/EV/learning/save/blackout/native proof. Bill requires Route24/25/Nugget/BillsHouse scene and capacity-aware SS_TICKET-before-guard transition.
- Original teams/intended moves need a current GenV exposure audit. In current44bd learnsets Pidgeotto18 includes Whirlwind17 and Abra15 is Teleport-only; CityBLUE makes their correct trainer behavior a direct story dependency, not merely optional TM04. This is literal exposure/source policy, NOT mechanics verification or a reason to expand the active Brock batch.
- Full original151/GenV/campaign/postgame/audio/device goals remain unchanged. One terrain map is not Cerulean acceptance.

## Reproduction and evidence

Requires existing pinned Pillow12.0.0 environment; no downloads or hidden skips. Explicit project/reference/archive inputs, fresh output required:

```
PYTHONDONTWRITEBYTECODE=1 "$PYTHON" tools/generate_cerulean.py --project "$PROJECT" --reference "$POKERED_REFERENCE" --archive "$POKERED_ARCHIVE" --check generated-04
PYTHONDONTWRITEBYTECODE=1 "$PYTHON" tools/check_source.py --reference "$POKERED_REFERENCE" --archive "$POKERED_ARCHIVE" --candidate generated-04 --pin source-pin.json
CERULEAN_PROJECT="$PROJECT" POKERED_REFERENCE="$POKERED_REFERENCE" POKERED_ARCHIVE="$POKERED_ARCHIVE" PYTHONDONTWRITEBYTECODE=1 "$PYTHON" -m unittest discover -s tests -v
```

Final reports: reproduction-check.json/source-oracle-reviewed.json/host-tests-reviewed.log.13host tests PASS/0skip, including actual archive/extracted-source mutation, canonical grid/collision/provenance, strict one native pixel and one mask pixel with count/bbox, invisibleRGB, wrong warp/sprite alias, BLUE/guards/walkers/random thresholds, hidden/alias omission, bogus text/team, wrong connection/false upperarrival and false runtime qualification. All91artifacts reproduce exactly and all79primary inputs verify against the immutable archive. Source89earlier artifact counts/checker diagnostics remain historical, not substituted for current proof. No SDK/native/Simulator/device was run and no runtime integration is supplied.

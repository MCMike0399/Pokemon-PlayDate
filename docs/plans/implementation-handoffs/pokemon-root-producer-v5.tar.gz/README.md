# Explicit preBrock move producer migrations — staged only

Only files in manifest.json are root-owned integration files; NEVER copy this entire tools/Source snapshot. It contains an older host harness used for isolated producer checks. Live Source/host ownership remains serialized by root. Current production Source is still accepted epoch2 while three natural starter jobs run.

Epoch3: exactly six rows change: five bounded rule fields(ElectroBall,Assurance,Endeavor,SuckerPunch,RagePowder) and GenV SweetScent Eva-1. All original scalars retained. Epoch4: only Bide117 added as425th row for Blue TM34; every424 prior row byte-identical. Epoch5: only Captivate gains oppositeSex attemptRule, existing SpA-2 unchanged. Existing constructor gains only three optional typed rule fields.

Immutable historical424 ability metadata artifact and ORIGINAL scalar/effect hashes are unchanged. Metadata from five pinned PS base→Gen5 sources independently matches all425 rows (supplemental Bide defined explicitly). Exact added Bide row must validate before removing it from historical424 projection; unexpected rows and mutated added fields fail. Per-rule introduction epochs distinguish legitimate complete older producer versions from missing/deleted current metadata. Current marker is supplied to the historical acceptance checker; rows-only inference is not an acceptance substitute.

Root independently ran372 snapshot host checks0skips, including12 new strict producer groups and original360 checks. This snapshot predates the21 expanded journey host groups; rerun the FULL live integrated suite after merging. Wrong/deleted rule metadata, changed PP/power/accuracy/payloads, old SweetScent restoration, missing Bide or unknown rows all fail. Old2/3/4 inverse projections retain original424 hash. No original golden hash was changed to hide a failure.

Generated moves SHAc52fe6187a112fab18520899ffb594404941cb2ffae27cc3e6301c5ce94df61f. Stagev3(6063f750...) andv4(8773180a...) remain separate for batch/Bide helpers. Need actual engine packets for runtime semantics; generated data/host proofs are not mechanics acceptance.

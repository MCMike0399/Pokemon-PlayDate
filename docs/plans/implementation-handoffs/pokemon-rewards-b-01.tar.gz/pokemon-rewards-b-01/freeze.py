from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
base=json.loads((P/'baseline.json').read_text());shared=json.loads((P/'shared-hunks.json').read_text())
new=['Source/battle/rewards.lua','Source/dev/rewardContracts.lua']
manifest={'schema':1,'packet':'rewards-b-01','base_source_sha256':base['source_sha256'],'new_source_files':new,
 'shared_files':{i['path']:{'base_sha256':hashlib.sha256((P/'originals'/i['path']).read_bytes()).hexdigest(),'after_sha256':hashlib.sha256((P/i['path']).read_bytes()).hexdigest()}for i in shared},'files':{}}
for f in sorted(P.rglob('*')):
 if not f.is_file()or f.name=='manifest.json'or'__pycache__'in f.parts:continue
 rel=f.relative_to(P).as_posix()
 if rel.startswith('Source/')and rel not in new and rel not in manifest['shared_files']:continue
 manifest['files'][rel]=hashlib.sha256(f.read_bytes()).hexdigest()
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest())

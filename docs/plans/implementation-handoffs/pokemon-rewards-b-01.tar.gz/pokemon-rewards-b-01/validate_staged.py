#!/usr/bin/env python3
"""Private guarded B composition. Compile only unless root explicitly --execute."""
import argparse,hashlib,importlib.util,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
P=Path(__file__).resolve().parent
MUTATIONS={
 'split-ev':('Source/battle/rewards.lua','local ev,delta,wasted=IndividualStats.addEffort(mon.evs,yield)','local divided=copy(yield);for key,value in pairs(divided)do divided[key]=value//alive end;local ev,delta,wasted=IndividualStats.addEffort(mon.evs,divided)'),
 'exclude100':('Source/battle/rewards.lua','if set[mon]and mon:isAlive()then','if set[mon]and mon:isAlive()and mon.level<100 then'),
 'repeat-foe':('Source/battle/rewards.lua','battle.awardedEnemies[plan.foe]=true','battle.awardedEnemies[plan.foe]=nil'),
 'early-live':('Source/battle/rewards.lua','            record(candidate) -- No fallible candidate validation follows commit.','            candidate:recalcStats();record(candidate) -- mutant: premature live stats.'),
 'xp-before-ev':('Source/battle/rewards.lua','candidateRecord.evs=ev','candidateRecord.evs=copy(mon.evs)'),
 'live-preflight':('Source/battle/rewards.lua','local leveled,result=candidate:gainXP(amount)','local leveled,result=mon:gainXP(amount)'),
 'total511':('Source/domain/individualStats.lua','    local room=510','    local room=511'),
 'wrong-order':('Source/domain/individualStats.lua','{"hp","atk","def","spe","spa","spd"}','{"hp","atk","def","spa","spd","spe"}'),
 'no-hud-hold':('Source/battle/rewards.lua','local held=owner and not owner.closed and owner.holds[mon]','local held=nil'),
 'no-return-flush':('Source/battle/battle.lua','    assert(self:flushRewards()) -- Canonical field stats before any return/evolution/rest callback.','    -- mutant: return callback precedes canonical stat flush.'),
}
def apply_hunks(root,items):
 for item in items:
  path=root/item['path'];text=path.read_text()
  for h in item['hunks']:
   assert text.count(h['old'])==1,'shared hunk base changed: '+item['path'];text=text.replace(h['old'],h['new'],1)
  path.write_text(text)
def main():
 p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--case',choices=['contracts','reward-hud'],default='contracts');p.add_argument('--mutation',choices=sorted(MUTATIONS));p.add_argument('--with-residual',type=Path);a=p.parse_args()
 project=a.project.resolve();sys.path.insert(0,str(project));from tools.harness import run as runner
 from tools.harness.protocol import atomic_json
 from tools.harness import journeys
 manifest=json.loads((P/'manifest.json').read_text());original=runner.prepare;original_journey=journeys.run
 correction=a.with_residual.resolve()if a.with_residual else None
 def prepare(project,sdk,out,session):
  for rel,digest in manifest['files'].items():assert hashlib.sha256((P/rel).read_bytes()).hexdigest()==digest,'B packet changed: '+rel
  meta=original(project,sdk,out,session)
  apply_hunks(out,json.loads((P/'shared-hunks.json').read_text()))
  for rel in manifest['new_source_files']:
   path=out/rel;assert not path.exists(),'new B file already exists: '+rel;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(P/rel,path)
  if correction:
   cm=json.loads((correction/'manifest.json').read_text())
   for rel,digest in cm['files'].items():assert hashlib.sha256((correction/rel).read_bytes()).hexdigest()==digest,'correction changed: '+rel
   apply_hunks(out,json.loads((correction/'shared-hunks.json').read_text()))
   for rel in cm['new_source_files']:
    path=out/rel;assert not path.exists();shutil.copyfile(correction/rel,path)
   assert 'function BattleConditions:roost()'in(out/'Source/battle/conditions.lua').read_text(),'accepted Roost dependency required'
  if a.mutation:
   rel,old,new=MUTATIONS[a.mutation];path=out/rel;text=path.read_text();expected=2 if a.mutation=='exclude100'else 1;assert text.count(old)==expected;path.write_text(text.replace(old,new))
  pdx=out/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(meta['original_pdxinfo']);meta['source_sha256']=runner.fingerprint(out);meta['build_id']=meta['revision']+':'+meta['source_sha256']
  atomic_json(out/'source-manifest.json',{str(f.relative_to(out/'Source')):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted((out/'Source').rglob('*'))if f.is_file()and f.relative_to(out/'Source').as_posix()!='dev/harness_build.lua'})
  pdx.write_text(generated);lines=[]
  for key in ['protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir']:
   value=meta[key];lines.append('    '+key+' = '+('true'if value is True else'false'if value is False else json.dumps(value))+',')
  (out/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(lines)+'\n}\n')
  meta.update(compiled_source_sha256=runner.fingerprint(out,exclude_generated=False),reward_packet_sha256=hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),reward_mutation=a.mutation,residual_packet_sha256=hashlib.sha256((correction/'manifest.json').read_bytes()).hexdigest()if correction else None)
  with(out/'reward-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(out/'Source'),meta['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
  atomic_json(out/'build.json',meta);return meta
 def journey(client,scenario,evidence_dir,*args,**kwargs):
  if scenario.get('journey',{}).get('name')=='reward-hud':
   spec=importlib.util.spec_from_file_location('private_reward_hud',P/'tools/harness/reward_hud.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module.run(client,scenario,evidence_dir)
  return original_journey(client,scenario,evidence_dir,*args,**kwargs)
 runner.prepare=prepare;runner.PROJECT=project;journeys.run=journey
 try:return runner.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(P/'scenarios'/(a.case+'.json')),commands=[],build_only=not a.execute,timeout=180,ready_timeout=20,max_frames=3600))
 finally:runner.prepare=original;journeys.run=original_journey
if __name__=='__main__':raise SystemExit(main())

'use strict';
const path=require('path');const {Battle}=require(path.join(path.resolve(process.argv[2]),'dist/sim'));
const set=(species,ability,level,moves)=>({species,ability,gender:'M',nature:'Hardy',level,ivs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},moves});
const rows=[];for(const curl of [false,true]){
 const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,4],p1:{name:'RAW',team:[set('Nidoran-M','Rivalry',50,['defensecurl','rollout','splash'])]},p2:{name:'TARGET',team:[set('Snorlax','Immunity',100,['splash'])]}});if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');
 const events=[],original=b.runEvent;b.runEvent=function(...args){const result=original.apply(this,args);if(args[0]==='BasePower'&&args[3]?.id==='rollout')events.push({turn:this.turn,raw:args[4],modified:result});return result;};
 if(curl)b.makeChoices('move 1','move 1');for(let i=0;i<3&&!b.ended;i++)b.makeChoices('move rollout','move splash');
 rows.push({defenseCurl:curl,events,log:b.log.filter(x=>!x.startsWith('|t:|'))});b.destroy();
}console.log(JSON.stringify({revision:'9b136a8c8cdb860a8ab96fa063f906604e352547',note:'Actual choices establish Defense Curl and Rollout. Custom original151 learnset fixture; raw is observed argument to actual BasePower event before callback chain; no battle callback replacement.',rows},null,2));

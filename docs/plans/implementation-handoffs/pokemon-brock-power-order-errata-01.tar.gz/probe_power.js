'use strict';
const path=require('path');
const base=path.resolve(process.argv[2]);
const {Battle}=require(path.join(base,'dist/sim'));
function make(gender='M',ability='Rivalry'){
 const set=(species,ab,gender,moves)=>({species,ability:ab,gender,nature:'Hardy',level:50,ivs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},moves});
 const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,4],p1:{name:'ACTOR',team:[set('Nidoran-M',ability,'M',['mudsport','thundershock','splash','rollout'])]},p2:{name:'TARGET',team:[set('Charmander','Blaze',gender,['mudsport','splash'])]}});
 if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');return b;
}
const rows=[];
for(const gender of ['M','F'])for(const count of [0,1,2]){
 const b=make(gender),p=b.p1.active[0],e=b.p2.active[0];
 if(count===1)b.makeChoices('move 1','move 2');
 if(count===2)b.makeChoices('move 1','move 1');
 const move=b.dex.getActiveMove('thundershock');
 const power=b.runEvent('BasePower',p,e,move,40,true);
 const damage=b.actions.getDamage(p,e,{...move,willCrit:false});
 rows.push({gender,count,activeMud:p.volatiles.mudsport!==undefined,enemyMud:e.volatiles.mudsport!==undefined,power,damage,fixture:{p1:{species:p.species.id,gender:p.gender,ability:p.ability,stats:p.storedStats},p2:{species:e.species.id,gender:e.gender,ability:e.ability,stats:e.storedStats}},log:b.log.filter(x=>!x.startsWith('|t:|'))});b.destroy();
}
console.log(JSON.stringify({revision:'9b136a8c8cdb860a8ab96fa063f906604e352547',format:'gen5customgame',note:'Actual pinned engine and real makeChoices Mud Sport turns; original151 species, explicit IV0/EV0/Hardy sexes. Custom learnsets for isolated rule qualification, not acquisition proof. BasePower is queried through exact getDamage BasePower event path, no callback replacement. getDamage also runs real calculation with explicit no-crit fixture, ordinary sampled variance.',rows},null,2));

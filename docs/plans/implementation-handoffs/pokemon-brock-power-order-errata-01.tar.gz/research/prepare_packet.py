from pathlib import Path
import difflib,shutil
s=Path(__file__).resolve().parent
combined=Path('/private/tmp/pokemon-brock-integration-02')
sex=Path('/private/tmp/pokemon-brock-sex-abilities-compile-04')
for d in ('base/Source/battle','base/Source/dev','Source/battle','Source/dev','patches'): (s/d).mkdir(parents=True,exist_ok=True)
for name in ('battle/battle.lua','battle/conditions.lua','dev/earlyCombatContracts.lua'):
 shutil.copy2(combined/'Source'/name,s/'base/Source'/name)
shutil.copy2(sex/'Source/battle/effects.lua',s/'base/Source/battle/effects.lua')
# Base is the accepted sex body plus charge owner's exact appended weather API/predicate.
p=s/'base/Source/battle/effects.lua';t=p.read_text();charge=Path('/private/tmp/pokemon-brock-charge-lock-01/Source/battle/effects.lua').read_text();apis=charge[charge.index('-- Canonical GenV query seam.'):charge.index('function BattleEffects:basePower')]
t=t.replace('function BattleEffects:basePower',apis+'function BattleEffects:basePower',1).replace('if self.weather and move.sandWeakened then ratio=chain(ratio,2048) end','if move.sandWeakened and select(2,BattleEffects.solarPolicy(self:weatherId()))==2048 then ratio=chain(ratio,2048) end');p.write_text(t)
for p in (s/'base/Source').rglob('*.lua'):
 dst=s/'Source'/p.relative_to(s/'base/Source');dst.write_bytes(p.read_bytes())
p=s/'Source/battle/conditions.lua';t=p.read_text();start=t.index('function BattleConditions:basePower(');end=t.index('function BattleConditions:mudSport()',start)
t=t[:start]+'''-- Raw move-defined multipliers precede the single BasePower modifier chain.
function BattleConditions:rawPower(mon,move,power)
    power=power or move.power;local state=self.members[mon] or {}
    if move.rollout then power=power*2^((state.rollout and state.rollout.hits) or 0)*(state.defenseCurl and 2 or 1) end
    return power
end
-- Pure active-holder observation; withdrawal/defeat cannot contribute a modifier.
function BattleConditions:mudSportCount()
    local count=0
    for _,active in ipairs({self.battle.player,self.battle.enemy}) do
        if alive(active) and (self.members[active] or {}).mudSport then count=count+1 end
    end
    return count
end
'''+t[end:];p.write_text(t)
p=s/'Source/battle/battle.lua';t=p.read_text().replace('self.conditions:basePower(attacker,move,power)','self.conditions:rawPower(attacker,move,power)');p.write_text(t)
p=s/'Source/battle/effects.lua';t=p.read_text();old='    if move.sandWeakened and select(2,BattleEffects.solarPolicy(self:weatherId()))==2048 then ratio=chain(ratio,2048) end\n';assert t.count(old)==1;t=t.replace(old,'');needle='    if power>0 and ratio~=4096 then return math.max(1,round(power,ratio)) end';assert t.count(needle)==1
t=t.replace(needle,'''    -- Pinned PS Gen5 BasePower callback priorities: Rivalry24, Mud Sport1,
    -- Solar Beam0. Chain Q12 ratios first, then round the raw power once.
    if power>0 and move.type=="electric" then
        for _=1,self.battle.conditions:mudSportCount() do ratio=chain(ratio,1352) end
    end
    if move.sandWeakened and select(2,BattleEffects.solarPolicy(self:weatherId()))==2048 then ratio=chain(ratio,2048) end
'''+needle);p.write_text(t)
p=s/'Source/dev/earlyCombatContracts.lua';t=p.read_text();import re
t,n=re.subn(r'b.conditions:basePower\(b.player,moveData\.(\w+)\)',r'b:effectiveMovePower(moveData.\1,b.player,b.enemy)',t);assert n==7,n;p.write_text(t)
for p in (s/'base/Source').rglob('*.lua'):
 rel=p.relative_to(s/'base');new=s/rel
 diff=''.join(difflib.unified_diff(p.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(rel),tofile=str(rel),n=3));(s/'patches'/('__'.join(rel.parts)+'.patch')).write_text(diff)
print('Prepared four narrow patch files; full staged bodies are context only.')

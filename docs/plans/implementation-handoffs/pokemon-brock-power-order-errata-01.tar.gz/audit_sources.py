#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--showdown',type=Path,required=True);a=p.parse_args();s=Path(__file__).resolve().parent
m=json.loads((s/'source-manifest.json').read_text())
for row in m['references']:
 assert hashlib.sha256((s/row['path']).read_bytes()).hexdigest()==row['sha256'],'reference drift '+row['path']
for row in m['compiled_engine_inputs']:
 assert hashlib.sha256((a.showdown/row['file']).read_bytes()).hexdigest()==row['sha256'],'engine drift '+row['file']
print('Verified 4 pinned C inputs + 10 actual compiled-engine/source inputs')

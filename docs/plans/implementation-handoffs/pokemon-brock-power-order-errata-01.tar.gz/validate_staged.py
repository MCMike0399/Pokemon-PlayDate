#!/usr/bin/env python3
"""Private compile by default; only root may explicitly request execution."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__)
for key in ('project','output'):p.add_argument('--'+key,required=True)
p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--charge-stage',type=Path);a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def patch(output,path):
 result=subprocess.run(['git','apply','-p0','--check',str(path)],cwd=output,capture_output=True,text=True)
 if result.returncode:
  reverse=subprocess.run(['git','apply','-p0','--reverse','--check',str(path)],cwd=output,capture_output=True,text=True)
  assert reverse.returncode==0,'patch conflict '+str(path)+': '+result.stderr;return
 subprocess.run(['git','apply','-p0',str(path)],cwd=output,check=True)
def prepare(project,sdk,output,session):
 metadata=original(project,sdk,output,session)
 if a.charge_stage:
  # Only the exact weather query/predicate dependency, not the charge lifecycle.
  target=output/'Source/battle/effects.lua';text=target.read_text();owner=(a.charge_stage/'Source/battle/effects.lua').read_text()
  api=owner[owner.index('-- Canonical GenV query seam.'):owner.index('function BattleEffects:basePower(')]
  assert hashlib.sha256(api.encode()).hexdigest()==manifest['charge_weather_api_sha256'],'charge API drift'
  if 'function BattleEffects:weatherId()'not in text:
   text=text.replace('function BattleEffects:basePower(',api+'function BattleEffects:basePower(',1)
   old='if self.weather and move.sandWeakened then ratio=chain(ratio,2048) end';assert text.count(old)==1
   text=text.replace(old,'if move.sandWeakened and select(2,BattleEffects.solarPolicy(self:weatherId()))==2048 then ratio=chain(ratio,2048) end');target.write_text(text)
 effects=(output/'Source/battle/effects.lua').read_text();assert 'function BattleEffects:weatherId()'in effects and 'attacker:getSex()'in effects,'requires composed sex and charge weather APIs'
 battle=(output/'Source/battle/battle.lua').read_text();assert 'if move.category=="status" or (move.power==0 and not move.powerRule) then return 0 end'in battle,'requires early0 guard'
 for row in manifest['patches']:
  path=stage/row['path'];assert sha(path)==row['sha256'];patch(output,path)
 for row in manifest['new_source']:
  path=stage/row['path'];assert sha(path)==row['sha256'];shutil.copy2(path,output/row['path'])
 main=output/'Source/main.lua';text=main.read_text();anchor='import "dev/catalog"';assert text.count(anchor)==1
 if 'import "dev/powerOrderContracts"'not in text:text=text.replace(anchor,'import "dev/powerOrderContracts"\nContracts.register("basepower-order",PowerOrderContracts.run)\n'+anchor,1)
 main.write_text(text)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated);values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['power_order']=manifest
 with(output/'power-order-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

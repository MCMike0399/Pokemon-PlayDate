import hashlib,json,re,unittest
from pathlib import Path
S=Path(__file__).resolve().parent
class PacketTests(unittest.TestCase):
 def test_packet_hashes(self):
  m=json.loads((S/'manifest.json').read_text())
  for row in m['patches']+m['new_source']:self.assertEqual(hashlib.sha256((S/row['path']).read_bytes()).hexdigest(),row['sha256'])
 def test_actual_engine_vectors(self):
  data=json.loads((S/'actual-ps-order-02.json').read_text());expected=[50,17,5,30,10,3,40,13,4,40,13,4]
  self.assertEqual([r['result']for r in data['rows']],expected)
  self.assertEqual([r['result']for r in data['solar']],[150,150,75,75,75])
 def test_real_callback_order_and_ratios(self):
  data=json.loads((S/'actual-ps-order-02.json').read_text())
  self.assertEqual([c['priority']for c in data['rows'][2]['calls']],[24,1,1])
  self.assertEqual([c['afterQ12']for c in data['rows'][2]['calls']],[5120,1690,558])
  self.assertEqual([c['effect']for c in data['solar'][2]['calls']],['rivalry','solarbeam'])
  self.assertEqual([c['priority']for c in data['solar'][2]['calls']],[24,0])
 def test_old_double_round_mutant_fails_actual_engine_vector(self):
  # Reproduce the OLD bug only; oracle is captured real engine, not Python SDK.
  halfdown=lambda value,ratio:(value*ratio+2047)//4096
  old=halfdown(halfdown(40,1352),5120)
  actual=json.loads((S/'actual-ps-order-02.json').read_text())['rows'][1]['result']
  self.assertEqual(old,16);self.assertEqual(actual,17);self.assertNotEqual(old,actual)
 def test_all_existing_component_expectations_preserved(self):
  old=(S/'base/Source/dev/earlyCombatContracts.lua').read_text();new=(S/'Source/dev/earlyCombatContracts.lua').read_text()
  expected,n=re.subn(r'b.conditions:basePower\(b.player,moveData\.(\w+)\)',r'b:effectiveMovePower(moveData.\1,b.player,b.enemy)',old)
  self.assertEqual(n,7);self.assertEqual(new,expected)
 def test_raw_power_and_early_zero(self):
  body=(S/'Source/battle/battle.lua').read_text();start=body.index('function Battle:effectiveMovePower(');end=body.index('\nend',start)
  self.assertIn('if move.category=="status" or (move.power==0 and not move.powerRule) then return 0 end',body[start:end])
  self.assertIn('self.conditions:rawPower(attacker,move,power)',body[start:end]);self.assertNotIn('conditions:basePower',body)
  conditions=(S/'Source/battle/conditions.lua').read_text();self.assertNotIn('function BattleConditions:basePower',conditions)
 def test_actual_rollout_raw_multipliers(self):
  r=json.loads((S/'actual-ps-rollout-03.json').read_text())['rows']
  self.assertEqual([(x['raw'],x['modified'])for x in r[0]['events']],[(30,37),(60,75)])
  self.assertEqual([(x['raw'],x['modified'])for x in r[1]['events']],[(60,75),(120,150)])
 def test_only_declared_effect_body_changed(self):
  old=(S/'base/Source/battle/effects.lua').read_text();new=(S/'Source/battle/effects.lua').read_text()
  def outside(s):a=s.index('function BattleEffects:basePower(');b=s.index('function BattleEffects:statusImmunity(',a);return s[:a],s[b:]
  self.assertEqual(outside(old),outside(new))
if __name__=='__main__':unittest.main(verbosity=2)

# BasePower rounding errata — staged, runtime acceptance pending

The current split pipeline rounds Mud Sport before Rivalry. The actual pinned Showdown Gen5 engine returns power **17** for Electric40 × same-sex Rivalry × one Mud Sport; the old pipeline returns16. This packet uses one BasePower Q12 chain and rounds once. No move data, art, durable stats, RNG rules or other Effects methods change.

Apply the four `patches/*.patch` files with `git apply -p0` after sex/OwnTempo and charge composition. Copy only **Source/dev/powerOrderContracts.lua**, then import it and register `Contracts.register("basepower-order",PowerOrderContracts.run)` in root's main composition. The other Source bodies are review contexts, NOT whole-file overlays. `manifest.json` records exact before/after source hashes refreshed against root's read-only integration-02 after sex/OwnTempo/charge merge. No live checkout was edited.

The sole production pipeline is `movePower → conditions:rawPower → effects:basePower`. `rawPower` only multiplies Rollout/Defense Curl; `mudSportCount()` observes living active holders. Effects chains Rivalry(priority24), each Mud Sport(priority1), Solar Beam weather(priority0), then rounds raw power once. The status/fixed-power early0 guard remains before this pipeline. There is no old rounded Conditions.basePower facade. All **seven** earlyCombat component call sites (five Mud Sport including calcDamage input, two Rollout) migrate to the authoritative observer without changing expected numbers; the production call is the eighth migrated call.

Validation performed:

- Actual compiled PS engine probes personally executed: `actual-ps-power-01.json`, `actual-ps-order-02.json`, `actual-ps-rollout-03.json`. Node v26.8.1, Gen5customgame, pinned revision9b136a8c8cdb860a8ab96fa063f906604e352547. Inputs are original151 species with explicitly controlled sex/IV0/EV0/Hardy and custom learnsets, NOT acquisition/legality proof.
- The richer probe records original chainModify calls without replacing their arithmetic or rule callbacks. Real makeChoices establishes Mud Sport. Same-sex powers50/17/5; opposite30/10/3; ordinary Static Pikachu40/13/4; genderless target40/13/4. Ratios same-sex4096→5120→1690→558. Solar weather fixtures preserve actual callback order24→0 and powers150/150/75/75/75 for none/sun/rain/sand/hail.
- Real Defense Curl/Rollout input choices confirm raw30→60 and60→120 before Rivalry produces37→75 and75→150. Some third attacks miss and correctly emit no BasePower event; no event was fabricated.
- `test_packet.py`:8 host groups PASS,0 skipped (`host-tests-02.log`), including explicit old-double-round mutant16 rejected against actual reference17, unchanged legacy expected values, exact unrelated Effects preservation and early0 guard.
- `audit_sources.py`:4 pinned C inputs and10 actual engine/source hashes PASS.
- Compile-only `/private/tmp/pokemon-brock-power-order-compile-03` PASS against current combined root Source, with no dependency overlays. No Simulator or SDK contract execution by worker.

Eight new production SDK groups await root: four reference combo values17/5/10/3; ordinary Static/Pikachu Electro Ball13; genderless neutral/Mud isolated results; solar policy; Rollout raw multipliers; observer purity including opposite current direction; living-active holder removal and status/fixed early0.

## Reproduction and root runtime

```sh
python3 /private/tmp/pokemon-brock-power-order-errata-01/audit_sources.py --showdown /private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547
node /private/tmp/pokemon-brock-power-order-errata-01/probe_order.js /private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547 > /private/tmp/pokemon-power-order-replay.json
python3 /private/tmp/pokemon-brock-power-order-errata-01/test_packet.py
python3 /private/tmp/pokemon-brock-power-order-errata-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-power-order-root-build
```

Default is compile only. Root alone may add `--execute` with a fresh output path. It uses the ordinary owned harness and all registered suites; `contracts.json` invokes the production contracts operation. The new8 groups must pass alongside unchanged earlyCombat, sex, Bide, charge, held-item and observer regressions. For visual regression retain ordinary real-input campaign/battle jobs; the custom impossible Nidoran/Mud Sport combination is labeled a controlled rule fixture, not a new naturally available encounter. The pure observer contract separately verifies the real Electro Ball fallback40 and Mud13 used by root's observer regression.

The optional `--charge-stage PATH` installs only charge's exact verified weather-query API/predicate when compiling a sex-composed project without that dependency. It does not install/claim charge lifecycle integration. Current integration-02 already includes charge, so omit it.

## Source qualification and limitation

Primary maintained engine: [pinned BasePower calculation](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/sim/battle-actions.ts), [chainModify/event final rounding](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/sim/battle.ts), [Gen5 Mud Sport](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/mods/gen5/moves.ts), [Rivalry](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/abilities.ts), [Solar Beam and Rollout callbacks](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/moves.ts). Source and loaded dist hashes, immutable archive hash and C pins are in `source-manifest.json`.

Independent native-decompilation cross-check: pinned `bw_btl_server_flow.c` ServerEvent_GetMovePower dispatches raw-power handlers0x37, then Q12 ratio handlers0x38, then performs one fixed_round(power,ratio). `bw_ability_handlers.c` Rivalry modifies ratio0x31 at event0x38. These support one shared-ratio boundary. HOWEVER `bw_btl_field.c` maintains one event per field-effect ID with multiple dependent owners; the pinned tree provides only field_handlers.h, not the field-handler implementation. Its callback may differ from PS's one volatile per owner. Therefore **two-Mud-Sport stacking is observed/preserved PS Gen5 behavior, not proven exact-cartridge behavior**. Single-Mud-Sport rounding is concrete independently of that unresolved stacking discrepancy. No emulator/cartridge execution or full native-equivalence claim is made.

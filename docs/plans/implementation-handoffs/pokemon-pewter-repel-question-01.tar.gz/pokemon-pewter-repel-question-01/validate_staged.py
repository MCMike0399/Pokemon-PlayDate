#!/usr/bin/env python3
"""Owned source overlay; compile-only default. --execute exclusively for root Simulator owner."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario',type=Path);a=p.parse_args()
stage=Path(__file__).resolve().parent;project=a.project.resolve();sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def prepare(project,sdk,output,session):
    for entry in manifest['source_files']:
        relative=entry['path'];assert relative.startswith('Source/')and'..'not in Path(relative).parts
        assert sha(stage/relative)==entry['sha256'],'staged owned source drift'
        live=project/relative
        if entry['operation']=='modify':assert sha(live)in(entry['before_sha256'],entry['sha256']),'owned source changed: root merge/review required'
        else:assert not live.exists()or sha(live)==entry['sha256'],'new suite already has different owner'
    metadata=original(project,sdk,output,session)
    for entry in manifest['source_files']:
        destination=output/entry['path'];destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(stage/entry['path'],destination)
    main=output/'Source/main.lua';text=main.read_text();marker='import "dev/catalog"';assert text.count(marker)==1
    text=text.replace(marker,'import "dev/pewterQuestionContracts"\nContracts.register("pewter-question",PewterQuestionContracts.run)\n'+marker,1);main.write_text(text)
    info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    info.write_text(generated)
    values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        values.append('    '+key+' = '+('true'if metadata[key]is True else json.dumps(metadata[key],ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['pewter_question_packet']=manifest['source_files']
    with (output/'question-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:
    code=harness.run(SimpleNamespace(sdk=a.sdk,output=str(a.output),scenario=str(a.scenario or stage/'sdk-scenario.json'),commands=[],build_only=not a.execute,timeout=60,ready_timeout=20,max_frames=1800))
finally:harness.prepare=original
raise SystemExit(code)

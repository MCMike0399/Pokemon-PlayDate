PewterQuestionContracts={}
local gfx <const> = playdate.graphics
local ID <const> = "pokered:PEWTER_CITY:objects:4"
local PROMPT <const> = "Psssst! Do you know what I'm doing?"
local YES <const> = "That's right! It's hard work!"
local NO <const> = "I'm spraying REPEL to keep POKEMON out of my garden!"
local function eq(a,b)assert(a==b,"expected "..tostring(b)..", got "..tostring(a))end
local function same(a,b,path)
    path=path or "record";eq(type(a),type(b))
    if type(a)~="table"then eq(a,b);return end
    for k,v in pairs(a)do same(v,b[k],path.."."..tostring(k))end
    for k in pairs(b)do assert(a[k]~=nil,path.." missing "..tostring(k))end
end
local function model(g)
    return {session=assert(SessionCodec.encode(g.session,{root="overworld",overworld="explore",settled=true})),
        rules=RulesRNG.toData(),world=g.session:worldRngData(),actors=g.session:actorData()}
end
local function complete(g)
    eq(g.machine:getCurrent(),"dialog");local dialog=g.machine:get("dialog")
    dialog.dialog.onComplete();dialog:handleInput()
end
local function prompt(g,event)
    eq(g.machine:getCurrent(),"dialog");eq(event.phase,"dialog");eq(event.waiting,"_PewterCitySuperNerd2DoYouKnowWhatImDoingText")
    eq(g.machine:get("dialog").dialog.lines[1],PROMPT);eq(event.menu.isActive,false)
    complete(g);eq(g.machine:getCurrent(),"event");eq(event.phase,"question")
    eq(event.menu.selectedIndex,1);eq(event.menu.options[1],"YES");eq(event.menu.options[2],"NO")
end
local function interact(g)
    assert(KantoWorld.tryInteract(g),"production interaction should claim source actor")
    eq(g.machine:getCurrent(),"dialog");eq(g.machine:get("event").id,ID)
end
local function scene(fn)
    local oldZone,oldStory,oldOwner=currentZone,Story.currentContext(),GameSession.activeRNGSession()
    local oldRng=RulesRNG.toData();local ox,oy=gfx.getDrawOffset();local oldSprites,sets={},{}
    for _,sprite in ipairs(gfx.sprite.getAllSprites())do oldSprites[sprite]={enabled=sprite:updatesEnabled(),visible=sprite:isVisible()}end
    for key,value in pairs(SpriteFactory.npc)do sets[key]=value end
    local ids=WorldTiles:maxID();local g,manager
    local ok,problem=pcall(function()
        g=GameContext({sessionLocationPolicy=PewterWorld.locationPolicy()});manager=g.npcManager
        assert(g:recruit(Pokemon("squirtle",5)));assert(g.session:setIntro({stage="done",starter="squirtle",rivalStarter="bulbasaur"}))
        PewterSprites.installFor(PewterSlice.padded("PewterCity"));currentZone=PewterWorld.isolated("PewterCity")
        eq(currentZone.collision[27][27],0)
        g.player=Player(26,26,currentZone.collision,g.npcManager);g.player.facing="up";g.player:updateSprite()
        currentZone:spawnNPCs(g.npcManager)
        local sub=StateMachine();sub:register("explore",{});sub:change("explore")
        -- Passive lower world isolates the controlled event; production dispatch,
        -- source Zone/Player/NPCMotion/Dialog/Event/BattleMenu are used unchanged.
        g.machine:register("overworld",{sub=sub});g.machine:register("event",EventState(g));g.machine:register("dialog",DialogState(g));g.machine:change("overworld")
        g.npcManager.motion:attach(g,currentZone)
        local npc
        for _,actor in ipairs(g.npcManager.npcs)do if actor.def.source_event_id==ID then npc=actor end end
        assert(npc,"exact source NPC required");fn(g,g.machine:get("event"),npc,g.npcManager.motion)
        same(RulesRNG.toData(),oldRng);eq(GameSession.activeRNGSession(),oldOwner);eq(Story.currentContext(),oldStory)
    end)
    if g then
        pcall(g.machine.change,g.machine,"overworld")
        if g.npcManager~=manager then pcall(g.npcManager.clear,g.npcManager)end
        pcall(manager.clear,manager)
    end
    for _,sprite in ipairs(gfx.sprite.getAllSprites())do if not oldSprites[sprite]then sprite:remove()end end
    for sprite,previous in pairs(oldSprites)do sprite:setUpdatesEnabled(previous.enabled);sprite:setVisible(previous.visible)end
    for key in pairs(SpriteFactory.npc)do if not sets[key]then SpriteFactory.npc[key]=nil end end
    for key,value in pairs(sets)do SpriteFactory.npc[key]=value end
    currentZone=oldZone;Story.bind(oldStory)
    local active=GameSession.activeRNGSession()
    if active~=oldOwner then if active then active:deactivateRNG()end;if oldOwner then oldOwner:activateRNG()end end
    RulesRNG.restoreData(oldRng);gfx.setDrawOffset(ox,oy)
    eq(WorldTiles:maxID(),ids)
    for _,sprite in ipairs(gfx.sprite.getAllSprites())do assert(oldSprites[sprite],"new sprite leaked after contract")end
    if not ok then error(problem,0)end
end
function PewterQuestionContracts.run()
    local report={ok=true,passed=0,failed=0,tests={}}
    local function test(name,fn)
        local ok,problem=pcall(fn);report.tests[#report.tests+1]={name=name,ok=ok,error=not ok and tostring(problem)or nil}
        if ok then report.passed=report.passed+1 else report.failed=report.failed+1;report.ok=false end
    end
    test("Only source object4 gains a question; museum object3 stays blocked",function()
        assert(PewterEvents.has(ID)and PewterEvents.isQuestion(ID));eq(PewterEvents.has("pokered:PEWTER_CITY:objects:3"),false)
        local d=PewterSlice.padded("PewterCity");local specs=PewterSlice.specs("PewterCity",d)
        eq(specs[ID].status,"bound");eq(specs["pokered:PEWTER_CITY:objects:3"].status,"blocked")
        for _,bad in ipairs({0,3,"1",false})do eq(pcall(PewterEvents.answer,ID,bad),false)end
        eq(pcall(PewterEvents.answer,"pokered:PEWTER_CITY:objects:3",1),false)
        local labels=PewterEvents.answer(ID,1);labels[1]="invented";eq(PewterEvents.answer(ID,1)[1],"_PewterCitySuperNerd2ThatsRightText")
    end)
    test("Pinned prompt and YES/NO source recipes contain exactly original words",function()
        eq(PewterEvents.pages({"_PewterCitySuperNerd2DoYouKnowWhatImDoingText"})[1].text,PROMPT)
        eq(PewterEvents.pages(PewterEvents.answer(ID,1))[1].text,YES);eq(PewterEvents.pages(PewterEvents.answer(ID,2))[1].text,NO)
    end)
    test("Production interaction dispatch types prompt before initial YES menu and retains Dialog style",function()
        scene(function(g,event,npc)
            local before=model(g);interact(g);eq(event.questionNPC,npc);eq(event.questionDef,npc.def);prompt(g,event)
            eq(event.questionPanel.lines[1],PROMPT);eq(event.questionPanel.charIndex,#PROMPT);eq(event.questionPanel.isActive,true)
            event:draw();same(model(g),before)
        end)
    end)
    test("Real YES input shows only original YES answer then returns without gameplay or RNG changes",function()
        scene(function(g,event,npc,motion)
            local before=model(g);local pose=motion:actor(npc);interact(g);prompt(g,event);event:handleButton("a")
            eq(g.machine:getCurrent(),"dialog");eq(g.machine:get("dialog").dialog.lines[1],YES);eq(event.menu.isActive,false)
            complete(g);eq(g.machine:getCurrent(),"overworld");same(model(g),before);same(motion:actor(npc),pose)
        end)
    end)
    test("Down then A shows only NO source answer without consuming REPEL or adding effects",function()
        scene(function(g,event)
            assert(g.session:inventory():add("repel",2));local before=model(g);interact(g);prompt(g,event)
            event:handleButton("down");eq(event.menu.selectedIndex,2);event:handleButton("a")
            eq(g.machine:get("dialog").dialog.lines[1],NO);complete(g);eq(g.session:inventory():quantity("repel"),2);same(model(g),before)
        end)
    end)
    test("B selects source NO rather than silently aborting question",function()
        scene(function(g,event)
            local before=model(g);interact(g);prompt(g,event);event:handleButton("b")
            eq(g.machine:getCurrent(),"dialog");eq(g.machine:get("dialog").dialog.lines[1],NO);complete(g);eq(g.machine:depth(),1);same(model(g),before)
        end)
    end)
    test("Repeat choices are not one-time flags and a retained selection cannot duplicate answers",function()
        scene(function(g,event)
            local before=model(g)
            for _,index in ipairs({2,1,2})do
                interact(g);prompt(g,event);local stale=event.menu.onSelect
                if index==2 then event:handleButton("down")end;event:handleButton("a")
                local generation=g.machine:get("dialog").generation;stale(index);eq(g.machine:get("dialog").generation,generation)
                complete(g);eq(g.machine:getCurrent(),"overworld")
            end
            same(model(g),before)
        end)
    end)
    test("Forced prompt exit and old callback cannot affect a reentered question",function()
        scene(function(g,event)
            local before=model(g);interact(g);local stale=g.machine:get("dialog").onComplete;g.machine:change("overworld")
            interact(g);local dialog=g.machine:get("dialog");local generation=dialog.generation;stale()
            eq(dialog.generation,generation);eq(dialog.dialog.lines[1],PROMPT);eq(event.phase,"dialog");same(model(g),before)
        end)
    end)
    test("Forced menu exit invalidates cached YES across same-actor reentry",function()
        scene(function(g,event)
            local before=model(g);interact(g);prompt(g,event);local stale=event.menu.onSelect;g.machine:change("overworld")
            interact(g);prompt(g,event);stale(1);eq(event.phase,"question");eq(g.machine:getCurrent(),"event");same(model(g),before)
        end)
    end)
    test("Actor removal during owned prompt removes only that Dialog and Event without dead overlay",function()
        scene(function(g,event,npc)
            local before=model(g);interact(g);local stale=g.machine:get("dialog").onComplete;g.npcManager:removeNPC(npc)
            g.machine:update();eq(g.machine:getCurrent(),"overworld");eq(g.machine:depth(),1);stale();eq(g.machine:depth(),1);same(model(g),before)
        end)
    end)
    test("Removing the actual sprite invalidates actor ownership even if manager entry survives",function()
        scene(function(g,event,npc)
            local before=model(g);interact(g);prompt(g,event);local stale=event.menu.onSelect;npc:remove()
            stale(1);eq(g.machine:getCurrent(),"event");g.machine:update();eq(g.machine:depth(),1);same(model(g),before)
        end)
    end)
    test("Same-ID actor replacement during owned answer cannot finish against replacement actor",function()
        scene(function(g,event,npc)
            local before=model(g);interact(g);prompt(g,event);event:handleButton("a");local stale=g.machine:get("dialog").onComplete
            local def=npc.def;g.npcManager:removeNPC(npc)
            local replacement=NPC(def.gridX,def.gridY,def.name,def.dialog,nil,def.sprite,def.facing);replacement.def=def;g.npcManager:addNPC(replacement)
            g.machine:update();eq(g.machine:getCurrent(),"overworld");stale();eq(g.machine:depth(),1);same(model(g),before)
        end)
    end)
    test("Foreign newer Dialog generation is not popped; cancelled Event exits only when uncovered",function()
        scene(function(g,event,npc)
            local before=model(g);interact(g);local old=g.machine:get("dialog").onComplete;g.machine:pop()
            local calls=0;local foreign=function()calls=calls+1 end;g.machine:push("dialog",{"FOREIGN CONTROLLED DIALOG"},foreign)
            local dialog=g.machine:get("dialog");local generation=dialog.generation;g.npcManager:removeNPC(npc)
            g.machine:update();eq(g.machine:getCurrent(),"dialog");eq(dialog.generation,generation);eq(dialog.onComplete,foreign)
            old();eq(calls,0);complete(g);eq(calls,1);g.machine:update();eq(g.machine:depth(),1);same(model(g),before)
        end)
    end)
    test("New Dialog generation invalidates old question even while its actor remains valid",function()
        scene(function(g,event)
            local before=model(g);interact(g);local old=g.machine:get("dialog").onComplete;g.machine:pop()
            local calls=0;local foreign=function()calls=calls+1 end;g.machine:push("dialog",{"NEW GENERATION"},foreign)
            local dialog=g.machine:get("dialog");local generation=dialog.generation
            g.machine:update();eq(g.machine:getCurrent(),"dialog");eq(dialog.generation,generation);eq(dialog.onComplete,foreign)
            old();eq(calls,0);complete(g);eq(calls,1);g.machine:update();eq(g.machine:depth(),1);same(model(g),before)
        end)
    end)
    test("Orphaned prompt popped without completion cannot retain or reactivate a dead Event",function()
        scene(function(g,event)
            local before=model(g);interact(g);local stale=g.machine:get("dialog").onComplete;g.machine:pop()
            g.machine:update();eq(g.machine:depth(),1);stale();eq(g.machine:depth(),1);same(model(g),before)
        end)
    end)
    test("Replacement manager receives no finishInteraction call from invalid question cleanup",function()
        scene(function(g,event)
            local before=model(g);interact(g);prompt(g,event);local stale=event.menu.onSelect
            local replacement=NPCManager(g);local calls=0;replacement.motion.finishInteraction=function()calls=calls+1 end;g.npcManager=replacement
            stale(1);g.machine:update();eq(g.machine:depth(),1);eq(calls,0);same(model(g),before)
        end)
    end)
    test("Replacement session during answer cannot receive cleanup or old completion",function()
        scene(function(g,event,npc,motion)
            local original=g.session;local before=model(g);interact(g);prompt(g,event);event:handleButton("b")
            local stale=g.machine:get("dialog").onComplete;local calls=0;motion.finishInteraction=function()calls=calls+1 end
            local other=GameContext({sessionLocationPolicy=PewterWorld.locationPolicy()});g.session=other.session
            local replacement=model(g);g.machine:update();eq(g.machine:depth(),1);stale();eq(calls,0);same(model(g),replacement)
            g.session=original;same(model(g),before)
        end)
    end)
    test("Player or zone reset during prompt aborts without clearing replacement traversal state",function()
        for _,kind in ipairs({"player","zone"})do scene(function(g,event)
            local before=model(g);interact(g);local stale=g.machine:get("dialog").onComplete
            if kind=="player"then
                g.player=Player(26,26,currentZone.collision,g.npcManager);g.player.pendingEdgeDoor={controlled=true};g.player.stepJustFinished=true
            else currentZone=zoneRegistry.reds_house_2f end
            g.machine:update();eq(g.machine:depth(),1);stale();eq(g.machine:depth(),1)
            if kind=="player"then assert(g.player.pendingEdgeDoor.controlled);eq(g.player.stepJustFinished,true)end
            same(model(g),before)
        end)end
    end)
    test("Source actor ID and definition identity remain guarded after prompt dispatch",function()
        for _,kind in ipairs({"id","definition"})do scene(function(g,event,npc)
            local before=model(g);interact(g);local stale=g.machine:get("dialog").onComplete
            if kind=="id"then npc.def.source_event_id="controlled:replaced-source"
            else local replacement={};for key,value in pairs(npc.def)do replacement[key]=value end;npc.def=replacement end
            -- Production definitions contain closures: preserve their identity
            -- on a shallow replacement instead of inventing serializable defs.
            stale();g.machine:update();eq(g.machine:depth(),1);same(model(g),before)
        end)end
    end)
    test("Direct supported ID cannot open a question without the actual front source actor",function()
        scene(function(g,event)
            local before=model(g);g.player.facing="left"
            eq(pcall(KantoWorld.dispatch,g,ID),false);g.machine:change("overworld");same(model(g),before)
        end)
    end)
    test("Actual source walker settles eight-frame motion before queued production interaction",function()
        scene(function(g,event,npc,motion)
            local value
            for _=1,256 do motion:tick();value=motion:actor(npc);if value.phase=="moving"then break end end
            eq(value.phase,"moving");eq(value.tick,1)
            g.player.gridX,g.player.gridY=value.target_x,value.target_y+1;g.player:moveTo(g.player.gridX*TILE_SIZE,g.player.gridY*TILE_SIZE);g.player.facing="up"
            assert(KantoWorld.tryInteract(g));eq(g.machine:getCurrent(),"overworld")
            for _=1,7 do motion:tick()end;eq(g.machine:getCurrent(),"overworld");eq(motion:actor(npc).phase,"delay")
            motion:tick();eq(g.machine:getCurrent(),"dialog");eq(event.questionNPC,npc);prompt(g,event)
            local before=model(g);local pose=motion:snapshot();for _=1,24 do motion:tick();g.machine:update()end
            same(model(g),before);same(motion:snapshot(),pose);event:handleButton("a");complete(g);eq(g.machine:depth(),1)
        end)
    end)
    return report
end

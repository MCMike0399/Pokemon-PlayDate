"""Read-only exact primary words/branch audit; does not execute Lua or qualify runtime."""
import argparse,hashlib,json,re
from pathlib import Path

def check(project,reference,stage):
 pin=json.loads((stage/'source-pin.json').read_text())
 for f in pin['files']:assert hashlib.sha256((reference/f['path']).read_bytes()).hexdigest()==f['sha256'],'primary source drift: '+f['path']
 labels={'_PewterCitySuperNerd2DoYouKnowWhatImDoingText':"Psssst! Do you know what I'm doing?",'_PewterCitySuperNerd2ThatsRightText':"That's right! It's hard work!",'_PewterCitySuperNerd2ImSprayingRepelText':"I'm spraying REPEL to keep POKEMON out of my garden!"}
 data=json.loads((project/'Source/data/pewterSlice/dialogue.json').read_text())['texts'];text=(reference/'text/PewterCity.asm').read_text()
 for label,literal in labels.items():
  block=text.split(label+'::',1)[1].split('\n_',1)[0];expected=[]
  for line in block.splitlines():
   m=re.fullmatch(r'\s*(text|line|cont|para) "(.*)"',line)
   if m:expected.append({'op':m[1],'text':m[2]})
   elif line.strip()=='done':expected.append({'op':'control','source':'done'})
  actual=[{k:v for k,v in row.items()if k!='source_line'}for row in data[label]['recipe']]
  assert actual==expected,'source recipe differs: '+label
  display=' '.join(row['text']for row in expected if 'text'in row).replace('#','POKE')
  assert display==literal,'independent literal differs: '+label
 script=(reference/'scripts/PewterCity.asm').read_text().split('PewterCitySuperNerd2Text:',1)[1].split('PewterCityYoungsterText:',1)[0]
 code=script.split('.DoYouKnowWhatImDoingText:',1)[0]
 assert re.findall(r'call (\w+)',code)==['PrintText','YesNoChoice','PrintText','PrintText']
 assert '\tcp $0\n\tjr nz, .playerDoesNotKnow' in code
 assert code.index('ld hl, .ThatsRightText')<code.index('\n.playerDoesNotKnow\n')<code.index('ld hl, .ImSprayingRepelText')
 menu=(reference/'engine/menus/text_box.asm').read_text();assert 'jr nz, .choseSecondMenuItem ; automatically choose the second option if B is pressed' in menu
 owned={str(f.relative_to(stage))for f in (stage/'Source').rglob('*')if f.is_file()}
 assert owned=={'Source/game/eventState.lua','Source/game/pewterEvents.lua','Source/dev/pewterQuestionContracts.lua'},'unexpected source/art/data write in packet'
 return {'ok':True,'primary_files':len(pin['files']),'exact_text_recipes':3,'independent_display_literals':3,'read_only_source_branch':True,'SDK_groups_authored':21,'SDK_native_verified':False}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);a=p.parse_args();print(json.dumps(check(a.project,a.reference,Path(__file__).resolve().parent),indent=2))

# Pewter object4 REPEL question — frozen private candidate

Base82cb207 Source44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc. Private regional work AFTER Brock, not an addition to the active correctness/Brock freeze. No liveSource/HEAD/harness/Simulator/Data/art/generator writes. Museum object3 proposal remains frozen and object3 stays blocked.

Apply only two owned source patches and one new actualSDK suite. Full files are review copies, base/ is the exact old owned files, hooks/main.patch is a separate root-owned import/registry hook. No main full-file overwrite and no new controller/world/session/save owner. No data regeneration: all three exact source labels already exist unchanged.

Behavior: source object4 prompts `Psssst! Do you know what I'm doing?`; after readable typing/completion, existing BattleMenu starts YES1/NO2. Up/down switch selection; A confirms; B chooses source NO. Pure PewterEvents.answer accepts only this exact ID and1/2, returns a fresh exact-label array. YES displays `That's right! It's hard work!`; NO displays `I'm spraying REPEL to keep POKEMON out of my garden!`. No durable answer flag, item consumption, REPEL effect, money/party/progression/RNG mutation. Repeat answers are allowed. Question uses the production Dialog panel/font/wrapping at bottom and existing menu above it; new native visual inspection remains pending.

Only this question captures/validates exact front NPC, sourceID, definition identity, manager identity, membership, settled pose and actual sprite presence. No global sprite enumeration is added outside this active question. Existing requestInteraction queues a walking NPC until its actual eight-frame step settles; NPCMotion is unchanged. Prompt/menu/answer guards use EventState epoch/serial/top/context and an exact owned Dialog record (instance,generation,callback,stack position). Actor/context invalidation removes only its still-owned Dialog+Event. A newer/unrelated Dialog remains untouched; the cancelled Event exits when uncovered, never advances. Even with a still-valid actor, a replaced Dialog generation/orphaned prompt cannot reactivate an old question. Invalid cleanup calls finishInteraction only under original captured session/player/zone/manager/actor ownership; replacement owners receive no cleanup. Unsupported arbitrary private queue mutations are not claimed sandboxed.

Source provenance: source-pin.json reuses seven exact immutable pret/pokered af519899719f0754965776faac0e836a3b906e6d primary file pins from the frozen proposal, plus base dependency hashes. check_sources.py verifies all source hashes, the three existing raw text recipes, independent literal display words, source YES/NO branch order and absence of item/flag/RNG calls in the original object4 branch. Source uses initialYES and B→NO. It does not test Lua runtime behavior.

Validation: installedSDK pdc compile03 PASS; exact source/text host check PASS. Candidate Source fingerprint3000d827a398954d2b495999035c2aa983e76c6cc766ea2b90281799471a96d2 (includes root-owned staged import hook +new contracts); compiled fingerprintddb8dab8c4d7a5550bb1895ffe145beab4c2cdca0b3bcbcf10693ed06dedb277. All21 productionSDK groups are AUTHORED/UNRUN. No worker Simulator/native run. The suite uses real imported PewterCity/Player/NPC/NPCMotion/PewterWorld/KantoWorld/EventState/DialogState/BattleMenu; a passive lower-world fixture isolates controlled event calls. It does not pretend to be a natural journey. Cleanup removes all newly created sprites on success/failure, restores original sprite references/flags and asserts global Story/RNG owner/RulesRNG and numeric tile IDs unchanged.

SDK coverage includes exact words/whitelist, production dispatch, initialYES, A/Down+A/B, repeat/no REPEL use, partial prompt/menu abort, actor/sprite/sourceID/definition replacement, session/player/zone/manager reset, exact owned versus newer unrelated Dialog generation, orphan cleanup, and actual queued source-walker eight-frame settle. Tests return the standard `{ok,passed,failed,tests}` report. Existing1091 suites remain included by the helper; root must execute them and review failures before acceptance. No host fakeSDK or “handler exists→verified” shortcut.

Default compile-only:
```
PYTHONDONTWRITEBYTECODE=1 python3 validate_staged.py --project "$PROJECT" --output /private/tmp/pewter-question-build-UNIQUE
python3 check_sources.py --project "$PROJECT" --reference "$PINNED_POKERED_AF519899"
```

Root runtime owner only, after active freeze and review:
```
PYTHONDONTWRITEBYTECODE=1 python3 validate_staged.py --project "$PROJECT" --output /private/tmp/pewter-question-sdk-UNIQUE --execute
```

Helper overlays only manifest-owned files onto a fresh current Source snapshot, rejects changed originals, adds only the root-owned contract import hook, rebuilds private build/source identities and uses normal runner locks for explicit execution. It never launches in default mode. New output directories are required; old proofs are not overwritten. sdk-scenario.json runs contracts and promises no PNG exports; real native input/frame requirements are separately in native-recipe.md for root integration.

Expected preservation: existing art/NPC grids/masks/World/provider/data/dialogue files unchanged, protected catalog PNGs expected2494exact. PewterCity object4 binding metadata intentionally becomes bound; source region is not promoted complete. Frozen per-event coverage source-body guards will become stale when this code is eventually integrated; root must refresh only this event after actual SDK/native review, never blindly rehash the whole report. Source object3 escort, other silent actors, audio and full regional fidelity remain pending.

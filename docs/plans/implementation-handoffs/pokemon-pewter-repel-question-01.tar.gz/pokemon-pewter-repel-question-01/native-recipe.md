# Root-only native proof recipe — unrun

Do not merge into the active82cb207 Brock freeze. After root accepts the source patch, run a new owned private bundle or use validate_staged.py --execute for the SDK suite. Default validator is compile-only. Existing protected2494 image pixels are expected exact; object4 event-binding metadata changes blocked→bound, not art. Inspect that intentional semantic metadata separately without regenerating a baseline.

For native conversation proof use the existing production fixture only to establish a labeled supplementary scene:

```
{op:"fixture",options:{intro:"skip",seed:42,zone:"kanto_pewter_city",
 entry:{x:26,y:26,facing:"up"},player_pokemon:{species:"squirtle",level:5}}}
```

Root must turn this sketch into runner JSON/semantic input using current fixtures/protocol; it is not a claimed executed scenario. NPC4 actually walks: locate diagnostics.npcs by source_event_id `pokered:PEWTER_CITY:objects:4`; use its real current cell/reserved target and collision-aware Player inputs. A static source coordinate is not a guaranteed runtime actor pose. Existing NPCMotion.requestInteraction owns settling; do not teleport/force its state or repeatedly mash A past the question.

1. Approach source object4. Real A interaction through normal Overworld→KantoWorld/PewterWorld. Await root dialog, event.id matching sourceID and readable dialog.ready. Capture `repel-prompt.png` with original prompt.
2. Complete the prompt once. Await root event, event.phase=question, menu.active=true and selected=1. Capture `repel-menu-yes.png`. Confirm native prompt panel font/wrapping and YES/NO cursor match existing UI, no clipping or blank field.
3. Press A once. Await root dialog/readable ready and waiting label `_PewterCitySuperNerd2ThatsRightText`. Capture `repel-answer-yes.png`; assert exact text, complete it once, await settled overworld. No new inventory effects/flags or REPEL use.
4. Repeat a real interaction. Await question, press DOWN, assert selected2, capture `repel-menu-no.png`, press A and capture readable `repel-answer-no.png` (`_PewterCitySuperNerd2ImSprayingRepelText`). Finish once.
5. Repeat and press B at the question. It must select original NO and show the same exact source answer (`repel-answer-b-no.png`), not exit silently. A/typing completion remains the existing Dialog behavior; B's NO semantics apply only once the question menu appears.
6. Check same party/bag/quest/trainer/location/captured actor DTO and rules RNG across each owned interaction interval. The separate world stream must not draw during menu/dialog/script ownership. Ordinary exploration ticks before/after may legitimately move NPCs and draw world RNG; don't call those idle draws a conversation effect or weaken the interval oracle.
7. Object3 still blocks normally and never displays a fake museum conversation/escort. No museum warp, invented gift/REPEL field effect or audio-complete claim.

Root inspects actual native frames. Lifecycle cancellation/session/zone/manager/actor replacement cases are controlled actualSDK contracts, not natural path acceptance. No physical-device proof or whole-Pewter fidelity claim follows from this packet.

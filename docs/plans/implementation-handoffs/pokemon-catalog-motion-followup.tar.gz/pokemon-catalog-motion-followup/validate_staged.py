#!/usr/bin/env python3
"""Root-owner guard qualification. Default compile-only; explicit --execute launches."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--catalog-stage',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');a=p.parse_args()
stage=Path(__file__).resolve().parent;project=Path(a.project).resolve();catalog=Path(a.catalog_stage).resolve();sys.path.insert(0,str(project));sys.dont_write_bytecode=True
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'manifest.json').read_text());base=json.loads((catalog/'bridge-manifest.json').read_text());original=harness.prepare
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def prepare(project,sdk,output,session):
    for row in base['files']:
        if row['path'].startswith('Source/'):assert sha(catalog/row['path'])==row['sha256'],'frozen baseline catalog packet changed'
    for row in manifest['files']:assert sha(stage/row['path'])==row['sha256'],'guard followup changed'
    metadata=original(project,sdk,output,session)
    for row in base['files']:
        if row['path'].startswith('Source/'):
            target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(catalog/row['path'],target)
    for row in manifest['files']:
        target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/row['path'],target)
    main=output/'Source/main.lua';text=main.read_text();marker='import "dev/catalog"';assert text.count(marker)==1
    additions=''
    if 'import "dev/pewterCatalogExporter"' not in text:additions+='\nimport "dev/pewterCatalogExporter"\nPewterCatalogExporter.register()'
    assert 'CatalogMotionContracts.run' not in text,'motion suite already registered; review composition'
    additions+='\nimport "dev/catalogMotionContracts"\nContracts.register("catalog-motion", CatalogMotionContracts.run)'
    main.write_text(text.replace(marker,marker+additions,1))
    pdx=output/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f) for f in sorted((output/'Source').rglob('*')) if f.is_file() and f.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    pdx.write_text(generated);values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        value=metadata[key];values.append('    '+key+' = '+('true' if value is True else json.dumps(value,ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['catalog_motion_followup']=manifest
    with (output/'motion-build.log').open('w') as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:result=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(stage/'scenario.json'),commands=[],build_only=not a.execute,timeout=60,ready_timeout=20,max_frames=1800))
finally:harness.prepare=original
raise SystemExit(result)

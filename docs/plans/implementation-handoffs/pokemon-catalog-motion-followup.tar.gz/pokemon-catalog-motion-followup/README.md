# Separate catalog world-motion guard followup

Frozen original catalog packet is unchanged. Apply `patches/catalogRuntime.patch` after its catalogRuntime.lua, add `Source/dev/catalogMotionContracts.lua`, and register `Contracts.register("catalog-motion", CatalogMotionContracts.run)` after importing it. `manifest.json` pins both files and the expected original runtime file. No live Source/Simulator/Data was touched.

The guard now observes defensive `session:worldRngData()`, `session:actorData()` and `{owner=motion,pose=motion:snapshot()}`. Existing live NPC grid/facing/isMoving/native image and pixel-position snapshots remain in force. Typed traversal rollback preserves the captured actors payload. Supported session-world RNG/captured-DTO rollback uses the current owner’s validating `_installWorldMotion({version=1,rng,actors})`; it neither swaps session/Party/Storage/Inventory owners nor consumes RulesRNG.

Live NPCMotion private moving/delay/interaction/pending values have no general undo interface. Any changed state visible in `motion:snapshot()` that remains after ordinary sprite/actor restoration explicitly fails as `unrestored/unsupported state: motion`. This is a trusted exporter guard, not a universal private-queue sandbox. It does not claim detection of unobservable private queue-only edits. The actual pure exporter does not invoke motion updates or queues.

Two SDK cases use real production interfaces: a live `session:worldRandom` draw must be rejected and restore exact independent continuation/RNG/DTO/scene; a detached valid source Mart actor DTO is changed through the session’s own validating install, rejected and restored without touching live NPC simulation. Both require full CatalogRuntime snapshot equality after restoration. No fake Playdate implementation.

Default compile succeeded at `/private/tmp/pokemon-catalog-motion-compile-01`; runtime execution belongs to root:

```sh
python /path/to/followup/validate_staged.py \
  --project /path/to/Pokemon-PlayDate \
  --catalog-stage /path/to/pokemon-comprehensive-catalog \
  --output /path/to/new-unique-run --execute
```

The helper composes only the unchanged frozen catalog files plus these two owned files over current Source. It registers the two new cases, not the original seven comprehensive cases (whose paired1718images root already ran). If root registers both suites in a combined build, retain original required artifacts/compare semantics. No image additions, checker tolerance or baseline changes occur in this followup. Native proof is pending.

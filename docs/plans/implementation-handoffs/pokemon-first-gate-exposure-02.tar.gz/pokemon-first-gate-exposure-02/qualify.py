#!/usr/bin/env python3
"""Independent report/primary vectors and mutation checks; does not execute SDK."""
import copy,hashlib,json,sys,unittest
from pathlib import Path
S=Path(__file__).resolve().parent
class AuditContracts(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.r=json.loads((S/'inventory-qualified.json').read_text());cls.ps=json.loads((S/'primary-qualified.json').read_text())
 def test_all_historical_events_and_moves_retained_no_cutoff(self):
  old=json.loads((PROJECT/'docs/validation/prebrock-mechanics/prebrock-checklist.json').read_text());new={(r['species'],r['event_index']if'event_index'in r else r['event'],r['move'],r['level'])for r in self.r['events']}
  self.assertTrue({(r['species'],r['event_index'],r['move'],r['level'])for r in old['learn_events']}<=new)
  self.assertTrue({r['move']for r in old['moves']}<={r['move']for r in self.r['moves']});self.assertTrue(any(r['level']>70 for r in self.r['events']))
 def test_literal_acquisition_all_slots_original_no_invented_loot(self):
  r22=next(r for r in self.r['acquisition']if r['zone_id']=='pokered:ROUTE_22');self.assertEqual(r22['rate_bytes'],{'grass':25,'water':0})
  self.assertEqual([(r['species'],r['level'])for r in r22['literal_slots']],[('rattata',3),('nidoranF',3),('rattata',4),('nidoranF',4),('rattata',2),('nidoranF',2),('spearow',3),('spearow',5),('nidoranM',3),('nidoranM',4)])
  self.assertEqual(self.r['normal_abilities'],[5,8,9,14,19,38,50,51,61,62,65,66,67,68,69,71,77,79])
 def test_true_evolution_boundaries_and_inheritance(self):
  species={r['species']:r for r in self.r['species']}
  self.assertEqual(species['nidorina']['earliest_level'],16);self.assertEqual(species['nidorino']['earliest_level'],16);self.assertEqual(species['fearow']['earliest_level'],20)
  self.assertNotEqual(species['nidoqueen']['access'],'natural-player');self.assertNotEqual(species['nidoking']['access'],'natural-player');self.assertNotEqual(species['raichu']['access'],'natural-player')
  self.assertIn('pursuit',species['fearow']['inherited_possible_moves']);self.assertIn('mirrorMove',species['pidgeot']['inherited_possible_moves'])
 def test_primary_every_move_and_special_case_callbacks(self):
  self.assertEqual({r['key']for r in self.ps['moves']},{r['move']for r in self.r['moves']});m={r['key']:r['definition']for r in self.ps['moves']}
  self.assertEqual(m['poisonFang']['secondary'],{'chance':30,'status':'tox'});self.assertEqual(m['thrash']['self'],{'volatileStatus':'lockedmove'});self.assertTrue(m['chipAway']['ignoreDefensive']);self.assertTrue(m['chipAway']['ignoreEvasion'])
  self.assertEqual(m['helpingHand']['target'],'adjacentAlly');self.assertEqual(m['flatter']['boosts'],{'spa':1});self.assertEqual(m['flatter']['volatileStatus'],'confusion')
 def test_every_retained_move_scalar_against_actual_merged_gen5(self):
  by={m['key']:m['definition']for m in self.ps['moves']}
  for row in self.r['moves']:
   m=by[row['move']];current=row['current_definition']
   expected={'power':m['basePower'],'accuracy':0 if m['accuracy']is True else m['accuracy'],'pp':m['pp'],'type':m['type'].lower(),'category':m['category'].lower()}
   for key,value in expected.items():self.assertEqual(current[key],value,(row['move'],key))
  # Semantic payload disagreement remains visible, not folded into scalar pass.
  current=next(m['current_definition']for m in self.r['moves']if m['move']=='poisonFang')
  self.assertIn('Chance ( 50 )',current['secondaries'][0]);self.assertIn('"poison"',current['secondaries'][0]);self.assertEqual(by['poisonFang']['secondary'],{'chance':30,'status':'tox'})
 def test_item_access_witness_and_primary_minimize_condition(self):
  proof=json.loads((S/'item-access-final.json').read_text());self.assertTrue(proof['ok']);self.assertEqual(proof['reachable_cells'],331)
  self.assertEqual([o['object_cell']for o in proof['objects']],[[13,54],[13,45]])
  for row in proof['objects']:self.assertEqual(row['reachable_interaction_cells'],[])
  by={m['key']:m['definition']for m in self.ps['moves']};self.assertEqual(by['steamroller']['flags']['minimize'],1)
  self.assertNotIn('onAccuracy',self.ps['conditionalProducers']['minimize']);self.assertIn('chainModify(2)',self.ps['conditionalProducers']['minimize']['onSourceModifyDamage']['function'])
 def test_actual_reference_logs_not_synthesized_success(self):
  rows={r['label']:r for r in self.ps['rows']};log=lambda key:'\n'.join(rows[key]['log'])
  self.assertIn('|-fail|',log('MirrorMove-no-history'));self.assertIn('|Tackle|',log('MirrorMove-copies-prior-Tackle'));self.assertEqual(rows['Whirlwind-trainer-reserve']['after']['active2'],'pikachu');self.assertIn('|-fail|',log('Whirlwind-no-reserve'))
  self.assertIn('[notarget]',log('HelpingHand-singles-fails'));self.assertLess(log('Flatter-new-confusion').index('|-boost|'),log('Flatter-new-confusion').index('|-start|'))
  self.assertEqual(rows['Flatter-OwnTempo-partial-success']['after']['boosts']['spa'],1);self.assertFalse(rows['Flatter-OwnTempo-partial-success']['after']['confusion']);self.assertIn('|-fail|',log('Flatter-capped-and-confused'))
  self.assertEqual(rows['BugBite-Oran-mechanism-only']['after']['held'],'');self.assertIn('|-heal|',log('BugBite-Oran-mechanism-only'))
  self.assertLess(log('Pursuit-actual-voluntary-withdraw').index('|Pursuit|'),log('Pursuit-actual-voluntary-withdraw').index('|switch|p2a: Pikachu'))
 def test_conditional_moves_remain_requirements_not_deleted(self):
  m={r['move']:r for r in self.r['moves']}
  for key in ('mirrorMove','whirlwind','pursuit','helpingHand','flatter','bugBite'):self.assertTrue(m[key]['player_natural_key'])
  self.assertEqual(m['roost']['status'],'staged-notaccepted');self.assertIn('pluck',m);self.assertFalse(m['pluck']['player_natural_key'])
  self.assertEqual(m['poisonFang']['status'],'semantic-gap-natural');self.assertEqual(m['thrash']['status'],'semantic-gap-technical-only');self.assertEqual(m['chipAway']['status'],'semantic-gap-technical-only');self.assertFalse(m['thrash']['player_natural_key']);self.assertFalse(m['chipAway']['player_natural_key'])
 def test_removed_move_event_hidden_loot_and_natural_stone_mutants_fail(self):
  def verify(r):
   assert any(x['move']=='mirrorMove'for x in r['moves'])
   assert len(r['events'])==511
   assert next(s for s in r['species']if s['species']=='nidoking')['access']!='natural-player'
   assert next(x for x in r['wild_held']if x['species']=='spearow')['native_held_fields']==[0,0,0]
  verify(self.r)
  for change in ('move','event','stone','loot'):
   r=copy.deepcopy(self.r)
   if change=='move':r['moves']=[m for m in r['moves']if m['move']!='mirrorMove']
   elif change=='event':r['events'].pop()
   elif change=='stone':next(s for s in r['species']if s['species']=='nidoking')['access']='natural-player'
   else:next(x for x in r['wild_held']if x['species']=='spearow')['native_held_fields']=[0,244,0]
   with self.assertRaises(AssertionError):verify(r)
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a,rest=p.parse_known_args();PROJECT=a.project;unittest.main(argv=[sys.argv[0]]+rest)

from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent
import argparse
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--trait-primary',type=Path,required=True);p.add_argument('--showdown',type=Path,required=True);a=p.parse_args()
r=json.loads((S/'inventory-qualified.json').read_text());ps=json.loads((S/'primary-qualified.json').read_text());by={m['key']:m['definition']for m in ps['moves']}
rows=['# Complete retained move ledger','', 'Current950 Source +frozen/unaccepted Route22. No level cutoff; all135 historical keys retained. Every row has actual merged Gen5 primary data in primary-engine.json. Source presence, scoped SDK acceptance, native evidence and semantic completion are distinct. The104 source-path rows are explicitly NOT certified complete from data membership. Technical-only events are retained, not presented as acquisitions.','', '| Move | Access | Actual Gen5 behavior summary | Current status / remaining |','|---|---|---|---|']
for m in r['moves']:
 d=by[m['move']];access=('player'if m['player_natural_key']else'no player acquisition')+('/fixedtrainer'if m['actual_trainer_initial_key']else'')
 summary=f"{d.get('category')} {d.get('type')} BP{d.get('basePower')} acc{d.get('accuracy')} PP{d.get('pp')}, target={d.get('target')}"
 for field in ('boosts','status','volatileStatus','sideCondition','weather','secondary','self','multihit','drain','forceSwitch','selfdestruct','ignoreDefensive','ignoreEvasion'):
  if d.get(field):summary+='; '+field+'='+json.dumps(d[field],separators=(',',':'))
 callbacks=[k for k,v in d.items()if isinstance(v,dict)and'function'in v]
 if callbacks:summary+='; callbacks='+','.join(callbacks)
 summary=summary.replace('|','/');remaining=(m['status']+': '+m['remaining']).replace('|','/')
 rows.append(f"| {m['move']} | {access} | {summary} | {remaining} |")
(S/'moves.md').write_text('\n'.join(rows)+'\n')
# Source pins include immutable-source URLs, matching local bytes, and exact
# compiled primary-engine artifacts. No floating master references.
P=a.project;T=a.trait_primary;C=a.showdown
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
references=[]
pin=json.loads((P/'tools/references/early-abilities-sources.json').read_text())['files']
for name in('bw_move_handlers.c','bw_btl_server_flow.c','bw_btl_calc.c'):
 assert sha(T/name)==pin[name]['sha256'];references.append({'path':str(T/name),**pin[name]})
pin=json.loads((P/'tools/references/specimen-sources.json').read_text())['files']
for name in('personal_b2w2','PersonalInfo5B2W2.cs'):
 assert sha(T/name)==pin[name]['sha256'];references.append({'path':str(T/name),**pin[name]})
for row in ps['files']:
 assert sha(C/row['file'])==row['sha256'];references.append({'path':str(C/row['file']),'sha256':row['sha256'],'url':('https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/'+row['file'])if not row['file'].startswith('dist/')else None,'qualification':'actual compiled reference artifact'if row['file'].startswith('dist/')else'immutable primary source'})
for path,digest in r['primary_source_pins'].items():references.append({'path':path,'sha256':digest,'url':'https://github.com/pret/pokered/blob/af519899719f0754965776faac0e836a3b906e6d/'+path.split('af519899719f0754965776faac0e836a3b906e6d/',1)[1]})
(S/'references.json').write_text(json.dumps({'schema':1,'files':references,'runtime_readonly':True,'primary_probe':'actual compiled pinnedPS11 real-choice cases; not SDK/cartridge claim'},indent=2)+'\n')

#!/usr/bin/env python3
"""Directed source collision proof for unavailable first-gate stone/vitamin."""
import argparse,collections,hashlib,json,re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
f=a.project/'Source/data/pewterSlice/Route2.json';d=json.loads(f.read_text());compact=json.loads((a.project/'Source/data/pewterSlice/compact.json').read_text())['maps']['Route2'];w,h=d['dimensions']['cells'];directions={'up':(0,-1),'down':(0,1),'left':(-1,0),'right':(1,0)}
def collision(x,y):return d['collision'][y][x]or str(y*w+x+1)in compact['blocked']
def foot(x,y):return d['grids'][d['tile_ids'][y][x]-1]['terrain']['foot_tile']
def edge(x,y,di):
 dx,dy=directions[di];tx,ty=x+dx,y+dy
 if not(0<=tx<w and 0<=ty<h):return None
 pair=(foot(x,y),foot(tx,ty));ledge=any(r['facing']=='SPRITE_FACING_'+di.upper()and pair==(r['standing_foot_tile'],r['target_foot_tile'])for r in d['directional_rules']['ledges'])
 if ledge:tx,ty=x+2*dx,y+2*dy
 elif list(pair)in d['directional_rules']['forbidden_tile_pairs']:return None
 return(tx,ty)if 0<=tx<w and 0<=ty<h and not collision(tx,ty)else None
# Conservative overapproximation: every passable N/S boundary cell plus both
# actual registered Forest gate destinations; other source doors are blocked.
seeds={(x,y)for x in range(w)for y in(0,h-1)if not collision(x,y)}|{(3,11),(3,44)}
objects={(e['x'],e['y'])for e in d['events']['objects']};seen=seeds-objects;q=collections.deque(seen)
while q:
 x,y=q.popleft()
 for direction in directions:
  dest=edge(x,y,direction)
  if dest and dest not in seen and dest not in objects:seen.add(dest);q.append(dest)
rows=[]
for event in d['events']['objects']:
 points=[(event['x']+dx,event['y']+dy)for dx,dy in directions.values()];reachable=[point for point in points if point in seen]
 rows.append({'id':event['id'],'item_source':event['extra'][0],'object_cell':[event['x'],event['y']],'reachable_interaction_cells':reachable,'unavailable_in_current_registered_surface':not reachable})
 assert not reachable,'unexpected legitimate item access: '+event['id']
source=(a.reference/'data/maps/objects/Route2.asm').read_text();assert 'object_event 13, 54' in source and 'MOON_STONE' in source and 'object_event 13, 45'in source and 'HP_UP'in source
marts=(a.reference/'data/items/marts.asm').read_text();stocks={}
for label in('ViridianMartClerkText','PewterMartClerkText'):
 stock=re.search(label+r'::\s*script_mart([^\n]+)',marts)[1].strip();assert not any(item in stock for item in('STONE','HM_CUT','BERRY'));stocks[label]=stock
report={'ok':True,'definition_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'source_object_sha256':hashlib.sha256((a.reference/'data/maps/objects/Route2.asm').read_bytes()).hexdigest(),'seed_policy':'conservative all passable N/S source boundaries +actual2Forestgate arrivals, all current explicit unimplemented warps blocked, real directionalledge/pair rules; source item actors block cells','seeds':sorted(seeds),'reachable_cells':len(seen),'objects':rows,'current_source_mart_stocks':stocks,'qualification':'No constructor/learnset projection is used as item availability. This is source/production surface directed reachability, not a native walking witness; Root native still pending. Future Cut/upperRoute2/Diglett passage or other stone acquisition changes this closure. No general fullcampaign unavailable claim.'}
assert not a.output.exists();a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

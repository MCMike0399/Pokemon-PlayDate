#!/usr/bin/env python3
"""Read-only no-level-cutoff source closure. No Source/runtime/old-report writes."""
import argparse,collections,hashlib,json,re,subprocess,sys
from pathlib import Path
S=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def plain(v):
 if hasattr(v,'text'):return v.text
 if isinstance(v,dict):return{k:plain(x)for k,x in v.items()}
 if isinstance(v,list):return[plain(x)for x in v]
 return v

def build(project,route22,reference,showdown,sdk_evidence,trait_primary):
 sys.path.insert(0,str(project));from tools.verify_moves.parse_lua import LuaParser,read_moves,read_table,Expression,Reader,tokens
 from tools.harness.run import fingerprint
 pokemon=LuaParser(project/'Source/data/pokemon.lua').parse();moves=read_moves(project/'Source/battle/moves.lua');evo=read_table(project/'Source/data/evolutionData.lua','EvolutionData')['rules'];items=read_table(project/'Source/data/items.lua','ItemData')
 for key,fields in items['definitions'].items():
  if isinstance(fields,list):
   row={}
   for field in fields:
    assert isinstance(field,Expression);m=re.fullmatch(r'\[ ("(?:[^"\\]|\\.)*") \] = (.+)',field.text);assert m
    row[json.loads(m[1])]=Reader(tokens(m[2])).value()
   items['definitions'][key]=row
 starters=['bulbasaur','charmander','squirtle'];wild=[];acquisition=[];minimum={s:5 for s in starters}
 directmoves={s:set()for s in starters};directlevels=collections.defaultdict(set)
 for s in starters:directlevels[s].add(5)
 files=[project/'Source/data/viridianSlice/Route1.json',project/'Source/data/pewterSlice/Route2.json',project/'Source/data/pewterSlice/ViridianForest.json',route22/'Source/data/route22Slice/Route22.json']
 for f in files:
  d=json.loads(f.read_text());rows=[]
  for section in ('grass','water'):
   for i,row in enumerate(d['encounters'][section]['slots'],1):
    species=row['species'];level=row['level'];wild.append(species);directlevels[species].add(level);minimum[species]=min(minimum.get(species,100),level)
    rows.append({'section':section,'slot':i,**row})
  acquisition.append({'path':str(f),'sha256':sha(f),'zone_id':d['id'],'rate_bytes':{s:d['encounters'][s]['rate_byte']for s in('grass','water')},'literal_slots':rows})
 # Preserved authored Pallet exit grass remains a real production acquisition
 # exception; it must not disappear merely because it is not a Blue wild file.
 authored=(project/'Source/data/maps.lua').read_text().split('registerZone("reds_house"',1)[0]
 pallet=[]
 for species,lo,hi,weight in re.findall(r'\{ species = "(\w+)",\s*minLevel = (\d+), maxLevel = (\d+), weight = (\d+)',authored):
  lo,hi,weight=map(int,(lo,hi,weight));assert species in pokemon
  wild.append(species);minimum[species]=min(minimum.get(species,100),lo);directlevels[species].update(range(lo,hi+1));pallet.append({'species':species,'minLevel':lo,'maxLevel':hi,'weight':weight})
 assert len(pallet)==4
 acquisition.append({'path':'Source/data/maps.lua:pallet_town','sha256':sha(project/'Source/data/maps.lua'),'zone_id':'pallet_town','rate_unit':0.15,'literal_slots':pallet,'qualification':'preserved authored exitgrass, source exception distinct from originalBlue wild tables; debugtest_zone is not naturally connected'})
 wild=sorted(set(wild));direct=set(starters+wild)
 def closure(seeds,methods):
  out=set(seeds);todo=list(seeds)
  while todo:
   for r in evo[todo.pop()]:
    if r['trigger']in methods and r['to']not in out:out.add(r['to']);todo.append(r['to'])
  return out
 natural=closure(direct,{'level'});fixed=json.loads((project/'Source/data/pewterSlice/trainers.json').read_text())['trainers'];scene=json.loads((route22/'Source/data/route22Slice/first-rival.json').read_text())
 trainerrows=[]
 for row in fixed:trainerrows.append({'source':'pinnedBluePewter','id':row['id'],'name':row.get('name')or row.get('class_source')or row.get('trainer_class'),'party':row['party'],'payout':row['payout']})
 for starter in starters:
  trainerrows.append({'source':'pinnedBlueRoute22-frozen-notintegrated','id':scene['trainer_id'],'variant_rival_starter':starter,'party':scene['party_by_rival_starter'][starter],'payout':scene['payout']})
  trainerrows.append({'source':'originalintro-productionStory','id':'authored:oaks_lab:npc:2','variant_rival_starter':starter,'party':[{'species':starter,'level':5}],'payout':175})
 def initial(s,level):
  eligible=[r['move']for r in pokemon[s]['learnset']if r['level']<=level];known=[]
  for key in reversed(eligible):
   if key not in known:known.append(key)
   if len(known)==4:break
  return list(reversed(known))
 for row in trainerrows:
  for mon in row['party']:mon['initial_moves']=initial(mon['species'],mon['level'])
 enemies={m['species']for row in trainerrows for m in row['party']};technical=closure(direct|enemies,{'level','stone','trade'})
 for _ in range(151):
  before=dict(minimum)
  for s,l in before.items():
   for r in evo[s]:
    if r['trigger']=='level':minimum[r['to']]=min(minimum.get(r['to'],101),max(l+1,r['minimum']))
  if before==minimum:break
 else:raise ValueError('cyclic evolution')
 # Possible ownership of a move: initial last-four at actual acquisition, every
 # subsequent level event, and retained parent moves across any delayed evolution.
 learnable={s:set()for s in natural}
 for s in direct:
  for level in directlevels[s]:learnable[s].update(initial(s,level))
  learnable[s].update(r['move']for r in pokemon[s]['learnset']if r['level']>minimum[s])
 for s in natural-direct:learnable[s].update(r['move']for r in pokemon[s]['learnset']if r['level']>=minimum[s])
 for _ in range(151):
  before={s:set(v)for s,v in learnable.items()}
  for s in natural:
   for r in evo[s]:
    if r['trigger']=='level':learnable[r['to']]|=learnable[s]
  if before==learnable:break
 # Earliest per-key ownership, allowing parent level-up then evolution at the
 # same level (the production progression owner resolves learning first).
 earliestMoves={s:{}for s in natural}
 for s in direct:
  for level in directlevels[s]:
   for key in initial(s,level):earliestMoves[s][key]=min(earliestMoves[s].get(key,101),level)
 for s in natural:
  for row in pokemon[s]['learnset']:
   if row['level']>=(minimum[s]if s not in direct else minimum[s]+1):earliestMoves[s][row['move']]=min(earliestMoves[s].get(row['move'],101),row['level'])
 for _ in range(151):
  before={s:dict(v)for s,v in earliestMoves.items()}
  for s in natural:
   for rule in evo[s]:
    if rule['trigger']=='level':
     child=rule['to']
     for key,level in earliestMoves[s].items():earliestMoves[child][key]=min(earliestMoves[child].get(key,101),max(minimum[child],level))
  if before==earliestMoves:break
 # Source event availability is distinct from key availability by inheritance.
 events=[];species=[]
 slots={int(d):(int(a),int(b),int(h))for d,a,b,h in re.findall(r'\[(\d+)\] = \{first=(\d+),second=(\d+),hidden=(\d+)\}',(project/'Source/data/specimenData.lua').read_text())}
 for s in sorted(technical,key=lambda s:pokemon[s]['dex']):
  p=pokemon[s];access='natural-player'if s in natural else'actual-fixed-trainer-only'if s in enemies else'stone-or-trade-unavailable'if any(r['to']==s and r['trigger']in('stone','trade')for x in evo.values()for r in x)else'trainer-evolution-technical-only'
  species.append({'species':s,'dex':p['dex'],'access':access,'direct_levels':sorted(directlevels[s]),'earliest_level':minimum.get(s),'evolution_edges':evo[s],'normal_ability_ids':list(slots[p['dex']][:2]),'hidden_ability_not_acquired':slots[p['dex']][2],'inherited_possible_moves':sorted(learnable.get(s,set())),'possible_key_earliest_levels':earliestMoves.get(s,{})})
  for index,r in enumerate(p['learnset'],1):
   assert r['move']in moves
   if s not in natural:availability='technical-source-event-only'
   elif s in direct and r['move']in set().union(*(set(initial(s,l))for l in directlevels[s])):availability='actual-initial-or-later-event'
   elif r['level']>=(minimum[s]if s not in direct else minimum[s]+1):availability='evolution-current-level-or-later-level-event'
   elif r['move']in learnable[s]:availability='source-event-too-early-but-key-retainable-from-parent-or-other-event'
   else:availability='source-event-unavailable-no-relearner-do-not-delete'
   events.append({'species':s,'event':index,**r,'access':access,'availability':availability})
 keys={r['move']for r in events}|{'struggle','bide'}
 actual_player={key for keys in learnable.values()for key in keys}|{'struggle','bide'}
 actual_trainer={key for row in trainerrows for m in row['party']for key in m['initial_moves']}
 # This is an audit ledger, not automatic semantic certification.
 old=json.loads((project/'docs/validation/prebrock-mechanics/prebrock-checklist.json').read_text());oldgaps={r['move']:r for r in old['moves']}
 promoted={'assurance','captivate','dig','earthquake','electroBall','endeavor','explosion','feint','furyCutter','gyroBall','heavySlam','hurricane','lightScreen','magnitude','petalDance','protect','ragePowder','rainDance','safeguard','selfDestruct','skullBash','smackDown','solarBeam','suckerPunch','sweetScent','tailwind','thunder','worrySeed','focusEnergy','razorLeaf','slash','nightSlash','shadowClaw','stoneEdge'}
 special={
 'mirrorMove':('semantic-gap-natural','No move-history/eligibility/called-move execution producer; empty status row currently narrates and spends PP without copying or honest failure.'),
 'whirlwind':('semantic-gap-natural','Missing wild escape + trainer reserve selection/forced replacement/failure/level checks; empty status row does not implement source forcedSwitch.'),
 'pursuit':('conditional-semantic-gap','Normal40 damage works; missing before-withdraw interception,doublepower,tracking/accuracy. Current enemy AI never chooses voluntary withdraw; forced replacement is not that producer. Preserve requirement.'),
 'helpingHand':('source-implemented-singles-failure-unverified','targetId3 is explicitly no-ally in Battle.moveHasTarget before accuracy; no target and spent PP. No named production SDK/native witness found; doubles boost is outside current singles format, not a reason to delete move.'),
 'flatter':('partial-source-order-review','Current effects confuse thenSpA+1. Actual reference generic move effects boost beforeconfusion; correct caps/immunity/already-confused success aggregation and ordering need direct regression; no named SDK/native witness.'),
 'bugBite':('conditional-semantic-gap','Damage present; target berry removal/consumption/effect absent. No actual berry acquisition: only enabled nonzero wildheld LightBall; existing Blue bag has no berry. Preserve conditional producer requirement.'),
 'poisonFang':('semantic-gap-natural','Current50%ordinarypoison is wrong: actualGen5 30%badpoison. Needs explicit producer migration and toxic residual/status/PP/RNG regression, not baseline hash normalization.'),
 'thrash':('semantic-gap-technical-only','Current120damage lacks actual lockedmove2-3turn/finalfatigue lifecycle. Reuse existing PetalDance owner through explicit typed rule, not name inference.'),
 'chipAway':('semantic-gap-technical-only','Current70damage does not ignore target Defense/evasion stages. Requires pure declared stage-bypass queries, preserve source own accuracy/stats/crit/weather/abilities.'),
 'pluck':('conditional-semantic-gap','Like BugBite, target berry removal/consumption/effect missing. No naturally obtainable berry producer, but fullmove requirement retained.'),
 'roost':('staged-notaccepted','Current950 has old half-heal only; approved private Roost packet adds temporary effective Flying removal +correct healing/order, SDK/native acceptance pending.'),
 'growth':('conditional-semantic-gap','Ordinary+1/+1 implemented; Sun+2 no current Sun producer; pending, not removed.'),
 'gust':('conditional-semantic-gap','Fly/Bounce doublepower pending, no actual preBrock Fly/Bounce producer; preserve.'),
 'twister':('conditional-semantic-gap','Fly/Bounce doublepower pending, no actual preBrock Fly/Bounce producer; preserve.'),
 'flareBlitz':('conditional-semantic-gap','Recoil/burn present; freeze self-thaw/Fire thaw remains pending, no current freeze producer among actual player+fixedtrainer moves.'),
 'steamroller':('conditional-semantic-gap','PinnedC maps Steamroller toStomp and doublesdamage vsMinimize. ActualPSGen5 retains Minimize onSourceModifyDamage but removes onAccuracy. No current Minimize producer; damagebonus pending, do not invent Gen6alwayshit.'),
 }
 sdk=json.loads(sdk_evidence.read_text());contracts=next(r['contracts']for r in sdk['results']if r.get('contracts'));assert contracts['ok']and contracts['passed']==950 and not contracts['failed']
 def evidence_for(key):
  # Literal named tests are only pointers to scoped assertions, never inferred
  # per-move proof from a generic suite count or a matching substring.
  return [t['name']for t in contracts['tests']if re.search(r'(?<![a-z])'+re.escape(key.lower())+r'(?![a-z])',t['name'].lower())]
 move_rows=[]
 for key in sorted(keys):
  current=plain(moves[key]);status,remaining=special.get(key,('source-path-present-notcertified','No bespoke missing branch identified by this refresh; every inherited primary callback and failure/PP/RNG interaction remains explicit review, not certified from data membership.'))
  if key in promoted and key not in special:status='integrated-with-scoped-SDK-evidence';remaining='Current950 includes bounded implementation and suite acceptance; exact test pointers below are limited evidence, not exhaustive per-move native certification.'
  move_rows.append({'move':key,'player_natural_key':key in actual_player,'actual_trainer_initial_key':key in actual_trainer,'source_event_count':sum(r['move']==key for r in events),'current_definition':current,'status':status,'remaining':remaining,'named_sdk_test_pointers':evidence_for(key),'native_verification':'No automatic attribution. See accepted root native case list; no per-move native claim from aggregate950.','historical_status':oldgaps.get(key,{}).get('status')})
 abilityids=sorted({n for row in species if row['species']in natural|enemies for n in row['normal_ability_ids']})
 acquisitions={'pokeBall':['ViridianMartstock','PewterMartstock','Forestobjects7','frozenRoute22Oakgift5afterfirstwin'], 'potion':['newgameREDPCPotion1','Route1sourcegift','PewterMartstock','Forestobjects6','Foresthidden1'],'antidote':['ViridianMartstock','PewterMartstock','Forestobjects5','Foresthidden2'],'parlyzHeal':['ViridianMartstock','PewterMartstock'],'burnHeal':['ViridianMartstock','PewterMartstock'],'awakening':['PewterMartstock'],'escapeRope':['PewterMartstock'],'townMap':['DaisyafterDex'],'oaksParcel':['Martparcelhandoff'],'tm34':['Brockreward, post-first-Brock boundary']}
 itemrows=[{'id':k,'definition':plain(items['definitions'][k]),'acquisition':v,'implementation':'authoritative bounded domain/field/UI paths on950Source; per-scenario verification separate'}for k,v in acquisitions.items()]
 itemrows.extend([{'id':'lightBall','nativeGenVId':236,'PokeAPIId':213,'acquisition':'ordinary wildPikachu5%; real physicalslot0 CompoundEyes20%; successfulrecruit/heldtransfer only','implementation':'integrated950; scoped trait/heldSDK+native sources retained','not_berries':True}, {'id':'moonStone','acquisition':'Route2east sourceitem blocked beforeCut/upperroute, no reviewed preBrock acquisition','implementation':'stone engine exists but natural Nidoqueen/Nidoking unavailable here'}, {'id':'hpUp','acquisition':'Route2east sourceitem blocked beforeCut/upperroute','implementation':'not naturally obtainable here'}, {'id':'thunderStone','acquisition':'no preBrock shop/gift/pickup','implementation':'Raichu remains technical only'}])
 heldSource=trait_primary.parent/'species-sex-held.json'
 heldRows=json.loads(heldSource.read_text())['species']
 wildHeld=[row for row in heldRows if row['species']in wild]
 personal=trait_primary/'personal_b2w2';rawPersonal=personal.read_bytes();info=trait_primary/'PersonalInfo5B2W2.cs'
 assert 'SIZE = 0x4C' in info.read_text()
 for row in wildHeld:
  record=rawPersonal[row['dex']*0x4C:(row['dex']+1)*0x4C]
  literal=[int.from_bytes(record[offset:offset+2],'little')for offset in(0x0C,0x0E,0x10)]
  assert literal==row['native_held_fields']==([0,236,0]if row['species']=='pikachu'else[0,0,0])
 for row in species:
  record=rawPersonal[row['dex']*0x4C:(row['dex']+1)*0x4C]
  assert list(record[0x18:0x1A])==row['normal_ability_ids']and record[0x1A]==row['hidden_ability_not_acquired']

 referenceFiles=[reference/'data/wild/maps'/f'{name}.asm'for name in('Route1','Route2','ViridianForest','Route22')]
 referenceFiles += [reference/'data/trainers/parties.asm',reference/'data/maps/objects/Route2.asm',reference/'data/items/marts.asm',reference/'scripts/OaksLab.asm',reference/'scripts/PalletTown.asm']
 referencePins={str(f):sha(f)for f in referenceFiles}
 pins={str(f.relative_to(project)):sha(f)for f in sorted((project/'Source').rglob('*'))if f.is_file()and f.suffix in('.lua','.json')}
 routepins=json.loads((route22/'manifest.json').read_text());historical=project/'docs/validation/prebrock-mechanics/prebrock-checklist.json'
 return {'schema':2,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip(),'source_sha256':fingerprint(project),'source_files':pins,'route22_packet_manifest_sha256':sha(route22/'manifest.json'),'route22_status':'frozen staged unaccepted, not current production','historical_report':{'path':str(historical.relative_to(project)),'sha256':sha(historical),'unchanged':True},'boundaries':{'no_level_cutoff':True,'level_range':[1,100],'level0_source_events_retained':True,'stone_trade_unavailable_kept_technical':True,'relearner':False,'breeding':False,'hidden_abilities_acquired':False,'late_routes_not_added':True,'staged_individuals_and_roost_not_accepted':True},'counts':{'direct_player_species_union':len(direct),'natural_player_species_union':len(natural),'technical_allmethods_species':len(technical),'all_retained_learn_events':len(events),'all_retained_move_keys':len(keys),'natural_player_move_keys':len(actual_player),'actual_fixed_trainer_move_keys':len(actual_trainer),'actual_normal_ability_ids':len(abilityids)},'campaigns':{s:sorted(closure({s}|set(wild),{'level'}),key=lambda x:pokemon[x]['dex'])for s in starters},'acquisition':acquisition,'species':species,'events':events,'moves':move_rows,'trainer_parties':trainerrows,'normal_abilities':abilityids,'temporary_effective_abilities':[{'id':15,'producer':'natural WorrySeed, battle-scoped Insomnia, no durable slot mutation'}],'wild_held':wildHeld,'wild_held_source_sha256':sha(heldSource),'personal_binary_sha256':sha(personal),'personal_layout_sha256':sha(info),'primary_source_pins':referencePins,'items':itemrows,'shops':plain(items['marts']),'scoped_evidence':{'sdk_result_sha256':sha(sdk_evidence),'sdk_path':str(sdk_evidence),'passed':contracts['passed'],'failed':contracts['failed'],'suites':contracts['suites'],'qualification':'Suite acceptance does not prove every exposed move or unlimitedgrind scenario.'},'old_authored_placeholder':{'current_source_present':'outdoorPalletlevel7counterstarter','frozenRoute22':'separate intentional removal; never map its save flag to authenticRoute22victory'},'supported_engine_scope':'singles only; trainer party replacement and actual player switching implemented; enemy voluntary switch AI absent','status_counts':dict(collections.Counter(r['status']for r in move_rows))}

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for k in('project','route22','reference','showdown','sdk-evidence','trait-primary','output'):p.add_argument('--'+k,type=Path,required=True)
 p.add_argument('--check',action='store_true');a=p.parse_args();d=build(a.project.resolve(),a.route22.resolve(),a.reference.resolve(),a.showdown.resolve(),a.sdk_evidence.resolve(),a.trait_primary.resolve());raw=(json.dumps(d,indent=2)+'\n').encode()
 if a.check:assert a.output.read_bytes()==raw,'exposure drift'
 else:assert not a.output.exists(),'refuse overwrite evidence';a.output.write_bytes(raw)
 print(json.dumps({'ok':True,'counts':d['counts'],'status_counts':d['status_counts'],'sha256':sha(a.output)}))
if __name__=='__main__':main()

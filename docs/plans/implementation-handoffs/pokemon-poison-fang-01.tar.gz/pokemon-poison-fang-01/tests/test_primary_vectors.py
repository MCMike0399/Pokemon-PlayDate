import json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class PrimaryVectors(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.original=json.loads((ROOT/'observations.json').read_text());cls.rows={x['case']:x for x in cls.original['rows']};cls.boundary={x['case']:x for x in json.loads((ROOT/'boundary-observations.json').read_text())['rows']};cls.payload={x['case']:x for x in json.loads((ROOT/'payload-observations.json').read_text())['rows']}
 def test_pinned_metadata_not_later_gen_50percent(self):self.assertEqual(self.original['metadata'],{'power':50,'pp':15,'secondary':{'chance':30,'status':'tox'},'contact':1,'protect':1})
 def test_30_31_literal_status_boundary(self):self.assertEqual(self.rows['neutral30']['after']['status'],'tox');self.assertEqual(self.rows['neutral31']['after']['status'],'');self.assertEqual(self.rows['neutral30']['secondaryDraws'][0]['index'],29);self.assertEqual(self.rows['neutral31']['secondaryDraws'][0]['index'],30)
 def test_no_secondary_through_steel_and_shielddust(self):
  for name in ['SteelType','ShieldDust']:self.assertEqual(self.rows[name]['secondaryDraws'],[]);self.assertFalse(self.rows[name]['after']['status'])
 def test_other_preventions_happen_after_chance(self):
  for name in ['PoisonType','Immunity','Safeguard']:self.assertEqual(len(self.rows[name]['secondaryDraws']),1);self.assertFalse(self.rows[name]['after']['status'])
  self.assertEqual(self.rows['already-status']['after']['status'],'psn')
 def test_actual_lethal_status_no_mutation_but_draws(self):r=self.rows['lethal'];self.assertEqual(len(r['secondaryDraws']),1);self.assertEqual(r['after']['hp'],0);self.assertFalse(r['after']['status'])
 def test_native_recipe_hp_and_counter_literals(self):
  r=self.boundary['native-Butterfree34'];self.assertEqual((r['before']['hp'],r['after']['hp'],r['after']['toxicStage']),(84,43,1));r=self.boundary['native-Butterfree34-fail31'];self.assertEqual(r['after']['hp'],47);self.assertFalse(r['after']['status'])
 def test_actual_stat_protocol_disagreement_retained(self):r=self.payload['crunch-lethal'];self.assertEqual(len(r['chance']),1);self.assertEqual(r['targetBoosts']['def'],0)
 def test_actual_selfboost_after_ko_ignores_opposing_shielddust(self):
  r=self.payload['metalclaw-lethal-ShieldDust'];self.assertEqual(r['attackerBoosts']['atk'],1);self.assertEqual(len(r['chance']),1)
  r=self.payload['ancientpower-lethal-ShieldDust'];self.assertEqual([r['attackerBoosts'][x]for x in ['atk','def','spa','spd','spe']],[1]*5)
 def test_actual_triattack_lethal_still_selects_without_status_mutation(self):r=self.payload['triattack-lethal'];self.assertEqual(len(r['chance']),1);self.assertEqual(r['sample'],[['brn','par','frz']]);self.assertFalse(r['targetStatus'])
 def test_typed_shape_inventory_is_complete(self):
  x=json.loads((ROOT/'typed-secondary-audit.json').read_text())['counts'];self.assertEqual(x,{'move_rows':99,'typed_wrappers':102,'major_or_confusion':45,'flinch':25,'stat_nodes':39,'self_wrappers':6,'random_condition':1,'stat_sequences':2})
if __name__=='__main__':unittest.main()

# Root integration

Apply only the five manifest-owned Source patches against the reviewed integration03 base. Do not replace entire directories or generator tools.

Register these modules after battle/data imports:

```lua
import "dev/poisonFangContracts"
import "dev/secondaryContracts"
Contracts.register("poison-fang", PoisonFangContracts.run)
Contracts.register("secondaries", SecondaryContracts.run)
```

There are 12 Poison Fang and 15 secondary groups. The expected total is 996 + 27 = 1023, subject to actual registry execution.

Existing diagnostics and fixtures suffice: enemy status, HP/PP, `battle.conditions.enemy.toxic_counter` and `rng.rolls`. No persistence schema changes are needed. The generated move dependency is root producer12, SHA `de3bfca54ce62e8f06d1c170493bf9f5e318a5d5e0ed7facf033206a039121b7`.

Thrash and Chip Away rows remain unchanged and deferred. Their original request and source findings remain in the separate Route 22 proposal packet.

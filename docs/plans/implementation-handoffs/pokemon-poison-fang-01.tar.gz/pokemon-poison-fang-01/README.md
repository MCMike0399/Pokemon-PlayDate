# Poison Fang and secondary eligibility

This private candidate changes five Source files: two battle modules, the root-generated move dependency, and two new contract modules. It is based on the reviewed integration03 tree containing A, Roost and its predicate correction. Base hashes and narrow patches are recorded in the manifest. Live Source, Simulator/Data, art, world content, persistence and generator tools are untouched.

Poison Fang now has the sourced Gen V 30% chance to inflict bad poison. Its power 50, accuracy 100, PP 15, contact and protection flags remain unchanged. The exact producer12 artifact is `de3bfca54ce62e8f06d1c170493bf9f5e318a5d5e0ed7facf033206a039121b7`. Root qualified its one-row migration with 53 strict host tests and five pinned CSV inputs. Natural learnset records are Nidoran F at 45 and Nidorina at 58. Route 22 acquisition acceptance belongs to root. Thrash and Chip Away remain required later work; no currently inaccessible Moon Stone is invented to justify a first-gate claim.

The existing secondary effect classes now report a typed `secondaryKind`: condition, flinch or stat. `When` delegates; `EffectSeq` accepts homogeneous stat payloads. The wrapper validates that payload and wrapper identify the same recipient, caches the kind, then queries the existing BattleEffects owner. Ordinary equivalent Target objects and legacy selector strings remain supported. Mixed kinds, mismatched recipients and unsupported else/no-effect shapes reject before RNG or mutation. All current 99 rows and 102 wrappers are covered: 46 condition payloads including Tri Attack, 25 flinch and 31 stat; six target the attacker, including two sequences that boost five stats.

Shield Dust prevents chance sampling. The approved native-family policy samples condition/flinch chance after a KO, while a stat effect requires its actual recipient to be alive before sampling. A living attacker can therefore boost itself after defeating the opponent. The existing ApplyStatus dead guard prevents status, flinch, confusion and duration mutations. ModifyStat gains the same dead-recipient invariant. Tri Attack retains the approved conditional chance followed by status selection, including after a KO; no dead-before-choice guard was installed.

The references disagree on some draw protocols. Native C skips a lethal stat chance; actual Showdown Gen V samples it but applies no stat change. Native Tri Attack selects before chance; the existing approved Showdown order remains. Fang rows retain their existing Showdown status-then-flinch ordering. These choices and the corrected earlier Tri Attack inference are documented in `SECONDARY-ERRATUM.md`. Historical proposals and unsuccessful draft observations remain intact and are not used as passing oracles. No exact cartridge entropy or PRNG equivalence is claimed.

Actual compiled Showdown probes use immutable revision `9b136a8c8cdb860a8ab96fa063f906604e352547`; native reconstruction sources use `b279bbefa99bb2f6fbabcc95e4b6d3e939290353`. Pins and literal observations are included. Root independently replayed the initial condition and payload reports. The current boundary supplement adds the natural Butterfree fixture and reads the actual toxic stage. No fake SDK or Lua transpiler is used.

The 27 authored SDK groups comprise 12 Poison Fang tests and 15 secondary tests. They cover the 30/31 boundary, HP and counter progression, immunities, Guard, Shield Dust, existing status, Steel/Protect, Antidote/reapplication, codec and actual party switching, all typed payload shapes, malformed construction, lethal and self effects, Tri Attack and primary stat compatibility. Existing contract expectations have not been rewritten in anticipation of failures. Root must first observe and diagnose the complete SDK result.

Compile without launching Simulator:

```sh
python3 /private/tmp/pokemon-poison-fang-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-03 --output /private/tmp/pokemon-poison-fang-compile-final
python3 -m unittest discover -s /private/tmp/pokemon-poison-fang-01/tests -v
python3 /private/tmp/pokemon-poison-fang-01/mutations.py --project /private/tmp/pokemon-brock-integration-03 --output /private/tmp/pokemon-poison-mutants-compile-FRESH
```

Root alone adds `--execute` with a fresh output path for SDK execution, or selects one of `scenarios/poison-fang-proc30.json` and `scenarios/poison-fang-fail31.json`. The helper overlays only declared files and refreshes the hashes after fault injection. Mutation qualification requires the exact named test failure from exactly one numbered contract-bearing report; timeouts and malformed reports do not qualify.

The two unrun native recipes use naturally initialized Nidoran F 45 and Butterfree 34 with neutral attributes. Only Butterfree's known Rage Powder remains available; its real singles failure avoids an unsupported no-op dependency. Seed 1 produces chance 30 and variance 94: damage 36, HP 84→48, then toxic damage 5→43. Seed 107 produces chance 31 and variance 99: damage 37, HP 47 and no status. Both spend one PP per Pokémon and five rules rolls. Captures cover the natural four-move menu, impact frames, status text, first toxic tick and settled state.

This is not Brock or full-game acceptance. Mirror Move, Whirlwind and Flatter remain next first-gate dependencies. Classification does not prove every secondary probability or all 425 moves, 111 abilities and held effects. Further ability modifiers remain explicitly pending. Fixture stats use deterministic IV0/EV0; RootA production individual-stat generation, awards and Codec7 are preserved.

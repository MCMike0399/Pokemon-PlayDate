#!/usr/bin/env python3
"""Private patch composition and compile; --execute is reserved to root owner."""
import argparse,hashlib,json,subprocess,sys,shutil
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--mutant',choices=['poison50','ordinary-poison','skip-lethal-condition','roll-dead-stat','suppress-self','skip-shielddust','mutate-dead-stat','tri-skip-dead-choice']);a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def apply(output,path):
 result=subprocess.run(['git','apply','-p1','--check',str(path)],cwd=output,capture_output=True,text=True)
 if result.returncode:
  inverse=subprocess.run(['git','apply','-p1','--reverse','--check',str(path)],cwd=output,capture_output=True,text=True)
  assert inverse.returncode==0,'shared source conflict '+str(path)+': '+result.stderr;return
 subprocess.run(['git','apply','-p1',str(path)],cwd=output,check=True)
def change(path,old,new):
 body=path.read_text();assert body.count(old)==1,'mutant anchor '+old;path.write_text(body.replace(old,new,1))
def prepare(project,sdk,output,session):
 for r in manifest['source_files']:
  assert sha(stage/r['path'])==r['sha256'],'source drift '+r['path'];assert sha(stage/r['patch'])==r['patch_sha256'],'patch drift '+r['patch']
 for rel,expected in manifest.get('packet_files',{}).items():assert sha(stage/rel)==expected,'packet drift '+rel
 metadata=original(project,sdk,output,session)
 for row in manifest['source_files']:
  if row['base_sha256']is None:
   target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/row['path'],target)
  else:apply(output,stage/row['patch'])
 if a.mutant=='poison50':change(output/'Source/battle/moves.lua','When(Chance(30), ApplyStatus(DEFENDER, "badPoison"))','When(Chance(50), ApplyStatus(DEFENDER, "badPoison"))')
 elif a.mutant=='ordinary-poison':change(output/'Source/battle/moves.lua','When(Chance(30), ApplyStatus(DEFENDER, "badPoison"))','When(Chance(30), ApplyStatus(DEFENDER, "poison"))')
 elif a.mutant=='skip-lethal-condition':change(output/'Source/battle/effects.lua','return kind=="condition" or kind=="flinch" or alive(target)','return alive(target)')
 elif a.mutant=='roll-dead-stat':change(output/'Source/battle/effects.lua','return kind=="condition" or kind=="flinch" or alive(target)','return true')
 elif a.mutant=='suppress-self':change(output/'Source/battle/effects.lua','if source~=target and self:effectiveAbility(target)==19 then return false end','if self:effectiveAbility(target)==19 then return false end')
 elif a.mutant=='skip-shielddust':change(output/'Source/battle/effects.lua','if source~=target and self:effectiveAbility(target)==19 then return false end','-- deliberately missing prechance ShieldDust gate')
 elif a.mutant=='mutate-dead-stat':change(output/'Source/battle/dsl.lua','function ModifyStat:apply(battle)\n    local pokemon = self.target:resolve(battle)\n    if not pokemon:isAlive() then return end','function ModifyStat:apply(battle)\n    local pokemon = self.target:resolve(battle)')
 elif a.mutant=='tri-skip-dead-choice':change(output/'Source/battle/dsl.lua','function RandomMajorStatusEffect:apply(battle)\n    ApplyStatus','function RandomMajorStatusEffect:apply(battle)\n    if not self.target:resolve(battle):isAlive() then return end\n    ApplyStatus')
 main=output/'Source/main.lua';body=main.read_text();anchor='import "dev/catalog"';assert body.count(anchor)==1
 for module,key,table in [('poisonFangContracts','poison-fang','PoisonFangContracts'),('secondaryContracts','secondaries','SecondaryContracts')]:
  if 'import "dev/'+module+'"'not in body:body=body.replace(anchor,'import "dev/'+module+'"\nContracts.register("'+key+'",'+table+'.run)\n'+anchor,1)
 main.write_text(body)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f)for f in sorted((output/'Source').rglob('*'))if f.is_file()and f.name!='harness_build.lua'})
 info.write_text(generated);values=[]
 for k in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):values.append('    '+k+' = '+('true'if metadata[k]is True else json.dumps(metadata[k],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['poison_fang']=manifest;metadata['fault_mutant']=a.mutant
 with(output/'fixture-repair-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

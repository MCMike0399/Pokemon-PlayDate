# Bounded contact-source comparison

Design evidence only. No implementation or exact GameFreak PRNG replication claim.

Pinned reconstruction revision b279bbefa99bb2f6fbabcc95e4b6d3e939290353 declares btl_server_flow.c, battle_event.c, ability_handlers.c and item_handlers.c `complete` in b2_us overlay167 delinks. The nonmatching ledger describes all nonmatching C functions and lists neither contact handler. Symbols identify CuteCharm0x021bf544 (0x88 bytes), EffectSpore0x021bf5d8 (0x4c), CommonContactStatusAbility0x021bf630 (0x78). These are repository matching assertions; I did not rebuild/compare a ROM. This strengthens but does not automatically settle every semantic interpretation over the independent mature Gen5 simulator.

The complete pinned bodies remain in references/bw_ability_handlers.c at1998–2069; caller in references/bw_btl_server_flow.c3268–3278 and4916–4934; dispatcher in references/bw_battle_event.c216–302. Successful direct-hit processing calls reactions after drain/additional effects and before CheckFainted. The event sequence includes `BattleEvent_CallHandlers(flow, 0x4b);`. Dispatch filters active/sleeping/reentry/suppression/registered skip callbacks; it has no contact-specific filter in the isolated unsuppressed case. The per-handler target and non-substitute guards still apply.

Bounded exact C expressions: `rand = BattleRandom(30);`, `rand > 20`, `rand > 10`, and `getMoveFlag(BattleEventVar_GetValue(0x12), 0)`. The first chooses poison for21..29, paralysis11..20, sleep0..10, then calls the common contact/chance helper. Thus a successful noncontact direct hit can consume the status-selection draw but cannot apply status. Eligible contact consumes that draw and a30% chance draw; successful sleep can additionally roll duration. Suppression prevents entering the body.

Independent pinned PS base Effect Spore samples `const r = this.random(100);` after contact/powder-status eligibility:0..10sleep,11..20paralysis,21..29poison,30..99none. In Gen5 there is no later Grass powder immunity. Both have unconditional marginal outcomes11/10/9/70 in the isolated eligible case. They are not trajectory/draw-count equivalent. Current-status/type-specific rejection happens later and must be exercised separately.

Cute Charm's C body has a terminal matchup guard, then non-genderless opposite-sex eligibility, before the common30% contact helper. Independent PS contact body rolls30% before Attract's sex eligibility. Attract onStart rejects incompatible sexes, but has no HP/terminal guard; its onUpdate removes the source-linked volatile when the source ceases active. Consequently same-sex/genderless contacts differ in RNG count only; a last-member lethal contact can also differ in transient message/volatile order before cleanup. This needs an explicit case, not a claim of equality.

| Isolated case | C | PS | Classification |
|---|---|---|---|
|Effect Spore noncontact direct hit|one status-selection sample, no effect|no sample/effect|Draw-count adaptation only|
|Effect Spore eligible contact|two samples before any sleep-duration sample|one categorical sample before duration|Same11/10/9/70 marginals, different stream|
|Cute Charm eligible opposite contact, battle ongoing|one30% sample|one30% sample|Shared activation distribution|
|Cute Charm same/genderless contact|no chance sample|chance sample then eligibility failure|No infatuation either; stream differs|
|Cute Charm last-member lethal contact|terminal guard blocks|handler/Attract can run before faint cleanup|Observable ordering case to resolve|

Recommendation: preserve GenV probability, eligibility and event ordering; normalize Effect Spore to one eligible-contact categorical draw and document this RulesRNG protocol. Preserve Cute Charm's explicit C sex/terminal guard unless independent cartridge evidence changes the interpretation. Freeze literal sample counts for this recreation, without claiming GameFreak stream identity. Root approval remains required; new priority freezes this proposal without implementation.

#!/usr/bin/env python3
"""Read-only proposal audit: native B2W2 sex/item fields, independent IDs/ratios."""
import argparse,collections,csv,hashlib,json,re,struct
from pathlib import Path
HERE=Path(__file__).resolve().parent

def rows(path):return list(csv.DictReader(path.open()))
def native_items(path):
 byid={};current=-1
 for line in path.read_text().splitlines():
  line=line.strip()
  if not line or line.startswith('#'):continue
  if '=' in line:name,value=map(str.strip,line.split('=',1));current=int(value)
  else:name=line;current+=1
  if name!='ITEM_LAST':byid[current]=name
 return byid

def probabilities(values,weights):
 # The actual equal-common/rare shortcut is important: guaranteed item/no RNG.
 if values[0]==values[1]:return {str(values[0]):100}
 result=collections.Counter();remainder=100
 for value,chance in zip(values,weights):result[str(value)]+=chance;remainder-=chance
 result['0']+=remainder
 return {k:v for k,v in sorted(result.items(),key=lambda x:int(x[0])) if v}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);a=p.parse_args();root=a.project
 refs=HERE/'references'
 if (HERE/'source-manifest.json').exists():
  for name,spec in json.loads((HERE/'source-manifest.json').read_text())['files'].items():
   assert hashlib.sha256((refs/name).read_bytes()).hexdigest()==spec['sha256'],'source checksum '+name
 raw=(refs/'personal_b2w2').read_bytes()
 assert hashlib.sha256(raw).hexdigest()=='6df24e7f00dab32322d9d8f8b3209d30de1c89b0de88277081fe53434211830f'
 dex={s:int(n) for s,n in re.findall(r'^    (\w+) = \{\n        name = "[^\"]+", dex = (\d+)',(root/'Source/data/pokemon.lua').read_text(),re.M)};assert len(dex)==151
 enums=native_items(refs/'generated_items.txt');modern=(refs/'pkhex_text_Items_en.txt').read_text(encoding='utf-8-sig').splitlines()
 api_items={int(r['id']):r['identifier'] for r in rows(refs/'items.csv')}
 api_map={int(r['game_index']):int(r['item_id']) for r in rows(refs/'item_game_indices.csv') if r['generation_id']=='5'}
 species={int(r['id']):r for r in rows(refs/'pokemon_species.csv')};ratio_for_rate={0:0,1:31,2:63,4:127,6:191,8:254,-1:255}
 source=(refs/'src_ov036_enc_pokeset.c').read_text();rates=re.search(r'HELD_ITEM_RATES\[4\]\[3\] = \{(.*?)\};',source,re.S)[1]
 rates=[list(map(int,re.findall(r'\d+',line))) for line in rates.splitlines() if '{' in line]
 assert rates==[[50,5,0],[60,20,0],[50,5,1],[60,20,5]]
 current_wild=set()
 for rel in ['Source/data/viridianSlice/Route1.json','Source/data/pewterSlice/Route2.json','Source/data/pewterSlice/ViridianForest.json']:
  current_wild|={s['species'] for s in json.loads((root/rel).read_text())['encounters']['grass']['slots']}
 current_wild|={'pidgey','rattata','caterpie','weedle'}
 mtmoon=json.loads((refs/'mtmoon-exposure.json').read_text());future_wild={s['species'] for s in mtmoon['encounter_and_trainer_slots'] if s['origin']=='wild' and s.get('naturally_reachable_within_slice',True)}
 definitions=dict(re.findall(r'^        (\w+) = \{ .*?\["symbol"\] = "([^\"]+)"',(root/'Source/data/items.lua').read_text(),re.M))
 symbols_to_existing={v:k for k,v in definitions.items()}
 records=[];needed=collections.defaultdict(lambda:{'ordinary_species':[],'third_slot_species':[],'current_wild_species':[],'proposed_mtmoon_wild_species':[]})
 ratio_counts=collections.Counter()
 for name,index in sorted(dex.items(),key=lambda x:x[1]):
  ratio=raw[index*76+18];nominal=int(species[index]['gender_rate']);assert ratio==ratio_for_rate[nominal],name+' independent ratio category'
  ratio_counts[ratio]+=1;values=list(struct.unpack_from('<3H',raw,index*76+12));plain=probabilities(values,rates[0]);compound=probabilities(values,rates[1])
  default='genderless' if ratio==255 else ('female' if ratio>=128 else 'male')
  records.append({'dex':index,'species':name,'sex_ratio_byte':ratio,'nominal_female_eighths':nominal,'ordinary_female_byte_count':0 if ratio in [0,255] else (256 if ratio==254 else ratio),'default_policy_candidate':default,'native_held_fields':values,'ordinary_percent_by_native_id':plain,'compound_eyes_percent_by_native_id':compound,'held_sample_required':values[0]!=values[1],'current_connected_wild':name in current_wild,'proposed_mtmoon_wild':name in future_wild})
  for item in set(values)-{0}:
   n=needed[item]
   if plain.get(str(item),0):
    n['ordinary_species'].append(name)
    if name in current_wild:n['current_wild_species'].append(name)
    if name in future_wild:n['proposed_mtmoon_wild_species'].append(name)
   if values[2]==item:n['third_slot_species'].append(name)
 # Verify ratio preservation along every current original151 graph edge.
 graph_edges=0
 evo=(root/'Source/data/evolutionData.lua').read_text()
 for line in evo.splitlines():
  m=re.match(r'\s+(\w+) = (.*)',line)
  if m:
   for target in re.findall(r'to = "(\w+)"',m[2]):
    assert raw[dex[m[1]]*76+18]==raw[dex[target]*76+18],(m[1],target,'ratio changes')
    graph_edges+=1
 items=[]
 for item,record in sorted(needed.items()):
  symbol=enums[item][5:];canonical=''.join([symbol.lower().split('_')[0]]+[s.title() for s in symbol.lower().split('_')[1:]])
  # Canonical IDs retain established Gen5 identity, e.g Stick not modern Leek.
  if symbol in symbols_to_existing:canonical=symbols_to_existing[symbol]
  canonical={'SILVERPOWDER':'silverPowder','TWISTEDSPOON':'twistedSpoon'}.get(symbol,canonical)
  assert item in api_map,(item,'missing independent native game_index')
  record.update({'gen5Id':item,'gen5Symbol':symbol,'canonicalId':canonical,'pokeApiId':api_map[item],'pokeApiIdentifier':api_items[api_map[item]],'modern_pkhex_display':modern[item],'existing_blue_definition':symbol in symbols_to_existing,'ordinary_acquirable_if_species_is_wild':bool(record['ordinary_species'])})
  # Independent schema cross-check permits renamed Stick/Leek identity only.
  normalized=symbol.lower().replace('_','-')
  aliases={'silverpowder':'silver-powder','twistedspoon':'twisted-spoon','stick':'leek'}
  assert api_items[api_map[item]] in {normalized,aliases.get(normalized)},(item,symbol,api_items[api_map[item]])
  items.append(record)
 assert len(needed)==38;assert sum(bool(i['ordinary_species']) for i in items)==35
 # Verify the accepted49 ordinary Blue holder IDs remain their native identities.
 block=(root/'Source/data/specimenData.lua').read_text().split('    holdable = {',1)[1].split('    },',1)[0]
 held=re.findall(r'        (\w+) = (\d+),',block);assert len(held)==49
 aliases={'ELIXER':'ELIXIR','MAX_ELIXER':'MAX_ELIXIR','THUNDER_STONE':'THUNDERSTONE'}
 for key,item in held:assert enums[int(item)]=='ITEM_'+aliases.get(definitions[key],definitions[key]),(key,item,enums[int(item)])
 report={'schema':1,'proposal_only':True,'species_count':151,'sex_ratio_counts':dict(sorted(ratio_counts.items())),'original151_evolution_edges_same_ratio':graph_edges,'held_item_native_ids':38,'ordinary_native_ids':35,'new_ordinary_definitions':sum(not i['existing_blue_definition'] and bool(i['ordinary_species']) for i in items),'third_only_native_ids':[i['gen5Id'] for i in items if not i['ordinary_species']],'existing_blue_holdables_native_crosscheck':49,'current_connected_wild_item_ids':[i['gen5Id'] for i in items if i['current_wild_species']],'proposed_mtmoon_wild_item_ids':[i['gen5Id'] for i in items if i['proposed_mtmoon_wild_species']]}
 (HERE/'species-sex-held.json').write_text(json.dumps({'schema':1,'species':records},indent=2)+'\n');(HERE/'wild-held-items.json').write_text(json.dumps({'schema':1,'rates':rates,'items':items},indent=2)+'\n');(HERE/'audit-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()

# Mt. Moon source/content candidate

Read [the proposal](docs/proposal.md) before runtime integration, then [the exact inventory](docs/inventory.md). This packet is source/art/data preparation only. No live Source, Simulator, Data or frozen catalog packet was changed. No Lua controller is supplied or claimed playable.

Current final source candidate is `generated-02/` (128 deterministic artifacts). `generated-01/` and `source-pin-preliminary-01.json` preserve the earlier extraction; they are historical and are not the integration target. `source-pin.json` pins107 consumed original files from the independently SHA256-verified immutable pret/pokered archive, revision `af519899719f0754965776faac0e836a3b906e6d`. `generator-dependencies.json` pins the three existing project helper modules. No unpinned master/network fallback.

The six new maps are Route3, Route4, MtMoonPokecenter, MtMoon1F, MtMoonB1F and MtMoonB2F. Source metadata indexes21trainers/47opponents,22warps,9visible pickups,3hidden items,2hidden Center controls and101text labels. **One indexed Route4 Lv31 LASS is structurally unreachable from this region entry.** Keep her original row/object, not a new bridge or an available early fight. The actor-free directed source geometry report proves only structural connectivity, not natural gameplay. The CeruleanCity boundary stays explicitly blocked until its region is prepared and registered.

There are99unique canonical tile keys,65 shared exactly with current Pewter source grids/terrain/collision and34new; five new source strips (clipboard,fossil,hiker,middle_aged_man,rocket),20frames. All12region strips/51source frames are supplied for complete indexing, with102 independent raw/mask previews; seven shared strips remain their exact original source data. Native phase/motion/composition acceptance is pending. No protected RED/BLUE/Oak/Pallet pixel is regenerated.

`source-check-02.json` records the independent Pillow/source-byte oracle:6,656cells,137map-localgrids,12full-map PNGs (6,815,744native pixels),51source sprite frames and102RGBA/mask PNGs match pinned originals and the specified phase0/mask transform. Its directed collision/pair/ledge/warp graph checks22passable target cells and14exact-cell internal ladder arrivals. A source oracle and a conservative structural graph do not replace actual SDK captures/input.

`combat-exposure-02.json` is a separate read-only audit of exact current production hashes:98source slots (47trainer mons,50wild slots,1gift),58initialized GenV move IDs and142later level-up IDs across those species. Empty status records are flagged for dispatcher/runtime review, not automatically called missing behavior. It includes the unreachable trainer with an explicit false natural-reachability tag. Nature/ability/held acquisition follows current Specimen policy, not an invented original Blue reward. Battle implementation and broader ability/item qualification remain root/rules-owner work.

## Reproduce and qualify

Use a venv with repository `tools/requirements-dev.txt` (Pillow12.0.0). All paths below are explicit inputs; use the same command with another checkout/reference directory. No machine paths are embedded in the tools.

```sh
python /path/to/packet/tools/generate_mt_moon.py \
  --project /path/to/Pokemon-PlayDate \
  --reference /path/to/pokered-af519899719f0754965776faac0e836a3b906e6d \
  --check /path/to/packet/generated-02

python /path/to/packet/tools/generate_mt_moon.py \
  --project /path/to/Pokemon-PlayDate \
  --reference /path/to/pokered-af519899719f0754965776faac0e836a3b906e6d \
  --output /path/to/new-unique-candidate

python /path/to/packet/tools/check_source.py \
  --reference /path/to/pokered-af519899719f0754965776faac0e836a3b906e6d \
  --candidate /path/to/packet/generated-02 \
  --report /path/to/new-unique-source-report.json

python /path/to/packet/tests/test_mt_moon.py \
  --project /path/to/Pokemon-PlayDate \
  --reference /path/to/pokered-af519899719f0754965776faac0e836a3b906e6d \
  --candidate /path/to/packet/generated-02
```

Generator check rejects missing/extra/changed artifacts, unknown inputs/hash drift, malformed source dimensions/palettes/party indices/frame counts/text dependencies and changed project helper bytes. Candidate publication refuses existing directories and production Source destinations. The independent oracle does not import the generator. Ten tests include resigned candidate-grid, invisible-RGB one-pixel and mask one-pixel mutations, real source-byte drift, missing/extra artifacts and a blocked ladder arrival. All10pass; exact reproduction and the independent source report pass. No Simulator was run by this worker.

`discover_pins.py` is an explicit development bootstrap only: verifies the entire archive SHA before discovering consumed hashes; refuses to replace an already frozen pin. Ordinary generation requires only the frozen pin and explicit extracted checkout. It never downloads source.

## Runtime integration work remains

Root should first review the proposed shared region/trainer/event seams, then stage an integration against the current Source. Avoid a second ImportedMaps/WorldDeltas owner, copied Pewter controller or blanket source-event binding. These generated map records retain `runtime_adapter.integrated=false`, script status unimplemented and explicit blocked controls. They are not ready-to-drop live campaign JSON.

Concrete dependencies are cave floor encounter eligibility/rate interpretation; source-safe B2F fossil rectangle and post-choice sight policy; atomic paid gift/recruit/debit/flag/RNG; exclusive fossil commit with validated source Nerd movement; new NPC cadence/masks; nurse/PC/checkpoint whitelist; and source ladder/exterior arrival distinction. The proposal specifies exact IDs/text/coords and failure behavior. No primary source inputs are missing; runtime owners/effects/native validation are the outstanding dependencies.

Required real-SDK evidence after integration:

- Natural Brock-complete east exit→Route3→Route4 Center→correct cave ladder chain→fossil gate→eastern Route4 boundary, without teleport/outcome fixtures. Observe collision, source trainers/flags/payouts, encounter returns/blackout and per-transition settled state. Exercise all22warps and14internal ladder directions separately where natural main path omits branches; no arrival ping-pong.
- Seller NO/insufficient funds/success to party/success to current box/full party+box retry/repeat/stale epoch. Exact money, identity/dex, flags and RNG unchanged on failure; one charge/gift on success, no receipt before commit. Actual two-process save/Continue preserves purchase and boxed identity.
- Super Nerd loss/retry/win and both fossil choices in independent sessions. Full bag leaves both fossils eligible, no item/flag; freeing a slot then YES grants only one, removes both from rebuilt scene, correct source actor movement without overlap; NO/cancel/stale callbacks change nothing. Save/restart retains exclusive choice and Nerd defeat. Source safe area suppresses wild draws only under correct flag/coords.
- All visible/hidden pickups retry on full bag and persist collected state. Center heal/checkpoint and PC transfers use existing authoritative owners. Link functions/unused text/unregistered Cerulean and unsupported field item actions remain explicit. Do not expose the unreachable Lv31 trainer through convenience spawn/path changes.
- Native full maps/collision/events and every new NPC frame/mask/background/direction/cadence, protected catalog exact preservation, source independent comparison, real actor motion and natural scene inspection. This packet’s host PNGs are not actual game screenshots or reviewed baselines.

Source links and precise owner interfaces are in `docs/proposal.md`. No art replacement, UI completion, physical-device budget or campaign-completion claim is made.

#!/usr/bin/env python3
"""Explicit full pinned-source qualification and independent defect detection."""
import argparse,copy,hashlib,importlib.util,json,shutil,sys,tempfile,unittest
from pathlib import Path
from PIL import Image
STAGE=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--reference',required=True);p.add_argument('--candidate',required=True);ARGS,rest=p.parse_known_args();sys.argv=[sys.argv[0],*rest]
PROJECT=Path(ARGS.project);REFERENCE=Path(ARGS.reference);CANDIDATE=Path(ARGS.candidate)
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
G=load('candidate_generator',STAGE/'tools/generate_mt_moon.py');O=load('independent_oracle',STAGE/'tools/check_source.py')
def resign(root,path):
 manifest_path=root/'source-manifest.json';manifest=json.loads(manifest_path.read_text());manifest['artifacts'][path]=hashlib.sha256((root/path).read_bytes()).hexdigest();manifest_path.write_text(json.dumps(manifest))
class SourceTests(unittest.TestCase):
 def test_exact_reproduction(self):
  out,ref=G.build(PROJECT,REFERENCE);G.publish(CANDIDATE,out,True);self.assertEqual(len(out),128);self.assertEqual(len(ref.consumed),107)
 def test_independent_pixels_masks_geometry(self):
  r=O.run(REFERENCE,CANDIDATE);self.assertEqual(r['maps']['cells'],6656);self.assertEqual(r['maps']['native_pixels'],6815744);self.assertEqual(r['sprites']['frames'],51)
  self.assertEqual(r['geometry']['warps_checked'],22);self.assertEqual(r['geometry']['ladders_exact_cell'],14);self.assertFalse(r['runtime_accepted'])
 def test_source_scope_and_unused_high_level_trainer(self):
  rows=json.loads((CANDIDATE/'trainers.json').read_text())['trainers'];self.assertEqual(len(rows),21)
  t=next(t for t in rows if t['id']=='pokered:ROUTE_4:objects:2');self.assertEqual([m['level'] for m in t['party']],[31,31,31]);self.assertEqual(t['payout'],465)
  nidoran=next(t for t in rows if t['id']=='pokered:ROUTE_3:objects:6');self.assertEqual(nidoran['party'][-1]['species'],'nidoranM')
  nerd=next(t for t in rows if t['id']=='pokered:MT_MOON_B2F:objects:1');self.assertTrue(nerd['talk_only']);self.assertEqual(nerd['coordinate_trigger'],{'x':13,'y':8});self.assertEqual(nerd['payout'],300)
 def test_real_byte_source_drift_rejected(self):
  pin=json.loads((STAGE/'source-pin.json').read_text())
  with tempfile.TemporaryDirectory(prefix='mtmoon-source-') as tmp:
   root=Path(tmp)
   for name in pin['files']:
    target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REFERENCE/name,target)
   bad=root/'scripts/MtMoonPokecenter.asm';bad.write_bytes(bad.read_bytes()+b'\n; controlled mutation\n')
   with self.assertRaisesRegex(ValueError,'source drift'):O.run(root,CANDIDATE)
 def test_changed_grid_rejected_even_resigned(self):
  with tempfile.TemporaryDirectory(prefix='mtmoon-grid-') as tmp:
   root=Path(tmp)/'candidate';shutil.copytree(CANDIDATE,root);path='maps/MtMoon1F.json';d=json.loads((root/path).read_text());row=d['grids'][0]['grid'][0];d['grids'][0]['grid'][0]=('#' if row[0]!='#' else '.')+row[1:];(root/path).write_text(json.dumps(d));resign(root,path)
   with self.assertRaisesRegex(ValueError,'source grid'):O.run(REFERENCE,root)
 def test_raw_invisible_RGB_one_pixel_rejected(self):
  with tempfile.TemporaryDirectory(prefix='mtmoon-rgba-') as tmp:
   root=Path(tmp)/'candidate';shutil.copytree(CANDIDATE,root);path='catalog/sprite-rocket-0-raw.png';im=Image.open(root/path).convert('RGBA');before=im.getpixel((0,0));self.assertEqual(before[3],0);im.putpixel((0,0),(0 if before[0] else 255,*before[1:]));im.save(root/path);resign(root,path)
   with self.assertRaisesRegex(ValueError,'rawRGBA pixel/mask mismatch'):O.run(REFERENCE,root)
 def test_mask_one_pixel_rejected(self):
  with tempfile.TemporaryDirectory(prefix='mtmoon-mask-') as tmp:
   root=Path(tmp)/'candidate';shutil.copytree(CANDIDATE,root);path='catalog/sprite-fossil-0-mask.png';im=Image.open(root/path).convert('L');im.putpixel((0,0),255-im.getpixel((0,0)));im.save(root/path);resign(root,path)
   with self.assertRaisesRegex(ValueError,'mask pixel/mask mismatch'):O.run(REFERENCE,root)
 def test_extra_missing_artifact_rejected(self):
  with tempfile.TemporaryDirectory(prefix='mtmoon-inventory-') as tmp:
   root=Path(tmp)/'candidate';shutil.copytree(CANDIDATE,root);(root/'unreviewed-extra.json').write_text('{}')
   with self.assertRaisesRegex(ValueError,'inventory differs'):O.run(REFERENCE,root)
   (root/'unreviewed-extra.json').unlink();(root/'catalog/sprite-fossil-0-mask.png').unlink()
   with self.assertRaisesRegex(ValueError,'inventory differs'):O.run(REFERENCE,root)
 def test_control_requirement_data(self):
  r=json.loads((CANDIDATE/'event-requirements.json').read_text());self.assertEqual(r['seller']['price'],500);self.assertEqual(r['seller']['level'],5)
  self.assertEqual(len(r['fossils']['choices']),2);self.assertEqual(r['fossils']['dome_nerd_movements'],['right','up']);self.assertFalse(r['fossils']['after_choice_automatic_trainer_sight']);self.assertTrue(r['fossils']['exclusive'])
  self.assertEqual([(x['argument_source'],x['x'],x['y']) for x in r['hidden_events'] if x['handler_source']=='HiddenItems'],[('MOON_STONE',18,12),('ETHER',33,9),('GREAT_BALL',40,3)])
 def test_blocked_ladder_arrival_is_detected(self):
  defs={n:json.loads((CANDIDATE/'maps'/f'{n}.json').read_text()) for n in G.MAPS}
  defs['MtMoonB1F']['collision'][5][5]=1
  with self.assertRaisesRegex(ValueError,'warp source target blocked'):O.geometry(defs,CANDIDATE)
if __name__=='__main__':unittest.main()

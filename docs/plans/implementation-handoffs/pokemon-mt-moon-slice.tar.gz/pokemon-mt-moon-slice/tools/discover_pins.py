#!/usr/bin/env python3
"""One-time explicit archive discovery; ordinary reproduction uses frozen pins."""
import argparse,hashlib,importlib.util,json,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--reference',required=True);p.add_argument('--archive',required=True);p.add_argument('--output',required=True);a=p.parse_args()
stage=Path(__file__).resolve().parents[1];spec=importlib.util.spec_from_file_location('candidate',stage/'tools/generate_mt_moon.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
archive=Path(a.archive)
if hashlib.sha256(archive.read_bytes()).hexdigest()!=m.ARCHIVE_SHA:raise SystemExit('immutable archive checksum mismatch')
pins={}
with tarfile.open(archive) as tar:
 for row in tar.getmembers():
  if row.isfile():pins[row.name.split('/',1)[1]]=hashlib.sha256(tar.extractfile(row).read()).hexdigest()
out,ref=m.build(a.project,a.reference,pins)
pin=stage/'source-pin.json'
if pin.exists():raise SystemExit('source pin already frozen; use ordinary generator --check')
pin.write_text(json.dumps({'schema':1,'revision':m.REVISION,'archive_sha256':m.ARCHIVE_SHA,'repository':'https://github.com/pret/pokered','files':dict(sorted(ref.consumed.items()))},indent=2)+'\n')
m.publish(a.output,out)
print(len(out),len(ref.consumed))

#!/usr/bin/env python3
"""Pinned Blue Mt. Moon source candidate. No runtime writes, ROM, network or Simulator."""
from __future__ import annotations
import argparse, hashlib, importlib.util, io, json, re, sys
from pathlib import Path
sys.dont_write_bytecode=True
from PIL import Image
STAGE = Path(__file__).resolve().parents[1]
REVISION = 'af519899719f0754965776faac0e836a3b906e6d'
ARCHIVE_SHA = 'e571972fc926dcb65d94fc989299d38109590aa945ed657bf215eac8561afd05'
MAPS = ('Route3', 'Route4', 'MtMoonPokecenter', 'MtMoon1F', 'MtMoonB1F', 'MtMoonB2F')
CLASSES = {key: (name+'Data', name+'Pic') for key,name in (
 ('OPP_BUG_CATCHER','BugCatcher'),('OPP_YOUNGSTER','Youngster'),('OPP_LASS','Lass'),
 ('OPP_HIKER','Hiker'),('OPP_SUPER_NERD','SuperNerd'),('OPP_ROCKET','Rocket'))}
ALIASES = {'NIDORAN_M':'nidoranM','NIDORAN_F':'nidoranF','MR_MIME':'mrMime','FARFETCHD':'farfetchd'}
EXTRA = ('home/trainers.asm','engine/overworld/trainer_sight.asm','macros/scripts/maps.asm',
 'engine/battle/read_trainer_party.asm','data/maps/toggleable_objects.asm','constants/event_constants.asm',
 'constants/item_constants.asm','engine/events/pokecenter.asm','engine/events/pick_up_item.asm',
 'engine/events/give_pokemon.asm','engine/overworld/hidden_events.asm','data/events/hidden_events.asm',
 'data/events/hidden_item_coords.asm','engine/events/black_out.asm','engine/events/set_blackout_map.asm',
 'data/maps/special_warps.asm','data/maps/rest_house_maps.asm','constants/toggle_constants.asm',
 'data/sprites/facings.asm','home/map_objects.asm','home/overworld.asm','engine/overworld/ledges.asm',
 'engine/events/hidden_items.asm','data/tilesets/door_tile_ids.asm',
 'engine/battle/wild_encounters.asm','engine/overworld/auto_movement.asm','engine/overworld/doors.asm',
 'engine/overworld/player_state.asm','data/maps/headers/PewterCity.asm',
 'data/maps/headers/CeruleanCity.asm','scripts/PewterCity.asm')
def digest(raw): return hashlib.sha256(raw).hexdigest()
def load(project,name,path):
 spec=importlib.util.spec_from_file_location(name,Path(project)/path)
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
def block(text,label):
 match=re.search(r'^'+re.escape(label)+r':{1,2}\s*$',text,re.M)
 if not match: raise ValueError('missing source label '+label)
 rest=text[match.end():];end=re.search(r'^\w+:',rest,re.M)
 return rest[:end.start()] if end else rest

def party(g,text,label,index):
 rows=g.records(block(text,label),'db')
 if not 1<=index<=len(rows): raise ValueError('trainer ordinal outside class')
 args=rows[index-1]['args'];out=[]
 if args[-1]!='0':raise ValueError('missing party terminator')
 if args[0].upper()=='$FF':
  if len(args)%2:raise ValueError('invalid mixed-level party')
  pairs=[(g.integer(args[i]),args[i+1]) for i in range(1,len(args)-1,2)]
 else:pairs=[(g.integer(args[0]),s) for s in args[1:-1]]
 for level,species in pairs:
  if not 1<=level<=100:raise ValueError('invalid trainer level')
  out.append({'species':ALIASES.get(species,species.lower()),'species_source':species,'level':level})
 if not 1<=len(out)<=6:raise ValueError('invalid trainer party size')
 return out

def trainers(g,ref,maps):
 source=g.blue_text(ref.text('data/trainers/parties.asm'))
 prices={r['args'][0]:g.integer(r['args'][1]) for r in g.records(ref.text('data/trainers/pic_pointers_money.asm'),'pic_money')}
 out=[]
 for name,d in maps.items():
  script=ref.text('scripts/'+name+'.asm');headers=g.records(script,'trainer');index=0
  for obj in d['events']['objects']:
   if obj['kind']!='trainer_or_static_pokemon':continue
   cls,ordinal=obj['extra'];ordinal=g.integer(ordinal);label,pic=CLASSES[cls]
   special=name=='MtMoonB2F' and obj['source_index']==1
   if special:
    flag='EVENT_BEAT_MT_MOON_EXIT_SUPER_NERD';sight=0
    labels=['MtMoonB2FSuperNerdTheyreBothMineText','MtMoonB2FSuperNerdOkIllShareText','MtMoonB2fSuperNerdEachTakeOneText']
   else:
    flag,view,*labels=headers[index]['args'];index+=1;sight=g.integer(view)
   roster=party(g,source,label,ordinal);base=prices[pic]
   if base%100:raise ValueError('unexpected fractional payout')
   out.append({'id':obj['id'],'map_id':d['id'],'source_object_index':obj['source_index'],
    'x':obj['x'],'y':obj['y'],'facing_source':obj['range_or_facing'],'sprite_source':obj['sprite'],
    'source_flag':flag,'class_source':cls,'roster_id':ordinal,'party':roster,'sight_range_cells':sight,
    'talk_only':special,'coordinate_trigger':{'x':13,'y':8} if special else None,
    'dialogue_script_labels':dict(zip(('before','won','after'),labels)),
    'money_source_bcd3':base,'base_money':base//100,'payout':base//100*roster[-1]['level'],
    'source':{'objects':'data/maps/objects/'+name+'.asm','script':'scripts/'+name+'.asm',
      'parties':'data/trainers/parties.asm','money':'data/trainers/pic_pointers_money.asm'}})
  if index!=len(headers):raise ValueError('unmatched trainer header '+name)
 return out

def sprites(g,sg,ref,maps):
 wanted={e['sprite'] for d in maps.values() for e in d['events']['objects']}
 declared=set(re.findall(r'^\s*const (SPRITE_\w+)',ref.text('constants/sprite_constants.asm'),re.M))
 rows=re.findall(r'^\s*overworld_sprite (\w+),\s*(\d+)\s*;\s*(SPRITE_\w+)',ref.text('data/sprites/sprites.asm'),re.M)
 graphics=dict(re.findall(r'^(\w+)::\s+INCBIN "([^"]+)"',ref.text('gfx/sprites.asm'),re.M))
 mapping={};strips={}
 for label,count,constant in rows:
  if constant not in wanted:continue
  if constant not in declared or label not in graphics:raise ValueError('unknown sprite constant')
  path=graphics[label].replace('.2bpp','.png');name=Path(path).stem
  mapping[constant]={'source':path,'name':name,'original_tiles':int(count)}
  strips[name]=sg.sprite_data(ref,name)
  if int(count)!=min(len(strips[name]['frames']),3)*4:raise ValueError('standing sprite tile count differs from source metadata')
 if set(mapping)!=wanted:raise ValueError('missing sprite binding')
 return {'schema':1,'source_revision':REVISION,'mapping':mapping,'sprites':strips}

def hidden(g,ref,maps):
 current=None;ordinal=0;out=[];byconst={d['source_map_constant']:d for d in maps.values()}
 for line in ref.text('data/events/hidden_events.asm').splitlines():
  marker=g.records(line,'hidden_events_for')
  if marker:current=marker[0]['args'][0];ordinal=0
  for row in g.records(line,'hidden_event'):
   if current not in byconst:continue
   ordinal+=1;x,y,handler,arg=row['args'];x,y=g.integer(x),g.integer(y)
   d=byconst[current];w,h=d['dimensions']['cells']
   if not 0<=x<w or not 0<=y<h:raise ValueError('hidden event outside map')
   out.append({'id':f'pokered:{current}:hidden:{ordinal}','map_id':d['id'],'x':x,'y':y,
    'handler_source':handler,'argument_source':arg,'source':'data/events/hidden_events.asm'})
 return out

def warps(g,ref,maps):
 byconst={d['source_map_constant']:d for d in maps.values()};out=[]
 door_text=ref.text('data/tilesets/door_tile_ids.asm')
 # Direction-specific GB engine arrivals need review. Internal ladder arrivals
 # intentionally remain exact source cells and preserve facing, without a
 # generic door advance. Exterior entries are labelled separately below.
 for name,d in maps.items():
  for e in d['events']['warps']:
   dst=e['destination'];constant=dst.get('map','ROUTE_4');target=byconst.get(constant)
   if target is None:raise ValueError('unexpected out-of-region warp '+constant)
   arrival=target['events']['warps'][dst['warp_index']-1]
   ladder=d['tileset']['constant']=='CAVERN' and target['tileset']['constant']=='CAVERN'
   row={'id':e['id'],'source_map_id':d['id'],'source_x':e['x'],'source_y':e['y'],
    'target_map_id':target['id'],'target_warp':dst['warp_index'],'target_x':arrival['x'],'target_y':arrival['y'],
    'dynamic_last_map':dst['kind']=='last_outdoor_map','resolved_last_map':'ROUTE_4' if dst['kind']=='last_outdoor_map' else None,
    'arrival_kind':'ladder' if ladder else 'exterior-door-or-cave-mouth',
    'proposed_runtime_arrival':{'x':arrival['x'],'y':arrival['y'],'preserveFacing':True} if ladder else None,
    'collision_at_source_arrival':target['collision'][arrival['y']][arrival['x']],
    'status':'source target resolved; door/cave-mouth offset requires owner traversal review' if not ladder else 'exact source ladder cell; suppress immediate retrigger until a completed new step'}
   out.append(row)
 return out

def script_inventory(g,sg,ref,maps,ts,hidden_events):
 bytrainer={t['id']:t for t in ts};toggle=ref.text('data/maps/toggleable_objects.asm');items=[];events=[]
 for name,d in maps.items():
  script=ref.text('scripts/'+name+'.asm');constants=[r['args'][0] for r in g.records(ref.text('data/maps/objects/'+name+'.asm'),'const_export')]
  pointers={r['args'][1]:r['args'][0] for r in g.records(script,'dw_const') if len(r['args'])==2 and r['args'][1].startswith('TEXT_')}
  # Resolve every local text pointer, recording exact far text dependencies and
  # non-text control calls; special controls are never flattened into dialogue.
  for kind,collection in d['events'].items():
   for event in collection:
    if kind=='warps':continue
    pointer=pointers.get(event.get('text_id'));body=block(script,pointer) if pointer and re.search(r'^'+re.escape(pointer)+':',script,re.M) else ''
    far=re.findall(r'\btext_far\s+(_\w+)',body)
    calls=sorted(set(re.findall(r'\b(?:call|jp)\s+(\w+)',body)))
    status='source-dialogue' if far and not calls else 'requires-control-owner'
    if event['id'] in bytrainer:status='trainer'
    if event.get('kind')=='item':
     status='atomic-item-pickup';symbol=constants[event['source_index']-1]
     if not re.search(r'toggle_object_state\s+'+re.escape(symbol)+r',\s*ON',toggle):raise ValueError('pickup initially hidden')
     items.append({'id':event['id'],'source_object':symbol,'item_source':event['extra'][0],'quantity':1,'x':event['x'],'y':event['y'],'map_id':d['id'],'initially_visible':True})
    events.append({'id':event['id'],'kind':kind,'x':event['x'],'y':event['y'],'source_text_id':event.get('text_id'),
      'script_pointer':pointer,'far_text_labels':far,'control_calls':calls,'status':status,'movement_source':event.get('movement'),'facing_or_range_source':event.get('range_or_facing')})
 return {'schema':1,'runtime_installed':False,'campaign_ready':False,'events':events,'visible_items':items,
  'hidden_events':hidden_events,'scripts':{name:maps[name]['script'] for name in MAPS},
  'required_owners':['shared immutable region catalog/ImportedMaps composition','registered trainer definitions and sprite cadence','region event adapter selected by stable event ID','cave walking encounters + fossil safe area','atomic seller/recruit/money/flag transaction','exclusive fossil transaction + bounded Nerd movement','nurse/PC/new checkpoint whitelist','external-door/cave-mouth arrival review; exact internal ladders'],
  'seller':{'id':'pokered:MT_MOON_POKECENTER:objects:4','source':'scripts/MtMoonPokecenter.asm:MtMoonPokecenterMagikarpSalesmanText',
   'species':'magikarp','level':5,'price':500,'flag':'EVENT_BOUGHT_MAGIKARP',
   'source_capacity':'party below6 receives; otherwise current box below20 receives; both full failure leaves money/flag unchanged; retry allowed',
   'required_atomic_commit':['planned active-session gift Specimen/RNG','same-identity recruit/dex','money debit500','EVENT_BOUGHT_MAGIKARP=true'],
   'receipt_labels':['_GotMonText','_SentToBoxText'],'failure_label':'_BoxIsFullText'},
  'fossils':{'map_id':'pokered:MT_MOON_B2F','trainer_id':'pokered:MT_MOON_B2F:objects:1','trainer_flag':'EVENT_BEAT_MT_MOON_EXIT_SUPER_NERD',
   'choices':[{'id':'pokered:MT_MOON_B2F:objects:6','item_source':'DOME_FOSSIL','flag':'EVENT_GOT_DOME_FOSSIL','x':12,'y':6},
              {'id':'pokered:MT_MOON_B2F:objects:7','item_source':'HELIX_FOSSIL','flag':'EVENT_GOT_HELIX_FOSSIL','x':13,'y':6}],
   'exclusive':True,'full_bag_label':'_MtMoonB2FYouHaveNoRoomText','receipt_label':'_MtMoonB2FReceivedFossilText',
   'nerd_claim_label':'_MtMoonB2FSuperNerdThenThisIsMineText','post_choice_visibility':'both fossil source objects absent; only chosen original item granted',
   'full_bag':'no item/choice/visibility mutation; retry remains available',
   'after_defeat_wild_safe_rectangle':{'x_min':11,'x_max':14,'y_min':5,'y_max':8},
   'after_choice_automatic_trainer_sight':False,
   'dome_near_player_cells':[[12,7],[11,6],[12,5]],'dome_nerd_movements':['right','up'],
   'helix_near_player_cells':[[13,7],[14,6],[14,5]],'helix_nerd_movements':['up'],
   'source':'scripts/MtMoonB2F.asm'},
  'checkpoint':{'zone_id':'pokered:ROUTE_4','x':11,'y':6,'facing':'down','source':'data/maps/special_warps.asm:.Route4'},
  'blocked_optional_controls':['MtMoonPokecenter LinkReceptionist cable club/serial connection','MtMoonB1FUnusedText has no object/background trigger','Route4 east CeruleanCity boundary until next region registered','Fly/Teleport/EscapeRope/Dig field travel not silently enabled by item pickups']}

def previews(g,maskmod,sprite_data):
 out={};rows=[]
 for name,strip in sprite_data['sprites'].items():
  for index,grid in strip['frames'].items():
   raw=g.render_map({'dimensions':{'cells':[1,1]},'grids':[{'id':1,'grid':grid}],'tile_ids':[[1]]})
   image=Image.open(io.BytesIO(raw)).convert('RGBA');mask=Image.frombytes('L',(32,32),maskmod.mask_bytes(grid));image.putalpha(mask)
   for kind,value in (('raw',image),('mask',mask)):
    filename=f'catalog/sprite-{name}-{index}-{kind}.png';buf=io.BytesIO();value.save(buf,format='PNG');out[filename]=buf.getvalue()
   rows.append({'source_id':strip['id']+':frame:'+index,'path':f'sprite-{name}-{index}-raw.png','mask':f'sprite-{name}-{index}-mask.png','phase':'explicit source phase0 candidate; protected legacy NPCs untouched'})
 out['catalog/sprite-inventory.json']=g.json_bytes({'schema':1,'images':rows,'review_status':'unreviewed host candidates, not native proof'})
 return out

def build(project,reference,pins=None):
 project=Path(project)
 for path,expected in json.loads((STAGE/'generator-dependencies.json').read_text())['project_files'].items():
  if digest((project/path).read_bytes())!=expected:raise ValueError('generator dependency changed '+path)
 g=load(project,'mtmoon_map_generator','tools/generate_kanto_maps.py');sg=load(project,'mtmoon_sprite_generator','tools/generate_viridian_slice.py');maskmod=load(project,'mtmoon_masks','tools/generate_overworld_sprites.py')
 if pins is None:
  pin=json.loads((STAGE/'source-pin.json').read_text())
  if pin['revision']!=REVISION or pin['archive_sha256']!=ARCHIVE_SHA:raise ValueError('source revision/archive mismatch')
  pins=pin['files']
 ref=g.Reference(reference,pins);maps={name:g.decode_map(ref,name) for name in MAPS}
 for d in maps.values():
  d['runtime_adapter']['padding_cells']=[max(0,(13-d['dimensions']['cells'][0])//2),0]
  for section in ('grass','water'):
   for slot in d['encounters'][section]['slots']:slot['species']=ALIASES.get(slot['species_source'],slot['species_source'].lower())
 ts=trainers(g,ref,maps);ss=sprites(g,sg,ref,maps);hh=hidden(g,ref,maps);ww=warps(g,ref,maps)
 texts={}
 for name in MAPS:
  path='text/'+name+'.asm'
  for label,recipe in sg.text_recipes(ref.text(path)).items():texts[label]={'source':path,'recipe':recipe}
 # Only retain referenced shared labels, preserving original control recipes.
 needed={'_MartSignText','_PokeCenterSignText','_MoneyForWinningText'}
 for d in maps.values():needed.update(re.findall(r'\btext_far\s+(_\w+)',ref.text(d['script']['source'])))
 for path in ('engine/events/pokecenter.asm','engine/events/pick_up_item.asm','engine/events/give_pokemon.asm','engine/events/hidden_items.asm'):
  needed.update(re.findall(r'\btext_far\s+(_\w+)',ref.text(path)))
 for path in ('data/text/text_1.asm','data/text/text_2.asm','data/text/text_3.asm','data/text/text_4.asm','data/text/text_5.asm'):
  for label,recipe in sg.text_recipes(ref.text(path)).items():
   if label in needed:texts.setdefault(label,{'source':path,'recipe':recipe})
 missing=needed-set(texts)
 if missing:raise ValueError('missing dialogue dependencies '+str(sorted(missing)))
 for path in EXTRA:ref.bytes(path)
 requirements=script_inventory(g,sg,ref,maps,ts,hh)
 seller=ref.text('scripts/MtMoonPokecenter.asm')
 if not re.search(r'lb bc, MAGIKARP, 5',seller) or 'EVENT_BOUGHT_MAGIKARP' not in seller or 'ld a, $5' not in seller:raise ValueError('seller source contract changed')
 fossil_script=ref.text('scripts/MtMoonB2F.asm')
 for flag in ('EVENT_GOT_DOME_FOSSIL','EVENT_GOT_HELIX_FOSSIL','EVENT_BEAT_MT_MOON_EXIT_SUPER_NERD'):
  if flag not in fossil_script:raise ValueError('fossil source contract changed')
 if not re.search(r'\.Route4:\s+fly_warp ROUTE_4,\s+11,\s+6',ref.text('data/maps/special_warps.asm')):raise ValueError('checkpoint source changed')
 out={}
 for name,d in maps.items():
  out['maps/'+name+'.json']=g.json_bytes(d);out['catalog/'+name+'-native.png']=g.render_map(d);out['catalog/'+name+'-reference.png']=g.render_map(d,False)
 out.update(previews(g,maskmod,ss))
 out['trainers.json']=g.json_bytes({'schema':1,'source_revision':REVISION,'trainers':ts})
 out['sprites.json']=g.json_bytes(ss);out['warps.json']=g.json_bytes({'schema':1,'warps':ww})
 out['dialogue.json']=g.json_bytes({'schema':1,'source_revision':REVISION,'texts':texts})
 out['event-requirements.json']=g.json_bytes(requirements)
 out['inventory.json']=g.json_bytes({'schema':1,'source_revision':REVISION,'maps':[{'name':n,'id':d['id'],'dimensions':d['dimensions']['cells'],'tileset':d['tileset']['constant'],'connections':d['connections'],'encounters':d['encounters'],'events':{k:len(v) for k,v in d['events'].items()},'unique_grids':len(d['grids'])} for n,d in maps.items()],
  'counts':{'maps':len(maps),'warps':len(ww),'trainers':len(ts),'trainer_pokemon':sum(len(t['party']) for t in ts),'visible_items':len(requirements['visible_items']),'hidden_items':sum(e['handler_source']=='HiddenItems' for e in hh),'hidden_controls':sum(e['handler_source']!='HiddenItems' for e in hh),'sprite_strips':len(ss['sprites']),'sprite_frames':sum(len(s['frames']) for s in ss['sprites'].values()),'dialogue_labels':len(texts)},'runtime_installed':False,'campaign_ready':False})
 out['source-manifest.json']=g.json_bytes({'schema':1,'source_revision':REVISION,'archive_sha256':ARCHIVE_SHA,'source_files':dict(sorted(ref.consumed.items())),'maps':list(MAPS),'artifacts':{path:digest(raw) for path,raw in sorted(out.items())},'status':'source/art/data candidate only; no runtime acceptance'})
 return out,ref

def publish(output,artifacts,check=False):
 output=Path(output)
 if check:
  expected=set(artifacts);actual={p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}
  if actual!=expected:raise ValueError('candidate file inventory differs missing='+str(sorted(expected-actual))+' extra='+str(sorted(actual-expected)))
  for path,raw in artifacts.items():
   if (output/path).read_bytes()!=raw:raise ValueError('candidate changed '+path)
 else:
  if output.exists():raise ValueError('unique nonexistent output directory required')
  for name,raw in artifacts.items():
   target=output/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--project',required=True);parser.add_argument('--reference',required=True)
 mode=parser.add_mutually_exclusive_group(required=True);mode.add_argument('--output');mode.add_argument('--check');a=parser.parse_args()
 artifacts,ref=build(a.project,a.reference)
 if a.output and Path(a.output).resolve().is_relative_to((Path(a.project)/'Source').resolve()):raise ValueError('candidate output must not write production Source')
 publish(a.output or a.check,artifacts,bool(a.check))
 print(json.dumps({'ok':True,'artifacts':len(artifacts),'source_files':len(ref.consumed),'mode':'check' if a.check else 'candidate','runtime_installed':False}))
if __name__=='__main__':main()

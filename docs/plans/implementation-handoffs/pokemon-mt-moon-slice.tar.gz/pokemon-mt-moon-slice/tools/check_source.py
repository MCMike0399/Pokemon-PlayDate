#!/usr/bin/env python3
"""Independent Pillow/source-byte oracle and conservative source geometry audit.

Does not import the generator. Actor-free reachability is an over-approximation,
not input-driven playability. Exact source art/masks and hostile mutations fail.
"""
from __future__ import annotations
import argparse,hashlib,json,re
from collections import deque
from pathlib import Path
from PIL import Image,ImageChops
ROOT=Path(__file__).resolve().parents[1]
SHADES={255:'.',170:'1',85:'2',0:'#'}
LIGHT=(0xbb,0xff,0xee,0xff,0xbb,0xff,0xee,0xff)
DARK=(0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa)
MAPS=('Route3','Route4','MtMoonPokecenter','MtMoon1F','MtMoonB1F','MtMoonB2F')
def check(condition,message):
 if not condition:raise ValueError(message)
def raster(grid):
 im=Image.new('RGBA',(32,32))
 for y in range(32):
  for x in range(32):
   shade=grid[y//2][x//2]
   v=255 if shade=='.' else 0 if shade=='#' else 255 if (LIGHT if shade=='1' else DARK)[y%8]&(128>>(x%8)) else 0
   im.putpixel((x,y),(v,v,v,255))
 return im

def opacity(grid):
 # Independent outside-component union: repeated region expansion rather than
 # generator queue implementation, enclosing white cells remain opaque.
 outside={(x,y) for y in range(16) for x in range(16) if (x in (0,15) or y in (0,15)) and grid[y][x]=='.'}
 while True:
  expanded=outside|{(x,y) for y in range(16) for x in range(16) if grid[y][x]=='.' and any((a,b) in outside for a,b in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)))}
  if expanded==outside:break
  outside=expanded
 return bytes(0 if (x//2,y//2) in outside else 255 for y in range(32) for x in range(32))

def exact_image(actual,expected,label):
 actual=actual.convert(expected.mode)
 check(actual.size==expected.size,label+' dimensions')
 if actual.tobytes()!=expected.tobytes():
  changed=sum(a!=b for a,b in zip(actual.tobytes(),expected.tobytes()))
  raise ValueError(label+' pixel/mask mismatch bytes='+str(changed))

def source_maps(reference,candidate,pin):
 # All bytes are checked against archive-derived immutable pins before use.
 def raw(path):
  check(path in pin['files'],'unverified source '+path)
  data=(reference/path).read_bytes();check(hashlib.sha256(data).hexdigest()==pin['files'][path],'source drift '+path);return data
 for path in pin['files']:raw(path)
 constants={m[0]:(int(m[1]),int(m[2])) for m in re.findall(r'^\s*map_const\s+(\w+),\s*(\d+),\s*(\d+)',raw('constants/map_constants.asm').decode(),re.M)}
 # Preserve original maps.asm aliases: several headers can share a .blk.
 layouts={};pending=[]
 for line in raw('maps.asm').decode().splitlines():
  match=re.match(r'(\w+)_Blocks::?',line)
  if match:pending.append(match[1])
  inc=re.search(r'INCBIN "([^"]+)"',line)
  if inc:
   for name in pending:layouts[name]=inc[1]
   pending=[]
 collisions={};pending=[]
 for line in raw('data/tilesets/collision_tile_ids.asm').decode().splitlines():
  match=re.match(r'(\w+)_Coll::',line)
  if match:pending.append(match[1])
  values=re.match(r'\s*coll_tiles\s+([^;]+)',line)
  if values:
   allowed={int(x.strip().replace('$','0x'),0) for x in values[1].split(',')}
   for name in pending:collisions[name]=allowed
   pending=[]
 defs={};count=0;grids=0;native_pixels=0
 for name in MAPS:
  d=json.loads((candidate/'maps'/f'{name}.json').read_text());defs[name]=d
  check(d['name']==name,'map name mismatch')
  header=raw('data/maps/headers/'+name+'.asm').decode()
  match=re.search(r'map_header\s+'+name+r',\s*(\w+),\s*(\w+)',header);check(match is not None,'header missing')
  constant,tileset=match.groups();bw,bh=constants[constant];w,h=bw*2,bh*2
  check(d['id']=='pokered:'+constant and d['dimensions']['cells']==[w,h] and d['tileset']['constant']==tileset,'header dimensions/identity mismatch')
  layout=raw(layouts[name]);check(len(layout)==bw*bh,'layout length')
  blocks=raw(d['tileset']['blockset']);sheet=Image.open(__import__('io').BytesIO(raw(d['tileset']['graphics']))).convert('L')
  check(set(sheet.getdata())<=set(SHADES),'unknown tile palette')
  sheets_w=sheet.width//8;expected_native=Image.new('RGBA',(w*32,h*32));expected_ref=Image.new('L',(w*16,h*16));memo={}
  for y in range(h):
   for x in range(w):
    block=layout[(y//2)*bw+x//2];quad=(y%2)*2+x%2;base=block*16+(quad//2)*8+(quad%2)*2
    ids=[blocks[base],blocks[base+1],blocks[base+4],blocks[base+5]]
    entry=d['grids'][d['tile_ids'][y][x]-1]
    check(entry['source_tile_ids']==ids,f'{name} cell {x},{y} quadrant IDs')
    grid=[]
    for py in range(16):
     row=''
     for px in range(16):
      tile=ids[(py//8)*2+px//8];row+=SHADES[sheet.getpixel(((tile%sheets_w)*8+px%8,(tile//sheets_w)*8+py%8))]
     grid.append(row)
    check(entry['grid']==grid,f'{name} cell {x},{y} source grid')
    check(d['collision'][y][x]==(0 if ids[2] in collisions[d['tileset']['name']] else 1),f'{name} collision {x},{y}')
    key=tuple(ids)
    if key not in memo:
     memo[key]=raster(grid)
     tiny=Image.new('L',(16,16));tiny.putdata([next(v for v,c in SHADES.items() if c==char) for row in grid for char in row]);memo[key+('ref',)]=tiny
    expected_native.paste(memo[key],(x*32,y*32));expected_ref.paste(memo[key+('ref',)],(x*16,y*16));count+=1
  exact_image(Image.open(candidate/'catalog'/f'{name}-native.png'),expected_native,name+' native')
  exact_image(Image.open(candidate/'catalog'/f'{name}-reference.png'),expected_ref,name+' reference')
  grids+=len(d['grids']);native_pixels+=w*h*32*32
 return defs,{'cells':count,'map_grid_rows':grids,'map_pngs':12,'native_pixels':native_pixels}

def source_sprites(reference,candidate,pin):
 data=json.loads((candidate/'sprites.json').read_text());frames=0
 for name,strip in data['sprites'].items():
  raw=(reference/strip['source']).read_bytes();check(hashlib.sha256(raw).hexdigest()==pin['files'][strip['source']]==strip['sha256'],'sprite pin mismatch')
  source=Image.open(__import__('io').BytesIO(raw)).convert('L');check(source.width==16 and source.height in (16,48,96),'sprite dimensions')
  check(len(strip['frames'])==source.height//16,'sprite frame count')
  for index,grid in strip['frames'].items():
   expected_grid=[''.join(SHADES[source.getpixel((x,int(index)*16+y))] for x in range(16)) for y in range(16)]
   check(grid==expected_grid,'source sprite grid '+name+'/'+index)
   alpha=opacity(grid);image=raster(grid);image.putalpha(Image.frombytes('L',(32,32),alpha))
   exact_image(Image.open(candidate/'catalog'/f'sprite-{name}-{index}-raw.png'),image,name+'/'+index+' rawRGBA')
   exact_image(Image.open(candidate/'catalog'/f'sprite-{name}-{index}-mask.png'),Image.frombytes('L',(32,32),alpha),name+'/'+index+' mask')
   frames+=1
 return {'strips':len(data['sprites']),'frames':frames,'rgba_and_mask_pngs':frames*2}

def geometry(defs,candidate):
 # Actor-free directed graph deliberately over-approximates reachable cells;
 # no battles, NPC walking or progression acceptance is implied.
 dirs={'up':(0,-1),'down':(0,1),'left':(-1,0),'right':(1,0)}
 source_dir={'SPRITE_FACING_UP':'up','SPRITE_FACING_DOWN':'down','SPRITE_FACING_LEFT':'left','SPRITE_FACING_RIGHT':'right'}
 byid={d['id']:n for n,d in defs.items()};warps=json.loads((candidate/'warps.json').read_text())['warps'];warp_edges={}
 for row in warps:
  src=byid[row['source_map_id']];dst=byid[row['target_map_id']];x,y=row['target_x'],row['target_y'];d=defs[dst]
  check(0<=x<d['dimensions']['cells'][0] and 0<=y<d['dimensions']['cells'][1] and d['collision'][y][x]==0,'warp source target blocked')
  if dst=='Route4':y+=1
  check(d['collision'][y][x]==0,'proposed exterior advance blocked')
  warp_edges[(src,row['source_x'],row['source_y'])]=(dst,x,y)
 def good(n,x,y):
  d=defs[n];w,h=d['dimensions']['cells'];return 0<=x<w and 0<=y<h and d['collision'][y][x]==0
 def foot(n,x,y):
  d=defs[n];return d['grids'][d['tile_ids'][y][x]-1]['terrain']['foot_tile']
 def neighbors(node):
  n,x,y=node;d=defs[n];w,h=d['dimensions']['cells']
  if node in warp_edges:yield warp_edges[node]
  for direction,(dx,dy) in dirs.items():
   a,b=x+dx,y+dy
   if good(n,a,b) and [foot(n,x,y),foot(n,a,b)] not in d['directional_rules']['forbidden_tile_pairs']:yield n,a,b
   for ledge in d['directional_rules']['ledges']:
    if source_dir.get(ledge['facing'])==direction and 0<=a<w and 0<=b<h and foot(n,x,y)==ledge['standing_foot_tile'] and foot(n,a,b)==ledge['target_foot_tile'] and good(n,x+2*dx,y+2*dy):yield n,x+2*dx,y+2*dy
  if n=='Route3' and y==0 and good('Route4',x-50,17):yield 'Route4',x-50,17
  if n=='Route4' and y==17 and good('Route3',x+50,0):yield 'Route3',x+50,0
 roots=[('Route3',0,y) for y in range(18) if good('Route3',0,y)]
 reached=set(roots);queue=deque(roots)
 while queue:
  for node in neighbors(queue.popleft()):
   if node not in reached:reached.add(node);queue.append(node)
 check(set(n for n,x,y in reached)==set(MAPS),'map structurally disconnected')
 trainer='pokered:ROUTE_4:objects:2';target=('Route4',63,3)
 adjacent=[('Route4',63+dx,3+dy) for dx,dy in dirs.values()]
 check(target not in reached and not any(n in reached for n in adjacent),'source upper-route trainer unexpectedly reachable')
 return {'policy':'actor-free directed collision/pair/ledge/warp graph; structural over-approximation, no runtime/playability proof',
  'entry_cells':roots,'reachable_cells_by_map':{n:sum(a==n for a,x,y in reached) for n in MAPS},
  'unreachable_indexed_trainers':[{'id':trainer,'reason':'upper Route4 component has no path from the bounded region entry; even ignoring every actor',
   'source_object_present':True,'has_toggle_visibility_record':False,'natural_fight_enabled':False}],
  'warps_checked':len(warps),'all_source_warp_targets_passable':True,'ladders_exact_cell':sum(r['arrival_kind']=='ladder' for r in warps),
  'blocked_boundary':'Route4 east to unregistered Cerulean; no graph edge invented'}

def run(reference,candidate):
 reference=Path(reference);candidate=Path(candidate);pin=json.loads((ROOT/'source-pin.json').read_text())
 manifest=json.loads((candidate/'source-manifest.json').read_text())
 check(manifest['source_files']==pin['files'],'candidate consumed-source manifest differs')
 expected=set(manifest['artifacts'])|{'source-manifest.json'};actual={p.relative_to(candidate).as_posix() for p in candidate.rglob('*') if p.is_file()}
 check(actual==expected,'candidate output inventory differs')
 for path,sha in manifest['artifacts'].items():check(hashlib.sha256((candidate/path).read_bytes()).hexdigest()==sha,'candidate artifact drift '+path)
 defs,m=source_maps(reference,candidate,pin);ss=source_sprites(reference,candidate,pin);geo=geometry(defs,candidate)
 return {'ok':True,'source_files':len(pin['files']),'maps':m,'sprites':ss,'geometry':geo,'runtime_accepted':False,'art_reviewed':False}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reference',required=True);p.add_argument('--candidate',required=True);p.add_argument('--report',required=True);a=p.parse_args()
 target=Path(a.report);check(not target.exists(),'report already exists');result=run(a.reference,a.candidate);target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Read current declarative GenV data for this slice; no Lua execution or semantics claims."""
import argparse,hashlib,json,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--candidate',required=True);p.add_argument('--output',required=True);a=p.parse_args()
project=Path(a.project);candidate=Path(a.candidate);sys.path.insert(0,str(project));sys.dont_write_bytecode=True
from tools.verify_moves.parse_lua import LuaParser,read_moves,Expression
from tools.generate_learnsets import initial_moves
species=LuaParser(project/'Source/data/pokemon.lua').parse();moves=read_moves(project/'Source/battle/moves.lua');trainers=json.loads((candidate/'trainers.json').read_text())['trainers']
initial=set();levelup=set();rows=[]
for trainer in trainers:
 for index,mon in enumerate(trainer['party'],1):rows.append({'origin':'trainer','source_id':trainer['id'],'slot':index,'species':mon['species'],'level':mon['level'],'naturally_reachable_within_slice':trainer['id']!='pokered:ROUTE_4:objects:2'})
for path in sorted((candidate/'maps').glob('*.json')):
 d=json.loads(path.read_text())
 for mode in ('grass','water'):
  for slot in d['encounters'][mode]['slots']:rows.append({'origin':'wild','source_id':d['id']+':'+mode+':'+str(slot['index']),'species':slot['species'],'level':slot['level'],'naturally_reachable_within_slice':True})
rows.append({'origin':'gift','source_id':'pokered:MT_MOON_POKECENTER:objects:4','species':'magikarp','level':5,'naturally_reachable_within_slice':True})
for row in rows:
 data=species[row['species']];known=initial_moves(data['learnset'],row['level']);row['initial_moves']=known
 row['ability_scope']='first/second slots from current Specimen creation; hidden is not rolled; effects require production qualification'
 row['nature_scope']='0..24 from current Specimen creation; not original Blue source acquisition'
 row['held_item']='none under current origin policy'
 for name in known:
  if name not in moves:raise ValueError('unknown move '+name)
  initial.add(name)
 levelup.update(m['move'] for m in data['learnset'] if m['level']>row['level'])
# Known empty status records are surfaced as review obligations; even nonempty
# effects do not imply correct GenV semantics (and dispatcher branches exist).
move_rows=[]
for name in sorted(initial):
 d=moves[name];move_rows.append({'id':name,'category':d['category'],'power':d['power'],'pp':d['pp'],
  'effects':[x.text if isinstance(x,Expression) else str(x) for x in d.get('effects',[])],
  'review':'empty status record: inspect dedicated dispatcher / intentional failure before exposing' if d['category']=='status' and not d.get('effects') else 'actual GenV runtime contract required; static definition is not proof'})
files=['Source/data/pokemon.lua','Source/battle/moves.lua','Source/battle/battle.lua','Source/battle/dsl.lua','Source/domain/specimen.lua','Source/data/specimenData.lua']
result={'schema':1,'production_sha256':{p:hashlib.sha256((project/p).read_bytes()).hexdigest() for p in files},'policy':'current ordered B2W2 initialization; source Blue supplies parties/levels only; no claim effects/abilities implemented',
 'encounter_and_trainer_slots':rows,'initial_move_ids':sorted(initial),'initial_move_definitions':move_rows,'later_levelup_move_ids':sorted(levelup),
 'runtime_qualified':False,'natural_run_accepted':False}
output=Path(a.output)
if output.exists():raise ValueError('unique output report required')
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'rows':len(rows),'initial_moves':len(initial),'later_levelup_moves':len(levelup),'empty_status_records':[r['id'] for r in move_rows if r['review'].startswith('empty')]}))

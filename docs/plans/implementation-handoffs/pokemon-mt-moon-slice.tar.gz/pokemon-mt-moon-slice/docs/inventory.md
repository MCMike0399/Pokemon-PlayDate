# Exact source inventory

Generated JSON is authoritative for complete rows/coordinates; this view helps review. Runtime binding and natural acceptance are false.

| Map | Stable ID | Cells | Warps | Objects | Backgrounds | Rate byte |
|---|---|---|---:|---:|---:|---:|
|Route3|pokered:ROUTE_3|70×18|0|9|1|20|
|Route4|pokered:ROUTE_4|90×18|3|3|3|20|
|MtMoonPokecenter|pokered:MT_MOON_POKECENTER|14×8|2|6|0|0|
|MtMoon1F|pokered:MT_MOON_1F|40×36|5|13|1|10|
|MtMoonB1F|pokered:MT_MOON_B1F|28×28|8|0|0|10|
|MtMoonB2F|pokered:MT_MOON_B2F|40×36|4|9|0|10|

## Indexed trainers

One upper Route4 row is unreachable from this bounded region. Even actor-free reachability of the other rows is not playable-fight acceptance. Defeat/payout state must use exact stable IDs and source flags.

| Source object | Class/roster | Party (source Blue levels; GenV moves in separate report) | Payout | Flag |
|---|---|---|---:|---|
|pokered:ROUTE_3:objects:2|OPP_BUG_CATCHER/4|caterpie Lv10, weedle Lv10, caterpie Lv10|100|EVENT_BEAT_ROUTE_3_TRAINER_0|
|pokered:ROUTE_3:objects:3|OPP_YOUNGSTER/1|rattata Lv11, ekans Lv11|165|EVENT_BEAT_ROUTE_3_TRAINER_1|
|pokered:ROUTE_3:objects:4|OPP_LASS/1|pidgey Lv9, pidgey Lv9|135|EVENT_BEAT_ROUTE_3_TRAINER_2|
|pokered:ROUTE_3:objects:5|OPP_BUG_CATCHER/5|weedle Lv9, kakuna Lv9, caterpie Lv9, metapod Lv9|90|EVENT_BEAT_ROUTE_3_TRAINER_3|
|pokered:ROUTE_3:objects:6|OPP_LASS/2|rattata Lv10, nidoranM Lv10|150|EVENT_BEAT_ROUTE_3_TRAINER_4|
|pokered:ROUTE_3:objects:7|OPP_YOUNGSTER/2|spearow Lv14|210|EVENT_BEAT_ROUTE_3_TRAINER_5|
|pokered:ROUTE_3:objects:8|OPP_BUG_CATCHER/6|caterpie Lv11, metapod Lv11|110|EVENT_BEAT_ROUTE_3_TRAINER_6|
|pokered:ROUTE_3:objects:9|OPP_LASS/3|jigglypuff Lv14|210|EVENT_BEAT_ROUTE_3_TRAINER_7|
|pokered:ROUTE_4:objects:2|OPP_LASS/4|paras Lv31, paras Lv31, parasect Lv31|465|EVENT_BEAT_ROUTE_4_TRAINER_0|
|pokered:MT_MOON_1F:objects:1|OPP_HIKER/1|geodude Lv10, geodude Lv10, onix Lv10|350|EVENT_BEAT_MT_MOON_1_TRAINER_0|
|pokered:MT_MOON_1F:objects:2|OPP_YOUNGSTER/3|rattata Lv10, rattata Lv10, zubat Lv10|150|EVENT_BEAT_MT_MOON_1_TRAINER_1|
|pokered:MT_MOON_1F:objects:3|OPP_LASS/5|oddish Lv11, bellsprout Lv11|165|EVENT_BEAT_MT_MOON_1_TRAINER_2|
|pokered:MT_MOON_1F:objects:4|OPP_SUPER_NERD/1|magnemite Lv11, voltorb Lv11|275|EVENT_BEAT_MT_MOON_1_TRAINER_3|
|pokered:MT_MOON_1F:objects:5|OPP_LASS/6|clefairy Lv14|210|EVENT_BEAT_MT_MOON_1_TRAINER_4|
|pokered:MT_MOON_1F:objects:6|OPP_BUG_CATCHER/7|weedle Lv11, kakuna Lv11|110|EVENT_BEAT_MT_MOON_1_TRAINER_5|
|pokered:MT_MOON_1F:objects:7|OPP_BUG_CATCHER/8|caterpie Lv10, metapod Lv10, caterpie Lv10|100|EVENT_BEAT_MT_MOON_1_TRAINER_6|
|pokered:MT_MOON_B2F:objects:1|OPP_SUPER_NERD/2|grimer Lv12, voltorb Lv12, koffing Lv12|300|EVENT_BEAT_MT_MOON_EXIT_SUPER_NERD|
|pokered:MT_MOON_B2F:objects:2|OPP_ROCKET/1|rattata Lv13, zubat Lv13|390|EVENT_BEAT_MT_MOON_3_TRAINER_0|
|pokered:MT_MOON_B2F:objects:3|OPP_ROCKET/2|sandshrew Lv11, rattata Lv11, zubat Lv11|330|EVENT_BEAT_MT_MOON_3_TRAINER_1|
|pokered:MT_MOON_B2F:objects:4|OPP_ROCKET/3|zubat Lv12, ekans Lv12|360|EVENT_BEAT_MT_MOON_3_TRAINER_2|
|pokered:MT_MOON_B2F:objects:5|OPP_ROCKET/4|raticate Lv16|480|EVENT_BEAT_MT_MOON_3_TRAINER_3|

## Warp source/target coordinates

LAST_MAP is resolved to Route4 only for these source maps. Ladder rows preserve the exact target cell; outer doors/mouths require native arrival proof.

| Source stable warp ID / cell | Target stable map / warp / cell | Kind |
|---|---|---|
|pokered:ROUTE_4:warps:1 (11,5)|pokered:MT_MOON_POKECENTER #1 (3,7)|exterior-door-or-cave-mouth|
|pokered:ROUTE_4:warps:2 (18,5)|pokered:MT_MOON_1F #1 (14,35)|exterior-door-or-cave-mouth|
|pokered:ROUTE_4:warps:3 (24,5)|pokered:MT_MOON_B1F #8 (27,3)|exterior-door-or-cave-mouth|
|pokered:MT_MOON_POKECENTER:warps:1 (3,7)|pokered:ROUTE_4 #1 (11,5)|exterior-door-or-cave-mouth|
|pokered:MT_MOON_POKECENTER:warps:2 (4,7)|pokered:ROUTE_4 #1 (11,5)|exterior-door-or-cave-mouth|
|pokered:MT_MOON_1F:warps:1 (14,35)|pokered:ROUTE_4 #2 (18,5)|exterior-door-or-cave-mouth|
|pokered:MT_MOON_1F:warps:2 (15,35)|pokered:ROUTE_4 #2 (18,5)|exterior-door-or-cave-mouth|
|pokered:MT_MOON_1F:warps:3 (5,5)|pokered:MT_MOON_B1F #1 (5,5)|ladder|
|pokered:MT_MOON_1F:warps:4 (17,11)|pokered:MT_MOON_B1F #3 (25,9)|ladder|
|pokered:MT_MOON_1F:warps:5 (25,15)|pokered:MT_MOON_B1F #4 (25,15)|ladder|
|pokered:MT_MOON_B1F:warps:1 (5,5)|pokered:MT_MOON_1F #3 (5,5)|ladder|
|pokered:MT_MOON_B1F:warps:2 (17,11)|pokered:MT_MOON_B2F #1 (25,9)|ladder|
|pokered:MT_MOON_B1F:warps:3 (25,9)|pokered:MT_MOON_1F #4 (17,11)|ladder|
|pokered:MT_MOON_B1F:warps:4 (25,15)|pokered:MT_MOON_1F #5 (25,15)|ladder|
|pokered:MT_MOON_B1F:warps:5 (21,17)|pokered:MT_MOON_B2F #2 (21,17)|ladder|
|pokered:MT_MOON_B1F:warps:6 (13,27)|pokered:MT_MOON_B2F #3 (15,27)|ladder|
|pokered:MT_MOON_B1F:warps:7 (23,3)|pokered:MT_MOON_B2F #4 (5,7)|ladder|
|pokered:MT_MOON_B1F:warps:8 (27,3)|pokered:ROUTE_4 #3 (24,5)|exterior-door-or-cave-mouth|
|pokered:MT_MOON_B2F:warps:1 (25,9)|pokered:MT_MOON_B1F #2 (17,11)|ladder|
|pokered:MT_MOON_B2F:warps:2 (21,17)|pokered:MT_MOON_B1F #5 (21,17)|ladder|
|pokered:MT_MOON_B2F:warps:3 (15,27)|pokered:MT_MOON_B1F #6 (13,27)|ladder|
|pokered:MT_MOON_B2F:warps:4 (5,7)|pokered:MT_MOON_B1F #7 (23,3)|ladder|

## Visible items

| Stable ID | Original item | Cell |
|---|---|---|
|pokered:ROUTE_4:objects:3|TM_WHIRLWIND|(57,3)|
|pokered:MT_MOON_1F:objects:8|POTION|(2,20)|
|pokered:MT_MOON_1F:objects:9|MOON_STONE|(2,2)|
|pokered:MT_MOON_1F:objects:10|RARE_CANDY|(35,31)|
|pokered:MT_MOON_1F:objects:11|ESCAPE_ROPE|(36,23)|
|pokered:MT_MOON_1F:objects:12|POTION|(20,33)|
|pokered:MT_MOON_1F:objects:13|TM_WATER_GUN|(5,32)|
|pokered:MT_MOON_B2F:objects:8|HP_UP|(25,21)|
|pokered:MT_MOON_B2F:objects:9|TM_MEGA_PUNCH|(29,5)|

## Hidden events

| Stable ID | Original handler / argument | Cell |
|---|---|---|
|pokered:MT_MOON_POKECENTER:hidden:1|PrintBenchGuyText / SPRITE_FACING_LEFT|(0,4)|
|pokered:MT_MOON_POKECENTER:hidden:2|OpenPokemonCenterPC / SPRITE_FACING_UP|(13,3)|
|pokered:MT_MOON_B2F:hidden:1|HiddenItems / MOON_STONE|(18,12)|
|pokered:MT_MOON_B2F:hidden:2|HiddenItems / ETHER|(33,9)|
|pokered:ROUTE_4:hidden:1|HiddenItems / GREAT_BALL|(40,3)|

## Art additions

99 canonical tile keys: 65 already occur in the current Pewter source inventory and 34 are new. All shared keys must compare exact grids/terrain/collision before a combined catalog accepts them. New strips are clipboard, fossil, hiker, middle_aged_man, rocket (20 source frames), rendered using the existing faithful phase0/mask workflow. Existing7 shared strips and all protected RED/BLUE/Oak art stay unchanged. No native image review is implied.

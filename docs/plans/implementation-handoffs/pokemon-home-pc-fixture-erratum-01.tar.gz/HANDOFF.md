# Home/PC SDK fixture erratum01

Only two existing SDK fixture files change. No production or geometry changes. PC01 and home01 original packets remain unchanged; all failure evidence remains retained.

1. home-lead checkpoint/legacy-codec case recruited Squirtle+Pidgey via model() but left the session's intro tuple preOak. SessionCodec correctly refused pre-starter ownership. The case now sets its actual acquired Squirtle/counter-Bulbasaur/done tuple before encoding. Every exact new default Pallet5,6/down, original bedroom location and old valid saved bedroom checkpoint assertion remains unchanged; codec strictness is untouched.
2. pc-ui legacy test still expected RED'S PC to be unavailable and had not registered the new real ItemPCState in its existing real Player/GameContext/PCState + settled Explore fixture. It now registers ItemPCState, selects RED, asserts actual itemPC/menu + session unchanged, returns to PC, checks Bill/Someone names through source flags, then actually selects Oak and preserves the unsupported/unavailable + no-mutation assertions. Defensive menu-copy assertion remains. No fake successful RED result, omitted branch, assertion relaxation or new service.

Three bedroom failures were a root composition omission: both historical composed-sdk-01 and integration02 at diagnosis still had the old Center-only pcTerminals module. Root confirmed and applied PC01's original unchanged guarded world patch. The packet does NOT duplicate/rewrite that production patch. Source geometry remains player7,3/up at existing PC tile7,2, as reviewed/pinned. Read-only integration checker finds exactly that missing file in the failed runtime's Source; after root apply, all9 PC01 overlays exactly match reviewed bytes.

Apply patches/Source/dev/{homeLeadContracts,pcContracts}.patch only. Full snapshots are review aids. Root's updated sessionBridge checkpoint assertions are untouched and guarded in manifest. No new tests mirror implementation; existing real production SDK cases are migrated to valid fixtures. Counts remain home11 +redPC18 +existing PC UI count.

```
python3 /private/tmp/pokemon-home-pc-fixture-erratum-01/tools/check_integrated_pc.py --project /private/tmp/pokemon-brock-integration-02 --packet /private/tmp/pokemon-red-pc-items-01
python3 /private/tmp/pokemon-home-pc-fixture-erratum-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-home-pc-erratum-compile-01
```

Root-only actual SDK rerun after review/sole runtime ownership:

```
python3 /private/tmp/pokemon-home-pc-fixture-erratum-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-home-pc-erratum-native-01 --execute
```

Exact PC checker intentionally requires review if later legitimate shared-file composition differs; it is a bounded packet integration aid, not a permanent source-code mirroring unit test. It reads only Source and packet manifests, never SDK Data.

Field-ability primary research is retained separately at /private/tmp/pokemon-field-abilities-01; no encounter implementation/shared edits proceeded after this repair priority.

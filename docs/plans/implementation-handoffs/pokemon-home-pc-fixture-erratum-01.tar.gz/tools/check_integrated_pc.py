#!/usr/bin/env python3
"""Read-only exact packet integration check; differing shared files need review."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--packet',type=Path,required=True);a=p.parse_args()
m=json.loads((a.packet/'manifest.json').read_text());results=[]
for rel in m['overlay_files']:
 path=a.project/rel;expected=m['files'][rel];actual=hashlib.sha256(path.read_bytes()).hexdigest()if path.is_file()else None
 results.append({'file':rel,'expected_sha256':expected,'actual_sha256':actual,'exact':actual==expected})
print(json.dumps({'ok':all(r['exact']for r in results),'packet':m['packet'],'files':results},indent=2))
raise SystemExit(not all(r['exact']for r in results))

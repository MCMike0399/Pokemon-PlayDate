import math,unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from tools.verify_moves.parse_lua import read_moves
ROOT=Path(__file__).resolve().parents[1]
class BideVectors(unittest.TestCase):
 def test_added425th_preserves_all424(self):
  before=read_moves('/private/tmp/pokemon-brock-move-batch01/Source/battle/moves.lua');after=read_moves(ROOT/'Source/battle/moves.lua')
  self.assertEqual(len(before),424);self.assertEqual(len(after),425);self.assertEqual(set(after)-set(before),{'bide'})
  for k,v in before.items():self.assertEqual(after[k],v,k)
  self.assertEqual({k:after['bide'][k]for k in ('type','category','power','accuracy','pp','priority','targetId','contact','hasSecondary','ohko','damageRule')},{'type':'normal','category':'physical','power':0,'accuracy':0,'pp':10,'priority':1,'targetId':7,'contact':True,'hasSecondary':False,'ohko':False,'damageRule':'bide'})
 def test_actual_removed_sturdy_literal(self):
  hp=2*40*5//100+5+10
  self.assertEqual(hp,19);removed=min(40,hp-1);self.assertEqual(removed,18);self.assertEqual(170-2*removed,134)
 def test_seed2_doublekick_literal(self):
  # One enemy choice, accuracy, then independent crit+variance per hit.
  n=2;states=[]
  for _ in range(6):n=n*16807%2147483647;states.append(n)
  base=(42*30*117//135)//50+2;self.assertEqual(base,23)
  self.assertNotEqual(1+(states[2]-1)%16,1);self.assertNotEqual(1+(states[4]-1)%16,1)
  hit1=base*(85+(states[3]-1)%16)//100*2;hit2=base*(85+(states[5]-1)%16)//100*2
  self.assertEqual((hit1,hit2,hit1+hit2),(40,46,86))
 def test_native_tackle_two_stores(self):
  # Squirtle5 Def11/HP19 vs Rattata2 Atk7/HP13, seed2 AI/accuracy/crit/variance.
  n=2;states=[]
  for _ in range(9):n=n*16807%2147483647;states.append(n)
  base=(2*50*7//11)//50+2;self.assertEqual(base,3)
  damages=[]
  for offset in (0,4):
   self.assertNotEqual(1+(states[offset+2]-1)%16,1)
   damages.append((base*(85+(states[offset+3]-1)%16)//100)*3//2)
  self.assertEqual(damages,[3,3]);self.assertEqual(13-2*sum(damages),1);self.assertEqual(19-sum(damages),13)
 def test_ps_object_normalization_provenance(self):
  dex=(ROOT/'references/sim_dex.ts').read_text();moves=(ROOT/'references/sim_dex-moves.ts').read_text()
  self.assertIn('move = this.moves.get(move);',dex);self.assertIn("if (name && typeof name !== 'string') return name;",moves)
  # This is source qualification of the normalizer, not a fake JS/SDK runtime.
if __name__=='__main__':unittest.main()

# GenV Bide / original Blue TM34 dependency

Staged only on frozen batch01+errata01. Root owns live Source, generator, Teaching and Simulator. No art/world/story/save specimen changes are included. This packet implements actual Bide behavior; original TM34 acquisition/teaching remains root-owned and must be qualified together before claiming playable completion.

## Behavior

Bide is Physical/Normal, PP10, priority+1, always-hit, contact, target=self while storing. It stores on its first two attempts and releases on the third. Only the first attempt spends PP; both player and enemy continue their locked move without selecting another move or generating another enemy-choice draw. Existing public index0 remains exclusively Struggle. While locked, nonfight selections and alternate/forged public slots reject unchanged. Bide state belongs to `BattleConditions`, never the Pokémon/save.

Actual direct-hit HP removed is recorded once at the typed receipt commit. Multiple hits and fixed direct attacks count; status/residual, recoil, HP payments and self-hit do not. The pool survives rounds and healing, retains its actual latest attacking identity, and releases twice the total. Damage received earlier in the first turn before Bide starts is not retroactive. Faster equal-priority damage on the release turn still arrives while the state exists and is included before the actual release action.

A surviving active latest attacker is targeted. If it has left, singles has only the current living opponent as an eligible retarget; no reserve is preselected or marked seen. Retargeting a sole eligible battler does not add a degenerate random-choice draw. No eligible target or no recorded damage fails and clears the lock. The source protocol is not an exact Game Freak PRNG emulation.

Release is Normal fixed damage: Ghost is immune, Rock/Steel resistance does not reduce the fixed amount, fullHP Sturdy can limit lethal damage, and real contact reactions such as Static still run. Store/release do not roll accuracy, critical or damage variance. Contact reactions can legitimately draw; this is explicitly tested. Positive status gates still run before each attempt; flinch, blocked sleep/freeze/paralysis and confusion self-hit abort the whole sequence. Withdrawal, faint and exit clear the pool. Unsupported later charge/Protect/weather features are not added by this packet.

Midbattle learning may remove Bide's learned slot while its stored identity is active. A small lexical private fight commit is shared with validated public selectMove; automatic Bide continuation can use the stored identity without forging a durable move slot, PP entry or public key bypass. The actual LearningState replacement case tests this through XP, enemy self-KO, replacing Bide with Bubble, continuation against enemy2 and exact six-damage retarget.

`Battle:getConditionsSnapshot()` adds `bide_turns` (0/1/2) and `bide_damage`. Root diagnostics already delegates to this pure snapshot. The shared pure `effectiveMovePower` now passes explicit attacker/defender into optional Effects:basePower arguments for the separately owned Rivalry hook; a contract verifies correct identities when current Battle direction is opposite. No Rivalry effect is implemented here.

## Generator and source evidence

Root's exact425-row generated candidate SHA256 is `8773180a2e1af065c0b9292dddfd8cfa39b96a46bd9d65e0716c1742a3ae8f79`. Only Bide is appended; every prior424 row is unchanged. Root's independent425 metadata/CSV qualifier and exact regeneration report is `/private/tmp/pokemon-root-producer-v4/primary-qualifier.json`. `generator-request.json` describes Bide117 with existing `damageRule="bide"`; no new constructor field. Generated Source was copied unchanged.

Source pins/checksums and full normalization/immunity trace are in `source-pins.json` / `provenance.md`. Maintained pinned Gen5 Showdown is the semantic reference. C reconstruction confirms the store/store/release and typed handler shape, but exact native Bide quality/data confirmation is pending; no independent two-oracle or matched retail-ROM proof is claimed.

Two root-owned old-count contracts need narrow424→425 expectations while retaining all existing metadata loops and adding exact Bide target7/rule assertions. Reviewed hunks are in `patches/Source__dev__*.patch`; the private adapter applies those exact narrow compatibility edits and hashes the resulting Source. Do not delete the coverage or overwrite those full files from the packet.

## Reproduce (root alone executes SDK)

Core compile-only and host checks:

```sh
python3 /private/tmp/pokemon-brock-bide-01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-brock-bide-build-NEW
python3 -m unittest discover -s /private/tmp/pokemon-brock-bide-01/tests -v
```

Five host checks pass: exact425th addition/all424 unchanged, actualHP Sturdy vector, independent seed2 DoubleKick40+46 vector, actual teaching native Tackle3+3→release12 vector, and pinned object-normalization source qualification. These are expected-vector/provenance checks; production Lua is tested separately.

Core SDK (29 authored groups):

```sh
python3 /private/tmp/pokemon-brock-bide-01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-brock-bide-sdk-NEW --execute
```

**Required composed Teaching proof:** adds root's frozen16 Teaching groups plus the separate real `BideTeachingContracts` group. No skipped/fake dependency probe is used. This group requires actual Teaching and GameSession.resolveTeaching, consumes real TM34 exactly once, preserves party/Pokémon/bag identity and replacement PP, then uses that taught move in an actual three-turn Battle.

```sh
python3 /private/tmp/pokemon-brock-bide-01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-brock-bide-teaching-sdk-NEW --with-teaching --execute
```

`--with-teaching` checks root Teaching manifestSHA `d9813432903d7c516df85c5b3f97b52d4c95417067af19b4a6cf6428ab36a0bd`, copies its declared data/domain/UI/test dependencies, appends only its exact reviewed GameSession method when missing and adds imports to CURRENT main. It never copies root's old full GameSession/main snapshot. Unknown shared bases fail before runtime. Default mode compiles only.

Actual native field teaching→Bide store/store/release witness:

```sh
python3 /private/tmp/pokemon-brock-bide-01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-brock-bide-native-NEW --with-teaching --scenario /private/tmp/pokemon-brock-bide-01/scenarios/brock-bide-tm34.json --execute
```

The host-encoded recipe enters the real field bag, uses TM34 on Squirtle5, captures the learned message and consumed TM, enters a real battle and uses its actual third move. Enemy Tail Whip PP is explicitly disabled through the existing battle-adjustment fixture, without resetting the taught owner. Seed2 Tackle deals3+3 while storing; release12 leaves Rattata2 at1HP, user at13HP, Bide9PP, rules9raw rolls at release; after the actual enemy response, the real command menu returns with user10HP/PP9, enemy1HP/Tackle32PP and rules12rolls. Native captures include both stores and release motion/frame sequence. This is supplementary fixture-driven mechanics/teaching proof, not a natural campaign or earned-Brock-reward acceptance claim.

Compile passed for core and Teaching composition (SDK3.1.2). SDK assertions and native recipe remain unrun by this worker; root results/images are required. Full campaign, all starters, Route22, other exposed grind-tail moves and remaining111-union ability/held dependencies remain active goal work.

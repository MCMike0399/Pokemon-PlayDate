#!/usr/bin/env python3
"""Root-only runtime adapter; compile-only unless --execute. No old tree overlay."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--merge-current',action='store_true');p.add_argument('--with-teaching',action='store_true');a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'foundation-manifest.json').read_text());original=harness.prepare

def prepare(project,sdk,output,session):
    for item in manifest['source_files']:assert hashlib.sha256((stage/item['path']).read_bytes()).hexdigest()==item['sha256'],'packet drift '+item['path']
    metadata=original(project,sdk,output,session);composed=[]
    for item in manifest['source_files']:
        source=stage/item['path'];live=project/item['path'];target=output/item['path'];base=stage/'base'/item['path'];sha=hashlib.sha256(live.read_bytes()).hexdigest() if live.exists()else None
        target.parent.mkdir(parents=True,exist_ok=True)
        if sha in (item['base_sha256'],item['sha256'],item.get('additional_reviewed_base_sha256')):shutil.copyfile(source,target)
        elif a.merge_current and base.exists() and live.exists():
            result=subprocess.run(['git','merge-file','-p',str(source),str(base),str(live)],capture_output=True);assert result.returncode==0,'source conflict '+item['path'];target.write_bytes(result.stdout)
        else:raise AssertionError('live owned Source changed '+item['path'])
        composed.append({'path':item['path'],'live_sha256':sha,'candidate_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
    teachingMetadata=None
    if a.with_teaching:
        dependency=manifest['teaching_dependency'];teaching=Path(dependency['manifest']).parent
        raw=(teaching/'manifest.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==dependency['sha256'],'teaching manifest drift'
        teachingMetadata=json.loads(raw)
        for row in teachingMetadata['source_files']:
            rel=row['path']
            if rel in ('Source/main.lua','Source/domain/gameSession.lua'):continue
            source=teaching/rel;assert hashlib.sha256(source.read_bytes()).hexdigest()==row['sha256'],'teaching source drift '+rel
            live=project/rel;current=hashlib.sha256(live.read_bytes()).hexdigest()if live.exists()else None
            assert current in (row['base_sha256'],row['sha256']),'teaching shared base changed '+rel
            target=output/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        hook=teaching/'session-hook.lua';assert hashlib.sha256(hook.read_bytes()).hexdigest()==dependency['session_hook_sha256'],'teaching owner hook drift'
        session=output/'Source/domain/gameSession.lua';body=session.read_text()
        if 'function GameSession:resolveTeaching('not in body:session.write_text(body+'\n'+hook.read_text())
        else:assert ('function '+hook.read_text().split('function ',1)[1]).strip()in body,'teaching existing owner hook changed'
    main=output/'Source/main.lua';text=main.read_text();anchor='import "dev/catalog"';assert anchor in text
    if 'import "dev/bideContracts"'not in text:
        text=text.replace(anchor,'import "dev/bideContracts"\nContracts.register("bide", BideContracts.run)\n'+anchor,1)
    if a.with_teaching:
        if 'import "domain/teaching"'not in text:text=text.replace('import "domain/gameSession"','import "domain/gameSession"\nimport "domain/teaching"',1)
        if 'import "dev/teachingContracts"'not in text:text=text.replace(anchor,'import "dev/teachingContracts"\nContracts.register("teaching",TeachingContracts.run)\n'+anchor,1)
        if 'import "dev/bideTeachingContracts"'not in text:text=text.replace(anchor,'import "dev/bideTeachingContracts"\nContracts.register("bide-teaching", BideTeachingContracts.run)\n'+anchor,1)
    main.write_text(text)

    for expected in manifest['metadata_count_patches']:
        rel=expected['path'];target=output/rel;body=target.read_text()
        assert hashlib.sha256(target.read_bytes()).hexdigest()in(expected['base_sha256'],expected['sha256']),'metadata contract base changed '+rel
        assert hashlib.sha256((stage/expected['patch']).read_bytes()).hexdigest()==expected['patch_sha256'],'metadata patch drift '+rel
        if rel.endswith('abilityContracts.lua'):
            body=body.replace('for424 moves','for425 moves');body=body.replace('eq(n,424)','eq(n,425);eq(moveData.bide.targetId,7);eq(moveData.bide.damageRule,"bide")')
        else:
            body=body.replace('All424 generated','All425 generated');body=body.replace('equal(count,424)','equal(count,425);equal(moveData.bide.targetId,7);equal(moveData.bide.damageRule,"bide")')
        target.write_text(body)
    info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted((output/'Source').rglob('*'))if x.is_file()and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    info.write_text(generated);values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        value=metadata[key];values.append('    '+key+' = '+('true'if value is True else json.dumps(value,ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['bide']=manifest;metadata['teaching_composition']=teachingMetadata;metadata['composed_files']=composed
    with(output/'bide-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project;scenario=Path(a.scenario).resolve()if a.scenario else stage/'contracts.json'
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(scenario),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

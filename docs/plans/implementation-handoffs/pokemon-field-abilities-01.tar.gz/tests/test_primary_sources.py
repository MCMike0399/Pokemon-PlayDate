import hashlib,json,re,subprocess,tempfile,unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]

def function(source,signature):
 start=source.index(signature);opening=source.index('{',start);depth=1;i=opening+1
 while depth:
  if source[i]=='{':depth+=1
  if source[i]=='}':depth-=1
  i+=1
 return source[start:i]

def c_oracle():
 source=(P/'references/ov036/enc_pokeset.c').read_text()
 names=[]
 for line in(P/'references/generated/abilities.txt').read_text().splitlines():
  line=line.strip()
  if line.startswith('ABILITY_'):names.append(line)
 header='''#include <stdio.h>
#include <string.h>
typedef unsigned char u8;typedef unsigned short u16;typedef unsigned int u32;typedef int BOOL;
#define TRUE 1
#define FALSE 0
#define TYPE_STEEL 8
#define TYPE_ELECTRIC 13
#define PERSONAL_TYPE_1 1
#define PERSONAL_TYPE_2 2
#define ITEM_CLEANSE_TAG 1
#define ITEM_PURE_INCENSE 2
'''
 header+='enum{'+','.join(names)+'};\n'
 header+='''typedef struct{int leadAbility,leadSex,rateUp,rateDown,isFishing,fishingRateUp,compoundEyes,cuteCharm,magnetPull,staticAbility,higherLevel,repelsWeaker,synchronize,forced,leadLevel,repelActive,slotCount;}EncountManager;
typedef struct{int species,form,minLevel,maxLevel;}WildEncSlot;
static unsigned roll;static unsigned calls;
static unsigned GFL_RandomLC(unsigned n){calls++;return roll%n;}
static unsigned PML_PersonalGetParamSingle(int species,int form,int which){(void)form;return ((species==2&&which==1)||(species==3&&which==2))?TYPE_ELECTRIC:0;}
'''
 body='\n'.join(function(source,sig)for sig in [
 'static void SetupEncountFlagsByPartyPokeAbil(EncountManager *manager, u16 weather) {',
 'static BOOL FieldEncount_CheckLevelRepelled(EncountManager *manager, u8 level) {',
 'static u8 GetEncountIndexForPreferredType(EncountManager *manager, const WildEncSlot *slots, u8 type) {'])
 main='''int main(void){EncountManager m;WildEncSlot slots[4]={{1,0,2,2},{2,0,3,3},{2,0,5,5},{3,0,4,4}};
for(unsigned ability=0;ability<3;ability++){for(unsigned r=49;r<=50;r++){memset(&m,0,sizeof(m));m.leadAbility=ability==0?ABILITY_STATIC:ability==1?ABILITY_KEEN_EYE:ABILITY_INTIMIDATE;roll=r;calls=0;SetupEncountFlagsByPartyPokeAbil(&m,0);printf("gate %d %u %d %d %u\\n",m.leadAbility,r,m.staticAbility,m.repelsWeaker,calls);}}
memset(&m,0,sizeof(m));m.repelsWeaker=1;m.leadLevel=10;printf("levels %d %d\\n",FieldEncount_CheckLevelRepelled(&m,5),FieldEncount_CheckLevelRepelled(&m,6));
m.repelActive=1;m.repelsWeaker=0;printf("repel %d %d\\n",FieldEncount_CheckLevelRepelled(&m,9),FieldEncount_CheckLevelRepelled(&m,10));m.isFishing=1;printf("fishing %d\\n",FieldEncount_CheckLevelRepelled(&m,9));m.repelsWeaker=1;printf("fishingability %d\\n",FieldEncount_CheckLevelRepelled(&m,5));m.forced=1;printf("forced %d\\n",FieldEncount_CheckLevelRepelled(&m,5));
memset(&m,0,sizeof(m));m.slotCount=4;for(roll=0;roll<3;roll++){calls=0;printf("slot %u %u\\n",roll,GetEncountIndexForPreferredType(&m,slots,TYPE_ELECTRIC));}for(int i=0;i<4;i++)slots[i].species=1;calls=0;printf("nomatch %u\\n",GetEncountIndexForPreferredType(&m,slots,TYPE_ELECTRIC));printf("nomatchcalls %u\\n",calls);return 0;}
'''
 with tempfile.TemporaryDirectory(prefix='field-source-oracle-')as tmp:
  root=Path(tmp);(root/'oracle.c').write_text(header+body+main)
  subprocess.run(['clang','-std=c11','-Wall','-Wextra','-Werror',str(root/'oracle.c'),'-o',str(root/'oracle')],check=True,capture_output=True)
  return subprocess.run([str(root/'oracle')],check=True,capture_output=True,text=True).stdout.splitlines()
class SourceTests(unittest.TestCase):
 def test_consumed_source_bytes_and_git_blobs(self):
  pin=json.loads((P/'source-pins.json').read_text())
  self.assertEqual(pin['revision'],'b279bbefa99bb2f6fbabcc95e4b6d3e939290353')
  for rel,d in pin['files'].items():
   b=(P/'references'/rel).read_bytes();self.assertEqual(hashlib.sha256(b).hexdigest(),d['sha256']);self.assertEqual(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),d['git_blob'])
 def test_actual_primary_c_gate_level_repel_and_physical_slot_vectors(self):
  self.assertEqual(c_oracle(),['gate 9 49 0 0 1','gate 9 50 1 0 1','gate 51 49 0 0 1','gate 51 50 0 1 1','gate 22 49 0 0 1','gate 22 50 0 1 1','levels 1 0','repel 1 0','fishing 0','fishingability 1','forced 0','slot 0 1','slot 1 2','slot 2 3','nomatch 255','nomatchcalls 0'])
 def test_physical_ability_and_conscious_threshold_are_distinct_primary_owners(self):
  s=(P/'references/ov036/enc_pokeset.c').read_text();f=function(s,'void CreateEncountManager(EncountManager *manager, GameData *gameData, int encType, u32 mode, u16 weather) {')
  self.assertIn('lead = PokeParty_GetPkm(party, 0);',f);self.assertIn('PKM_PARAM_IS_EGG',f);self.assertNotIn('PKM_PARAM_HP',f)
  self.assertIn('PokeParty_GetPkm(party, PokeParty_GetFirstBattleReady(party))',f)
  party=(P/'references/system/pokeparty.c').read_text();battle=function(party,'static BOOL PML_PkmIsBattleReady(PartyPkm *pkm) {');self.assertIn('isEgg != TRUE && hp != 0',battle)
 def test_actual_source_manager_precedes_rate_and_suppression_precedes_creation(self):
  s=(P/'references/ov036/field_encount.c').read_text();s=s[s.index('GameEvent *EventWildBattleCall_CreateRandom'):s.index('GameEvent *EventWildBattleCall_CreateStatic')]
  self.assertLess(s.index('CreateEncountManager('),s.index('!EncSys_CheckRNGEncounter('));self.assertIn('count == 0',s)
  c=(P/'references/ov036/enc_pokeset.c').read_text();f=function(c,'static int FieldEncount_GenWildsCore(EncountManager *manager, const WildEncSlot *slots, WildPkmParam *params) {')
  self.assertLess(f.index('FieldEncount_GenWildPokeParam('),f.index('FieldEncount_CheckLevelRepelled('))
  self.assertNotIn('FieldEncount_CreateWildPkm',f)
if __name__=='__main__':unittest.main()

import json,os,unittest
from pathlib import Path
from tools.harness.brock_journey import load_models
P=Path(__file__).resolve().parents[1]
class RecipeTests(unittest.TestCase):
 def test_actual_source_grass_step_is_reciprocal_clear_and_outside_source_trainer_sight(self):
  models,doors,trainers=load_models(Path(os.environ['FIELD_BUNDLE_SOURCE']));z=models['pokered:VIRIDIAN_FOREST']
  for x,y in [(6,6),(7,6)]:self.assertTrue(z.grass[y][x]);self.assertEqual(z.collision[y][x],0)
  self.assertEqual(z.terrain_step((6,6),'right').destination,(7,6));self.assertEqual(z.terrain_step((7,6),'left').destination,(6,6))
  for event in z.source_data['events']['objects']:self.assertGreater(abs(event['x']-7)+abs(event['y']-6),8)
  for trainer in trainers:
   if trainer['map_id']=='pokered:VIRIDIAN_FOREST':self.assertGreater(abs(trainer['x']-7)+abs(trainer['y']-6),trainer['sight_range_cells'])
 def test_fixed_recipes_only_use_source_confirmed_opcode_subset_and_restarts_do_not_reset(self):
  allowed={'move','seed','press','shot','record'}
  for path in(P/'scenarios').glob('*.json'):
   if path.stem=='contracts':continue
   s=json.loads(path.read_text());groups=s.get('processes',[{'requests':[s['commands']]}]if'commands'in s else[])
   for index,g in enumerate(groups):
    fixture_count=0
    for commands in g['requests']:
     for c in commands:
      if isinstance(c,str):
       words=c.split();self.assertIn(words[0],allowed,(path,c))
       if words[0]=='move':self.assertEqual(words,['move','right','1'])
      elif c['op']=='fixture':fixture_count+=1;self.assertEqual(index,0)
      else:self.assertIn(c['op'],{'assert','await'})
    self.assertEqual(fixture_count,1 if index==0 else 0)
 def test_independent_rules_stream_literal_vectors(self):
  def draw(state,span,low=0):
   while True:
    state=state*16807%2147483647
    if state-1<2147483646//span*span:return state,(state-1)%span+low
  for v in json.loads((P/'literal-forest-vectors.json').read_text()):
   s,g=draw(v['seed'],100);s,r=draw(s,256);s,pick=draw(s,2,1);level=3 if pick==1 else 5
   s,_=draw(s,1,level);s,ability=draw(s,2,1);s,nature=draw(s,25);s,sex=draw(s,256);s,held=draw(s,100)
   self.assertEqual([g,r,8+pick,level,ability,nature,sex,held,str(s)],[v['gate'],v['rate'],v['source_slot'],v['level'],2,v['nature'],v['sex_byte'],v['held_roll'],v['rules_state']])
if __name__=='__main__':unittest.main()

# First-gate field abilities01

Private implementation; no live writes, Simulator launch, SDK Data access or runtime-pass claim. Use current read-only integration02, including PC/home fixture corrections. PC01 and its historical failure/recipe packets are unchanged.

Apply only patches/Source/world/zone.patch and game/overworldState.patch plus new domain/fieldEncounters.lua and dev/fieldEncounterContracts.lua. Root import/register delta is patches/main-root-hook.patch; optional diagnostics has one `field_encounter` value guarded by `game.lastEncounterSession==game.session`. Do not replace whole shared files. Specimen/party/session/codec/provider/TrainerEvents/EventState/battle engine/art/data remain unchanged. Whole current Source was staged by the normal identified runner; baseline SHA guards include owned files/main/diagnostics/Specimen/session.

## Source and explicit adaptation

Pinned B2W2 revision b279bbefa99bb2f6fbabcc95e4b6d3e939290353. Six complete consumed primary files are stored with SHA256+Git blob IDs; downloaded raw bytes match pinned tree hashes. proposal.md cites original functions and the approved adaptation. Three UNCHANGED primary C function bodies are compiled/run with controlled type/RNG adapters in host tests, independently proving17 literal gate/boundary/Repel/fishing/forced/duplicate-slot vectors. This is source audit proof, not Playdate runtime proof or a claim synthetic C adapter species are campaign data.

Physical party slot1's durable ability applies even fainted. Keen Eye/Intimidate level threshold comes from first conscious member. No Egg specimens exist in current original151 codec; do not invent Egg behavior. Static/Intimidate/Keen Eye IDs9/22/51 add a50% coin on eligible grass attempts BEFORE existing Blue rate check: rolls0..49 inactive,50..99 active. Static uniformly selects matching ELECTRIC physical slot indices, retaining duplicate species/levels; no matches falls back to ordinary unchanged weights. Suppression occurs after slot+level, before any specimen creation, if first-conscious level>=wild level+5.

Blue rates/weights/rows/levels remain exact; no new species, reweighted ordinary pool, table truncation, species deduplication or forms. The project's RulesRNG (not Nintendo's PRNG) remains the encounter stream; actor World RNG is untouched. New gate draws change seeded outcomes for these three abilities. Unrelated/Compound Eyes paths retain current calls; source's otherwise-unused generic coin for many unrelated abilities is intentionally omitted as approved. This is a recorded bounded adaptation, not old-route equivalence or full field-ability/DS stream fidelity.

Original Repel/fishing/forced ordering is independently audited in source/C tests. Current first-gate has no usable Repel producer, and this packet adds none. Unknown `forced`/`repelActive` context fields reject; fixture/trainer/debug battle starts bypass the normal grass boundary. Other field abilities, weather-rate effects, swarms/roaming/doubles/fishing and Egg/alternate-form rules remain outside scope. No unsupported item success is invented.

## Owner and API

`Zone:encounterPolicyAt(x,y)` returns detached rate+all physical rows for valid passable grass. No random draw; disabled/unbound/invalid policies are explicit. Existing checkEncounter/rollEncounter helpers retain prior behavior for explicit fixture/legacy tests; normal walking now uses the cohesive boundary.

`FieldEncounters.prepare({session,party,zone,x,y}) -> opaque plan|nil,reason`: strict explicit context/ownership, valid active Rules session, first conscious member, terrain/bounds/rate/whole table/all species/levels/weights, full durable roster and identity snapshot. No global current game/battle owner and no rolls. `resolve(plan) -> ok,{kind,reason,pokemon?,receipt}` revalidates all captured state, plans on cloned RulesRNG, performs gate/rate/slot/level/suppression and existing Specimen.create, then revalidates before one continuation commit. Rejected/stale/constructor/counter failure does not advance actual streams. Legitimate rate miss/suppression commits just its intended attempt draws. Each opaque plan is one-shot.

Normal Explore still checks edge doors, Story, source doors and trainer sight first. Accepted creation now finishes before the original15frame iris so a suppressed/missed attempt never flashes an iris or creates a specimen. The accepted mon is captured for original transition; session/zone/player guards prevent a stale transition from starting battle. Battle admission stays FieldBattle.start, so field effect owner and send-out lead are correctly distinct. No player movement/update ordering changed.

`game.lastEncounterAttempt` receipt records version/policy, source zone/cell, physical fainted lead/ability, conscious threshold, gate/rate/physical slot, creation fields and exact decimal Rules RNG continuation. `lastEncounterSession` guards diagnostics; new session entry clears old receipt/owner references. Receipts are transient and no pending attempt is saved. Existing save Rules+World continuations replay normally; no SessionCodec change. Stats, flags, money, bag and party ownership are not mutated by attempts.

## Checks and root jobs

Host7/7 PASS0skips: verified primary bytes/blobs, unchanged C function oracle17 vectors, physical/conscious owner/order source proof, independent Park-Miller Forest literals, source geometry and source-confirmed recipe opcode subset. Actor/candidate geometry6,6→7,6 is reciprocal passable grass, far from all source NPCs/trainer sight. Opcode checks are only the selected authored subset, not execution of SDK Lua normalization. Build/JSON process-shape checks do NOT establish runtime acceptance; prior PC recipe bug is retained, not repeated as a pass claim.

```
FIELD_BUNDLE_SOURCE=/private/tmp/pokemon-field-abilities-compile-final python3 -m unittest discover -s /private/tmp/pokemon-field-abilities-01/tests -v
python3 /private/tmp/pokemon-field-abilities-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-field-abilities-compile-final-identified
```

18 declared production SDK cases (UNRUN by worker): gate49/50; uniform duplicate preferred rows; no-Electric fallback; Keen Eye+Intimidate +5 no-creation; +4/inactive pass; fainted physical ability/conscious threshold; selected battle active ignored; real Worry Seed volatile ignored; exact unrelated/Compound Eyes old-helper continuation; unchanged actual Electric creation sequence; invalid/non-grass/no-usable/foreign/malformed/forced/Repel pure rejection; changed HP/roster/table/terrain/RNG stale; actual original Blue Forest byte rate/ten rows/two independently calculated Static Pikachu literals; failed constructor/exhaustion purity; both streams; codec replay; actual Explore suppression/no iris vs accepted iris; actual door preemption with zero gate rolls. All existing SDK suites remain enabled.

Root-only SDK job (serialize with every other Simulator owner):

```
python3 /private/tmp/pokemon-field-abilities-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-field-abilities-native-01 --execute
```

Then root supplementary actual-input cases: `--case static`, `--case static-fainted`, `--case keen-eye`, `--case intimidate`, `--case save-continue`, each unique output. All use initial explicitly labeled party/location fixtures and a controlled supplementary seed413, then REAL `move right 1`. No fake battle outcomes, later HP changes or direct encounter injection. Static cases record48 actual iris/entry frames then await actual battle intro ready and assert original Pikachu row9/Lv3/LightBall. Suppression cases record48 settled frames with no battle/no iris and exactly4 attempt draws. Save/Continue case saves on grass BEFORE attempt, then actual new-process Continue restores owned Rules seed413/roll0; same real step produces exact accepted literal continuation796991454. It uses existing runner two-process requests, with real Save dialog/Title captures, no copied saves/new process framework. These recipes are source/JSON-checked and compile-only until root executes them.

Four compileable domain mutants are available through `--mutation gate-boundary|static-first-slot|suppression-boundary|physical-threshold`. Root actual control must pass first; each actual mutated SDK run must fail the field group (no retry-as-pass). Mutation is applied only in isolated staged Source after packet SHA verification and BEFORE source manifest/fingerprints/config regeneration. Build metadata declares selected mutation. Host compilation of a mutant is syntax qualification only, not a killed-mutant claim.

Re-run actual first-gate natural/protocol/medicine/PC/capture/evolution regressions and protected2494 catalog after root integration. New gated behavior requires fresh native evidence; no claim previous routes qualify the modified encounter policy.

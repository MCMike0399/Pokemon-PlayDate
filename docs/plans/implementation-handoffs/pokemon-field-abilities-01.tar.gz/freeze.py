from pathlib import Path
import hashlib,json,difflib
p=Path(__file__).parent;base=Path('/private/tmp/pokemon-brock-integration-02')
shared=['Source/world/zone.lua','Source/game/overworldState.lua'];new=['Source/domain/fieldEncounters.lua','Source/dev/fieldEncounterContracts.lua']
for rel in shared:
 out=p/'patches'/Path(rel).with_suffix('.patch');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(''.join(difflib.unified_diff((base/rel).read_text().splitlines(True),(p/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
main=(base/'Source/main.lua').read_text();marker='game = GameContext(';assert main.count(marker)==1
main=main.replace(marker,'import "domain/fieldEncounters"\nimport "dev/fieldEncounterContracts"\nContracts.register("field-encounters",FieldEncounterContracts.run)\n\n'+marker)
(p/'patches/main-root-hook.patch').write_text(''.join(difflib.unified_diff((base/'Source/main.lua').read_text().splitlines(True),main.splitlines(True),fromfile='a/Source/main.lua',tofile='b/Source/main.lua')))
m={'schema':1,'packet':'field-abilities-01','base':'/private/tmp/pokemon-brock-integration-02','base_files':{rel:hashlib.sha256((base/rel).read_bytes()).hexdigest()for rel in shared+['Source/main.lua','Source/dev/diagnostics.lua','Source/domain/specimen.lua','Source/domain/gameSession.lua']},'shared_patches':shared,'new_files':new,'overlay_files':shared+new,'files':{}}
for f in sorted(p.rglob('*')):
 if f.is_file()and f.name!='manifest.json'and'__pycache__'not in f.parts:m['files'][f.relative_to(p).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
(p/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest())

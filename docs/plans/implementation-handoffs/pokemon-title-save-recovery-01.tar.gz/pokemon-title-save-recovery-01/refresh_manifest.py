#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,difflib
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for path in sorted((root/'Source').rglob('*.lua')):
 rel=str(path.relative_to(root));base=root/'base'/rel;patch=root/'patches'/(path.stem+'.patch')
 patch.parent.mkdir(exist_ok=True)
 patch.write_text(''.join(difflib.unified_diff(base.read_text().splitlines(True)if base.exists()else [],path.read_text().splitlines(True),fromfile='a/'+rel if base.exists()else '/dev/null',tofile='b/'+rel)))
 rows.append(dict(path=rel,sha256=sha(path),base_sha256=sha(base)if base.exists()else None,patch=str(patch.relative_to(root)),patch_sha256=sha(patch)))
packet={str(p.relative_to(root)):sha(p)for p in sorted(root.rglob('*'))if p.is_file()and p.parts[-1]!='manifest.json'and not any(part in {'Source','base','patches','__pycache__'}for part in p.relative_to(root).parts)}
(root/'manifest.json').write_text(json.dumps({'source_files':rows,'packet_files':packet},indent=2)+'\n')
print(sha(root/'manifest.json'))

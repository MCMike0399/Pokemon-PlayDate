#!/usr/bin/env python3
"""Private composition. Compile is default; root alone opts into Simulator."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--mutant');p.add_argument('--with-observers',action='store_true');a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def apply(output,path):
 result=subprocess.run(['git','apply','-p1','--check',str(path)],cwd=output,capture_output=True,text=True)
 if result.returncode:
  inverse=subprocess.run(['git','apply','-p1','--reverse','--check',str(path)],cwd=output,capture_output=True,text=True)
  assert inverse.returncode==0,'shared source conflict '+str(path)+': '+result.stderr;return
 subprocess.run(['git','apply','-p1',str(path)],cwd=output,check=True)

def prepare(project,sdk,output,session):
 for row in manifest['source_files']:
  assert sha(stage/row['path'])==row['sha256'],'source drift '+row['path'];assert sha(stage/row['patch'])==row['patch_sha256'],'patch drift '+row['patch']
 for rel,want in manifest.get('packet_files',{}).items():assert sha(stage/rel)==want,'packet drift '+rel
 metadata=original(project,sdk,output,session)
 for row in manifest['source_files']:
  target=output/row['path']
  if row['base_sha256']is None:target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/row['path'],target)
  else:apply(output,stage/row['patch'])
 dependency=stage/'dependencies/moves.lua';assert sha(dependency)==manifest['moves_sha256']
 shutil.copyfile(dependency,output/'Source/battle/moves.lua')
 if a.with_observers:apply(output,stage/'root-hooks/diagnostics.patch')
 main=output/'Source/main.lua';body=main.read_text();anchor='import "dev/catalog"';assert body.count(anchor)==1
 if 'import "dev/whirlwindContracts"'not in body:body=body.replace(anchor,'import "dev/whirlwindContracts"\nContracts.register("whirlwind",WhirlwindContracts.run)\n'+anchor,1)
 main.write_text(body)
 if a.mutant:
  mutants=json.loads((stage/'mutants.json').read_text());mutation=mutants[a.mutant]
  target=output/mutation['path'];body=target.read_text();assert body.count(mutation['old'])==1,'mutant anchor';target.write_text(body.replace(mutation['old'],mutation['new'],1))
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo'])
 metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(path.relative_to(output/'Source')):sha(path)for path in sorted((output/'Source').rglob('*'))if path.is_file()and path.name!='harness_build.lua'})
 info.write_text(generated)
 values=[]
 for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
  values.append('    '+key+' = '+('true'if metadata[key]is True else json.dumps(metadata[key],ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
 metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['whirlwind_manifest_sha256']=sha(stage/'manifest.json');metadata['whirlwind_mutant']=a.mutant;metadata['whirlwind_observers']=a.with_observers
 with(output/'whirlwind-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=3000))
finally:harness.prepare=original
raise SystemExit(code)

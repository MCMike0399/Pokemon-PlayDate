# Whirlwind private candidate

**Private/unintegrated.** Root alone executes Simulator and integrates shared files. Baseline is `82cb2073d2e20f1a85cb3643428fc342a23c8e66`, Source `44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc`. No live Source, Simulator, runtime Data, map, art, save owner or generator tools were changed by this worker.

## Production result

Three narrow production patches: `battle.lua`, `dsl.lua`, `effects.lua`. Conditions is an unchanged baseline snapshot, not an integration change. There is one new SDK suite, plus ten explicit older fixture migrations. Root's generated moves file is a declared dependency rather than a worker-owned generated-data edit.

- Whirlwind applies typed `ForceSwitchEffect(DEFENDER)`. The selector must be an ordinary opposing Target; malformed/foreign typed targets fail before model/RNG changes.
- One private non-yielding `commitActiveMember` now serves ordinary voluntary selection, ordinary faint replacement and random phazing. Existing public turn/phase/trapping rules remain at their original callers. It clears old Conditions/Effects/stages/volatiles and GenV sleep duration through the current owner, switches actual Party identity, resets incoming stages, preserves side timers/weather and keeps the current reward owner.
- Real trainer phazing samples stable usable nonactive party indices once, including a one-choice call. The existing accuracy/Protect/PP/status pipeline precedes the effect; missing reserves fail after accuracy and PP without a choice sample. A miss or Protect never samples a replacement. Ordinary status Whirlwind ignores Ghost's Normal damage immunity.
- Wild mode follows the pinned native strict targetLevel<=sourceLevel policy. Either source side ends the encounter through `run`, not victory/caught/defeat; no XP, EV, prize, flag or recruitment is fabricated. The terminal return is exactly nil|'run' through `ForceSwitchEffect -> applyMoveEffects -> performMove -> resolveTurn`. Generic true/false effect results do not become outcomes.
- Every production queued action carries its actual actor. `resolveTurn` rejects displaced identities before direction, beginAction, status, PP or RNG. Effects' pending-action map also uses that identity. There is deliberately no production nil-actor compatibility fallback.
- `participants` remains the BattleRewards interface, aliased to an identity-keyed set for the current opposing mon. Living phaze/reentry retains its previous actual participants. Existing once-only `awardedEnemies`, EV/XP preparation/commit, learning receipts and reward presentation remain authoritative.
- Actual incoming foes pass through exactly one `opponentEntered(cause)` boundary: mark seen immediately before visible announcement; phaze uses dragged-out narration, nil retains existing trainer send-out/wild appearance. Conditions hazards then Effects entry run on that identity once. Entry-hazard faint checks use actual current defender rather than the old local reference, then existing once-XP/learning/faint replacement owners continue.

`battle:getForceSwitchSnapshot()` returns a defensive primitive result: `present`, `cause`, `sourceSide`, `targetSide`, `outgoing`, `incoming`, `index`, `wild`, `success`, `reason`. It retains only diagnostic scalars, not live Pokemon references or a parallel outcome controller. It is not serialized.

## Source evidence

Frozen reviewed proposal `/private/tmp/pokemon-whirlwind-flatter-proposal`, manifest `1de27783a640c367320686b6281007b02fc4a3bec26c38dfdb89f5b75ea61ee8`, retains 17 exact immutable PokeAPI B2W2/method1 raw tuples and all primary URLs/checksums. Natural Pidgey/Pidgeotto/Pidgeot Whirlwind17 and Butterfree Whirlwind22 remain unchanged; no level cap/content removal.

Actual compiled PS `9b136a8c8cdb860a8ab96fa063f906604e352547` probe: 21 cases, byte-exact replay SHA `be8324657ac51f9a4fe4eab71bbca1941b3862bce9fb1fda26851a852a4c54e7`; root independently replayed it. It proves Protect/Substitute/normal-status Ghost behavior, reserve selection, displaced actor cancellation, hazard faint and named HelpingHand no-target. Native reconstruction `b279bbefa99bb2f6fbabcc95e4b6d3e939290353` ForceSwitchCore4542, SwitchOutCore1524, ActionOrder849 supports wild level/end handling and cancelled old action; native stat/condition sequencing is retained only as proposal evidence, not implemented Flatter here. Native message0x34d and pinned PS `data/text/default.ts:20` support dragged-out narration.

No retail/emulator or cartridge PRNG equivalence is claimed. The native move-quality/flag NARC table is not independently supplied here; the generic dispatch and maintained PS move identity are disclosed separately. PS has no fabricated wild encounter/XP oracle. ParkMiller range sampling, including rejection behavior, remains the game's existing deterministic adaptation; literal SDK seeds avoid rejection and do not claim the PS/native seed protocol.

Root producer13: moves SHA `174c5c0d1a534c0056f0ad3c1eb71e9d75132ddc3a2702a28400377f67f0d747`, final producer manifest `aa5f65f8ebcd2b8037775e55ee834cb1c158ec8c7a8cd4a187be297a34ee503c`, 58 root host passes. Exactly Whirlwind gains its effect; constructor, all other 424 rows and historical oracles remain unchanged. The declared header12->13 also changes. The first worker host check incorrectly expected a single changed file line; its repaired strict check allows only that exact header and exact Whirlwind payload, not arbitrary differences.

## Explicit fixture migration

`fixture-migrations.json` records version2 for ten old manual-action fixtures. Only actual actor properties/helper arguments are added. Offline inverse checks recover every original source byte; **zero assertions or expected RNG/PP values change**. Production code requires actors rather than inferring missing identities. Tests that already use `enemyTurn()` automatically receive the production bound actor.

## Checks and root execution

Worker-run: six offline artifact/vector checks, control compile, and ten compiling fault variants. Compilation is real Playdate SDK pdc, not a transpiler/fake SDK. **SDK assertions and native input remain unrun by the worker and require root acceptance.** No fault is claimed killed merely because it compiles.

```
python3 -m unittest discover -s /private/tmp/pokemon-whirlwind-01/tests -v
python3 /private/tmp/pokemon-whirlwind-01/validate_staged.py \
 --project /Users/burbujamc/Developer/Pokemon-PlayDate \
 --output /private/tmp/pokemon-whirlwind-final-compile-01
```

Root SDK (all existing suites plus 27 new groups):

```
python3 /private/tmp/pokemon-whirlwind-01/validate_staged.py \
 --project /Users/burbujamc/Developer/Pokemon-PlayDate \
 --output /private/tmp/pokemon-root-whirlwind-sdk-01 --execute
```

The new suite exercises public real commands, typed DSL effects, real Party/Session/Signal and actual LearningState/receipt continuation. It covers malformed targets, pure eligibility, stale/missing actor, wild both source sides/equal/lower/higher levels, no reserve, one/two stable choices, PP/miss/Ghost/Protect/priority, displaced actor PP/sleep/beginAction, invalid commands, actual binding/ArenaTrap bypass, seen-on-entry, durable status/sleep/stages, real Bide/SkullBash/PetalDance/Roost/WorrySeed lifecycle, side/weather preservation, repeated per-foe participation with literal58+51 split awards, hazard-faint identity/seen-once/XP/learning, normal replacement narration, forced exit, boolean effect nonterminal behavior and directly named HelpingHand singles failure.

Fault names in `mutants.json`: no-effect, discard-run, rebind-displaced, first-reserve, wild-inverted-level, erase-participation, no-entry-seen, no-member-clear, old-defender-faint, sent-out-phaze. Root runs a fresh SDK output for each and must observe a matching actual assertion failure with unchanged artifact qualification; no success is inferred from a compiler error.

```
python3 /private/tmp/pokemon-whirlwind-01/validate_staged.py \
 --project /Users/burbujamc/Developer/Pokemon-PlayDate \
 --output /private/tmp/pokemon-root-whirlwind-fault-discard-run-01 \
 --mutant discard-run --execute
```

## Native recipes and root-owned hook

`root-hooks/diagnostics.patch` is one requested root-owned observer line, not a full diagnostics replacement. Main's sole needed hook is import/register `WhirlwindContracts` after the existing Contracts import/production dependencies. The private helper does that and refreshes actual staged Source hashes, source-manifest, generated HarnessBuild identity/data_dir and compiled Source hash. It defaults to compile only.

Native scenarios require the explicit `--with-observers` option (or root's independently merged equivalent):

```
python3 /private/tmp/pokemon-whirlwind-01/validate_staged.py \
 --project /Users/burbujamc/Developer/Pokemon-PlayDate \
 --scenario /private/tmp/pokemon-whirlwind-01/scenarios/whirlwind-trainer.json \
 --with-observers --output /private/tmp/pokemon-root-whirlwind-trainer-01 --execute
```

Likewise run `whirlwind-wild-success.json` and `whirlwind-wild-higher-fail.json` with distinct outputs. These use natural initialized Pidgey17 (Whirlwind fourth), actual selected menu input, semantic messages/waits and real current move PP. The trainer case uses an explicitly synthetic trainer ID and actual prepared Rattata5/TailWhip and Caterpie5/StringShot sets; no outcome/seen flag is forged. It captures the new front sprite and dragged-out text, checks PP19/seen/no reward, confirms the incoming member did not act, and records repeated waiting frames with unchanged rules RNG. Wild equal17 Metapod ends as run; higher18 fails without reward/escape. The author-reasoned exact vectors remain subject to actual root SDK/native observation; failed vectors must be diagnosed, not weakened.

Root inspects 400x240 move menu, old/new actual sprites and platforms, dragged-out text, wild blown-away/failure, ordinary command return, and world return with no local reward. BattleScene already reads actual Battle.player/enemy dynamically, so no scene/art patch is needed. No new phaze animation assets are claimed. Root may append the primitive phaze receipt to lastBattleOutcome diagnostics; current recipes observe it before terminal return and assert existing nonwinning `run` afterward.

## Remaining mandatory work

Flatter compound order/partial-failure remains a separate approved-proposal candidate, not changed here. HelpingHand adds only its named singles proof; no ally/doubles mode is invented. Actual Substitute, Ingrain and MagicCoat/reflection producers are still required scheduled work; no fake volatile markers are accepted to claim those interactions. SuctionCups/MagicBounce have no original151 slot and are not invented acquisitions. All remaining original151 move/ability/held-effect/content obligations remain; campaign can advance without treating global grind-tail as completed. This packet does not certify the Brock journey or next Moon slice by compile/contract count.

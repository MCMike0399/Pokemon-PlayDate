from pathlib import Path
import hashlib,json,difflib
root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for path in sorted((root/'Source').rglob('*.lua')):
 rel=str(path.relative_to(root));base=root/'base'/rel
 if base.exists()and path.read_bytes()==base.read_bytes():continue
 patch=root/'patches'/(path.stem+'.patch')
 patch.write_text(''.join(difflib.unified_diff(base.read_text().splitlines(True)if base.exists()else [],path.read_text().splitlines(True),fromfile='a/'+rel if base.exists()else '/dev/null',tofile='b/'+rel)))
 rows.append({'path':rel,'sha256':sha(path),'base_sha256':sha(base)if base.exists()else None,'patch':str(patch.relative_to(root)),'patch_sha256':sha(patch)})
files={str(path.relative_to(root)):sha(path)for path in sorted(root.rglob('*'))if path.is_file()and path.name!='manifest.json'and '__pycache__'not in path.parts}
(root/'manifest.json').write_text(json.dumps({'baseline_revision':'82cb2073d2e20f1a85cb3643428fc342a23c8e66','source_files':rows,'moves_sha256':'174c5c0d1a534c0056f0ad3c1eb71e9d75132ddc3a2702a28400377f67f0d747','packet_files':files},indent=2)+'\n')
print(sha(root/'manifest.json'))

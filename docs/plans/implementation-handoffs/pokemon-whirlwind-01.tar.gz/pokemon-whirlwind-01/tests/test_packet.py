"""Offline artifact/vector checks; no Lua transpilation or fake SDK execution."""
from pathlib import Path
import hashlib,json,re,unittest
ROOT=Path(__file__).resolve().parents[1]
class PacketTests(unittest.TestCase):
 def test_root_move_dependency_exact_sha(self):
  self.assertEqual(hashlib.sha256((ROOT/'dependencies/moves.lua').read_bytes()).hexdigest(),'174c5c0d1a534c0056f0ad3c1eb71e9d75132ddc3a2702a28400377f67f0d747')
 def test_root_only_whirlwind_row_delta(self):
  old=(ROOT/'base/moves.lua').read_text().splitlines();new=(ROOT/'dependencies/moves.lua').read_text().splitlines()
  self.assertEqual(len(old),len(new));changed=[(a,b)for a,b in zip(old,new)if a!=b]
  self.assertEqual(len(changed),2);self.assertEqual(changed[0],('-- move-producer-contract: 12','-- move-producer-contract: 13'));self.assertTrue(changed[1][0].strip().startswith('whirlwind = Move{'))
  self.assertEqual(changed[1][0],changed[1][1].replace(', effects = { ForceSwitchEffect(DEFENDER) }',''))
 def test_explicit_fixture_migrations_reverse_to_exact_original(self):
  packet=json.loads((ROOT/'fixture-migrations.json').read_text());self.assertEqual(len(packet['files']),10)
  for row in packet['files']:
   with self.subTest(path=row['path']):
    self.assertEqual(row['assertions_changed'],0);self.assertEqual(row['version'],2)
    body=(ROOT/row['path']).read_text()
    for edit in row['edits'][::-1]:body=body.replace(edit['new'],edit['old'])
    self.assertEqual(body,(ROOT/'base'/row['path']).read_text());self.assertEqual(hashlib.sha256(body.encode()).hexdigest(),row['base_sha256'])
 def test_literal_park_miller_choice_vectors(self):
  for seed,index,state in [(1,2,282475249),(2,3,564950498),(14,2,1807169839)]:
   with self.subTest(seed=seed):
    first=(seed*16807)%2147483647;second=(first*16807)%2147483647
    self.assertEqual(second,state);self.assertEqual(2+(second-1)%2,index)
 def test_no_source_conditions_changes(self):
  self.assertEqual((ROOT/'Source/battle/conditions.lua').read_bytes(),(ROOT/'base/Source/battle/conditions.lua').read_bytes())
 def test_all_sdk_case_names_unique(self):
  names=re.findall(r'^ test\("([^"\n]+)"', (ROOT/'Source/dev/whirlwindContracts.lua').read_text(),re.M)
  self.assertEqual(len(names),27);self.assertEqual(len(names),len(set(names)))
if __name__=='__main__':unittest.main()

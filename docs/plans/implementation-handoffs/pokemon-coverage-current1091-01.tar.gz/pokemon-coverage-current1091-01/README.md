# Current1091 evidence refresh — integrated root candidate

Apply AFTER frozen coverage79a4 plus evidence-chain9c992. Both earlier packets remain byte-for-byte unchanged. No Source/native/Simulator/new mechanics or generator changes. Root's source is observed read-only at `/private/tmp/pokemon-brock-integration-03/Source`.

Current observed source is44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc, build `d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc`. Actual1091passed/0failed result is copied byte-for-byte from `/private/tmp/pokemon-root-correctness-integrated-sdk-01/00001-result.json`. Summary/registry label it **integrated-root-candidate-not-yet-main**. Root must accept main copy/host/catalog separately. Current all3 natural Brock freeze remains pending; Route22/Mirror are not promoted.

Apply only five manifest patches +four new files. Full modified files are review copies; host-project/ is private validation context, NOT an overwrite tree. The loader from9c992 is unchanged and verifies actual raw SHA/build/source/report/test identities for every claimed assertion.

All48 main record scopes/capabilities/declared states/definition hashes/assertion hashes/test claims are retained. The audit in owner-audit48.json checks EVERY owner/assertion against current44bd bytes and every canonical claimed test against actual1091. Only two owner records refresh:

- Bide: exactly the two reviewed Roost-query bodies already accepted in the private1059 record, with actual1091 Bide29 rerun. No new Bide assertion/scope.
- SweetScent: ModifyStat owner adds only `if not pokemon:isAlive() then return end`; the named meaningful GenV evasion-stage/cap/PP test passes actual1091. Its living-target scope is unchanged; this does not claim that test independently proves every new dead-target branch.

Ten unverified owner records are intentionally left stale, NOT rehashed to green: nine source-gap entries have performMove typeMatchup query changes; HelpingHand source-only moveHasTarget now queries hasType. Their original declared gap/source-only scopes remain intact. Full report consequently has37 scoped-evidence rows,10 stale,102 review-required,285 unreviewed,0 scalar/learnset failures. The old9 known-gap partition now appears under stale; this is evidence drift, not repaired mechanics. `runtime_semantics_complete=false`, CLI remains nonzero1. RazorWind critical-only proof does not qualify its charge behavior. No new Roost/PF family records were added; their actual25/12 suite results are preserved in summary without broadening48 scoped claims.

Historical main950 registry is saved unchanged as runtime-move-coverage-main950.json, referencing the existing exact950 raw/summary. Private1059 registry/result/summary stay unchanged. The matrix now snapshots44bd current candidate; both selected correctness/recovery systems are implemented+sdk_scoped with actual1091 proof, while all3Brock remains pending and accepted_milestone_rows stays empty. All1501 rows and original independent layer/deadline/owner/dependency meanings remain; wholefile production evidence hashes are snapshot pins, not runtime qualification.

Validation:66 focused host tests PASS/0skip (previous61 +five current-refresh checks). Host tests explicitly retain48 scopes/assertions, require only reviewed2 owner refreshes, ensure10 stale unverified rows are not requalified, separate950/1059/1091 identities and reject campaign/future-content promotion. Existing actual SDK evidence mutants, body/assertion/metadata stale tests, full matrix inventory/dependency/layer tests and legacy verifier tests pass. Read-only final CLI report current-verifier-reviewed.json exits1 intentionally; old preliminary reports/errors are retained, never overwritten. No SDK/native was run by this worker.

After applying, use the immutable existing B2W2 CSV cache and run:

```
PYTHONDONTWRITEBYTECODE=1 /path/to/pillow-venv/bin/python -m unittest tools.tests.test_current1091_refresh tools.tests.test_runtime_sdk_evidence tools.tests.test_runtime_move_coverage tools.tests.test_move_verifier tools.tests.test_coverage_matrix -v
python3 tools/check_coverage_matrix.py --project "$PROJECT" --matrix "$PROJECT/docs/validation/coverage-current.json"
python3 tools/verify_moves/main.py --cache "$PINNED_B2W2_CACHE" --output /private/tmp/current1091-UNIQUE.json
```

Root updates the candidate/main acceptance label only after the actual source copy and host/catalog acceptance. No device or whole-engine qualification is inferred from1091.

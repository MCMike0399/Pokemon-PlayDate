// Actual pinned PS Gen5 choices. Custom literal sets are mechanics fixtures,
// not learnset/acquisition proof. Only wallclock |t:| records are removed.
const path=require('path');
const root=process.argv[2]||'/private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547';
const {Battle}=require(path.join(root,'dist/sim'));
const rev='9b136a8c8cdb860a8ab96fa063f906604e352547';
function mon(species,moves,ability,level=50){return {species,moves,ability,level,nature:'Hardy',ivs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0}};}
function setup(p1,p2,seed=[1,2,3,4]){const b=new Battle({formatid:'gen5customgame',seed,p1:{name:'USER',team:p1},p2:{name:'FOE',team:p2}});if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');return b;}
function state(b){return {turn:b.turn,request:b.requestState,p1:b.p1.pokemon.map(p=>({id:p.species.id,hp:p.hp,status:p.status,active:p.isActive,position:p.position,boosts:p.boosts,confusion:p.volatiles.confusion?.time,pp:p.moveSlots.map(x=>({id:x.id,pp:x.pp,maxpp:x.maxpp}))})),p2:b.p2.pokemon.map(p=>({id:p.species.id,hp:p.hp,status:p.status,active:p.isActive,position:p.position,boosts:p.boosts,confusion:p.volatiles.confusion?.time,pp:p.moveSlots.map(x=>({id:x.id,pp:x.pp,maxpp:x.maxpp}))}))};}
const rows=[];
function run(name,p1,p2,prepare,choice=['move 1','move 1'],seed=[1,2,3,4]){const b=setup(p1,p2,seed);if(prepare)prepare(b);const start=b.log.length;const before=JSON.parse(JSON.stringify(state(b)));const draws=[];const old=b.prng.rng.next.bind(b.prng.rng);b.prng.rng.next=function(){const n=old();draws.push(n);return n;};b.makeChoices(...choice);rows.push({name,seed,sets:{p1,p2},before,after:JSON.parse(JSON.stringify(state(b))),random32:draws,log:b.log.slice(start).filter(x=>!x.startsWith('|t:|'))});b.destroy();}
const wind=()=>mon('Pidgeot',['whirlwind','splash'],'Keen Eye');const rat=()=>mon('Rattata',['splash'],'Run Away');const reserve=()=>mon('Squirtle',['splash'],'Torrent');
run('whirlwind one usable reserve',[wind()],[rat(),reserve()]);
run('whirlwind no reserve',[wind()],[rat()]);
run('whirlwind Ghost target',[wind()],[mon('Gastly',['splash'],'Levitate'),reserve()]);
run('whirlwind Protect',[wind()],[mon('Rattata',['protect'],'Run Away'),reserve()]);
run('whirlwind Substitute bypass',[wind()],[mon('Rattata',['substitute','splash'],'Run Away'),reserve()],b=>b.makeChoices('move 2','move 1'),['move 1','move 2']);
run('whirlwind Ingrain prevents',[wind()],[mon('Tangela',['ingrain','splash'],'Chlorophyll'),reserve()],b=>b.makeChoices('move 2','move 1'),['move 1','move 2']);
run('whirlwind Soundproof does not prevent',[wind()],[mon('Mr. Mime',['splash'],'Soundproof'),reserve()]);
run('whirlwind Suction Cups external custom ability',[wind()],[mon('Rattata',['splash'],'Suction Cups'),reserve()]);
run('whirlwind ShadowTag does not prevent forced switch',[mon('Wobbuffet',['whirlwind'],'Shadow Tag')],[rat(),reserve()]);
run('whirlwind pending displaced identity cannot execute',[wind(),reserve()],[mon('Pidgey',['whirlwind'],'Keen Eye',5),reserve()]);
run('whirlwind target accuracy stages apply',[wind()],[rat(),reserve()],b=>{b.p1.active[0].boosts.accuracy=-6;b.p2.active[0].boosts.evasion=6;});
run('whirlwind accuracy stages alternate seed',[wind()],[rat(),reserve()],b=>{b.p1.active[0].boosts.accuracy=-6;b.p2.active[0].boosts.evasion=6;},['move 1','move 1'],[1,2,3,5000]);
run('whirlwind entry hazard KO',[mon('Cloyster',['spikes','whirlwind'],'Shell Armor')],[rat(),mon('Caterpie',['splash'],'Shield Dust',1),reserve()],b=>{b.makeChoices('move 1','move 1');b.p2.pokemon[1].hp=1;b.p2.pokemon[2].hp=1;},['move 2','move 1']);
function flatter(name,ability='Run Away',prepare,enemy='splash'){run(name,[mon('Nidoran-F',['flatter'],'Poison Point',50)],[mon('Rattata',[enemy],ability,100)],b=>{b.p2.active[0].boosts.spe=6;if(prepare)prepare(b);});}
flatter('flatter normal');
flatter('flatter Own Tempo','Own Tempo');
flatter('flatter capped SpA','Run Away',b=>b.p2.active[0].boosts.spa=6);
flatter('flatter already confused','Run Away',b=>b.p2.active[0].addVolatile('confusion'));
flatter('flatter both already capped and confused','Run Away',b=>{b.p2.active[0].boosts.spa=6;b.p2.active[0].addVolatile('confusion');});
flatter('flatter Safeguard','Run Away',b=>b.p2.addSideCondition('safeguard',b.p2.active[0],b.dex.moves.get('safeguard')));
flatter('flatter Protect','Run Away',undefined,'protect');
run('Helping Hand singles fails named',[mon('Nidoran-F',['helpinghand'],'Poison Point')],[rat()]);
process.stdout.write(JSON.stringify({revision:rev,format:'gen5customgame',seed:[1,2,3,4],provenance:'Literal IV0 EV0 Hardy sets above; illegal move/ability combinations are explicitly mechanics-only custom fixtures, not content availability. Default PS PP Ups retained; basePP SDK contracts must use actual generated basePP. random32 is the actual compiled PRNG next call trace during each real makeChoices, not a ParkMiller/cartridge equivalence claim. No wild/trainer XP model is fabricated.',rows},null,2)+'\n');

#!/usr/bin/env python3
"""Literal actual-reference checks and deterministic replay; no SDK simulation."""
import argparse,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--ps-root',type=Path);a=p.parse_args();root=Path(__file__).resolve().parent
sources=json.loads((root/'sources.json').read_text());ps=a.ps_root or Path(sources['ps_root'])
for key,info in sources['files'].items():
 if key.startswith('PS/'):
  assert hashlib.sha256((ps/key[3:]).read_bytes()).hexdigest()==info['sha256'],key
raw=subprocess.check_output(['node',str(root/'probe.js'),str(ps)])
assert raw==(root/'observations.json').read_bytes(),'actual PS replay changed'
packet=json.loads(raw);rows={r['name']:r for r in packet['rows']};assert len(rows)==21
log=lambda row:'\n'.join(row['log'])
active=lambda row:next(m['id']for m in row['after']['p2']if m['active'])
for name in ['whirlwind one usable reserve','whirlwind Ghost target','whirlwind Substitute bypass','whirlwind Soundproof does not prevent','whirlwind ShadowTag does not prevent forced switch','whirlwind pending displaced identity cannot execute']:
 assert active(rows[name])=='squirtle',name
for name in ['whirlwind no reserve','whirlwind Protect','whirlwind Suction Cups external custom ability']:
 assert active(rows[name])=='rattata',name
assert active(rows['whirlwind Ingrain prevents'])=='tangela'
displaced=rows['whirlwind pending displaced identity cannot execute']
assert len([x for x in displaced['log']if x.startswith('|move|')])==1
before=next(m for m in displaced['before']['p2']if m['id']=='pidgey')
after=next(m for m in displaced['after']['p2']if m['id']=='pidgey')
assert before['pp']==after['pp'],'displaced actor spent PP'
assert '|-miss|'in log(rows['whirlwind accuracy stages alternate seed'])
assert len(rows['whirlwind accuracy stages alternate seed']['random32'])==1
hazard=rows['whirlwind entry hazard KO'];assert hazard['after']['request']=='switch';assert '|faint|'in log(hazard)
assert log(hazard).index('|drag|')<log(hazard).index('[from] Spikes')<log(hazard).index('|faint|')
normal=rows['flatter normal'];assert normal['before']['p2'][0]['boosts']['spa']==0
assert normal['after']['p2'][0]['boosts']['spa']==1 and normal['after']['p2'][0]['confusion']==4
assert log(normal).index('|-boost|')<log(normal).index('|-start|')
for name in ['flatter Own Tempo','flatter Safeguard']:
 assert rows[name]['after']['p2'][0]['boosts']['spa']==1 and 'confusion'not in rows[name]['after']['p2'][0]
 assert len(rows[name]['random32'])==1
assert rows['flatter capped SpA']['after']['p2'][0]['confusion']==4
assert rows['flatter already confused']['after']['p2'][0]['boosts']['spa']==1
assert '|-fail|'in log(rows['flatter both already capped and confused'])
assert rows['flatter Protect']['after']['p2'][0]['boosts']['spa']==0
helping=rows['Helping Hand singles fails named'];assert '[notarget]'in log(helping)and '|-fail|'in log(helping);assert helping['random32']==[]
assert helping['after']['p1'][0]['pp'][0]['pp']==helping['before']['p1'][0]['pp'][0]['pp']-1
print(json.dumps({'ok':True,'actual_PS_cases':21,'observations_sha256':hashlib.sha256(raw).hexdigest()},indent=2))

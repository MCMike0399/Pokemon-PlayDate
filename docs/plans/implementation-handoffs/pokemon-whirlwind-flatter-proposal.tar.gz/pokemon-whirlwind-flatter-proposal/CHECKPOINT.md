# Research checkpoint: Whirlwind, Flatter and Helping Hand

Paused at root's explicit priority change. No Source implementation, generator edits, Simulator work or actual PS execution has been performed for this proposal. Whirlwind at Pidgey/Pidgeotto/Pidgeot level17 remains a near-term first-gate obligation; nothing is waived.

Verified current ordered learnset literals: Butterfree Whirlwind22, Pidgey/Pidgeotto/Pidgeot Whirlwind17. Nidoran F/M Helping Hand25 and Flatter33; Nidorina/Nidorino Helping Hand28 and Flatter38. Other library Helping Hand entries include Growlithe12 and Eevee family1, without claiming first-gate acquisitions.

Pinned maintained PS9b136a8c8cdb860a8ab96fa063f906604e352547: Gen5 Whirlwind override accuracy100 and flags protect/reflectable/bypasssub at data/mods/gen5/moves.ts985; base move is priority−6, PP20, forceSwitch=true, normal status. Current generated row has correct scalars/protect flag but no effect. Actual PS trainer-style forced replacement uses forceSwitch→dragIn→getRandomSwitchable, not voluntary selection. No actual wild PS support was identified yet; do not invent a simulator wild oracle.

Native reconstructionb279bbefa99bb2f6fbabcc95e4b6d3e939290353: btl_server_flow.c4525–4640 ForceSwitchCore. Trainer mode picks random usable bench slot; wild mode rejects higher-level target, then switches out/end result5. CheckForceSwitchBlocked precedes selection. Exact accuracy/level-check order, wild outcome owner/reward handling, hazards/entry learning/participation and ability policy still need complete call tracing/probes before an implementation proposal. Raw C result5 meaning requires caller confirmation, not assumed victory/run equivalence.

Flatter already has a payload, not an empty successful no-op: current row applies confusion then SpA+1. PS base moves.ts5700 defines boosts+1 and confusion; actual battle-actions applies boosts before volatile, suggesting current order needs verification/correction. Full failure when capped/already confused, Own Tempo/Safeguard partial effects and duration RNG are not yet probed. Do not call it missing wholesale.

Helping Hand is already rejected by current Battle target resolution for target3/15 in singles. It needs a directly named proof, not an invented ally. Native HelpingHandReady6410 requires FrontPosCount>1; PS adjacentAlly targeting can prove singles no-target with actual choice. Planned tests cover PP attempt timing, zero move RNG on no-target and no boost state.

Next work if resumed: actual pinned PS choices for trainer reserves/none, Protect, Ghost/status immunity, trapped target/entry, Flatter modifiers/failure/ability, Helping Hand; complete native force-switch caller/event trace; propose a narrow shared replacement operation that bypasses voluntary trapping but preserves member/side cleanup, seen-on-entry, learning and verdict ownership. No generator producer13 request is frozen yet.

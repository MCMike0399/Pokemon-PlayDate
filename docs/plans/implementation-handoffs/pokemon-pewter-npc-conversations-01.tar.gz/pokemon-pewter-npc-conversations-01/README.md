# Pewter source conversations — proposal checkpoint

Read PROPOSAL.md first. This packet deliberately contains NO runtime candidate/patch/contracts module and applies nothing to Source. Root explicitly required stopping at a concrete proposal if either interaction needed shared state/new DSL outside owned PewterEvents.lua. Both require a real YES/NO branch; EventState implements choices only for healing. Museum NPC NO additionally starts source player/NPC escort, music/arrival/exit/hide/reset, so a generic paragraph would remove intended gameplay.

Files:
- PROPOSAL.md: exact scripts/branches, smallest finite owner extension, museum movement/source limitations, proposed actualSDK/native/mutant acceptance cases.
- proposed-hunk.txt: NON-APPLYABLE interface sketch; do not bind either ID until corresponding EventState question/escort owners exist.
- mapping.json: stable IDs, source coordinates/labels, four museum approach prefixes and two literal commonRLE vectors.
- source-pin.json: seven exact immutable primary files +four current production dependency hashes. All seven needed text recipes already exist unchanged; no data regeneration/art change needed.
- check_sources.py: portable read-only primary/data/proposal-boundary checker; requires explicit project/reference paths, no private machine path default.
- source-check-final.json: PASS seven source hashes/seven exact text recipes/twoRLE vectors/branch and B→NO checks. Earlier failed checker output is retained; its initial substring-label assertion matched the jump reference instead of the label and was corrected before this final check. No production code changed.

Reproduce:
```
PYTHONDONTWRITEBYTECODE=1 python3 check_sources.py --project "$PROJECT" --reference "$PINNED_POKERED_AF519899"
```

Original source uses YES first; B selects NO. Forced state exit/reset is the cancellation test, not B. Object4 choice is read-only gameplay state; object3 NO intentionally moves the player/actor transiently. Normal NPC idle RNG ticks before interaction are separate from overlay/script execution; future tests should establish settled ownership then assert no new script/menu RNG draws. Native screenshots/SDK execution remain root-owned and UNRUN here. No claim of museum interior access, audio completion, conversation completion or new event acceptance.

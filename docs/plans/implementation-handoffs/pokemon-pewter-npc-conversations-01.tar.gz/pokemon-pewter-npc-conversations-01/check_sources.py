"""Read-only primary-source/data qualification for this proposal, no fake runtime."""
import argparse,hashlib,json,re
from pathlib import Path

def check(project,reference,packet):
 pin=json.loads((packet/'source-pin.json').read_text());mapping=json.loads((packet/'mapping.json').read_text())
 for entry in pin['files']:
  assert hashlib.sha256((reference/entry['path']).read_bytes()).hexdigest()==entry['sha256'],'primary source drift: '+entry['path']
 table=json.loads((project/'Source/data/pewterSlice/dialogue.json').read_text())['texts'];text=(reference/'text/PewterCity.asm').read_text()
 for label in mapping['labels']:
  body=text.split(label+'::',1)[1].split('\n_',1)[0];expected=[]
  for line in body.splitlines():
   m=re.fullmatch(r'\s*(text|line|cont|para) "(.*)"',line)
   if m:expected.append({'op':m[1],'text':m[2]})
   elif line.strip()=='done':expected.append({'op':'control','source':'done'})
  actual=[{k:v for k,v in r.items()if k!='source_line'}for r in table[label]['recipe']]
  assert actual==expected,'primary text differs: '+label
  assert table[label]['source']=='text/PewterCity.asm'
 script=(reference/'scripts/PewterCity.asm').read_text()
 one=script.split('PewterCitySuperNerd1Text:',1)[1].split('PewterCitySuperNerd1ItsRightHereText:',1)[0]
 two=script.split('PewterCitySuperNerd2Text:',1)[1].split('PewterCityYoungsterText:',1)[0]
 assert 'call YesNoChoice' in one and 'jr nz, .playerDidNotGoIntoMuseum' in one
 assert one.index('ld hl, .WerentThoseFossilsAmazingText')<one.index('\n.playerDidNotGoIntoMuseum\n')<one.index('ld hl, .YouHaveToGoText')
 assert 'ld a, $2\n\tld [wNPCMovementScriptPointerTableNum], a' in one
 assert 'GetSpritePosition2' in one and 'SCRIPT_PEWTERCITY_SUPER_NERD1_SHOWS_PLAYER_MUSEUM' in one
 assert 'call YesNoChoice' in two and 'jr nz, .playerDoesNotKnow' in two
 assert two.index('ld hl, .ThatsRightText')<two.index('\n.playerDoesNotKnow\n')<two.index('ld hl, .ImSprayingRepelText')
 auto=(reference/'engine/overworld/auto_movement.asm').read_text()
 for name,expected in mapping['common_rle'].items():
  block=auto.split(name+':',1)[1].split('\n\n',1)[0]
  actual=re.findall(r'\bdb (NO_INPUT|PAD_[A-Z]+|NPC_MOVEMENT_[A-Z]+), (\d+)',block)
  assert [[direction,int(count)]for direction,count in actual]==expected,'RLE differs: '+name
 menu=(reference/'engine/menus/text_box.asm').read_text()
 assert 'jr nz, .choseSecondMenuItem ; automatically choose the second option if B is pressed' in menu
 assert '.choseSecondMenuItem\n\tld a, 1\n\tld [wCurrentMenuItem], a' in menu
 event=(project/'Source/game/eventState.lua').read_text();assert 'elseif step.op=="shop" or step.op=="heal"' in event
 assert 'elseif step.op=="pewter-question"' not in event,'proposal boundary changed; reassess before using this packet'
 return {'ok':True,'pinned_primary_files':len(pin['files']),'exact_existing_text_labels':len(mapping['labels']),'common_RLE_vectors':len(mapping['common_rle']),'runtime_implemented':False,'sdk_native':'unrun','boundary':'shared EventState question +museum escort owner required'}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);a=p.parse_args();print(json.dumps(check(a.project,a.reference,Path(__file__).resolve().parent),indent=2))

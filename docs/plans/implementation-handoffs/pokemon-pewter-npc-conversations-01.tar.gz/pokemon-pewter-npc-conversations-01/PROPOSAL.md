# Pewter objects3/4: exact interaction boundary proposal

Base82cb207 Source44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc. Proposal/reference checks only. No runtime candidate or Source patch is supplied, no live writes/Simulator/native/art changes, and no claim either conversation is complete.

Root's scope explicitly says: **“if behavior needs shared state or new DSL beyond existing interfaces, stop at concrete proposal instead.”** This condition applies. Current EventState.enter accepts dialog/confirmed-dialog/receipt/trainer/move/shop/heal; its only YES/NO state and input handling is heal-confirm. PewterEvents.observe has no answer state. Both source interactions require a real choice; object3 NO additionally drives an escort outside this packet's owned PewterEvents file. Adding these IDs to simple dialogue would silently remove original branches. Adding an unsupported op without EventState ownership would fail production dispatch.

## Exact source mapping

Pinned original pret/pokered af519899719f0754965776faac0e836a3b906e6d. See source-pin.json and mapping.json for immutable byte pins, source lines, labels and literal recipe/path assertions. No missing dialogue dependency: all7 referenced labels already exist in Source/data/pewterSlice/dialogue.json and match the primary text recipes exactly. No generator, data/art regeneration or new sprite is needed for the words.

| Source ID | Script and choice | Actual continuation |
|---|---|---|
| pokered:PEWTER_CITY:objects:3 | PewterCitySuperNerd1Text prompts _PewterCitySuperNerd1DidYouCheckOutMuseumText, calls YesNoChoice, tests wCurrentMenuItem | YES/0 → _PewterCitySuperNerd1WerentThoseFossilsAmazingText, finish. NO/1 → _PewterCitySuperNerd1YouHaveToGoText, then museum movement pointer table2, arrival _PewterCitySuperNerd1ItsRightHereText, NPC DOWN4, hide/reset/show |
| pokered:PEWTER_CITY:objects:4 | PewterCitySuperNerd2Text prompts _PewterCitySuperNerd2DoYouKnowWhatImDoingText, calls YesNoChoice, compares index0 | YES/0 → _PewterCitySuperNerd2ThatsRightText. NO/1 → _PewterCitySuperNerd2ImSprayingRepelText. Finish; no bag, flag, party or RNG mutation |

These branch decisions are the player's answer, not museum ticket ownership, prior visitation, Pokedex, badge or bag checks. Both conversations repeat. home/yes_no.asm +engine/menus/text_box.asm establish ordinary YES_NO_MENU initial first option YES and B selects the second option NO. Thus **B on museum question starts the source NO branch, not an abort**. Forced machine exit/reset is the abort case for ownership tests. No menu choice should be persisted as a fake quest flag.

Object3 source start is(27,17), STAY/NONE. Object4 is(26,25), WALK/LEFT_RIGHT. Current provider instantiates both using existing SPRITE_SUPER_NERD and protected current art. Object4 may wander under NPCMotion before interaction; requestInteraction already owns settling/facing. Do not match a wandering actor only by stale coordinate. A script must hold the exact interacted NPC identity and source ID.

## Museum NO is an escort, not another paragraph

PewterCitySuperNerd1Text saves the source actor's position via GetSpritePosition2, chooses pointer table2 and the museum script. auto_movement.asm plays MUSIC_MUSEUM_GUY, seeds player simulated movement and the NPC stream. pewter_guys.asm adjusts the player prefix according to actual source approach (source tables are y,x): below(27,18) UP,UP; above(27,16) RIGHT,LEFT; left(26,17) UP,RIGHT; right(28,17) UP,LEFT. Raw common RLE player stream is NO_INPUT1,UP3,LEFT13,UP6; NPC stream UP6,LEFT13,UP3,LEFT1. Preserve these raw declarations; exact input decode/count ordering/final cells need executable geometry/actor trace before adaptation, not naive arithmetic over RLE bytes.

After movement completes the map script faces the NPC UP, shows _ItsRightHere, positions the temporary exit phase using its source setter, walks the NPC DOWN4, hides, restores saved position and shows it again; controls and map-script state reset. This is transient lifecycle, not a durable defeated NPC or one-time reward. Source default music is restored before arrival text. Audio is an explicit existing backlog; do not claim its timing is implemented from this text proposal.

Current source provider intentionally blocks Museum1F warps (outside the eight-map region). An escort implementation must trace the actual source endpoint and suppress ordinary warp/door/encounter progression while scripted. It must not open Museum1F, teleport through a blocked map, or claim museum interior access. Source path/motion/native witness is required before accepting a narrow current-region adaptation. No route/facing correction is proposed without that trace.

## Minimal owner extension for root review

1. Add ONE bounded EventState question operation for these TWO IDs, not a generic dialogue VM. Suggested plan step `{op='pewter-question',id=<same source ID>,prompt=<exact label>}`. Validate whitelist+same active game/session/player/zone and exact interacted source actor. Prompt completes before YES/NO appears; initialYES, B→NO. Use existing BattleMenu, EventState:guard epoch/serial/isTop, and current draw/input policy. No world progression beneath the overlay.
2. Keep branch content pure in PewterEvents: `answer(id,index)` accepts only these IDs and indices1/2, returns exact source labels and optional explicit `scene='pewter-museum-escort'` for object3 NO. No callback closures, arbitrary scripts, durable answer flags or inventory effect. Existing simple handlers remain unchanged. Object4 can then be completed using this small shared UI seam alone.
3. Object3 NO needs a separate bounded EventState-owned museum escort helper/phase set. Pin four approach prefixes, decode actual source movement first, validate collision/NPC occupancy and actor identity, advance real native eight-frame Player/NPC steps only, and suppress ordinary door/encounter/connection triggers. Existing SourceActors/NPCMotion wandering must stay frozen while scripted; do not consume world/battle RNG for source path playback. Abort/reset restores partial player/actor pose/queue/visibility and invalidates callbacks; successful completion retains source player arrival and returns NPC to source saved pose/home. Do not broaden GameSession or add a second world/controller owner.
4. If completion requires exposing a reusable actor-script step seam, root separately authorizes the narrow NPCMotion/NPC owner hook; it is outside this file ownership. Prefer existing exact source frame resolver/eight-frame cadence and no new art. No art changes are proposed here.

A proposed PewterEvents hunk is in proposed-hunk.txt for interface review ONLY. It is intentionally not an applyable runtime patch because EventState does not implement the required operation. No current bound bit/has() value changes until both branches can execute correctly.

## Required acceptance after owner authorization

Production SDK contracts must construct a real imported PewterCity, install existing source sprites idempotently, interact through PewterWorld.tryInteract/KantoWorld.dispatch, use actual EventState+DialogState+BattleMenu and restore all new sprites/global owner state on failure. No fakeSDK/mock menu. Source definitions/labels remain literal independent expectations.

- Object4 YES and NO: prompt before menu, exact selected source recipe once, B→NO, repeat both choices. Byte-identical session payload/bag/flags/party and both RNG streams throughout; no REPEL consumption/effect grant is invented. Try from both settled current poses and after real NPC walking.
- Object3 YES: exact prompt/fossils branch, no museum actor path, no ticket/flag/item mutation; repeat and contradictory answers are allowed. Abort during prompt/menu/result and invoke retained old callbacks after exit/reentry: no new dialog or movement.
- Object3 NO: all4 legal approaches, actual eight-frame pose/art cadence, collision/occupancy rejection, museum music limitation explicit, source arrival text only after arrival, DOWN4 exit/hide/reset/restore, same NPC identity, no temporary actor leak. Exact saved source pose restoration after success and partial-step cancellation; world/RulesRNG untouched. No Museum1F entry or false “source complete” claim while it remains blocked.
- Parent replacement/session install/zone change/actor removal invalidate both selected callbacks and motion completion. Stale YES/NO cannot cross to a newly entered event. Forced reset is distinct from source B→NO.
- Independent mutations: invert YES/NO, replace a label, alter RLE prefix/length, drop stale guard, consume REPEL, move the wrong actor, omit exit restoration. Meaningful contracts must fail.

Native root-only recipe: settled player adjacent to source object3/4; real A interaction, wait readable dialog, A to menu, capture both YES/NO choices and resulting text; for museum NO record every native movement frame and final actor/player/flags state. Repeat after Save/Continue only at settled overworld. Preserve original2494 protected catalog exactly; no new pixels expected. No SDK/native is run in this proposal packet.

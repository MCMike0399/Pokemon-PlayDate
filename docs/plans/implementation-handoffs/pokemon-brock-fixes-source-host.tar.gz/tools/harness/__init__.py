"""Playdate SDK harness."""

"""Optional small extension applied after the sex/status owner's narrow hunks."""
from pathlib import Path
import difflib,shutil,subprocess,tempfile
R=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory()as tmp:
 root=Path(tmp);shutil.copytree(R/'base/Source',root/'Source')
 for name in ('effects.patch','dsl-status.patch'):subprocess.run(['git','apply',str(R/'patches'/name)],cwd=root,check=True)
 path=root/'Source/battle/effects.lua';old=path.read_text();new=old.replace('function BattleEffects:init(battle)','handlers[20]={}\nfunction BattleEffects:init(battle)',1)
 anchor='''    if ability(mon)==17 and (status=="poison" or status=="badPoison") then return "Immunity" end''';assert new.count(anchor)==1
 new=new.replace(anchor,anchor+'\n    if ability(mon)==20 and status=="confuse" then return "Own Tempo" end',1)
 before='''    if not self:active(mon) or not alive(mon) or not self:statusImmunity(mon,mon.status) then return false end
    mon.status,mon.statusTurns,mon.sleepDuration=nil,0,0
    self.battle.conditions:of(mon).toxic=nil
    self.battle:say(mon.name.."'s Immunity cured its poison!")
    return true'''
 after='''    if not self:active(mon) or not alive(mon) then return false end
    if self:statusImmunity(mon,mon.status)=="Immunity" then
        mon.status,mon.statusTurns,mon.sleepDuration=nil,0,0
        self.battle.conditions:of(mon).toxic=nil
        self.battle:say(mon.name.."'s Immunity cured its poison!")
        return true
    end
    if mon.confusion~=nil and self:statusImmunity(mon,"confuse")=="Own Tempo" then
        mon.confusion=nil
        self.battle:say(mon.name.."'s Own Tempo cured its confusion!")
        return true
    end
    return false'''
 assert new.count(before)==1;new=new.replace(before,after,1)
 (R/'patches/own-tempo-effects.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/Source/battle/effects.lua',tofile='b/Source/battle/effects.lua')))
 path=root/'Source/battle/dsl.lua';old=path.read_text();anchor='''    if self.status == "confuse" then
        if pokemon.confusion then return end
''';assert old.count(anchor)==1
 new=old.replace(anchor,anchor+'''        local immunity=battle.effects and battle.effects:statusImmunity(pokemon,"confuse")
        if immunity then battle:say(pokemon.name.." is protected by "..immunity.."!");return end
''',1)
 (R/'patches/own-tempo-dsl.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/Source/battle/dsl.lua',tofile='b/Source/battle/dsl.lua')))

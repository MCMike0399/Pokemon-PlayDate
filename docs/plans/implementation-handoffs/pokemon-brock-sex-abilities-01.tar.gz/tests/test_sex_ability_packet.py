import importlib.util,json,shutil,subprocess,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('sex_ability_sources',ROOT/'audit_sources.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
class SourceAndComposition(unittest.TestCase):
 def test_primary_literal_sources_exact(self):
  report=audit.audit();self.assertTrue(report['ok']);self.assertEqual(report['poison_point_percent'],30);self.assertEqual(report['rivalry_q12_same'],5120);self.assertFalse(report['oblivious_gen5_taunt_immunity'])
 def test_missing_and_corrupt_pin_fail_without_changes(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);(root/'references').mkdir();shutil.copy2(ROOT/'source-manifest.json',root/'source-manifest.json')
   with patch.object(audit,'HERE',root):
    with self.assertRaises(FileNotFoundError):audit.audit()
    first=next(iter(json.loads((root/'source-manifest.json').read_text())['files']));p=root/'references'/first;p.write_text('mutated')
    with self.assertRaisesRegex(ValueError,'checksum'):audit.audit()
    self.assertEqual(p.read_text(),'mutated')
 def test_narrow_hunks_preserve_bide_and_existing_light_ball(self):
  with tempfile.TemporaryDirectory()as tmp:
   root=Path(tmp);shutil.copytree(ROOT/'base/Source',root/'Source')
   effects=root/'Source/battle/effects.lua';old=effects.read_text()
   subprocess.run(['git','apply',str(ROOT/'dependency-artifacts/light-ball-effects.patch')],cwd=root,check=True)
   held=effects.read_text().split('function BattleEffects:attackStat(',1)[1].split('function BattleEffects:defenseStat(',1)[0]
   self.assertIn('attacker.heldItem=="lightBall"',held)
   bide_lines=[line for line in old.splitlines()if 'bideHit('in line];self.assertTrue(bide_lines)
   battle_before=(root/'Source/battle/battle.lua').read_text();power=next(line for line in battle_before.splitlines()if 'return self.effects:basePower('in line);self.assertIn('attacker,defender',power)
   for p in sorted((ROOT/'patches').glob('*.patch')):
    result=subprocess.run(['git','apply','--check',str(p)],cwd=root,capture_output=True);self.assertEqual(result.returncode,0,result.stderr.decode());subprocess.run(['git','apply',str(p)],cwd=root,check=True)
   after=effects.read_text()
   for line in bide_lines:self.assertIn(line,after)
   self.assertEqual(held,after.split('function BattleEffects:attackStat(',1)[1].split('function BattleEffects:defenseStat(',1)[0]);self.assertIn(power,(root/'Source/battle/battle.lua').read_text())
   self.assertIn('statusImmunity(mon,"poison")',(root/'Source/battle/conditions.lua').read_text());self.assertIn('battle.effects:statusImmunity(pokemon,self.status)',(root/'Source/battle/dsl.lua').read_text())
 def test_q12_literals_distinguish_combined_and_sequential_rounding(self):
  def chain(a,b):return (a*b+2048)//4096
  def apply(value,ratio):return (value*ratio+2047)//4096
  self.assertEqual(apply(40,5120),50);self.assertEqual(apply(40,3072),30)
  self.assertEqual(apply(29,chain(2048,5120)),18);self.assertEqual(apply(apply(29,2048),5120),17)
 def test_exact_captivate_request_has_no_effect_replacement(self):
  request=json.loads((ROOT/'generator-request.json').read_text());self.assertEqual(request['addition'],{'attemptRule':'oppositeSex'});self.assertEqual(request['producer_epoch'],5);self.assertNotIn('effects',request['addition'])
if __name__=='__main__':unittest.main()

#!/usr/bin/env python3
"""Independent literal primary evidence; no Lua/TS execution, no network/SDK."""
import argparse,hashlib,json,re
from pathlib import Path
HERE=Path(__file__).resolve().parent
def audit():
 pins=json.loads((HERE/'source-manifest.json').read_text())['files'];text={}
 for name,pin in pins.items():
  raw=(HERE/'references'/name).read_bytes()
  if hashlib.sha256(raw).hexdigest()!=pin['sha256']:raise ValueError('source checksum '+name)
  text[name]=raw.decode()
 moves=text['ps_data_moves.ts'];cap=moves.split('\tcaptivate: {',1)[1].split('\n\t},',1)[0]
 for token in ("pokemon.gender === 'M' && source.gender === 'F'","pokemon.gender === 'F' && source.gender === 'M'",'spa: -2','accuracy: 100','pp: 20'):assert token in cap,token
 c=text['bw_move_handlers.c'];capc=c.split('static void HandlerCaptivate(',2)[2].split('\n}',1)[0];assert 'sex == 2 || targetSex == 2 || sex == targetSex'in capc
 abilities=text['ps_data_abilities.ts'];rivalry=abilities.split('\trivalry: {',1)[1].split('\n\t},',1)[0]
 for token in ('attacker.gender && defender.gender','attacker.gender === defender.gender','chainModify(1.25)','chainModify(0.75)'):assert token in rivalry
 for version in (8,7,6,5):
  override=text[f'ps_data_mods_gen{version}_abilities.ts']
  for key in ('rivalry','poisonpoint','immunity'):
   match=re.search(r'^\t'+key+r': \{\n(.*?)^\t\},',override,re.M|re.S)
   if match:
    assert 'inherit: true'in match[1]
    residue=re.sub(r'(?m)^\t\t(?:inherit: true|rating: [0-9.]+),?\s*$', '',match[1]);assert not residue.strip(),'behavioral override '+str(version)+key
 oblivious=text['ps_data_mods_gen5_abilities.ts'].split('\toblivious: {',1)[1].split('\n\t},',1)[0];assert "move.id === 'captivate'"in oblivious;assert 'taunt'not in oblivious
 actions=text['ps_sim_battle-actions.ts'];start=actions.index('this.hitStepTryHitEvent,');immunity=actions.index('this.hitStepTryImmunity,',start);accuracy=actions.index('this.hitStepAccuracy,',start);assert start<immunity<accuracy
 own=abilities.split('\towntempo: {',1)[1].split('\n\t},',1)[0];assert "status.id === 'confusion'"in own and "pokemon.removeVolatile('confusion')"in own
 own7=text['ps_data_mods_gen7_abilities.ts'].split('\towntempo: {',1)[1].split('\n\t},',1)[0];assert 'onTryBoost: undefined'in own7
 c=text['bw_ability_handlers.c'];assert 'HandlerCommonGuardStatus(flow, monId, 6)'in c;common=c.split('void CommonContactStatusAbility(',1)[1].split('\n}',1)[0]
 assert 'getMoveFlag'in common and 'AbilityEvent_RollEffectChance(flow, chance)'in common
 assert 'CommonContactStatusAbility(flow, monId, 5, condition, 0x1e)'in c;assert 'HandlerCommonGuardStatus(flow, monId, 5)'in c;assert 'HandlerImmunityCureStatus' in c
 return {'ok':True,'pins':len(pins),'captivate_spa':-2,'rivalry_q12_same':5120,'rivalry_q12_opposite':3072,'poison_point_percent':30,'poison_status_id':5,'oblivious_gen5_taunt_immunity':False,'scope':'source proof only; SDK/native unexecuted'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--report',type=Path);a=p.parse_args();v=audit()
 if a.report:a.report.write_text(json.dumps(v,indent=2)+'\n')
 print(json.dumps(v))

"""Rebuild narrow reviewed source hunks from explicit frozen engine inputs."""
from pathlib import Path
import difflib
R=Path(__file__).resolve().parent
def write(name,path,changes):
 old=(R/'base'/path).read_text();new=old
 for before,after in changes:
  assert new.count(before)==1,'base drift '+name+' '+before[:70];new=new.replace(before,after,1)
 (R/'patches'/name).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
write('effects.patch','Source/battle/effects.lua',[
 ('function BattleEffects:init(battle)','-- Captivate-only Oblivious dependency; Attract producer remains explicitly pending.\nhandlers[12],handlers[17],handlers[38],handlers[79]={},{},{},{}\nfunction BattleEffects:init(battle)'),
 ('function BattleEffects:canAttempt(move,attacker,defender)\n','''function BattleEffects:canAttempt(move,attacker,defender)
    if move.attemptRule=="oppositeSex" then
        -- GenV TryHit ability immunity precedes move-specific sex immunity.
        if ability(defender)==12 then return false,"oblivious" end
        local a,d=attacker:getSex(),defender:getSex()
        if a=="genderless" or d=="genderless" or a==d then return false,"sex" end
    end
'''),
 ('''function BattleEffects:basePower(move,power)
    if self.weather and move.sandWeakened then return math.max(1,round(power,2048)) end
    return power
end''','''function BattleEffects:basePower(move,power,attacker,defender)
    attacker,defender=attacker or self.battle.attacker,defender or self.battle.defender
    local ratio=4096
    if self.weather and move.sandWeakened then ratio=chain(ratio,2048) end
    if power>0 and attacker and defender and ability(attacker)==79 then
        local a,d=attacker:getSex(),defender:getSex()
        if a~="genderless" and d~="genderless" then ratio=chain(ratio,a==d and 5120 or 3072) end
    end
    if power>0 and ratio~=4096 then return math.max(1,round(power,ratio)) end
    return power
end
-- Shared major-status query; no RNG or changes to persistent stats/status here.
function BattleEffects:statusImmunity(mon,status)
    if ability(mon)==17 and (status=="poison" or status=="badPoison") then return "Immunity" end
end
function BattleEffects:entry(mon)
    if not self:active(mon) or not alive(mon) or not self:statusImmunity(mon,mon.status) then return false end
    mon.status,mon.statusTurns,mon.sleepDuration=nil,0,0
    self.battle.conditions:of(mon).toxic=nil
    self.battle:say(mon.name.."'s Immunity cured its poison!")
    return true
end'''),
 ('''    if ability(target)==9 and receipt.contact and receipt.removed>0 and RulesRNG.random(0,99)<30 then
        if alive(source) and not source.status then
            b:say(target.name .. "'s Static!")
            ApplyStatus({resolve=function() return source end},"paralyze"):apply(b)
        end
    end''','''    local id=ability(target)
    if (id==9 or id==38) and receipt.contact and receipt.removed>0 and RulesRNG.random(0,99)<30 then
        -- Preserve native/Static chance-before-eligibility order, including KO.
        local status=id==9 and "paralyze" or "poison"
        local eligible=status~="poison" or (not has(source,"poison") and not has(source,"steel")
            and not self:statusImmunity(source,status))
        if alive(source) and not source.status and eligible then
            b:say(target.name .. (id==9 and "'s Static!" or "'s Poison Point!"))
            ApplyStatus({resolve=function() return source end},status):apply(b)
        end
    end''')])
write('dsl-status.patch','Source/battle/dsl.lua',[
 ('''    -- Sample before committing durable fields; RNG exhaustion cannot leave an
''','''    local immunity=battle.effects and battle.effects:statusImmunity(pokemon,self.status)
    if immunity then battle:say(pokemon.name.." is protected by "..immunity.."!");return end
    -- Sample before committing durable fields; RNG exhaustion cannot leave an
''')])
write('conditions-status.patch','Source/battle/conditions.lua',[
 ('''elseif not has(mon,"steel") and not mon.status then''','''elseif not has(mon,"steel") and not mon.status
                        and not (b.effects and b.effects:statusImmunity(mon,"poison")) then''')])
write('battle-entry-message.patch','Source/battle/battle.lua',[
 ('''        if not self.player:isAlive() then return self:hasUsablePlayer() and "forcedSwitch" or "defeat" end''','''        self.effects:entry(self.player)
        self.effects:entry(self.enemy)
        if not self.player:isAlive() then return self:hasUsablePlayer() and "forcedSwitch" or "defeat" end'''),
 ('''        self.conditions:entry(chosen,"player")''','''        self.conditions:entry(chosen,"player")
        self.effects:entry(chosen)'''),
 ('''            self.conditions:entry(self.enemy,"enemy")''','''            self.conditions:entry(self.enemy,"enemy")
            self.effects:entry(self.enemy)'''),
 ('''    if not self.effects:canAttempt(move,attacker,defender) then
        self:say("But it failed!")''','''    local permitted,attemptReason=self.effects:canAttempt(move,attacker,defender)
    if not permitted then
        self:say(attemptReason=="oblivious" and (defender.name.." is protected by Oblivious!") or "But it failed!")''')])

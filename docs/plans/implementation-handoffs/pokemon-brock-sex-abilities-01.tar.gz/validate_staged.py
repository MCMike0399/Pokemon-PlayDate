#!/usr/bin/env python3
"""Patch-only private SDK adapter. No execution unless root passes --execute."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__)
for name in ('project','output'):p.add_argument('--'+name,required=True)
p.add_argument('--with-own-tempo',action='store_true');p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--traits-stage',type=Path);p.add_argument('--engine-stage',type=Path);p.add_argument('--moves',type=Path);a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'manifest.json').read_text());original=harness.prepare

def verified(path,sha):
 assert hashlib.sha256(path.read_bytes()).hexdigest()==sha,'dependency drift '+str(path)
def patch(output,path):
 header=next(line[4:]for line in path.read_text().splitlines()if line.startswith('--- '))
 assert header.startswith(('Source/','a/Source/')),'unexpected patch root '+header
 prefix=['-p0']if header.startswith('Source/')else[]
 result=subprocess.run(['git','apply',*prefix,'--check',str(path)],cwd=output,capture_output=True)
 if result.returncode:
  reverse=subprocess.run(['git','apply',*prefix,'--reverse','--check',str(path)],cwd=output,capture_output=True)
  assert reverse.returncode==0,'review patch conflict '+str(path)+' '+result.stderr.decode();return
 subprocess.run(['git','apply',*prefix,str(path)],cwd=output,check=True)
def prepare(project,sdk,output,session):
 metadata=original(project,sdk,output,session);dependencies={}
 if a.traits_stage:
  raw=(a.traits_stage/'manifest.json').read_bytes();verified(a.traits_stage/'manifest.json',manifest['dependencies']['traits_manifest_sha256']);traits=json.loads(raw)
  for row in traits['source_files']:
   src=a.traits_stage/row['path'];verified(src,row['sha256']);dst=output/row['path'];base=a.traits_stage/'base'/row['path'];dst.parent.mkdir(parents=True,exist_ok=True)
   current=hashlib.sha256(dst.read_bytes()).hexdigest()if dst.exists()else None
   if current in (row['base_sha256'],row['sha256']):shutil.copy2(src,dst)
   elif base.exists():
    result=subprocess.run(['git','merge-file','-p',str(src),str(base),str(dst)],capture_output=True);assert result.returncode==0,'traits dependency merge '+row['path'];dst.write_bytes(result.stdout)
   else:raise ValueError('traits dependency collision '+row['path'])
  for hook in traits['hooks']:
   # Effects may next be replaced by explicitly supplied frozen engine; reapply below.
   if not (a.engine_stage and hook['path']=='Source/battle/effects.lua'):patch(output,a.traits_stage/hook['patch'])
  main=output/'Source/main.lua';text=main.read_text()
  if 'import "data/lightBall"'not in text:text=text.replace('import "data/items"','import "data/items"\nimport "data/lightBall"',1)
  if 'import "dev/traitContracts"'not in text:text=text.replace('import "dev/catalog"','import "dev/traitContracts"\nContracts.register("specimen-sex-light-ball",TraitContracts.run)\nimport "dev/catalog"',1)
  main.write_text(text);dependencies['traits']=traits
 if a.engine_stage:
  verified(a.engine_stage/'foundation-manifest.json',manifest['dependencies']['engine_manifest_sha256']);engine=json.loads((a.engine_stage/'foundation-manifest.json').read_text())
  for row in engine['source_files']:
   if row['path']not in ('Source/battle/battle.lua','Source/battle/conditions.lua','Source/battle/effects.lua','Source/dev/bideContracts.lua'):continue
   src=a.engine_stage/row['path'];verified(src,row['sha256']);dst=output/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  for row in engine['metadata_count_patches']:
   verified(a.engine_stage/row['patch'],row['patch_sha256']);patch(output,a.engine_stage/row['patch'])
  if a.traits_stage:patch(output,a.traits_stage/'patches/light-ball-effects.patch')
  main=output/'Source/main.lua';text=main.read_text()
  if 'import "dev/bideContracts"'not in text:text=text.replace('import "dev/catalog"','import "dev/bideContracts"\nContracts.register("bide",BideContracts.run)\nimport "dev/catalog"',1)
  main.write_text(text);dependencies['engine']=engine
 if a.moves:
  verified(a.moves,manifest['dependencies']['producer_sha256']);shutil.copy2(a.moves,output/'Source/battle/moves.lua')
 assert 'function Pokemon:getSex()'in(output/'Source/data/pokemon.lua').read_text(),'requires real frozen traits model'
 assert 'canAttempt' in(output/'Source/battle/effects.lua').read_text(),'requires batch01 canAttempt owner'
 assert 'attacker,defender)'in(output/'Source/battle/battle.lua').read_text(),'requires explicit context engine owner'
 for row in manifest['patches']:
  path=stage/row['path'];verified(path,row['sha256']);patch(output,path)
 if a.with_own_tempo:
  for row in manifest['optional_own_tempo']['patches']:
   path=stage/row['path'];verified(path,row['sha256']);patch(output,path)
 source_files=manifest['source_files']+(manifest['optional_own_tempo']['source_files']if a.with_own_tempo else[])
 for row in source_files:
  path=stage/row['path'];verified(path,row['sha256']);shutil.copy2(path,output/row['path'])
 main=output/'Source/main.lua';text=main.read_text();anchor='import "dev/catalog"';assert text.count(anchor)==1
 if 'import "dev/sexAbilityContracts"'not in text:text=text.replace(anchor,'import "dev/sexAbilityContracts"\nContracts.register("sex-abilities",SexAbilityContracts.run)\n'+anchor,1)
 if a.with_own_tempo and 'import "dev/ownTempoContracts"'not in text:text=text.replace(anchor,'import "dev/ownTempoContracts"\nContracts.register("own-tempo",OwnTempoContracts.run)\n'+anchor,1)
 main.write_text(text)
 info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted((output/'Source').rglob('*'))if x.is_file()and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
 info.write_text(generated);values=[]
 for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
  v=metadata[key];values.append('    '+key+' = '+('true'if v is True else json.dumps(v,ensure_ascii=False))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n');metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['sex_abilities']=manifest;metadata['explicit_foundation_dependencies']=dependencies
 with(output/'sex-abilities-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'contracts.json'),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=2400))
finally:harness.prepare=original
raise SystemExit(code)

# Pre-Brock sex/status abilities candidate — staged only

Root owns integration, Simulator, Data and native acceptance. No live Source or world content was edited. Frozen traits01 remains unchanged. This candidate ships **two new dev suites and narrow patch files**, never replacement shared battle modules; base/Source files are read-only contextual test fixtures and are not overlay candidates.

`manifest.json`: core29 authored SDK groups, optional Own Tempo6 groups. All are unrun by this worker. Compile-only proof03 passed for core; proof04 passed with optional20 using explicit frozen traits01/Bide/V5 dependencies. `host-tests.log`: five portable source/composition/mutation groups passed. `source-proof.json`: eleven actual immutable C/Showdown input pins verified and literal mechanics independently read. These are preparation evidence, not runtime completion.

## Interfaces and merge order

1. Root's V5 generated moves candidate is the dependency, SHA256 `c52fe6187a112fab18520899ffb594404941cb2ffae27cc3e6301c5ce94df61f`. Captivate adds only `attemptRule='oppositeSex'`; target11, accuracy100, PP20 and original `ModifyStat(DEFENDER,'spa',-2)` remain exact. `generator-request.json` records the approved request. No generator/data rewrite authored here.
2. `patches/effects.patch`: extend existing pure canAttempt; basePower accepts explicit attacker/defender, preserving Bide's pass-through and fallback direction for old callers. Add typed statusImmunity and active entry cure; generalize actual Static contact receipt for Poison Point while preserving Static output/eligibility/RNG order.
3. `patches/dsl-status.patch`: shared major-status immunity query after existing status/type checks, before any duration/commit. `patches/conditions-status.patch`: existing Toxic Spikes also uses the same query; no bypass through its direct assignment, no false poisoned state.
4. `patches/battle-entry-message.patch`: real initial/player-switch/enemy-replacement entry calls; typed Oblivious failure text. Existing entry/hazard/learning/receipt owners remain in place. No new input or frame callback.
5. Optional `patches/own-tempo-effects.patch`, then `own-tempo-dsl.patch`, applied after core. Query statusImmunity(mon,'confuse') returns Own Tempo; existing confuse branch checks it before duration RNG. Entry cure clears only confusion, preserving major status. This is the shared charge/rampage owner's dependency: fatigue continues through actual ApplyStatus(ATTACKER,'confuse'). No copied Effects file, no Gen8 Intimidate immunity.

Root registers SexAbilityContracts.run and optionally OwnTempoContracts.run. Reports use exact `{ok,passed,failed,tests:[{name,ok,error}]}`. Existing suites remain registered. Core source is original16/seen/Focus +frozen batch01/Bide, plus real frozen sex model; no fake SDK or replacement Pokemon objects.

Default compile helper uses the receiving project's already integrated foundation. For explicit dependency composition before root integrates:

```sh
python validate_staged.py --project /project --output /unique/build \
  --traits-stage /path/to/frozen-traits01 --engine-stage /path/to/frozen-bide01 \
  --moves /path/to/root-V5/Source/battle/moves.lua --with-own-tempo
```

The optional stage flags verify manifest and source hashes and record exact composed dependencies. Bide's explicit two metadata-count patches are applied as qualified425-row updates, preserving old assertions; no unrelated count waiver. The receiving current Source is copied first by the identified harness. Helpers only compile unless **root** passes `--execute`. On integrated Source, ordinary harness scenarios can run directly; changed/shared patch contexts fail honestly for serial review.

## Mechanics and evidence

Captivate: actual opposite non-genderless sexes, both directions; same/genderless fails after attempted PP but before accuracy. GenV order is type guard → TryHit ability immunity → move TryImmunity → accuracy. Oblivious blocks Captivate first, even when sexes also fail; no modern Taunt immunity. Existing SpA-2 payload remains the only successful effect. Actual command contracts check both success directions, miss, failure, PP and exact isolated RNG count.

Rivalry79: use Pokemon:getSex(), never name/species inference. Q12 factor5120 same/3072 opposite/4096 if either genderless. Apply at **base power**, combined with weather ratio once; no durable Attack/SpAttack change. Explicit actor/target works even when Battle's current direction is opposite. Literal40→50/30/40; actual Tackle command against equal-stat male/female Charmander produces34/21 at known3-roll seed14. Fixed-power0 payloads remain outside the modifier. Old weather half-power behavior remains for non-Rivalry. The charge owner replaces only the old weather membership condition with its GenV solar policy; retain ratio=chain(...), not a separate early rounded return.

Poison Point38: native30% on actual contact HP-removal receipts, one-shot and per landed hit; includes defender KO before terminal handling. Preserve Static's chance-before-eligibility order: already-status, Poison/Steel types, Immunity17 and fainted source may consume the eligible contact chance without receiving poison. Noncontact/zero damage/miss/replayed/forged receipts do not consume reaction RNG. No physical-category heuristic, Shield Dust does not suppress contact reactions, and inflicted poison activates existing Guts without altering stored stats. Boundary29 succeeds/30 fails; actual two-hit contact uses7 samples including per-hit damage/reaction.

Immunity17: shared prevention for poison/badPoison and real entry cure; clears toxic counter, statusTurns/sleepDuration0, no RNG. Actual Toxic command spends PP/accuracy before status prevention. Poison/Steel remain type immune; Dark remains ordinarily eligible. Sleep/burn paths remain unchanged. Tests exercise initial, voluntary, forced and real enemy replacement entry plus both Toxic Spikes layers. No new wild availability is invented for Snorlax/Slowpoke.

Optional Own Tempo20: source-correct confusion prevention before duration sampling and active cure, no change to major status or Attack-drop eligibility. Real Confuse Ray consumes accuracy/PP but no confusion duration RNG against canonical Slowpoke slot2. Oblivious slot1 remains confusion-eligible. Native C uses confusion condition6; PS Gen7 override removes modern Intimidate immunity for GenV. Charge owner separately proves actual fatigue integration; this packet does not replace its rampage lifecycle.

Pins/immutable URLs are in source-manifest.json. Source audit replays actual C handlers and PS base→Gen8→Gen7→Gen6→Gen5 overrides, allowing only rating-only inherited overrides for unchanged handlers. C HandlerCaptivate checks gender2/same; HandlerRivalry multiplies power0x31; CommonContactStatusAbility samples contact chance before queued status add; Immunity/OwnTempo status guards/cures are explicit. No moving-master source or approximate percentages.

## Root native recipes and remaining bounds

Four real-input supplemental scenarios are authored under scenarios/ (unexecuted), with explicit required PNG names. They use legal known-slot fixtures: NidoranF43 learns Captivate in slot4; Gastly19 knows Confuse Ray in slot4. Opposite/same fixed Nidoran sexes and canonical Slowpoke slots need no invented sex fixture. Each acknowledges the two actual trainer-intro messages, then selects actual FIGHT/slot4, spends one PP, advances one message and captures at the semantic effect/immunity before enemy action. They are labelled controlled fixtures, not world acquisition. OwnTempo scenario requires the optional patch. Root must inspect phase/PP/stage/ability text and native files, not treat absence of an image as success. Screenshot output paths use normal harness shot protocol.

Run SDK all suites with helper --execute after review, then each scenario with --scenario; root alone runs Simulator. Record snapshots/traces and actual captures. Existing normal16 suites must still pass, plus all new groups; any shared future charge merge should rerun pure power-context and status-duration cases.

Oblivious is **Captivate-context coverage**, not a claim that the currently unsupported Attract producer/infatuation lifecycle is complete. Full ability111 completion counts stay root-owned after actual acceptance. Ability suppression/copy/Mold Breaker and later held/field effects remain explicit dependencies; no Worry Seed/Insomnia work is added. Substitute/other unsupported hit producers are not certified by following existing actual receipt hooks. World maps/story/art/roster/GenV base stats and durable save schema are unchanged in this packet.

# Field fixture erratum 02

Native failure is a fixture encoding error, not field policy. SessionCodec.encode declares pokemonEncoding=decimal-counters-v1 and serializes XP/nextMoveChoiceId/choice IDs as decimal strings through its public SessionCodec.encodePokemon seam. The test replaced an already encoded member with raw PokemonCodec.encode numeric counters; SessionCodec.pokemonFromWire correctly rejected those numbers as invalid-integer-text before testing the level10 reserve.

One expression now calls SessionCodec.encodePokemon(replacement). All fainted physical lead, ability51, active reserve index2, exact levels5/10, encounter-vs-suppression assertions remain unchanged. No production changes, codec relaxation, geometry/RNG changes or test deletion. Root must apply only the enclosed hunk against the recorded baseSHA and rerun actual SDK. No native pass claimed here.

import hashlib,importlib.util,json,unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]
def module(name):
 spec=importlib.util.spec_from_file_location(name,P/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
class References(unittest.TestCase):
 def test_pinned_primary_c_bytes(self):
  pin=json.loads((P/'b2w2-pin.json').read_text())
  for rel,expected in pin['files'].items():
   data=(P/'references'/rel).read_bytes();self.assertEqual(hashlib.sha256(data).hexdigest(),expected['sha256']);self.assertEqual(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),expected['git_blob_sha1'])
 def test_personal_data_and_parser_pin(self):
  pin=json.loads((P/'personal-pin.json').read_text())
  for rel,expected in pin['files'].items():self.assertEqual(hashlib.sha256((P/'references'/rel).read_bytes()).hexdigest(),expected['sha256'])
 def test_literal_primary_c_stat_vectors(self):self.assertEqual(module('reference_vectors').oracle()['vectors'],10)
 def test_literal_primary_c_ev_cap_vectors(self):self.assertEqual(module('effort_vectors').oracle()['vectors'],7)
 def test_all_151_yields_and_independent_literal_encounter_foes(self):
  rows=json.loads((P/'species151.json').read_text())['species'];self.assertEqual([r['dex']for r in rows],list(range(1,152)))
  raw=(P/'references/personal_b2w2').read_bytes()
  for r in rows:
   rec=raw[r['dex']*76:(r['dex']+1)*76];packed=int.from_bytes(rec[10:12],'little')
   self.assertEqual(r['ev_yield'],[(packed>>shift)&3 for shift in [0,2,4,8,10,6]]);self.assertEqual(len(r['ev_yield']),6);self.assertTrue(1<=sum(r['ev_yield'])<=3)
  literal={1:[0,0,0,1,0,0],4:[0,0,0,0,0,1],7:[0,0,1,0,0,0],10:[1,0,0,0,0,0],11:[0,0,2,0,0,0],13:[0,0,0,0,0,1],14:[0,0,2,0,0,0],16:[0,0,0,0,0,1],19:[0,0,0,0,0,1],25:[0,0,0,0,0,2],27:[0,0,1,0,0,0],50:[0,0,0,0,0,1],74:[0,0,1,0,0,0],95:[0,0,1,0,0,0],151:[3,0,0,0,0,0]}
  for dex,expected in literal.items():self.assertEqual(rows[dex-1]['ev_yield'],expected)
 def test_blue_fixed_trainer_source_constants(self):
  pin=json.loads((P/'blue-pin.json').read_text())
  for rel,expected in pin['files'].items():self.assertEqual(hashlib.sha256((P/'references/blue'/rel).read_bytes()).hexdigest(),expected)
  text=(P/'references/blue/constants/battle_constants.asm').read_text();self.assertIn('ATKDEFDV_TRAINER EQU $98',text);self.assertIn('SPDSPCDV_TRAINER EQU $88',text)
if __name__=='__main__':unittest.main()

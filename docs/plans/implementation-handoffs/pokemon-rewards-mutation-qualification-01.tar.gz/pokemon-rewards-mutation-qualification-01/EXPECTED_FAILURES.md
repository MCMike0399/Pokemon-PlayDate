# Named mutation expectations (native unrun)

Each run is a fresh identified standard owner-runner build/session. Control must pass before kills count. A mutant kill requires the named semantic test failure, never a compile/startup/artifact failure. All ten frozen B mutants retained unchanged. Additional guard is qualification-only, not a production interface.

| Mutant | Required named failure (substring in SDK report) |
|---|---|
| split-ev | one through six actual conscious participants each receive full unsplit yield |
| exclude100 | Lv100 receives full EV with zeroXP and remains in literal49 XP split denominator |
| repeat-foe | duplicate foe and foreign plan commits never duplicate reward or consume foreign plan |
| early-live | no-level EV changes keep live HP defense speed through next actual foe |
| xp-before-ev | level-up recomputes from EV already allocated before next foe and typed learning |
| live-preflight | invalid second recipient choice exhaustion leaves first marker owners and both streams untouched |
| total511 | pure EV addition obeys255/510 source stat order and input ownership |
| wrong-order | pure EV addition obeys255/510 source stat order and input ownership |
| no-hud-hold | HUD holds before vitals through gained message then releases before grew message |
| no-return-flush | emitEnd flushes before same-owned evolution callback and cannot flush twice |
| condition-early-xp | native condition boundary: no early level-heal before later poisoned member; native condition boundary: no early XP/EV to later-fainted no-level participant (both required) |
| condition-poison-only | enemy poison waits through later player burn when both teams retain reserves |
| condition-no-early-matchup | terminal matchup breaks BETWEEN cohorts before later burn without blanket deferral |
| condition-first-faint-wins | same-cohort last newly-fainted side retains existing winner and blackout policy |
| no-immediate-cleanup | immediate faint cleanup precedes announcement without awarding before condition checkpoint |
| direct-blanket-defer | direct move reward and learning retain immediate checkpoint before later poison |
| weather-blanket-defer | complete weather cohort remains immediate and excludes both sand-fainted actives |

The immediate cleanup guard observes actual faint narration before later trap callback can conceal delayed cleanup. It checks dead-member state, source trap and effective ability override removal plus no premature award. Strict original two expectations remain unchanged in frozen correction. Each fault changes only an exact production anchor in its own staged Source; no altered expectations or mocked outcomes.

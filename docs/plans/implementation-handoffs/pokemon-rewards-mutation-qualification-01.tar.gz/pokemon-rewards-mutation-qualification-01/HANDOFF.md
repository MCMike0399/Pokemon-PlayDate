# Frozen mutation qualification erratum 01

Frozen B/correction unchanged. This wrapper imports the frozen B validator in memory, composes its exact guarded hunks, then the two separately frozen SDK fixture repairs, and adds one qualification-only SDK observation group. Existing root code, main imports and standard runner lifecycle remain retained. No API expansion. The separate HUD recipe erratum is not used by contracts qualification.

Compile control:
`python3 /private/tmp/pokemon-rewards-mutation-qualification-01/validate_staged.py --project /private/tmp/pokemon-reward-input-base-01 --output /private/tmp/UNIQUE-control`

Root-only native: append `--execute`; mutants append `--mutation NAME` from EXPECTED_FAILURES.md, each with unique output. Seventeen mutants plus control. Root executes serially. Source/build/session/request/PID evidence comes from the existing owner runner; qualification-packet.json records immutable parent/erratum manifest identities. Output build.json retains actual mutation, source/compiled hashes and both frozen parent manifests. No native kill/device claim from compile. Require control success and exact named failure for each mutant; retain every failed output.

Shared files are changed only inside the identified staged build. No liveSource, frozen packet, Simulator or SDKData touched. Guard tests actual Battle/Party/Pokemon/Codec and faint script yield, with no field/world setup. New test restores rules stream and closes its actual battle. All held/growth/condition tests remain unmodified except the separately reviewed two SDK errata.

Identified immutable pre-B project: /private/tmp/pokemon-reward-input-base-01, SourceSHA0d88392102725cd82a58ff82d71216b2e5dc6f3462be64c074a3f1066707e90b (A+Roost+PF12). Do not use changing integration03 after B application.

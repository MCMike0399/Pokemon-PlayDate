#!/usr/bin/env python3
"""Root-only native execution; default is compile-only. Frozen parents unchanged."""
import hashlib,importlib.util,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent
B=Path('/private/tmp/pokemon-rewards-b-01');C=Path('/private/tmp/pokemon-residual-reward-correction-01');E=Path('/private/tmp/pokemon-rewards-fixture-erratum-01')
spec=importlib.util.spec_from_file_location('frozen_reward_validator',B/'validate_staged.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.MUTATIONS.update({
 'condition-early-xp':('Source/battle/battle.lua','local last,changed=self:_registerFaints(event.side)','local last,changed=self:handleFaint(event.side)'),
 'condition-poison-only':('Source/battle/battle.lua','event.order<=25','event.order<=9'),
 'condition-no-early-matchup':('Source/battle/battle.lua','if cohortEnd and (stageEnd or not self:hasUsablePlayer()or not self:hasUsableEnemy())then','if cohortEnd and stageEnd then'),
 'condition-first-faint-wins':('Source/battle/battle.lua','if changed then conditionFaint=last end','if changed and not conditionFaint then conditionFaint=last end'),
 'no-immediate-cleanup':('Source/battle/battle.lua','if not self.enemy:isAlive() then self.conditions:clear(self.enemy);self.effects:clear(self.enemy) end','if not self.enemy:isAlive() then self.effects:clear(self.enemy) end'),
 'direct-blanket-defer':('Source/battle/battle.lua','    return self:_resolveFaintCheckpoint(last)','    return "replacement" -- mutant: direct checkpoint omitted'),
 'weather-blanket-defer':('Source/battle/battle.lua','local outcome=self:handleFaint(weatherFaint);weatherFaint=nil','local last,changed=self:_registerFaints(weatherFaint);conditionFaint=changed and last or conditionFaint;weatherFaint=nil;local outcome="replacement"'),
})
original=m.apply_hunks
def apply(root,items):
 original(root,items)
 if any('_registerFaints' in h['new'] for i in items for h in i['hunks']):
  for packet in (P,E):
   manifest=json.loads((packet/'manifest.json').read_text())
   for rel,digest in manifest['files'].items():assert hashlib.sha256((packet/rel).read_bytes()).hexdigest()==digest,'erratum changed: '+rel
  original(root,json.loads((E/'shared-hunks.json').read_text())[:2])
  rel='Source/dev/rewardFaultGuards.lua';dest=root/rel;assert not dest.exists();dest.write_bytes((P/rel).read_bytes())
  main=root/'Source/main.lua';text=main.read_text();needle='game = GameContext(';assert text.count(needle)==1
  text=text.replace(needle,'import "dev/rewardFaultGuards"\nContracts.register("reward-fault-guards",RewardFaultGuards.run)\n\n'+needle);main.write_text(text)
  (root/'qualification-packet.json').write_text(json.dumps({'packet_sha256':hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),'reward_parent':hashlib.sha256((B/'manifest.json').read_bytes()).hexdigest(),'correction_parent':hashlib.sha256((C/'manifest.json').read_bytes()).hexdigest(),'fixture_erratum':hashlib.sha256((E/'manifest.json').read_bytes()).hexdigest()},indent=2)+'\n')
m.apply_hunks=apply
if __name__=='__main__':
 if '--with-residual'not in sys.argv:sys.argv+=['--with-residual',str(C)]
 raise SystemExit(m.main())

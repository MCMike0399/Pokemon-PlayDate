# Baseline title/save dead-end probe

No production change. Two SDK groups use real private SDK files and production TitleState, GameContext, GameSaves, SaveStore, Player and states. The overworld capture boundary is a real settled Player and registered State; the full native Overworld journey is separate, avoiding destruction of the host global WorldView. Other runtime owners/sprites/world/RNG are restored.

Expected current behavior: NO control passes. Confirmed New Game installs a valid pre_oak session and reaches opening dialog; after closing it the real captureSession succeeds, but Save fails specifically recovery-required. The regression asserts Save succeeds, so current code should report one targeted failure, not a fixture/capture failure. Child can compile but cannot execute SDK by root ownership; root must run this baseline before the fix.

Root command: python3 /private/tmp/pokemon-title-save-baseline-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-03 --output /private/tmp/pokemon-title-save-baseline-sdk-01 --execute

Default omits --execute and only compiles. No fake SDK, no production Data and no primary save file deletion.

-- PRIVATE measurement workload. Idle/manual are passive. Controlled is explicitly
-- debug bootstrap + owner-API lifecycle stress, never real-input acceptance.
ResourceWorkload={}
local completedMaps,battleEntries,battleExits=0,0,0
local providerNames={"Route2","ViridianForestSouthGate","ViridianForest","ViridianForestNorthGate","PewterCity","PewterGym","PewterMart","PewterPokecenter"}
local maps
local function operation(probe,kind,label,fn)
 local began=playdate.getCurrentTimeMilliseconds();fn();local duration=playdate.getCurrentTimeMilliseconds()-began
 probe.operation(kind,label,duration)
end
function ResourceWorkload.beforeFrame(game,frame,probe,cfg)
 if cfg.workload~="controlled"then return end
 if frame==60 then
  operation(probe,"bootstrap","controlled-new-session42-skip-intro",function()
   assert(game:beginNewSession(42));Story.skipIntro(game);game.machine:change("overworld",{respawn=true})
   maps={};local keys={};for _,key in ipairs(zoneList)do keys[#keys+1]=key end;table.sort(keys)
   for _,key in ipairs(keys)do maps[#maps+1]={key=key,id=zoneRegistry[key].stableID,name=key}end
   for _,name in ipairs(providerNames)do local d=PewterSlice.descriptor(name);maps[#maps+1]={key=d.key,id=d.id,name=name}end
   assert(#maps==18,"review available-map inventory before workload")
  end)
 elseif frame>=120 and frame<=1445 and(frame-120)%25==0 then
  local index=(frame-120)//25+1;local d=maps[(index-1)%18+1];local name=d.name
  operation(probe,"map-entry","cycle"..((index-1)//18+1)..":"..name,function()
   switchZone(d.key);game.machine:change("overworld",{respawn=true})
   assert(currentZone.stableID==d.id,"controlled map identity mismatch")
  end);completedMaps=completedMaps+1
 elseif frame==1560 then
  operation(probe,"battle-entry","controlled-real-battle-scene-no-outcome",function()
   game.machine:change("overworld",{respawn=true})
   assert(FieldBattle.start(game,game:getPlayerPokemon(),Pokemon("pidgey",5)))
   assert(game.machine:getCurrent()=="battle")
  end);battleEntries=battleEntries+1
 elseif frame==1680 then
  operation(probe,"battle-exit","cancel-unfinished-battle-owner",function()
   assert(game.machine:getCurrent()=="battle","controlled battle unexpectedly ended")
   -- Exercise real exit cleanup; no victory/capture/XP/outcome is fabricated.
   game.machine:change("overworld",{respawn=true})
  end);battleExits=battleExits+1
 end
end
function ResourceWorkload.snapshot(cfg)
 return {name=cfg.workload,completed_maps=completedMaps,battle_entries=battleEntries,battle_exits=battleExits,
  complete=cfg.workload~="controlled"or(completedMaps==54 and battleEntries==1 and battleExits==1),
  actual_input_acceptance=false,fixture_bootstrap=cfg.workload=="controlled",
  scope=cfg.workload=="controlled"and"three eighteen-map cycles, idle actual Battle/Scene, unfinished-owner exit; no combat outcome"or"passive observation; manual actions require root evidence"}
end

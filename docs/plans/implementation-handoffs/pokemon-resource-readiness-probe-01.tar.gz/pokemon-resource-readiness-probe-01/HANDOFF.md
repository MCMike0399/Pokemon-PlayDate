# Resource readiness probe01 — root-only runtime, compile-only by default

MEASUREMENT/PROPOSAL ONLY; no optimization implementation. Read PROPOSAL.md for exact observations, honest controlled-vs-actual-input scope and suggested review budgets. Baseline is private immutable baseline/ copied from root03 Source7f2f4eda; all source/host bytes guarded. All prior memory-probe01/erratum02 and actual memory02 outputs remain unchanged. No liveSource, Simulator or SDKData touched by worker.

Run host guards:
```
python3 -m unittest discover -s /private/tmp/pokemon-resource-readiness-probe-01/tests -v
```

Compile the matrix (fresh output names, root can later repeat with --execute):
```
python3 /private/tmp/pokemon-resource-readiness-probe-01/probe.py --project /private/tmp/pokemon-resource-readiness-probe-01/baseline --output /private/tmp/UNIQUE-idle-P --mode production --observer milestones --workload idle --frames 600
python3 /private/tmp/pokemon-resource-readiness-probe-01/probe.py --project /private/tmp/pokemon-resource-readiness-probe-01/baseline --output /private/tmp/UNIQUE-controlled-P --mode production --observer milestones --workload controlled --frames 1800 --timeout 120
python3 /private/tmp/pokemon-resource-readiness-probe-01/probe.py --project /private/tmp/pokemon-resource-readiness-probe-01/baseline --output /private/tmp/UNIQUE-controlled-P-imports --mode production --observer imports --workload controlled --frames 1800 --timeout 120
python3 /private/tmp/pokemon-resource-readiness-probe-01/probe.py --project /private/tmp/pokemon-resource-readiness-probe-01/baseline --output /private/tmp/UNIQUE-controlled-H --mode harness --observer milestones --workload controlled --frames 1800 --timeout 120
```

Native root executes SERIAL only under inherited global SDK owner lock, exact Simulator binary/PID, private UUID bundle/Data owner marker, confirmed owned exit/cleanup and stable done barrier. Production verifies actual input functions unchanged, enabled=false and absence of every normal mailbox/trace artifact. Enabled comparison retains ready+trace.jsonl with exact complete monotonic identities. Controlled total54map entries+one actual Battle/Scene+unfinished exit must complete, no fabricated outcomes. Host verification fails missing counters/workload, LRU>2, stale identity, runtime errors, incomplete frames/GC or producer barrier. It does not auto-accept memory thresholds.

After completed native job:
```
python3 /private/tmp/pokemon-resource-readiness-probe-01/tools/resources.py /private/tmp/ROOT-output > /private/tmp/ROOT-resource-report.json
```

Inspect probe-final.png and actual recorded root/zone/state/counters. Root may run separate --workload manual --frames1800 with real physical Simulator input (no synthetic input); action list and native screenshots required before claiming actual route/Save evidence. No same-process measurement is true-process persistence proof. Existing accepted gameplay/restart checks remain mandatory for a future import gate.

Resource counts are not nativebytes/device evidence. Native MallocLog/pool and physical device measurements require separate explicit evidence. No gate/facade/cache rewrite in this packet. Freeze original packet after delivery; any real runtime defect gets a separate erratum.

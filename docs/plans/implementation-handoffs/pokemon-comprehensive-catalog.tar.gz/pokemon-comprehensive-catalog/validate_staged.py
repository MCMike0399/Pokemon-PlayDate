#!/usr/bin/env python3
"""Current-source comprehensive catalog proof. Compile-only unless root --execute."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--project',required=True);parser.add_argument('--output',required=True);parser.add_argument('--sdk');parser.add_argument('--execute',action='store_true');args=parser.parse_args()
project=Path(args.project).resolve();stage=Path(__file__).resolve().parent;sys.path.insert(0,str(project))
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'bridge-manifest.json').read_text());original_prepare=harness.prepare

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def prepare(project,sdk,output,session):
    for row in manifest['files']:
        if not row['path'].startswith('Source/'):continue
        assert sha(stage/row['path'])==row['sha256'],'staged catalog changed'
        target=project/row['path']
        if target.exists():assert sha(target) in (row.get('original_sha256'),row['sha256']),'live owned catalog changed; rebase instead of overwrite'
        else:assert row['operation']=='add'
    assert (project/'Source/game/pewterWorld.lua').is_file(),'integrated provider dependency required'
    metadata=original_prepare(project,sdk,output,session)
    for phase in ('before','after'):
        (output/'frames'/('catalog-invariance-'+phase)).mkdir()
    for row in manifest['files']:
        if row['path'].startswith('Source/'):
            target=output/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/row['path'],target)
    main=output/'Source/main.lua';text=main.read_text();marker='import "dev/catalog"'
    assert text.count(marker)==1 and 'VisualCatalog.write=PewterCatalog.write' not in text,'comprehensive catalog seam overridden'
    additions='\nimport "dev/pewterCatalogExporter"\nPewterCatalogExporter.register()\nimport "dev/comprehensiveCatalogContracts"\nContracts.register("comprehensive-catalog", ComprehensiveCatalogContracts.run)'
    main.write_text(text.replace(marker,marker+additions,1))
    pdx=output/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(p.relative_to(output/'Source')):sha(p) for p in sorted((output/'Source').rglob('*')) if p.is_file() and p.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    pdx.write_text(generated);values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        value=metadata[key];values.append('    '+key+' = '+('true' if value is True else json.dumps(value,ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['comprehensive_catalog']=manifest
    with (output/'comprehensive-build.log').open('w') as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
added=json.loads((stage/'expected-added.json').read_text())
required=['catalog-invariance-'+phase+'/'+name for phase in ('before','after') for name in added]
scenario=stage/'scenario.json';atomic_json(scenario,{'requests':[['contracts'],['catalog'],['shot comprehensive-catalog']],'outputs':['comprehensive-catalog.png']+required})
try:result=harness.run(SimpleNamespace(sdk=args.sdk,output=args.output,scenario=str(scenario),commands=[],build_only=not args.execute,timeout=60,ready_timeout=20,max_frames=1800))
finally:harness.prepare=original_prepare
if args.execute and result==0:
    output=Path(args.output).resolve()
    def checked_reports(value):
        if isinstance(value,dict):
            if isinstance(value.get('tests'),list) and (value.get('failed',0)>0 or value.get('ok') is False):
                raise RuntimeError('native contract failure; retained result evidence required')
            for child in value.values():checked_reports(child)
        elif isinstance(value,list):
            for child in value:checked_reports(child)
    for path in output.glob('*-result.json'):checked_reports(json.loads(path.read_text()))
    for phase in ('before','after'):
        source=output/'runtime-data'/('catalog-invariance-'+phase+'.json')
        report=json.loads(source.read_text())
        assert len(report['images'])==859 and report['image_root']=='.','native invariance manifest incomplete'
        directory=output/'frames'/('catalog-invariance-'+phase)
        assert {row['path'] for row in report['images']}==set(added),'native invariance inventory differs'
        atomic_json(directory/'catalog.json',report)
    from tools.visual.compare import compare_catalog
    comparison=compare_catalog(output/'frames/catalog-invariance-before',output/'frames/catalog-invariance-after')
    atomic_json(output/'catalog-invariance-comparison.json',comparison)
    if not comparison['equal']:raise RuntimeError('native before/after RGBA/mask comparison failed')
raise SystemExit(result)

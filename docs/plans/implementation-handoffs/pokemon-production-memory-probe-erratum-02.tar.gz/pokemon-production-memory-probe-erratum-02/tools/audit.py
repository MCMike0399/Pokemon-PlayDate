"""Read-only startup import inventory; no Lua execution or claimed heap estimate."""
import argparse,hashlib,json,re
from pathlib import Path

def audit(project):
 source=project/'Source';text=(source/'main.lua').read_text();imports=[];registers=[]
 for line_no,line in enumerate(text.splitlines(),1):
  match=re.fullmatch(r'import "([^"]+)"',line)
  if match:
   name=match[1];file=source/(name+'.lua');entry={'line':line_no,'module':name,'kind':'dev'if name.startswith('dev/')else'sdk'if name.startswith('CoreLibs/')else'game'}
   if file.is_file():entry.update(source_bytes=file.stat().st_size,sha256=hashlib.sha256(file.read_bytes()).hexdigest())
   imports.append(entry)
  if line.startswith('Contracts.register('):registers.append({'line':line_no,'statement':line})
 first_dev=next(x['line']for x in imports if x['kind']=='dev')
 return {'schema':1,'main_sha256':hashlib.sha256((source/'main.lua').read_bytes()).hexdigest(),'imports':imports,'contract_registration_statements':registers,
         'counts':{'imports':len(imports),'dev_imports':sum(x['kind']=='dev'for x in imports),'contract_registrations':len(registers),'direct_dev_lua_bytes':sum(x.get('source_bytes',0)for x in imports if x['kind']=='dev')},
         'game_imports_after_first_dev':[x for x in imports if x['kind']=='game'and x['line']>first_dev],
         'interpretation':'Static source bytes/counts only. Not compiled-prototype retention, heap, native allocation or device capacity.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);a=p.parse_args();print(json.dumps(audit(a.project),indent=2))

#!/usr/bin/env python3
"""Compare completed passive probe runs of ONE unchanged game source baseline."""
import argparse,json
from pathlib import Path

def compare(paths):
 out=[];base=None;identities=set()
 for path in paths:
  build=json.loads((path/'build.json').read_text());outcome=json.loads((path/'outcome.json').read_text());summary=json.loads((path/'summary.json').read_text())
  if outcome.get('ok')is not True:raise RuntimeError('probe run did not succeed: '+str(path))
  identity=build['session_id']
  if identity in identities:raise RuntimeError('same runtime reused as independent measurement')
  identities.add(identity)
  if base is None:base=build['base_source_sha256']
  if base!=build['base_source_sha256']:raise RuntimeError('baseline Source changed between observer comparisons')
  if summary['run_id']!=identity or outcome['run_id']!=identity or summary['build_id']!=build['build_id']:raise RuntimeError('stale/mismatched probe summary')
  data=json.loads((path/'runtime-data/probe-report.json').read_text());samples={s['label']:s for s in data['samples']}
  gc=summary['gc_observations'];work=summary['work'];runtime=json.loads((path/'runtime.json').read_text())
  out.append({'output':str(path),'mode':build['mode'],'observer':build['observer'],'run_id':identity,'pid':runtime['pid'],
      'startup_elapsed_ms':summary['startup_ready']['elapsed_ms'],'startup_wall_seconds':runtime.get('ready_wall_seconds'),
      'first_measured_steady_heap_kib':samples['steady-frame-1']['lua_heap_kib'],'steady_before_full_gc_kib':gc['frame300-full-gc:before']['lua_heap_kib'],
      'frame300_after_full_gc_kib':gc['frame300-full-gc:after']['lua_heap_kib'],'final_after_full_gc_kib':gc['final-full-gc:after']['lua_heap_kib'],
      'sampled_peak_kib':summary['observed_samples_peak_kib'],'mean_instrumented_update_work_ms':work['total_ms']/work['count'],
      'observer_calibration':summary['observer_calibration']})
 return {'schema':1,'base_source_sha256':base,'runs':out,'claim':'Instrumented Simulator Lua heap/work only, no production-device/native-malloc/true-peak inference. No fix or release approval implied.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('outputs',type=Path,nargs='+');a=p.parse_args();print(json.dumps(compare(a.outputs),indent=2))

-- Passive, private Simulator-only measurement. Never imports or calls Autopilot,
-- reads requests, changes inputs/game data, changes GC policy, or seeds RNG.
ProductionProbe={done=false}
local cfg=ProductionProbeBuild
assert(cfg and cfg.enabled and playdate.isSimulator,"private Simulator production probe only")
local clock=playdate.getCurrentTimeMilliseconds
local rows={};local frame=0;local started=clock();local sampleCount=0;local initialInput={}
local work={count=0,total_ms=0,min_ms=nil,max_ms=0,histogram={}};local frameStarted,lastFrame
local function sample(label)
    local value={label=label,elapsed_ms=clock()-started,lua_heap_kib=collectgarbage("count"),frame=frame}
    sampleCount=sampleCount+1;rows[#rows+1]=value;return value
end
local function identity()
    return {version=1,run_id=cfg.run_id,build_id=cfg.build_id,mode=cfg.mode,observer=cfg.observer,sdk_version=cfg.sdk_version,
        bundle_id=cfg.bundle_id,simulator=not not playdate.isSimulator,lua_heap_only=true,native_malloc_observed=false,clock_resolution_ms=1}
end
local function write(name,value)
    local temporary=name..".tmp";local bytes=json.encode(value);local file=assert(playdate.file.open(temporary,playdate.file.kFileWrite))
    assert(file:write(bytes)==#bytes);file:flush();file:close();assert(playdate.file.rename(temporary,name))
end
function ProductionProbe.mark(label)return sample(label)end
function ProductionProbe.importMark(label)
    if cfg.observer=="imports"then return sample(label)end
end
function ProductionProbe.inputBaseline()
    for _,key in ipairs({"buttonJustPressed","buttonIsPressed","buttonJustReleased"})do initialInput[key]=playdate[key]end
end
local function inputUnchanged()
    for key,value in pairs(initialInput)do if playdate[key]~=value then return false end end;return true
end
local function state(game)
    local p=game.player
    return {root=game.machine:getCurrent(),stack=game.machine:stackNames(),zone_id=currentZone and currentZone.stableID,
        player=p and {x=p.gridX,y=p.gridY,facing=p.facing,moving=p.isMoving,moveFrames=p.moveFrames}or {},
        party_count=game.session:party():count(),inventory_count=game.session:inventory():count(),money=game.session:inventory():money(),
        pc_potion=game.session:itemStorage():quantity("potion"),rules_rng=game.session:rngData(),world_rng=game.session:worldRngData(),
        harness_enabled=HarnessBuild.enabled,input_functions_unchanged=inputUnchanged(),
        contract_globals=Contracts~=nil,catalog_globals=VisualCatalog~=nil,fixtures_reset_loaded=HarnessFixtures and type(HarnessFixtures.reset)=="function"or false,
        autopilot_frame_loaded=Autopilot and type(Autopilot.beginFrame)=="function"or false,
        sprite_count=playdate.graphics.sprite.spriteCount(),tile_count=WorldTiles:maxID(),registered_zone_count=#zoneList}
end
function ProductionProbe.ready(game)
    local ready=sample("startup-ready-before-publication");ready.state=state(game)
    local packet=identity();packet.samples=rows;packet.sample_count=#rows
    write("probe-startup.json",packet)
    rows={} -- Startup observer records are not intentionally retained in steady state.
    local publication=identity();publication.ready=true;publication.harness_enabled=HarnessBuild.enabled
    publication.input_functions_unchanged=inputUnchanged();publication.startup_elapsed_ms=clock()-started
    publication.heap_after_startup_publication_kib=collectgarbage("count")
    write("probe-ready.json",publication)
end
function ProductionProbe.beginFrame()
    frameStarted=clock()
    if lastFrame then work.last_period_ms=frameStarted-lastFrame end
    lastFrame=frameStarted
end
local function fullGC(label)
    sample(label..":before");local began=clock();collectgarbage("collect");local duration=clock()-began
    local after=sample(label..":after");after.explicit_full_gc_ms=duration
end
local function calibrate()
    local runs=512;local t=clock()
    for _=1,runs do clock()end
    local clockLoop=clock()-t
    local before=collectgarbage("count");local scratch={};t=clock()
    for i=1,runs do scratch[i]={label="observer-calibration",elapsed_ms=clock()-started,lua_heap_kib=collectgarbage("count"),frame=frame}end
    local elapsed=clock()-t;local delta=collectgarbage("count")-before
    scratch=nil;local gc=clock();collectgarbage("collect");gc=clock()-gc
    return {runs=runs,clock_loop_ms=clockLoop,sample_loop_ms=elapsed,retained_during_loop_delta_kib=delta,
        release_full_gc_ms=gc,heap_after_release_kib=collectgarbage("count"),note="Raw observer calibration, not subtracted from game/device measurements"}
end
function ProductionProbe.afterFrame(game)
    local ending=clock();local elapsed=ending-frameStarted
    frame=frame+1;work.count=work.count+1;work.total_ms=work.total_ms+elapsed
    work.min_ms=work.min_ms and math.min(work.min_ms,elapsed)or elapsed;work.max_ms=math.max(work.max_ms,elapsed)
    work.histogram[tostring(elapsed)]=(work.histogram[tostring(elapsed)]or 0)+1
    local mark=frame==1 or frame==60 or frame==180 or frame==299 or frame==301 or frame==cfg.frames
    if mark then local value=sample("steady-frame-"..frame);value.state=state(game)end
    if frame==300 then fullGC("frame300-full-gc")end
    if frame<cfg.frames then return end
    fullGC("final-full-gc")
    local finalState=state(game);local calibration=calibrate()
    local report=identity();report.samples=rows;report.sample_count=#rows;report.total_observations=sampleCount;report.frames=frame;report.work=work
    report.observer_calibration=calibration;report.final_state=finalState;report.gc_policy_changed=false
    report.claim="Instrumented Simulator Lua heap/timing only; not production-device/native-malloc proof"
    -- Captures occur only AFTER measured heap/timing and observer calibration.
    playdate.simulator.writeToFile(playdate.graphics.getWorkingImage(),cfg.data_dir.."/probe-final.png")
    write("probe-report.json",report)
    ProductionProbe.done=true -- Publication is a stable producer barrier for host verification.
    local complete=identity();complete.complete=true;complete.frames=frame;write("probe-done.json",complete)
end
ProductionProbe.mark("probe-loaded-before-corelibs")

from pathlib import Path
import hashlib,json,importlib.util
p=Path(__file__).parent;base=Path('/private/tmp/pokemon-brock-integration-02')
spec=importlib.util.spec_from_file_location('probe_freeze',p/'probe.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
audit_spec=importlib.util.spec_from_file_location('audit_freeze',p/'tools/audit.py');audit=importlib.util.module_from_spec(audit_spec);audit_spec.loader.exec_module(audit)
(p/'source-audit.json').write_text(json.dumps(audit.audit(base),indent=2)+'\n')
m={'schema':1,'packet':'production-memory-probe-01','base_source_sha256':mod.fingerprint(base,['Source/dev/harness_build.lua']),'base_main_sha256':hashlib.sha256((base/'Source/main.lua').read_bytes()).hexdigest(),'files':{}}
for f in sorted(p.rglob('*')):
 if f.is_file()and f.name!='manifest.json'and'__pycache__'not in f.parts:m['files'][f.relative_to(p).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
(p/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest())

#!/usr/bin/env python3
"""Compile-only by default. Root alone may --execute this passive UUID probe."""
import argparse,difflib,hashlib,importlib.util,json,os,re,shutil,subprocess,sys,time,uuid
from pathlib import Path
STAGE=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def atomic(path,value):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def instrument_main(original):
 lines=[];injected=[];imports=0;first_dev=False
 def put(line):injected.append(len(lines));lines.append(line)
 put('import "dev/production_probe_build"');put('import "dev/productionProbe"')
 source=original.splitlines()
 for number,line in enumerate(source):
  match=re.fullmatch(r'(\s*)import "([^"]+)"',line)
  call=re.fullmatch(r'(\s*)(Contracts\.register\(.*|PewterCatalogExporter\.register\(\))',line)
  special=line.strip()in {'KantoWorld.install(game)','PewterWorld.install(game)','game.saves = GameSaves(game)'}or line.startswith('game = GameContext(')
  if match:
   indent,name=match.groups();imports+=1
   if name.startswith('dev/')and not first_dev:put(indent+'ProductionProbe.mark("before-development-region")');first_dev=True
   if name=='dev/autopilot':put(indent+'ProductionProbe.inputBaseline()')
   put(indent+'ProductionProbe.importMark('+json.dumps('before-import:'+str(imports)+':'+name)+')')
  elif call:put(call[1]+'ProductionProbe.importMark('+json.dumps('before-call:'+line.strip())+')')
  elif special:put('ProductionProbe.mark('+json.dumps('before:'+line.strip())+')')
  lines.append(line)
  if match:put(match[1]+'ProductionProbe.importMark('+json.dumps('after-import:'+str(imports)+':'+match[2])+')')
  elif call:put(call[1]+'ProductionProbe.importMark('+json.dumps('after-call:'+line.strip())+')')
  elif special:put('ProductionProbe.mark('+json.dumps('after:'+line.strip())+')')
  if line.strip()=='game.saves:start()':put('ProductionProbe.mark("after-initial-game-state")')
  if line=='function playdate.update()':put('    if ProductionProbe.done then return end')
  if line.strip()=='if Harness.isQuiescent then return end':put('    ProductionProbe.beginFrame()')
  if number==len(source)-1:
   assert line=='end','review changed playdate.update tail before instrumentation'
   lines.pop();put('    ProductionProbe.afterFrame(game)');lines.append(line);put('ProductionProbe.ready(game)')
 # Exact roundtrip guard: all original lines/order/calls retained verbatim.
 restored=[line for i,line in enumerate(lines)if i not in set(injected)]
 assert restored==source,'instrumentation changed original source'
 return '\n'.join(lines)+'\n',injected

def fingerprint(root,exclude=()):
 h=hashlib.sha256()
 for path in sorted((root/'Source').rglob('*')):
  if path.is_file()and path.relative_to(root).as_posix()not in exclude:
   h.update(path.relative_to(root).as_posix().encode()+b'\0'+path.read_bytes())
 return h.hexdigest()
def lua(value):
 if isinstance(value,bool):return 'true'if value else'false'
 return json.dumps(value,ensure_ascii=False)
def prepare(args,runner):
 manifest_path=STAGE/'manifest.json';manifest=json.loads(manifest_path.read_text())
 for rel,digest in manifest['files'].items():
  if sha(STAGE/rel)!=digest:raise RuntimeError('frozen production probe packet changed: '+rel)
 if fingerprint(Path(args.project).resolve(),['Source/dev/harness_build.lua'])!=manifest['base_source_sha256']:raise RuntimeError('baseline Source changed; review/rebase probe before measurement')
 out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=False);run_id=uuid.uuid4().hex;sdk=runner.sdk_path(args.sdk)
 expected=json.loads((STAGE/'references/sdk.json').read_text())
 if (sdk/'VERSION.txt').read_text().strip()!=expected['sdk_version']or sha(sdk/'Inside Playdate.html')!=expected['documentation_sha256']:raise RuntimeError('installed SDK/docs changed; review probe assumptions before building')
 meta=runner.prepare(Path(args.project).resolve(),sdk,out,run_id)
 meta['probe_packet_sha256']=sha(manifest_path);meta['base_source_sha256']=meta['source_sha256'];meta['base_build_id']=meta['build_id']
 baseline_audit=json.loads((STAGE/'source-audit.json').read_text())
 main=out/'Source/main.lua';original=main.read_text();instrumented,indices=instrument_main(original);main.write_text(instrumented)
 shutil.copyfile(STAGE/'Source/dev/productionProbe.lua',out/'Source/dev/productionProbe.lua')
 (out/'instrumentation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),instrumented.splitlines(True),fromfile='a/Source/main.lua',tofile='b/Source/main.lua')))
 meta.update(mode=args.mode,observer=args.observer,frames=args.frames,enabled=args.mode=='harness',bundle_id='com.poc.pokemon.productionprobe.'+run_id)
 meta['data_dir']=str(sdk/'Disk/Data'/meta['bundle_id']);meta['generated_overlays']=['Source/main.lua','Source/dev/productionProbe.lua','Source/dev/production_probe_build.lua','Source/dev/harness_build.lua','Source/pdxinfo']
 pdx=out/'Source/pdxinfo';pdx.write_text(meta['original_pdxinfo'])
 exclusions=['Source/dev/harness_build.lua','Source/dev/production_probe_build.lua']
 meta['source_sha256']=fingerprint(out,exclusions);meta['source_hash_excludes']=exclusions
 meta['build_id']=meta['revision']+':production-probe:'+meta['source_sha256']
 config={'enabled':True,'mode':args.mode,'observer':args.observer,'frames':args.frames,'run_id':run_id,'build_id':meta['build_id'],'bundle_id':meta['bundle_id'],'data_dir':meta['data_dir'],'sdk_version':meta['sdk_version']}
 (out/'Source/dev/production_probe_build.lua').write_text('ProductionProbeBuild = {\n'+''.join('    '+k+' = '+lua(v)+',\n'for k,v in config.items())+'}\n')
 keys=['protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir']
 (out/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+''.join('    '+k+' = '+lua(meta[k])+',\n'for k in keys)+'}\n')
 pdx.write_text('\n'.join('bundleID='+meta['bundle_id']if line.startswith('bundleID=')else line for line in meta['original_pdxinfo'].splitlines())+'\n')
 meta['compiled_source_sha256']=fingerprint(out);meta['probe']={'version':1,'run_id':run_id,'mailbox_disabled':args.mode=='production','observer':args.observer,'frames':args.frames,'source_preserved_lines':len(original.splitlines()),'injected_lines':len(indices),'device_claim':False}
 meta['simulator_sha256']=sha(Path(meta['simulator']));meta['simulator']=str(Path(meta['simulator']).resolve());meta['probe_module_sha256']=sha(STAGE/'Source/dev/productionProbe.lua')
 atomic(out/'source-manifest.json',{str(p.relative_to(out/'Source')):sha(p)for p in sorted((out/'Source').rglob('*'))if p.is_file()})
 atomic(out/'startup-audit.json',baseline_audit)
 with(out/'probe-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(out/'Source'),meta['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic(out/'build.json',meta);return out,meta

def validate_identity(packet,meta):
 expected={'version':1,'run_id':meta['session_id'],'build_id':meta['build_id'],'mode':meta['mode'],'observer':meta['observer'],'bundle_id':meta['bundle_id'],'sdk_version':meta['sdk_version']}
 if not isinstance(packet,dict)or any(packet.get(k)!=v for k,v in expected.items()):raise RuntimeError('wrong or stale production-probe identity')
 if packet.get('simulator')is not True:raise RuntimeError('probe is not identified Simulator execution')
def verify_harness_trace(data,meta):
 # afterFrame emits one envelope only after an actual completed frame. Runtime
 # errors publish runtime-error.json and return before writing this trace.
 ready=json.loads((data/'ready.json').read_text())
 def identity(packet):
  if not isinstance(packet,dict)or any(packet.get(k)!=meta[k]for k in ['protocol','build_id','session_id']):raise RuntimeError('wrong or stale harness publication identity')
 identity(ready)
 if ready.get('status')!='ready'or ready.get('tick')!=1 or ready.get('sdk_version')!=meta['sdk_version']or not isinstance(ready.get('snapshot'),dict):raise RuntimeError('invalid actual harness ready publication')
 lines=(data/'trace.jsonl').read_text().splitlines()
 if len(lines)!=meta['frames']:raise RuntimeError('incomplete completed harness frame trace')
 for expected,line in enumerate(lines,1):
  packet=json.loads(line);identity(packet)
  if type(packet.get('tick'))is not int or packet['tick']!=expected or not isinstance(packet.get('snapshot'),dict):raise RuntimeError('nonmonotonic or incomplete harness frame trace')
 return len(lines)

def verify(data,meta):
 packets={name:json.loads((data/name).read_text())for name in ['probe-ready.json','probe-startup.json','probe-report.json','probe-done.json']}
 for packet in packets.values():validate_identity(packet,meta)
 report=packets['probe-report.json'];startup=packets['probe-startup.json'];done=packets['probe-done.json']
 for packet in [startup,report]:
  if not isinstance(packet.get('samples'),list)or packet.get('sample_count')!=len(packet['samples']):raise RuntimeError('incomplete probe sample inventory')
 if done.get('complete')is not True or done.get('frames')!=meta['frames']or report.get('frames')!=meta['frames']:raise RuntimeError('probe did not publish its complete producer barrier')
 if report.get('gc_policy_changed')is not False or report.get('lua_heap_only')is not True:raise RuntimeError('unexpected measurement/GC policy')
 labels={x['label']for x in report['samples']}
 for required in ['frame300-full-gc:before','frame300-full-gc:after','final-full-gc:before','final-full-gc:after']:
  if required not in labels:raise RuntimeError('missing distinct GC observation: '+required)
 if report.get('work',{}).get('count')!=meta['frames']or sum(report['work'].get('histogram',{}).values())!=meta['frames']:raise RuntimeError('incomplete frame timing inventory')
 if meta['mode']=='production':
  if packets['probe-ready.json'].get('harness_enabled')is not False or packets['probe-ready.json'].get('input_functions_unchanged')is not True:raise RuntimeError('production startup input/harness boundary violated')
  if report['final_state'].get('harness_enabled')is not False or report['final_state'].get('input_functions_unchanged')is not True:raise RuntimeError('production input/harness boundary violated')
  forbidden=['ready.json','request.json','result.json','heartbeat.json','cancel.json','captures-final.json','recent','captures.jsonl','frame-trace.jsonl','trace.jsonl','rejected.json']
  if any((data/name).exists()for name in forbidden):raise RuntimeError('production-mode probe unexpectedly used harness artifacts')
 else:
  state=report['final_state']
  if state.get('harness_enabled')is not True or state.get('input_functions_unchanged')is not False or state.get('autopilot_frame_loaded')is not True or state.get('fixtures_reset_loaded')is not True:raise RuntimeError('harness comparison did not retain enabled instrumentation')
  verify_harness_trace(data,meta)
 if(data/'runtime-error.json').exists():raise RuntimeError('game reported a runtime error')
 return packets

def summarize(packets):
 startup=packets['probe-startup.json'];report=packets['probe-report.json'];samples=startup['samples']+report['samples'];labels={x['label']:x for x in samples};intervals=[]
 for i,s in enumerate(startup['samples']):
  if s['label'].startswith('before-import:')or s['label'].startswith('before-call:'):
   after=labels.get('after-'+s['label'][7:])
   if after:intervals.append({'label':s['label'][7:],'elapsed_ms':after['elapsed_ms']-s['elapsed_ms'],'heap_delta_kib':after['lua_heap_kib']-s['lua_heap_kib']})
 return {'version':1,'mode':report['mode'],'observer':report['observer'],'build_id':report['build_id'],'run_id':report['run_id'],
         'startup_ready':labels.get('startup-ready-before-publication'),'observed_samples_peak_kib':max(x['lua_heap_kib']for x in samples),
         'gc_observations':{key:labels[key]for key in labels if 'full-gc:'in key},'work':report['work'],'observer_calibration':report['observer_calibration'],
         'largest_positive_import_intervals':sorted(intervals,key=lambda x:x['heap_delta_kib'],reverse=True)[:15],
         'interpretation':'Sampled Lua heap and inclusive instrumented Simulator elapsed time only. Not true peak/native malloc/device CPU or capacity; do not subtract observer cost blindly.'}

def execute(args,runner):
 # Only root invokes this branch. Same global lock as normal harness, before build.
 from tools.harness.protocol import OwnerLock
 with OwnerLock(runner.runtime_lock_path(runner.sdk_path(args.sdk))):
  out,meta=prepare(args,runner);data=Path(meta['data_dir']);process=None;owner=None;created=False;confirmed=True
  try:
   data.mkdir(parents=True,exist_ok=False);created=True
   atomic(data/'probe-owner.json',{'run_id':meta['session_id'],'bundle_id':meta['bundle_id'],'runner_pid':os.getpid()})
   owner=OwnerLock(data/'owner.lock');owner.__enter__()
   with(out/'simulator.stdout.log').open('w')as log:
    launch=time.monotonic();ready_wall=None
    process=subprocess.Popen([meta['simulator'],meta['bundle']],stdout=log,stderr=subprocess.STDOUT)
    atomic(out/'runtime.json',{'pid':process.pid,'run_id':meta['session_id'],'simulator':meta['simulator'],'simulator_sha256':meta['simulator_sha256'],'bundle':meta['bundle'],'bundle_id':meta['bundle_id'],'mode':meta['mode']})
    deadline=time.monotonic()+args.timeout
    while not(data/'probe-done.json').is_file():
     if ready_wall is None and(data/'probe-ready.json').is_file():
      validate_identity(json.loads((data/'probe-ready.json').read_text()),meta);ready_wall=time.monotonic()-launch
     if process.poll()is not None:raise RuntimeError('owned Simulator exited before probe completed')
     if time.monotonic()>deadline:raise RuntimeError('production probe deadline exceeded')
     time.sleep(.1)
    runtime=json.loads((out/'runtime.json').read_text());runtime.update(ready_wall_seconds=ready_wall,done_wall_seconds=time.monotonic()-launch);atomic(out/'runtime.json',runtime)
    packets=verify(data,meta);runner.verify_png(data/'probe-final.png',400,240)
    atomic(out/'summary.json',summarize(packets));atomic(out/'outcome.json',{'ok':True,'mode':meta['mode'],'run_id':meta['session_id'],'build_id':meta['build_id'],'pid':process.pid,'device_claim':False})
  except BaseException as error:
   atomic(out/'outcome.json',{'ok':False,'error':str(error),'run_id':meta['session_id'],'build_id':meta['build_id']});raise
  finally:
   if process:
    from tools.harness.restarting import stop_owned,UnconfirmedExit
    try:stop_owned(process,owner,data)
    except UnconfirmedExit:confirmed=False
   if created and confirmed:
    marker=json.loads((data/'probe-owner.json').read_text())
    if marker.get('run_id')!=meta['session_id']:raise RuntimeError('private probe ownership marker changed; Data preserved')
    shutil.copytree(data,out/'runtime-data');shutil.rmtree(data)
   if owner:owner.__exit__(None,None,None)
   if not confirmed:raise RuntimeError('owned process exit unconfirmed; private Data preserved')
  print(out)

def main():
 p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--mode',choices=['production','harness'],default='production');p.add_argument('--observer',choices=['milestones','imports'],default='milestones');p.add_argument('--frames',type=int,default=600);p.add_argument('--timeout',type=float,default=90);a=p.parse_args()
 if not 600<=a.frames<=1800:raise SystemExit('--frames requires600..1800')
 if not 10<=a.timeout<=180:raise SystemExit('--timeout requires10..180 seconds')
 sys.path.insert(0,str(a.project.resolve()));from tools.harness import run as runner
 if a.execute:execute(a,runner)
 else:out,meta=prepare(a,runner);print(out)
if __name__=='__main__':main()

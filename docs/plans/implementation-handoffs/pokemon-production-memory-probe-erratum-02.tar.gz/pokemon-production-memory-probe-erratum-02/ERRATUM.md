# Production probe verifier erratum 02

Frozen 01 incorrectly required frame-trace.jsonl. Runtime Harness.afterFrame actually appends trace.jsonl after each completed frame. Original failed runs remain failures; this packet requires four fresh UUID/output jobs. No production/game/probe Lua bytes changed.

Verifier now requires actual ready.json protocol/build/session, ready status/tick1/SDK/snapshot, and exactly configured frames (default600) trace.jsonl envelopes with matching identity, snapshots and consecutive ticks1..600. Production rejects trace.jsonl as well as previous forbidden artifacts. Source runtime-error rejection remains strict.

Host: python3 -m unittest discover -s /private/tmp/pokemon-production-memory-probe-erratum-02/tests -v — 10/10 PASS. No Simulator execution. Existing frozen01 four compile results remain source-equivalent because only host verifier/tests/docs changed; no new native claim.

Root: use this packet probe.py with the original arguments and NEW outputs for production/harness × milestones/imports. --execute remains root-exclusive. No reinterpretation of failed outcomes or shared Data reads.

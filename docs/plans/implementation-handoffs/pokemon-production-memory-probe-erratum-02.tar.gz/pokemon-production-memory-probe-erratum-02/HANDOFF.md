# Production-mode baseline probe01 — measurement before any fix

No production import-gating change is included. All original main.lua lines/imports/registrations/game calls remain verbatim and ordered; a host roundtrip guard checks that property. This packet only adds passive measurement hooks and an identified, bounded producer stop after observations. No input wrapper, fixture, mailbox request reader, RNG seed or game-data mutation is added. Worker ran host tests and pdc only; all runtime measurements below are PENDING ROOT.

Static findings: AUDIT.md + source-audit.json record159 imports /74 dev imports /64 registered suites /878,889 direct dev Lua source bytes, the five interleaved game imports and exact existing facade callsites. These are not heap measurements. SDK3.1.2 docs/version SHA is pinned. All imports compile into onePDZ; imported code executes once. Runtime gating savings/compiled-prototype residency are not proven. No optimization is proposed for approval before actual baseline observations.

## What the private probe observes

Two configuration axes over the SAME instrumented Lua code:

- mode production: generated HarnessBuild.enabled=false, current existing import order still unchanged. No standard harness mailbox/runtime publications or synthetic input wrappers may be present; host verifies actual input function identities before/after Autopilot and ready/final states, plus absence of ready/request/result/heartbeat/captures/frame-trace/recent artifacts.
- mode harness: current enabled harness path, including normal input wrapper/fixture methods and ready/frame-trace publications. Host requires those to prove this is a genuine instrumented comparison, not a mislabeled production run. It receives no commands. This passive probe is NOT the SDK contracts runner; dev test imports/registrations remain present and unchanged.
- observer milestones: startup section/game construction/install/save-start observations; steady frames1/60/180/299/301/600 by default, explicit fullGC at300 and final.
- observer imports: adds paired samples around all159 original imports +64 registrations +the catalog exporter registration. Startup records are written once and discarded before steady-state measurement so their deliberate retention does not masquerade as steady game data. Both observer modes contain the same mark call sites/code, with a no-op branch for detailed marks in milestones mode.

Every record names phase/frame/elapsedMS/LuaheapKiB. Reports separate sampled startup/steady/GC observations and inclusive game-update time histogram from afterFrame observer/fullGC time. Two explicit full collections are measurements only: existing automatic GC settings and game's incremental collect step remain unchanged. A512-sample calibration reports raw observer elapsed/allocation/releaseGC; do not subtract it blindly. Final native400x240 PNG is written only after the last measured heap/timing and calibration, so capture does not contaminate earlier samples.

The BEFORE first CoreLibs observation still includes the probe/main/PDZ startup overhead; it cannot measure a nonexistent zero-observer Lua process. Compare observer modes honestly. Reported peak is the maximum sampled Lua heap, not true peak/total native allocation. getCurrentTimeMilliseconds resolution is1ms; small observations can quantize to0. Startup has both in-Lua elapsed and external owned-process launch→ready wall time. No device CPU/RAM/16MB fit or physical release claim.

## Ownership and artifacts

probe.py defaults to COMPILE ONLY; no SDK Disk/Data directory is accessed/created in that branch. Staged Source is copied by existing normal prepare, then only probe/main/config overlays are applied with generated false/true mode. UUID bundle ID com.poc.pokemon.productionprobe.<run_id> has unique private Data. Root-only --execute acquires the SAME global SDK runtime lock BEFORE staging, then an owned private Data lock; uses the exact SDK Simulator binary/Popen PID, existing tested stop_owned termination, stable probe-done publication barrier, copies evidence after confirmed exit and removes ONLY the UUID directory with matching owner marker. No player Data/bundle/save is touched. Unconfirmed exit preserves Data. No external messaging, command mailbox or new client/runner framework.

build.json records original Source fingerprint/revision/dirty status, identified instrumented code and full compiled Source hashes, SDK/version/docs guard, exact simulator path+SHA, mode/observer/run/bundle and packet SHA. source-manifest.json pins actual compiled files. runtime.json binds PID/timing; runtime-data contains ready/startup/steady/report/done/calibration/PNG artifacts. summary.json preserves exact metrics and limitations. Wrong identity, incomplete samples/timing/GC/barrier, unexpected production mailbox/input interception or game runtime-error fails nonzero. No heap threshold auto-approves a fix/release.

## Host and compile checks

```
python3 -m unittest discover -s /private/tmp/pokemon-production-memory-probe-01/tests -v
python3 /private/tmp/pokemon-production-memory-probe-01/probe.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-probe-compile-P-min --mode production --observer milestones
python3 /private/tmp/pokemon-production-memory-probe-01/probe.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-probe-compile-P-import --mode production --observer imports
python3 /private/tmp/pokemon-production-memory-probe-01/probe.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-probe-compile-H-min --mode harness --observer milestones
python3 /private/tmp/pokemon-production-memory-probe-01/probe.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-probe-compile-H-import --mode harness --observer imports
```

All output names must be fresh. Baseline and packet SHA guards fail on changed source rather than silently measuring a new build. Probe is not a deployable device release bundle (Simulator-only assertion).

## Root-only native matrix

After reviewing the packet and current runtime queue, run the same four commands with new output paths and `--execute`. Each default600frame job is about20s at30FPS plus startup/GC;90s explicit deadline, only owned PID termination. Run serially, no parallel Simulator. Keep physical input idle for a comparable opening-dialog baseline. Then:

```
python3 /private/tmp/pokemon-production-memory-probe-01/tools/compare.py /private/tmp/ROOT-P-min /private/tmp/ROOT-P-import /private/tmp/ROOT-H-min /private/tmp/ROOT-H-import
```

Compare helper requires successful actual outcomes, distinct runtime IDs and exactly unchanged original Source. Inspect exact input-preserved fields, final image and expected opening dialog/bedroom/checkpoint/Potion/money state. Detailed import intervals include GC and observer allocations and can be negative; large positive raw deltas are hypotheses, not established retained leaks.

Optional separate production interaction observation: run a new private production probe with --frames1800, use real Simulator buttons to dismiss Oak, walk, open B menus/Debug, visit PC and save normally. Report final actual state and inspect final PNG/private save artifact. This does not claim true-process persistence; preserve existing normal two-process PC/Save/Continue qualification for any later gating candidate, then add explicit production restart proof if requested. No probe input injection or copied-save proof.

## Decision after measurement

Root reviews native startup/steady/postGC/observer/harness differences before authorizing any fix. A later narrow candidate must keep all real game modules (including the five late imports) unconditional, preserve Debug/input/save ownership and all enabled test/catalog imports/registrations. An early HarnessBuild +conditional dev block/no-op Harness facade is only a possible candidate, not justified savings yet; single-PDZ behavior may require different packaging. Run full enabled contracts/protocol/native journeys and exact protected catalogue, plus actual production input/persistence checks, before acceptance. No live Source changes by this worker.

"""UNCHANGED native TurnCheckConditions: explicit condition/effect I/O stubs."""
from pathlib import Path
import hashlib,json,re,subprocess,tempfile
P=Path(__file__).resolve().parent
def function(text,name):
 m=re.search(r'^(?:static )?(?:BOOL|void|u32|u16)\s+'+name+r'\([^;\n]*\) \{',text,re.M);assert m;start=m.start();end=m.end();depth=1
 while depth:
  if text[end]=='{':depth+=1
  elif text[end]=='}':depth-=1
  end+=1
 return text[start:end]
def run():
 source=(P/'references/btl_server_flow.c').read_bytes();pin=json.loads((P/'source-pin.json').read_text());assert hashlib.sha256(source).hexdigest()==pin['files']['btl_server_flow.c']['sha256']
 body=function(source.decode(),'ServerControl_TurnCheckConditions')
 c='''#include <stdio.h>
#include <assert.h>
typedef unsigned char u8;typedef unsigned int u32;typedef int BOOL;typedef int BattleCondition;
#define TRUE 1
#define FALSE 0
typedef struct {int id,hp,max,condition;} BattleMon;
typedef struct {void*pokeCon;int actionState;void*queue;} BtlServerFlow;
static BattleMon mons[2];static int mode,checks,effectCount;static int order[8];
u32 BtlMonSet_GetCount(void*m){return 2;}
BattleMon* BtlMonSet_Get(void*m,u32 i){return &mons[1-i];}
u8 GetMonID(BattleMon*m){return m->id;}
BattleMon* GetPokeParam(void*c,u8 id){return &mons[id];}
u32 GetConditionByIndex(u32 index){if(index==0)return 5;if(index==1&&mode==1)return 4;return 0;}
BOOL IsFainted(BattleMon*m){return m->hp==0;}
BOOL BattleMon_TickCondition(BattleMon*m,u32 c,BattleCondition*p,BOOL*cured){*p=0;*cured=0;return m->condition==c;}
u32 PushState(int*x,int tag){return 0;}void PopState(int*x,u32 prev,int tag){}
void Condition_EndTurnEffect(BattleMon*m,u32 c,BattleCondition p,BOOL cured,BtlServerFlow*f){int damage=m->max/8;if(damage<1)damage=1;m->hp=m->hp>damage?m->hp-damage:0;order[effectCount++]=m->id;}
BOOL ServerControl_CheckMatchup(BtlServerFlow*f){return FALSE;} /* BOTH have living reserves. */
u32 BtlCalc_PackMonIDs(u8*ids){return 0;}
void BtlServerCmdQueue_Put(void*q,int code,u8 count,u8 index,u32 packed){}
BOOL ServerControl_CheckExpGain(BtlServerFlow*f){checks++;assert(effectCount==2);assert(mons[0].hp==0);return TRUE;}
'''+body+'''\nint main(){for(int level=0;level<2;level++)for(mode=0;mode<2;mode++){
mons[0]=(BattleMon){0,1,level?104:21,mode?4:5};mons[1]=(BattleMon){1,1,level?100:20,5};checks=effectCount=0;
BtlServerFlow flow={0};assert(ServerControl_TurnCheckConditions(&flow,0));assert(checks==1);assert(order[0]==1&&order[1]==0);assert(mons[1].hp==0);
printf("case=%d/%d enemy_condition player_condition then_exp player_hp=%d enemy_hp=%d\\n",level,mode,mons[0].hp,mons[1].hp);
} }
'''
 with tempfile.TemporaryDirectory(prefix='native-cohort-',dir='/private/tmp')as tmp:
  src=Path(tmp)/'oracle.c';src.write_text(c);exe=Path(tmp)/'oracle';subprocess.run(['cc','-std=c99','-Wall','-Werror',str(src),'-o',str(exe)],check=True);result=subprocess.check_output([str(exe)],text=True)
 assert len(result.splitlines())==4
 return {'ok':True,'cases':4,'output':result,'scope':'unchanged TurnCheckConditions control flow; effect stubs use ordinary maxHP/8 damage; no DS RNG/EXP formula simulation'}
if __name__=='__main__':print(json.dumps(run(),indent=2))

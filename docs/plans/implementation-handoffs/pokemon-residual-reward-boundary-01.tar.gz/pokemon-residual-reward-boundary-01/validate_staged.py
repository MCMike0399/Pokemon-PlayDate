#!/usr/bin/env python3
"""Root-only --execute of deliberately failing native checkpoint diagnostic."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
P=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--output',required=True);p.add_argument('--execute',action='store_true');p.add_argument('--sdk');a=p.parse_args()
project=a.project.resolve();sys.path.insert(0,str(project));from tools.harness import run as runner
from tools.harness.protocol import atomic_json
manifest=json.loads((P/'manifest.json').read_text());original=runner.prepare

def prepare(project,sdk,out,session):
 for rel,digest in manifest['files'].items():assert hashlib.sha256((P/rel).read_bytes()).hexdigest()==digest,'packet changed: '+rel
 for rel,digest in manifest['baseline_functions'].items():assert hashlib.sha256((project/rel).read_bytes()).hexdigest()==digest,'diagnostic engine base changed: '+rel
 meta=original(project,sdk,out,session)
 shutil.copyfile(P/'Source/dev/residualRewardProbe.lua',out/'Source/dev/residualRewardProbe.lua')
 main=out/'Source/main.lua';text=main.read_text();marker='game = GameContext(';assert text.count(marker)==1
 main.write_text(text.replace(marker,'import "dev/residualRewardProbe"\nContracts.run=ResidualRewardProbe.run -- private diagnostic ONLY, not normal qualification\n'+marker))
 pdx=out/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(meta['original_pdxinfo']);meta['source_sha256']=runner.fingerprint(out);meta['build_id']=meta['revision']+':'+meta['source_sha256']
 atomic_json(out/'source-manifest.json',{str(f.relative_to(out/'Source')):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted((out/'Source').rglob('*'))if f.is_file()and f.relative_to(out/'Source').as_posix()!='dev/harness_build.lua'})
 pdx.write_text(generated);lines=[]
 for key in ['protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir']:
  value=meta[key];lines.append('    '+key+' = '+('true'if value is True else 'false'if value is False else json.dumps(value))+',')
 (out/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(lines)+'\n}\n')
 meta.update(compiled_source_sha256=runner.fingerprint(out,exclude_generated=False),residual_probe_packet_sha256=hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),expected_diagnostic_failure=True)
 with(out/'residual-probe-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(out/'Source'),meta['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(out/'build.json',meta);return meta
runner.prepare=prepare;runner.PROJECT=project
try:code=runner.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(P/'scenario.json'),commands=[],build_only=not a.execute,timeout=90,ready_timeout=20,max_frames=1800))
finally:runner.prepare=original
raise SystemExit(code)

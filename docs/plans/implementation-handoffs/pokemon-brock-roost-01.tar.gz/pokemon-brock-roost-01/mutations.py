#!/usr/bin/env python3
"""Compile eight bounded faults by default; root alone opts into SDK execution."""
import argparse,json,subprocess,sys
from pathlib import Path
S=Path(__file__).resolve().parent
expected={
 'floor-half':'roost: Odd85HP actual Roost heals43 and installs transient before narration yield',
 'mark-full':'roost: FullHP actual attempt fails spendsPP and remains Flying with Ground immunity',
 'durable-types':'roost: Odd85HP actual Roost heals43 and installs transient before narration yield',
 'raw-stab':'roost: Actual damage path removes FlyingSTAB148to99 while raw compatibility remains148',
 'raw-immunity':'roost: Successful real fasterRoost exposes grounded user to actual Earthquake3',
 'raw-ground':'roost: OHKO and trapping grounding share actual effective type seam',
 'expiry-late':'roost: Roost record expires at member25 before actual side26 and cannot tick replacement record',
 'skip-expiry':'roost: Successful real fasterRoost exposes grounded user to actual Earthquake3',
}

p=argparse.ArgumentParser();p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--execute',action='store_true');p.add_argument('--sdk');a=p.parse_args();output=Path(a.output);output.mkdir(parents=True,exist_ok=False);report=[]
for name,witness in [('control',None),*expected.items()]:
 run=output/name;cmd=[sys.executable,str(S/'validate_staged.py'),'--project',a.project,'--output',str(run)]
 if name!='control':cmd+=['--mutant',name]
 if a.execute:cmd+=['--execute']
 if a.sdk:cmd+=['--sdk',a.sdk]
 result=subprocess.run(cmd,capture_output=True,text=True);(output/(name+'.log')).write_text(result.stdout+result.stderr)
 row={'variant':name,'returncode':result.returncode,'runtime':a.execute}
 if not a.execute:
  if result.returncode:raise RuntimeError(name+' compile failed; see log')
  row['compiled']=True
 else:
  found=[]
  for path in sorted(run.glob('[0-9][0-9][0-9][0-9][0-9]-result.json')):
   for entry in json.loads(path.read_text()).get('results',[]):
    if entry.get('contracts'):found.append((path,entry['contracts']))
  if len(found)!=1:raise RuntimeError(name+': expected exactly1 numbered contract report, got'+str(len(found)))
  path,r=found[0];failed={x['name']for x in r['tests']if not x['ok']}
  if name=='control':assert result.returncode==0 and r['ok']and not failed,'control failed'
  else:assert result.returncode!=0 and not r['ok']and witness in failed,(name,witness,failed)
  row.update(qualified=True,evidence=str(path),passed=r['passed'],failed=r['failed'],failed_tests=sorted(failed))
 report.append(row)
(output/'qualification.json').write_text(json.dumps({'runtime_executed':a.execute,'results':report},indent=2)+'\n')
print(output/'qualification.json')

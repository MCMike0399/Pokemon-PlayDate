import hashlib,json,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class RoostReference(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.rows={r['case']:r for r in json.loads((ROOT/'observations.json').read_text())['rows']}
 def test_actual_engine_replay_byte_exact(self):self.assertEqual((ROOT/'observations.json').read_bytes(),(ROOT/'observations-replay.json').read_bytes())
 def test_odd_heal_and_ground_resolution(self):
  r=self.rows['odd-half-success'];c=r['checkpoints'][0];self.assertEqual((r['before']['maxhp'],c['hp'],r['after']['hp']),(85,44,41));self.assertEqual(c['types'],['Normal']);self.assertEqual(c['baseTypes'],['Normal','Flying']);self.assertTrue(c['grounded'])
 def test_full_hp_failure_retains_type_and_spends_one_pp(self):
  r=self.rows['full-HP-failure'];c=r['checkpoints'][0];self.assertEqual(c['types'],['Normal','Flying']);self.assertFalse(c['volatile']);self.assertFalse(c['grounded']);self.assertEqual(r['after']['hp'],85);self.assertEqual((r['before']['pp'],r['after']['pp']),(10,9))
 def test_cap_heal_is_success_and_earlier_immunity_retained(self):
  r=self.rows['one-HP-heal-success'];self.assertEqual(r['checkpoints'][0]['hp'],85);self.assertEqual(r['after']['hp'],82)
  r=self.rows['slower-Roost-ground-first'];self.assertEqual(r['checkpoints'][0]['event'],'before-real-Earthquake-hit');self.assertEqual(r['checkpoints'][0]['targetTypes'],['Normal','Flying']);self.assertEqual(r['after']['hp'],44)
 def test_natural_native_recipe_vector(self):
  r=self.rows['natural-Pidgeot44-Diglett40'];self.assertEqual((r['before']['maxhp'],r['checkpoints'][0]['hp'],r['after']['hp']),(127,65,26));self.assertEqual(r['after']['pp'],9)
 def test_gen5_pure_flying_fallback_and_nonflying(self):
  r=self.rows['pure-Flying-reference-fixture'];self.assertEqual(r['checkpoints'][0]['types'],['Normal']);self.assertEqual(r['after']['types'],['Flying'])
  r=self.rows['non-Flying-reference-fixture'];self.assertEqual(r['checkpoints'][0]['types'],['Water']);self.assertEqual(r['after']['hp'],53)
 def test_actual_stab_and_expiry_before_screen(self):
  self.assertEqual((self.rows['odd-half-success']['checkpoints'][0]['gustDamage'],self.rows['full-HP-failure']['checkpoints'][0]['gustDamage']),(99,148))
  for r in self.rows.values():
   if r['case']!='full-HP-failure':self.assertEqual(r['checkpoints'][-1]['screenDuration'],5);self.assertEqual(r['after']['screenDuration'],4);self.assertFalse(r['after']['roost'])
 def test_retain_actual_showdown_tie_disagreement(self):
  rows=json.loads((ROOT/'ties-observations.json').read_text())
  counts=[len([c for c in r['calls'] if c['where'][-1]=='at Battle.fieldEvent']) for r in rows]
  self.assertEqual(counts,[1,2]) # Native shared monSet policy is deliberately different; do not rewrite reference.
 def test_real_rules_rng_fixture_ranges(self):
  state=23;out=[]
  for low,high in [(1,1),(1,100),(1,16),(85,100)]:state=state*16807%2147483647;out.append(low+(state-1)%(high-low+1))
  self.assertEqual(out,[1,86,16,100]);self.assertEqual(state,1178867664)
if __name__=='__main__':unittest.main()

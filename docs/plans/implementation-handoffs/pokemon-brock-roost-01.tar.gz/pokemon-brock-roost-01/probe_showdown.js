const path=require('path');const ref='/private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547';const {Battle}=require(path.join(ref,'dist/sim'));
const ivs={hp:0,atk:0,def:0,spa:0,spd:0,spe:0};const set=(species,level,moves,ability)=>({species,level,moves,ability,ivs,evs:{},nature:'Hardy'});
const rows=[];
for(const cfg of[
 {name:'odd-half-success',hp:1},
 {name:'natural-Pidgeot44-Diglett40',hp:1,bird:true,enemyLevel:40},
 {name:'full-HP-failure',full:true},
 {name:'one-HP-heal-success',one:true},
 {name:'slower-Roost-ground-first',hp:1,enemyLevel:50},
 {name:'pure-Flying-reference-fixture',hp:1,pureFlying:true},
 {name:'non-Flying-reference-fixture',hp:1,water:true},
]){
 const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,4],p1:{name:'USER',team:[cfg.water?set('Squirtle',50,['roost'],'Torrent'):cfg.bird?set('Pidgeot',44,['roost'],'Keen Eye'):set('Pidgey',42,['roost'],'Keen Eye')]},p2:{name:'FOE',team:[cfg.water?set('Snorlax',5,['splash'],'Immunity'):set('Diglett',cfg.enemyLevel||1,['earthquake'],'Sand Veil')]}});if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');
 const p=b.p1.active[0],e=b.p2.active[0];p.moveSlots[0].pp=p.moveSlots[0].maxpp=10;p.baseMoveSlots[0].pp=p.baseMoveSlots[0].maxpp=10;if(!cfg.full)p.hp=cfg.one?p.maxhp-1:cfg.hp;if(cfg.pureFlying)p.types=['Flying'];
 b.randomizer=n=>n;const oldChance=b.randomChance.bind(b);b.randomChance=(n,d)=>n===1&&d===16?false:oldChance(n,d);
 b.p1.addSideCondition('lightscreen',p,b.dex.moves.get('lightscreen'));
 const before={hp:p.hp,maxhp:p.maxhp,types:p.getTypes(),baseTypes:[...p.types],pp:p.moveSlots[0].pp};const checkpoints=[];
 const oldMove=b.actions.useMove.bind(b.actions);b.actions.useMove=(...args)=>{const result=oldMove(...args);const move=args[0];if((typeof move==='string'?move:move.id)==='roost'){
  const gust=b.dex.getActiveMove('gust');gust.willCrit=false;
  checkpoints.push({event:'after-real-Roost',hp:p.hp,types:p.getTypes(),baseTypes:[...p.types],grounded:p.isGrounded(),volatile:!!p.volatiles.roost,gustDamage:b.actions.getDamage(p,e,gust,true)});
 }return result;};
 const oldHit=b.actions.trySpreadMoveHit.bind(b.actions);b.actions.trySpreadMoveHit=(targets,user,move,...rest)=>{if(move.id==='earthquake')checkpoints.push({event:'before-real-Earthquake-hit',targetTypes:p.getTypes(),volatile:!!p.volatiles.roost});return oldHit(targets,user,move,...rest);};
 const oldRemove=p.removeVolatile.bind(p);p.removeVolatile=(key,...args)=>{if(key==='roost')checkpoints.push({event:'roost-expiry',screenDuration:p.side.sideConditions.lightscreen?.duration,typesBefore:p.getTypes()});return oldRemove(key,...args);};
 b.makeChoices('move 1','move 1');rows.push({case:cfg.name,fixture:'Actual Gen5 turn. HardyIV0EV0. Noncritical/maxvariance controls, explicit noPPUps10PP; pureFlying/nonFlying Roost are explicit custom mechanism fixtures, no new world species or movepool.',before,checkpoints,after:{hp:p.hp,types:p.getTypes(),baseTypes:[...p.types],roost:!!p.volatiles.roost,screenDuration:p.side.sideConditions.lightscreen?.duration,pp:p.moveSlots[0].pp},log:b.log.filter(x=>!x.startsWith('|t:|'))});b.destroy();
}
process.stdout.write(JSON.stringify({reference:'9b136a8c8cdb860a8ab96fa063f906604e352547',rows},null,2)+'\n');

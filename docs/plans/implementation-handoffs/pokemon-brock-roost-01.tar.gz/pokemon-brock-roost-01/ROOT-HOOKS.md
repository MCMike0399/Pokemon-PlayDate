# Root-owned integration hooks

Register after battle/domain imports: `import "dev/roostContracts"` then `Contracts.register("roost",RoostContracts.run)` (25groups).

Read-only interface: `battle:effectiveTypes(mon)` returns two strings/nil without allocation; `battle:hasType(mon,move.type)` and `battle:typeMatchup(move.type,enemy)` are pure. Legal observer should use these for STAB/effectiveness. Existing general Pokemon snapshot `types` remains intrinsic. Optional per-battle-player `effective_types={battle:effectiveTypes(mon)}` is diagnostic only, not durable state; none of the authored native recipes requires that extra field. Existing `battle.conditions.player.roost`/enemy boolean now comes from Battle:getConditionsSnapshot. No fixture schema additions.

Root producer11 sole dependency: moves.lua2dd159e64ba5abe1477b54c7d764b70fe7635b89e5a8095f27189e286285ca25. OnlyRoostEffect payload; generator tools not owned/modified here. Merge seven Source patches only, preserving root main/diagnostics/fixture changes. No Pokemon/codec/field/world/art changes.

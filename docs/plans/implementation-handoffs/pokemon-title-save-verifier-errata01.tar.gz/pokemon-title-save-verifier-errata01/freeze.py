from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(root.rglob('*'))if p.is_file()and p.name!='manifest.json'and '__pycache__'not in p.parts}
(root/'manifest.json').write_text(json.dumps({'frozen_parent_manifest':'e0eefc4f2102bb38cce9b677d5b8a5eed62874af47c7a50140698de875bee89f','production_source_changes':[],'private_visual_probe':'expanded/Source/dev/titleExpandedProbe.lua','files':files},indent=2)+'\n')
print(hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest())

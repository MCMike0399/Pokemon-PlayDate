# Host verifier correction and private expanded Title inspection

This is a separate immutable erratum to `/private/tmp/pokemon-title-save-recovery-handoff01` (`e0eefc4f2102bb38cce9b677d5b8a5eed62874af47c7a50140698de875bee89f`). The original packet/evidence remain unchanged. There are **no production Source changes** here. The only Lua module is explicitly a private boot setup for a visual test, never a game feature/import.

Root actual SDK02 is **1089 pass / 0 fail**, Source `0869d026f9d208267870fb451828f2b6e000c86ca8f01fba3449871df14e7b15`. Root's two-process native run is independent of this host parser correction.

## Host defect and correction

Root reproduced that Python `True == 1` let an envelope with `schema: true` pass the old independent artifact verifier. Production Lua rejected it. The new verifier requires exact envelope fields; `type(schema) is int` and schema1; canonical sequence; byte input and <=1MiB file; string payload and <=256KiB UTF-8 payload; table payload and the existing generic primitive/number/depth bounds; exact schema/sequence/payload checksum. Malformed payload types fail with controlled `ValueError`, without `.encode()` attribute errors. Unknown/missing headers are rejected. This does not change or claim to independently validate the entire SessionCodec domain schema; actual SDK load does that.

All old verifier tests remain. New cases include boolean/float/string schemas with otherwise normal checksums, unknown/missing fields, every non-string payload family, inclusive file/payload byte boundaries, multibyte oversize payload, null/scalar/invalid-number payloads and checksum mutation. No native results or production assertions were weakened.

```
python3 -m unittest discover -s /private/tmp/pokemon-title-save-verifier-errata01/tests -v
```

Read-only requalification after root's original native job has finished and both processes are archived (no Simulator rerun):

```
python3 /private/tmp/pokemon-title-save-verifier-errata01/reverify.py \
  /private/tmp/pokemon-root-title-save-recovery-native-01 \
  --report /private/tmp/pokemon-title-save-native-reverified-01.json
```

The report is created exclusively; existing evidence cannot be overwritten. The verifier reads only stopped-generation copies inside the output, checks distinct confirmed-exited PIDs, exact binary seed archives, manifest/receipt/proposal checksum binding, planned target bytes, unknown leftovers and unchanged durable saves across Continue. It does not access live SDK Data.

## Expanded 4–6 choice visual recipe

`expanded/Source/dev/titleExpandedProbe.lua` is a **PRIVATE SOURCE-LABELED VISUAL SETUP**. `validate_expanded.py` composes frozen core/followup files and imports this probe immediately before `GameSaves:start()` only in its private harness build. It requires a UUID private bundle and missing root save files. It does not become part of the production handoff.

The probe uses actual `SessionCodec.encode(game.session)` and actual `SaveStore.save`, `prepareReplacement` and `replace` methods, backed by the real SDK filesystem. It produces two ordinary valid published saves, then uses a path-specific fault adapter to retain an actual valid third candidate (six choices) or a real torn candidate (five choices). A confirmed store ticket then archives the source files and proposal, with a deliberate primary-candidate write failure before publication. All adapters are restored, actual owner/RNG state is checked unchanged and the resulting actual metadata is asserted. `title-expanded-setup.json` labels the fault setup and records canonical RNG data. No fake session/save envelope or forged game outcome is used.

The six-choice input recipe captures every row and actual recovery confirmation, then uses real Repair -> YES -> message -> refresh to obtain four actual choices. It captures the four-choice menu with selection on the last row. The separate five-choice recipe captures the five-choice menu and last selection. No gameplay fixture is used after setup and no production mechanics are changed.

Compile only (default):

```
python3 /private/tmp/pokemon-title-save-verifier-errata01/validate_expanded.py \
  --project /private/tmp/pokemon-brock-integration-03 \
  --output /private/tmp/pokemon-title-expanded-compile-01
```

Root-only native 6 -> real repair -> 4:

```
python3 /private/tmp/pokemon-title-save-verifier-errata01/validate_expanded.py \
  --project /private/tmp/pokemon-brock-integration-03 \
  --output /private/tmp/pokemon-root-title-expanded-six-01 --execute
```

Root-only native 5:

```
python3 /private/tmp/pokemon-title-save-verifier-errata01/validate_expanded.py \
  --project /private/tmp/pokemon-brock-integration-03 --expanded-choices 5 \
  --output /private/tmp/pokemon-root-title-expanded-five-01 --execute
```

Root inspects all labels, bottom info/status placement, last-row selection, actual repair confirmation/result and preserved ordinary Title composition from the original restart run. These controlled captures qualify layout; they are not evidence that corruption arises during normal play or a replacement for actual Title→YES→Save→restart→Continue.

Worker can run host tests and compile only. Root owns native execution and acceptance. Frozen production core/followup remain unchanged; capacity64 safe-fail limitation and other original scope notes stand.

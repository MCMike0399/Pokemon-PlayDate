#!/usr/bin/env python3
"""Read stopped native output only; no Simulator, SDK Data or production writes."""
import argparse
import hashlib
import json
from pathlib import Path
from recovery_evidence import verify_run
p=argparse.ArgumentParser();p.add_argument('output',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for rel,want in manifest['files'].items():
    assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==want,'erratum drift '+rel
proof=verify_run(a.output)
proof['verifier_manifest_sha256']=hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()
proof['prior_native_output']=str(a.output.resolve())
with a.report.open('x')as stream:json.dump(proof,stream,indent=2);stream.write('\n')
print(a.report)

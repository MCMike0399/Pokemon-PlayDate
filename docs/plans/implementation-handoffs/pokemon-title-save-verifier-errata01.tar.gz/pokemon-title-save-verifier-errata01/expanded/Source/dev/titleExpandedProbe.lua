-- PRIVATE SOURCE-LABELED VISUAL SETUP ONLY; not a production feature or fixture.
-- Root composes this before GameSaves:start() in an isolated UUID bundle.
TitleExpandedProbe={}
function TitleExpandedProbe.prepare(game,choices)
 assert(HarnessBuild and HarnessBuild.enabled and HarnessBuild.bundle_id:match("^com%.poc%.pokemon%.harness%."),"private harness required")
 assert(choices==5 or choices==6,"explicit five/six menu setup required")
 local store=game.saves.store;local fs=store._fs;local before=RulesRNG.toData();local owner=GameSession.activeRNGSession()
 for _,path in pairs(store._paths)do local bytes,err=fs.read(path);assert(bytes==nil and err=="missing","fresh empty save prefix required")end
 local payload=assert(SessionCodec.encode(game.session,{root="overworld",overworld="explore",settled=true}))
 assert(store:save(payload));assert(store:save(payload))
 -- Use the existing actual save path to produce either a valid uncommitted
 -- third envelope or a torn candidate. No hand-constructed session/save rows.
 if choices==6 then
  store._fs={read=fs.read,write=fs.write,rename=function(from,to)
   if from==store._paths.candidate then return false,"PRIVATE PROBE: uncommitted candidate"end
   return fs.rename(from,to)
  end}
 else
  store._fs={read=fs.read,rename=fs.rename,write=function(path,bytes)
   if path==store._paths.candidate then assert(fs.write(path,bytes:sub(1,9)));return false,"PRIVATE PROBE: torn candidate"end
   return fs.write(path,bytes)
  end}
 end
 local ok,problem=pcall(function()
  local published,metadata=store:save(payload);assert(published==false)
  assert(metadata.reason==(choices==6 and "publication-failed" or "candidate-write-failed"))
 end)
 store._fs=fs;assert(ok,problem)
 local ticket=assert(store:prepareReplacement())
 store._fs={read=fs.read,rename=fs.rename,write=function(path,bytes)
  if path==store._paths.candidate then return false,"PRIVATE PROBE: archived proposal before publication"end
  return fs.write(path,bytes)
 end}
 ok,problem=pcall(function()
  local replaced,metadata=store:replace(payload,ticket)
  assert(replaced==false and metadata.reason=="candidate-write-failed")
 end)
 store._fs=fs;assert(ok,problem)
 local restored,metadata=game.saves:inspect()
 assert(restored and metadata.proposalAvailable and metadata.backupPublished)
 assert(metadata.backupCandidate==(choices==6))
 assert(metadata.pendingCandidate==(choices==6) and metadata.hasCorruption==(choices==5))
 local after=RulesRNG.toData()
 assert(before.seed==after.seed and before.state==after.state and before.rolls==after.rolls,"setup changed rules RNG")
 assert(GameSession.activeRNGSession()==owner,"setup changed active owner")
 assert(fs.write("title-expanded-setup.json",json.encode({private_source_probe=true,choices=choices,
  reason=metadata.reason,proposal=metadata.proposalAvailable,backupPublished=metadata.backupPublished,
  backupCandidate=metadata.backupCandidate,rules=after})))
end

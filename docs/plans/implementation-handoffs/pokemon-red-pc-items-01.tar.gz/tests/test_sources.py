import hashlib,json,re,unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]
class PrimarySourceTests(unittest.TestCase):
 def text(self,name):return(P/'references'/name).read_text()
 def test_complete_consumed_bytes_match_pins(self):
  pins=json.loads((P/'source-pins.json').read_text());self.assertEqual(pins['revision'],'af519899719f0754965776faac0e836a3b906e6d')
  for name,record in pins['files'].items():self.assertEqual(hashlib.sha256((P/'references'/name).read_bytes()).hexdigest(),record['sha256'],name)
 def test_original_capacity_literal_vectors(self):
  s=self.text('constants/menu_constants.asm');self.assertRegex(s,r'DEF BAG_ITEM_CAPACITY\s+EQU 20');self.assertRegex(s,r'DEF PC_ITEM_CAPACITY\s+EQU 50')
 def test_new_game_potion_is_in_pc_not_bag(self):
  s=self.text('engine/movie/oak_speech/oak_speech.asm');start=s.index('predef InitPlayerData2');segment=s[start:start+250]
  positions=[segment.index(x)for x in ['ld hl, wNumBoxItems','ld a, POTION','ld a, 1','call AddItemToInventory']];self.assertEqual(positions,sorted(positions));self.assertNotIn('wNumBagItems',segment)
  self.assertIn('ld hl, wNumBoxItems\n\tcall InitializeEmptyList',self.text('engine/movie/oak_speech/init_player_data.asm'))
 def test_first_full_overflow_reject_is_before_storing99(self):
  s=self.text('engine/items/inventory.asm');s=s[s.index('\n.increaseItemQuantity ;'):s.index('\n.increaseItemQuantityFailed\n')]
  positions=[s.index(x)for x in ['cp 100','sub 99','ld a, d','jr z, .increaseItemQuantityFailed','ld a, 99','ld [hli], a']];self.assertEqual(positions,sorted(positions))
 def test_removal_uses_selected_physical_index_not_species_total(self):
  s=self.text('engine/items/inventory.asm');s=s[s.index('RemoveItemFromInventory_::'):]
  self.assertIn('ld a, [wWhichPokemon] ; index (within the inventory)',s);self.assertIn('sla a',s);self.assertIn('sub e',s);self.assertIn('loop to move up the following slots',s)
 def test_key_storage_and_hm_toss_order(self):
  s=self.text('engine/menus/players_pc.asm');deposit=s[s.index('PlayerPCDeposit:'):s.index('PlayerPCWithdraw:')]
  self.assertIn('call IsKeyItem',deposit);self.assertIn('jr nz, .next',deposit)
  self.assertLess(deposit.index('call AddItemToInventory'),deposit.index('call RemoveItemFromInventory'))
  toss=self.text('engine/items/item_effects.asm');toss=toss[toss.index('TossItem_::'):toss.index('\n.tooImportantToToss\n',toss.index('TossItem_::'))]
  self.assertIn('call IsItemHM',toss);self.assertIn('call IsKeyItem_',toss);self.assertIn('call RemoveItemFromInventory',toss)
 def test_source_quantity_starts1_wraps_and_b_cancels(self):
  s=self.text('home/list_menu.asm');s=s[s.index('DisplayChooseQuantityMenu::'):]
  for token in ['initialize current quantity to 0','jp .incrementQuantity','wrap to 1','wrap to the max quantity','bit B_PAD_B']:
   self.assertIn(token,s)
 def test_original_bedroom_opens_personal_service_not_pokemon_boxes(self):
  s=self.text('engine/events/hidden_events/reds_room.asm');self.assertIn('OpenRedsPC:',s);self.assertIn('script_players_pc',s)
  self.assertIn('hidden_event  0,  1, OpenRedsPC, SPRITE_FACING_UP',self.text('data/events/hidden_events.asm'))
 def test_true_process_recipe_has_one_seed_only_and_no_later_fixture(self):
  s=json.loads((P/'scenarios/potion-restart.json').read_text());self.assertEqual(len(s['processes']),2);self.assertTrue(s['processes'][1]['restart'])
  commands=[c for group in s['processes']for request in group['requests']for c in request]
  fixtures=[c for c in commands if isinstance(c,dict)and c.get('op')=='fixture'];self.assertEqual(fixtures,[{'op':'fixture','options':{'seed':42}}])
  self.assertIn('shot red-pc-title-continue',commands);self.assertIn('shot red-pc-saved-dialog',commands);self.assertIn('shot red-pc-no-regenerated-potion',commands)
if __name__=='__main__':unittest.main()

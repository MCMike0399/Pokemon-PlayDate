from pathlib import Path
base=Path('/private/tmp/pokemon-brock-integration-02');p=Path(__file__).parent
for rel in ['Source/domain/gameSession.lua','Source/domain/sessionCodec.lua','Source/game/context.lua','Source/game/pcState.lua','Source/world/pcTerminals.lua']:
 out=p/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((base/rel).read_bytes())
def edit(rel,old,new):
 f=p/'Source'/rel;s=f.read_text();assert s.count(old)==1,(rel,old);f.write_text(s.replace(old,new))
edit('domain/gameSession.lua','storage=Storage(),inventory=Inventory(deps.itemDefinitions),','storage=Storage(),inventory=Inventory(deps.itemDefinitions),itemStorage=ItemStorage(deps.itemDefinitions),')
f=p/'Source/domain/gameSession.lua';f.write_text(f.read_text()+'''
-- Item PC owns physical stacks separately from Pokémon boxes and the bag.
function GameSession:itemStorage()return state[self].itemStorage end
function GameSession:selectPCItem(operation,index)return PCItems.prepare(self,operation,index)end
function GameSession:resolvePCItem(request,quantity,decision)return PCItems.resolve(self,request,quantity,decision)end
''')
edit('domain/sessionCodec.lua','inventory=true,rng=true,worldMotion=true})','inventory=true,rng=true,worldMotion=true,itemStorage=true})')
edit('domain/sessionCodec.lua','    return {deps=deps,data=data,intro=intro,','''    -- Old valid schema1 has no provenance for an initial Potion withdrawal.
    -- Missing itemStorage migrates EMPTY, never an inferred reward/regrant.
    local itemStorage=ItemStorage.normalize(deps.itemDefinitions,data.itemStorage or {version=1,slots={}})
    assert(data.itemStorage~=false,"malformed item storage record")
    ItemStorage.checkUnique(deps.itemDefinitions,data.inventory,itemStorage)
    return {itemStorage=itemStorage,deps=deps,data=data,intro=intro,''')
edit('domain/sessionCodec.lua','storage=assert(current.storage:toData(unique)),inventory=current.inventory:toData()}','storage=assert(current.storage:toData(unique)),inventory=current.inventory:toData(),itemStorage=current.itemStorage:toData()}')
edit('domain/sessionCodec.lua','local session=GameSession._restore(prepared.deps,{party=party,storage=storage,inventory=inventory,intro=prepared.intro,','local session=GameSession._restore(prepared.deps,{party=party,storage=storage,inventory=inventory,itemStorage=assert(ItemStorage.fromData(prepared.deps.itemDefinitions,prepared.itemStorage)),intro=prepared.intro,')
edit('game/context.lua','    assert(session:inventory():credit(3000)) -- pinned Blue InitPlayerData START_MONEY.','''    assert(session:inventory():credit(3000)) -- pinned Blue InitPlayerData START_MONEY.
    -- OakSpeech places one Potion in the item PC, not in the bag. This freshly
    -- constructed model has not been published; loading never calls newModel.
    session:itemStorage():_prepareCommit({version=1,slots={{id="potion",quantity=1}}})()''')
edit('game/pcState.lua','        if index==1 then self:storageMenu()','        if index==1 then self:storageMenu()\n        elseif index==2 then assert(ItemPCState.open(self.game,{parent=self}))')
edit('world/pcTerminals.lua','    local id=terminals[position.zone_id]','''    -- Original source OpenRedsPC is relocated to the existing authored PC tile;
    -- geometry/art remain unchanged. Bedroom PC opens only the personal service.
    if position.zone_id=="reds_house_2f"and position.x==7 and position.y==3 and position.facing=="up"then
        return {id="pokered:REDS_HOUSE_2F:hidden:1",zone_id=position.zone_id,x=7,y=2,personal=true}
    end
    local id=terminals[position.zone_id]''')
edit('world/pcTerminals.lua','    if not terminal or not machine:get("pc") then return false end','''    if not terminal then return false end
    if terminal.personal then return ItemPCState.open(game,{terminal_id=terminal.id})end
    if not machine:get("pc")then return false end''')

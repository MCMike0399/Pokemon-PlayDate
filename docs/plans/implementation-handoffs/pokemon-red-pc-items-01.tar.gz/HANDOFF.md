# RED'S PC item storage 01

Private packet against current `/private/tmp/pokemon-brock-integration-02` (home/lead+power, updated sessionBridge checkpoint assertions). No live Source/host writes, Simulator process or SDK Data access by this worker.

Apply only five guarded shared hunks in patches/Source: gameSession (one retained-owner field plus three appended methods), sessionCodec (optional itemStorage schema), context (new-game-only PC Potion initialization), pcState (RED service branch), pcTerminals (authored bedroom PC). Install four new files listed in manifest. Do not overwrite unrelated whole session/controller files. Root owns import/register and diagnostics deltas: patches/main-root-hook.patch imports domain/itemStorage and domain/pcItems before gameSession, imports game/itemPCState and dev/itemPCContracts, registers itemPC + red-pc-items contract group. Optional diagnostics `item_pc` and `session.item_storage` are applied by the private validator; preserve all current other hooks.

## Original source and explicit policy

Pinned pret/pokered revision af519899719f0754965776faac0e836a3b906e6d. All11 consumed files are copied with SHA256 in source-pins.json and independently checked against archive SHA e571972fc926dcb65d94fc989299d38109590aa945ed657bf215eac8561afd05. No ROM.

- menu_constants.asm: bag20 rows / PC50 rows. inventory.asm:99 per row; first matching row merges; overflow can split into a later duplicate/new physical row. When already full, FIRST matching overflow fails immediately even if a later duplicate has room. Full50 first98+1 succeeds; first99+1 fails despite later1. Detached plans preserve this exact ordering atomically. Existing broad Inventory.add behavior is unchanged; only these transfers use the original add routine's order.
- RemoveItemFromInventory indexes the selected physical row (wWhichPokemon), then compacts only if emptied. Duplicate99+1 is not one aggregated stack. Both directions and toss respect that row's quantity.
- players_pc.asm allows key/HM storage and withdrawal at quantity1. Ordinary quantities start1, wrap within selected stack, B cancels; deposit/withdraw commit on quantity A. Toss asks YES/NO and refuses key/HM. Capacity check precedes source removal. Native UI retains these choices in a400x240 layout using the existing PC font/menu primitives.
- OakSpeech initializes lists then places Potion1 into wNumBoxItems, not the bag. Production newModel now initializes only its unpublished new PC owner with Potion1 alongside existing initial3000 money. Generic dependency-injected GameSession starts with an empty PC (no required potion definition). All actual new-game/seed-reset paths pass through newModel. No automatic bag grant.
- Hidden REDS_HOUSE_2F event at source player(0,1), UP invokes OpenRedsPC/script_players_pc directly. Existing protected authored bedroom relocates this interaction to player(7,3), UP at its unchanged PC tile(7,2); no room pixels/geometry changed. Center generic PC still opens Someone/Bill Pokémon service; RED'S PC pushes the same personal item overlay. Oak's service remains unchanged/unimplemented.

## Domain and persistence

ItemStorage owns strict `{version=1,slots=[{id,quantity},...]}` data, known IDs, bounded50 rows/1..99 quantities, unique quantity1 key items. Bag/PC aggregate save rejects duplicate ownership of a key/HM. `session:itemStorage()` retains identity across transfers.

`session:selectPCItem(operation,index)` -> opaque one-shot request + defensive selected-row metadata. Captures exact source index/ID/quantity and complete bag/PC values including bag money. `resolvePCItem(request,quantity,'confirm'|'cancel')` validates owner/unspent request/unchanged containers/row quantity, plans detached source removal and destination add, validates both candidates, then commits retained bag and PC objects. PC assignment closure is fully prepared before bag commit; no callbacks, random draws or throwing validation after first assignment. Wrong owner, invalid/stale request, cancelled/committed request, quantity/stack/capacity failure leave both unchanged. Failed requests are terminal; retry selects a fresh row. No flags/economy/party/held/world/actor/RNG changes.

SessionCodec1 gains optional itemStorage version1. Missing legacy record migrates EMPTY; absence cannot establish whether an earlier player withdrew/used a Potion, so no inferred grant or bag adjustment. Present malformed records reject, including version/unknown keys/rows/IDs/qty/cross-container key duplicates. Decode constructs that exact owner; repeated save/load never calls new-game initialization. Existing SaveStore schema/checksums/two-slot corruption/refusal/recovery machinery remains authoritative. No request/PC overlay is persisted; ordinary save remains settled-world-only.

## Verification and native jobs

Host9/9 source/pin/recipe checks PASS,0skips; Python compile PASS. SDK3.1.2 compile-only contracts and two-process recipe PASS; all9 Source overlays match compiled staged Source exactly. These are compile results, NOT runtime acceptance.

```
python3 -m unittest discover -s /private/tmp/pokemon-red-pc-items-01/tests -v
python3 /private/tmp/pokemon-red-pc-items-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-red-pc-compile-final
```

Root-only jobs after review, serialized with all other Simulator work:

```
python3 /private/tmp/pokemon-red-pc-items-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-red-pc-native-01 --execute
python3 /private/tmp/pokemon-red-pc-items-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-red-pc-potion-restart-01 --case potion-restart --execute
```

Eighteen SDK cases are declared: actual new-game PC Potion/empty bag; both duplicate99+1 physical directions; exact full50 ordering; fullPC/fullbag failure and retry; key/HM moves/toss refusal; invalid qty; owner/cancel/reuse; changed bag/money/PC stale; retained owners/both streams/flags/money; old schema1 empty migration/repeated decode; malformed present PC; bedroom terminal/facing; native menu/quantity/cancel/withdraw/toss NO/stale callback; unchanged generic Pokémon service and unsafe overlay-save refusal; actual isolated SDK filesystem corruption of newest PC slot with valid checksum falls back to prior good slot and refuses silent overwrite. Full existing SDK tests remain enabled, including root's corrected sessionBridge assertions.

Native contract images: item-pc-main, item-pc-withdraw-list, item-pc-withdraw-quantity, item-pc-withdraw-result, item-pc-toss-confirm. Root should inspect clipping and preservation of underlying art.

potion-restart.json uses the existing runner process owner without any new dispatcher/framework. First process uses ONLY an initial seed fixture, then actual ten opening-dialog A presses, walks right2/UP to original authored PC, cancels a quantity, reselects/withdraws Potion1, exits, selects real SAVE/YES and records ready saved dialog/world. Second fresh process captures Title, selects actual Continue, asserts bag Potion1, reopens PC and verifies empty withdrawal/no regenerated reward. No subsequent fixture, forced outcomes, copied saves, teleport or direct inventory grant. Eight requested PNGs and per-process request/result/build/session/PID evidence remain normal strict runner artifacts. This recipe has compiled/schema-validated only; root owns all actual runtime proof.

Known limits: original PC on/off/withdraw sounds are not implemented by this packet; broader audio remains separate. No Oak PC, item use within PC, Pokémon-storage changes, Fly/teaching extension, new art or full-campaign claims. Existing original254/256 move grind and other campaign work remain separate. This packet does not add a backward import of real Game Boy save files.

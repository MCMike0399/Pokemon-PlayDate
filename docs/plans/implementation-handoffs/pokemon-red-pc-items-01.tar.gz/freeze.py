from pathlib import Path
import hashlib,json,difflib,shutil
p=Path(__file__).parent;base=Path('/private/tmp/pokemon-brock-integration-02');ref=Path('/private/tmp/pokered-af519899719f0754965776faac0e836a3b906e6d')
shared=['Source/domain/gameSession.lua','Source/domain/sessionCodec.lua','Source/game/context.lua','Source/game/pcState.lua','Source/world/pcTerminals.lua']
new=['Source/domain/itemStorage.lua','Source/domain/pcItems.lua','Source/game/itemPCState.lua','Source/dev/itemPCContracts.lua']
for rel in shared:
 out=p/'patches'/Path(rel).with_suffix('.patch');out.parent.mkdir(parents=True,exist_ok=True)
 out.write_text(''.join(difflib.unified_diff((base/rel).read_text().splitlines(True),(p/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
main=(base/'Source/main.lua').read_text();main=main.replace('import "domain/gameSession"','import "domain/itemStorage"\nimport "domain/pcItems"\nimport "domain/gameSession"')
main=main.replace('game = GameContext(','import "game/itemPCState"\nimport "dev/itemPCContracts"\nContracts.register("red-pc-items",ItemPCContracts.run)\n\ngame = GameContext(')
main=main.replace('machine:register("pc", PCState(game))','machine:register("pc", PCState(game))\nmachine:register("itemPC",ItemPCState(game))')
(p/'patches/main-root-hook.patch').write_text(''.join(difflib.unified_diff((base/'Source/main.lua').read_text().splitlines(True),main.splitlines(True),fromfile='a/Source/main.lua',tofile='b/Source/main.lua')))
files=['constants/menu_constants.asm','engine/items/inventory.asm','engine/menus/players_pc.asm','home/list_menu.asm','engine/movie/oak_speech/oak_speech.asm','engine/movie/oak_speech/init_player_data.asm','data/events/hidden_events.asm','engine/events/hidden_events/reds_room.asm','engine/items/item_effects.asm','home/names.asm','data/items/key_items.asm']
pins={'archive_sha256':'e571972fc926dcb65d94fc989299d38109590aa945ed657bf215eac8561afd05','revision':'af519899719f0754965776faac0e836a3b906e6d','files':{}}
for rel in files:
 out=p/'references'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ref/rel,out)
 pins['files'][rel]={'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'url':'https://github.com/pret/pokered/blob/'+pins['revision']+'/'+rel}
(p/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
m={'schema':1,'packet':'red-pc-items-01','base':'/private/tmp/pokemon-brock-integration-02','base_files':{rel:hashlib.sha256((base/rel).read_bytes()).hexdigest()for rel in shared+['Source/main.lua','Source/dev/diagnostics.lua','Source/data/maps.lua','Source/dev/sessionBridgeContracts.lua']},'shared_patches':shared,'new_files':new,'overlay_files':shared+new,'files':{}}
for f in sorted(p.rglob('*')):
 if f.is_file()and f.name!='manifest.json'and'__pycache__'not in f.parts:m['files'][f.relative_to(p).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
(p/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest())

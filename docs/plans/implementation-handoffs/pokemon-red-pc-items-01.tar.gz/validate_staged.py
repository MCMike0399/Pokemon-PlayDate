#!/usr/bin/env python3
"""Compile-only by default. Root alone may use --execute for actual SDK proof."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--case',choices=['contracts','potion-restart'],default='contracts');a=p.parse_args()
stage=Path(__file__).resolve().parent;project=a.project.resolve();sys.path.insert(0,str(project))
from tools.harness import run as runner
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'manifest.json').read_text());original=runner.prepare

def prepare(project,sdk,output,session):
 for rel,digest in manifest['base_files'].items():assert hashlib.sha256((project/rel).read_bytes()).hexdigest()==digest,'base Source changed: '+rel
 for rel,digest in manifest['files'].items():assert hashlib.sha256((stage/rel).read_bytes()).hexdigest()==digest,'packet changed: '+rel
 metadata=original(project,sdk,output,session)
 for rel in manifest['overlay_files']:
  destination=output/rel;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/rel,destination)
 main=output/'Source/main.lua';text=main.read_text();marker='import "domain/gameSession"';assert text.count(marker)==1
 text=text.replace(marker,'import "domain/itemStorage"\nimport "domain/pcItems"\n'+marker)
 marker='game = GameContext(';assert text.count(marker)==1
 text=text.replace(marker,'import "game/itemPCState"\nimport "dev/itemPCContracts"\nContracts.register("red-pc-items",ItemPCContracts.run)\n\n'+marker)
 marker='machine:register("pc", PCState(game))';assert text.count(marker)==1
 main.write_text(text.replace(marker,marker+'\nmachine:register("itemPC",ItemPCState(game))'))
 diagnostics=output/'Source/dev/diagnostics.lua';text=diagnostics.read_text();marker='        performance={';assert text.count(marker)==1
 text=text.replace(marker,'        item_pc=root:get("itemPC") and root:get("itemPC"):getSnapshot() or {phase="closed"},\n'+marker)
 marker='session = {party = party, inventory = inventory,';assert text.count(marker)==1
 diagnostics.write_text(text.replace(marker,'session = {item_storage=game.session:itemStorage():toData(),party = party, inventory = inventory,'))
 pdx=output/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(metadata['original_pdxinfo'])
 metadata['source_sha256']=runner.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted((output/'Source').rglob('*'))if x.is_file()and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
 pdx.write_text(generated);lines=[]
 for key in ['protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir']:
  value=metadata[key];lines.append('    '+key+' = '+('true'if value is True else json.dumps(value))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(lines)+'\n}\n')
 metadata['compiled_source_sha256']=runner.fingerprint(output,exclude_generated=False);metadata['red_pc_packet_sha256']=hashlib.sha256((stage/'manifest.json').read_bytes()).hexdigest()
 with(output/'red-pc-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
runner.prepare=prepare;runner.PROJECT=project
try:code=runner.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(stage/'scenarios'/(a.case+'.json')),commands=[],build_only=not a.execute,timeout=90,ready_timeout=20,max_frames=1800))
finally:runner.prepare=original
raise SystemExit(code)

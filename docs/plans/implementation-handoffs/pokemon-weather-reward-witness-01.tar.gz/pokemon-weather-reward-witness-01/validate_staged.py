import hashlib,importlib.util,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_qualification',Path('/private/tmp/pokemon-rewards-mutation-qualification-01/validate_staged.py'));q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
previous=q.m.apply_hunks
def apply(root,items):
 previous(root,items)
 if any('_registerFaints'in h['new']for i in items for h in i['hunks']):
  rel='Source/dev/weatherRewardWitness.lua';target=root/rel;assert not target.exists();target.write_bytes((P/rel).read_bytes())
  main=root/'Source/main.lua';body=main.read_text();anchor='game = GameContext(';assert body.count(anchor)==1;main.write_text(body.replace(anchor,'import "dev/weatherRewardWitness"\nContracts.register("weather-reward-witness",WeatherRewardWitness.run)\n\n'+anchor,1))
q.m.apply_hunks=apply
if __name__=='__main__':
 for rel,sha in json.loads((P/'manifest.json').read_text())['files'].items():assert hashlib.sha256((P/rel).read_bytes()).hexdigest()==sha
 if '--with-residual'not in sys.argv:sys.argv+=['--with-residual','/private/tmp/pokemon-residual-reward-correction-01']
 raise SystemExit(q.m.main())

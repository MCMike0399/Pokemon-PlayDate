"""Synthetic host artifact validator challenges, never a native gameplay proof."""
import hashlib,importlib.util,json,re,shutil,tempfile,unittest
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('q',ROOT/'tools/qualify_map.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
class StrictMapArtifacts(unittest.TestCase):
 def fixture(self,folder):
  output=Path(folder);source=output/'Source';(source/'data').mkdir(parents=True);(source/'world/sprites').mkdir(parents=True);(output/'frames').mkdir()
  for rel,path in [('data/townMap.json',ROOT/'Source/data/townMap.json'),('world/sprites/red.lua',Path.cwd()/'Source/world/sprites/red.lua')]:shutil.copyfile(path,source/rel)
  manifest={rel:hashlib.sha256((source/rel).read_bytes()).hexdigest()for rel in ['data/townMap.json','world/sprites/red.lua']};(output/'source-manifest.json').write_text(json.dumps(manifest))
  identity={'build_id':'host-fixture','session_id':'host-fixture','compiled_source_sha256':'synthetic-validator-only','sdk_version':'host-fixture'}
  (output/'build.json').write_text(json.dumps(identity));(output/'run.json').write_text(json.dumps(dict(identity,simulator_pid=123)))
  request=dict(identity,id='00001-fixture',commands=['contracts']);result=dict(identity,id=request['id'],status='ok',results=[{'contracts':{'suites':[{'id':'brock-field-items','ok':True,'passed':8,'failed':0}]}}])
  (output/'00001-request.json').write_text(json.dumps(request));(output/'00001-result.json').write_text(json.dumps(result))
  data=json.loads((source/'data/townMap.json').read_text());red=(source/'world/sprites/red.lua').read_text();grid=re.findall(r'"([.#12]{16})"',re.search(r'\bdown\s*=\s*\{([^}]+)',red)[1])
  for filename,selected in [('field-town-map-forest.png','VIRIDIAN_FOREST'),('field-town-map-pallet-selected.png','PALLET_TOWN')]:
   pixels,shade=q.raster(data);q.marker(pixels,data['cursor'],data['locations'][selected],shade);q.marker(pixels,grid,data['locations']['VIRIDIAN_FOREST'],shade)
   image=Image.new('RGBA',(400,240),'white');region=Image.new('RGBA',(160,144));region.putdata([(v,v,v,255)for row in pixels for v in row]);image.paste(region,(12,48));image.save(output/'frames'/filename)
  Image.new('RGBA',(400,240),'white').save(output/'frames/field-rope-arrival.png');return output
 def test_whole_map_pixels_and_request_result_pid_identity_are_concrete(self):
  with tempfile.TemporaryDirectory()as folder:
   output=self.fixture(folder);q.qualify(output,'contracts');r=json.loads((output/'field-map-qualification.json').read_text())
   self.assertTrue(r['ok']);self.assertEqual([m['checked_pixels']for m in r['maps']],[23040]*2)
   self.assertEqual(r['executions'][0]['request_sha256'],hashlib.sha256((output/'00001-request.json').read_bytes()).hexdigest());self.assertEqual(r['session_id'],'host-fixture')
 def test_missing_corrupt_wrong_size_and_rgb_or_alpha_drift_fail_strictly(self):
  for defect in ['missing','corrupt','size','rgb','alpha']:
   with self.subTest(defect=defect),tempfile.TemporaryDirectory()as folder:
    output=self.fixture(folder);path=output/'frames/field-town-map-forest.png'
    if defect=='missing':path.unlink()
    elif defect=='corrupt':path.write_bytes(b'not a PNG')
    elif defect=='size':Image.new('RGBA',(399,240),'white').save(path)
    else:
     with Image.open(path)as original:image=original.convert('RGBA')
     rgba=image.getpixel((20,60));image.putpixel((20,60),(255-rgba[0],rgba[1],rgba[2],255)if defect=='rgb'else(rgba[0],rgba[1],rgba[2],0));image.save(path)
    with self.assertRaises((AssertionError,OSError)):q.qualify(output,'contracts')
 def test_stale_archive_ignored_but_duplicate_executions_and_identity_drift_fail(self):
  for defect in ['stale','duplicate','identity','source']:
   with self.subTest(defect=defect),tempfile.TemporaryDirectory()as folder:
    output=self.fixture(folder)
    if defect=='stale':shutil.copyfile(output/'00001-result.json',output/'stale-result.json');q.qualify(output,'contracts');continue
    if defect=='duplicate':
     for suffix in ['request','result']:shutil.copyfile(output/f'00001-{suffix}.json',output/f'00002-{suffix}.json')
    elif defect=='identity':
     path=output/'00001-request.json';record=json.loads(path.read_text());record['session_id']='old-session';path.write_text(json.dumps(record))
    else:(output/'Source/data/townMap.json').write_text('{}')
    with self.assertRaises(AssertionError):q.qualify(output,'contracts')
if __name__=='__main__':unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Default compile-only. Only root may request --execute under runner ownership."""
import argparse,hashlib,importlib.util,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--case',choices=['contracts','daisy-map-restart','rope-input'],default='contracts');p.add_argument('--execute',action='store_true');a=p.parse_args()
stage=Path(__file__).resolve().parent;project=a.project.resolve();sys.path.insert(0,str(project))
from tools.harness import run as runner,journeys
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'manifest.json').read_text());original=runner.prepare;oldJourney=journeys.run
if a.execute:
 from PIL import Image # requested exact visual qualification must preflight before launch

def prepare(project,sdk,output,session):
 for rel,digest in manifest['base_files'].items():assert hashlib.sha256((project/rel).read_bytes()).hexdigest()==digest,'base Source changed: '+rel
 for rel,digest in manifest['files'].items():assert hashlib.sha256((stage/rel).read_bytes()).hexdigest()==digest,'field packet changed: '+rel
 metadata=original(project,sdk,output,session)
 for rel in manifest['overlay_files']:
  destination=output/rel;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/rel,destination)
 main=output/'Source/main.lua';text=main.read_text();marker='game = GameContext('
 assert text.count(marker)==1
 text=text.replace(marker,'import "game/townMapState"\nimport "game/fieldItems"\nimport "dev/fieldItemContracts"\nContracts.register("brock-field-items",FieldItemContracts.run)\n\n'+marker)
 marker='machine:register("bag", BagState(game))';assert text.count(marker)==1
 text=text.replace(marker,marker+'\nmachine:register("townMap",TownMapState(game))');main.write_text(text)
 diagnostics=output/'Source/dev/diagnostics.lua';text=diagnostics.read_text();marker='        performance={';assert text.count(marker)==1
 text=text.replace(marker,'        town_map=root:get("townMap") and root:get("townMap"):getSnapshot() or {phase="closed"},\n        field_item=game.lastFieldItem or {kind="none"},\n'+marker);diagnostics.write_text(text)
 pdx=output/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(metadata['original_pdxinfo'])
 metadata['source_sha256']=runner.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted((output/'Source').rglob('*'))if x.is_file()and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
 pdx.write_text(generated);lines=[]
 for key in ['protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir']:
  value=metadata[key];lines.append('    '+key+' = '+('true'if value is True else json.dumps(value))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(lines)+'\n}\n')
 metadata['compiled_source_sha256']=runner.fingerprint(output,exclude_generated=False);metadata['field_items_packet']=manifest['packet'];metadata['field_items_packet_sha256']=hashlib.sha256((stage/'manifest.json').read_bytes()).hexdigest()
 with(output/'field-items-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata

def journey(client,scenario,evidence,**kwargs):
 if scenario.get('journey',{}).get('case')=='field-rope-input':
  spec=importlib.util.spec_from_file_location('field_rope_input',stage/'jobs/rope_input.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  return module.run(client,scenario,evidence,**kwargs)
 return oldJourney(client,scenario,evidence,**kwargs)
runner.prepare=prepare;runner.PROJECT=project;journeys.run=journey
try:
 code=runner.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(stage/'scenarios'/f'{a.case}.json'),commands=[],build_only=not a.execute,timeout=90,ready_timeout=20,max_frames=1800))
finally:runner.prepare=original;journeys.run=oldJourney
if code==0 and a.execute:
 spec=importlib.util.spec_from_file_location('field_map_oracle',stage/'tools/qualify_map.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 try:module.qualify(Path(a.output),a.case)
 except BaseException as error:
  output=Path(a.output);atomic_json(output/'field-map-qualification.json',{'schema':1,'ok':False,'case':a.case,'error':str(error)})
  outcome=json.loads((output/'outcome.json').read_text());outcome.update(runtime_ok_before_field_map=outcome.get('ok'),ok=False,field_map_qualification='failed');atomic_json(output/'outcome.json',outcome)
  raise
raise SystemExit(code)

"""Exact independent source-grid composition; no alpha/getbbox shortcut."""
import hashlib,json,re
from pathlib import Path

def raster(data):
 patterns={'1':[0xBB,0xFF,0xEE,0xFF,0xBB,0xFF,0xEE,0xFF],'2':[0x55,0xAA,0x55,0xAA,0x55,0xAA,0x55,0xAA]}
 def shade(code,x,y):return (255 if code=='.'else 0)if code in '.#'else(255 if patterns[code][y%8]>>(7-x%8)&1 else 0)
 pixels=[]
 for y in range(144):
  row=[]
  for x in range(160):
   index=data['cells'][y//8*20+x//8];row.append(shade(data['tiles'][index][y%8][x%8],x,y%144))
  pixels.append(row)
 return pixels,shade

def marker(pixels,grid,point,shade):
 outside=set();queue=[(x,y)for x in range(16)for y in range(16)if x in (0,15)or y in (0,15)]
 while queue:
  x,y=queue.pop()
  if not(0<=x<16 and 0<=y<16)or(x,y)in outside or grid[y][x]!='.':continue
  outside.add((x,y));queue.extend([(x-1,y),(x+1,y),(x,y-1),(x,y+1)])
 for y in range(16):
  for x in range(16):
   if(x,y)not in outside:pixels[point['y']*8+8+y][point['x']*8+16+x]=shade(grid[y][x],x,y)

def qualify(output,case):
 from PIL import Image
 source=output/'Source';manifest=json.loads((output/'source-manifest.json').read_text())
 for rel in ['data/townMap.json','world/sprites/red.lua']:
  assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==manifest[rel],'identified staged source changed'
 d=json.loads((source/'data/townMap.json').read_text());red=(source/'world/sprites/red.lua').read_text()
 grid=re.findall(r'"([.#12]{16})"',re.search(r'\bdown\s*=\s*\{([^}]+)',red)[1]);assert len(grid)==16
 cases=[]
 if case=='contracts':
  cases=[(output/'frames/field-town-map-forest.png','VIRIDIAN_FOREST','VIRIDIAN_FOREST'),(output/'frames/field-town-map-pallet-selected.png','VIRIDIAN_FOREST','PALLET_TOWN')]
  with Image.open(output/'frames/field-rope-arrival.png')as image:assert image.size==(400,240);image.load()
 elif case=='daisy-map-restart':
  cases=[(output/'processes'/f'{n:04d}'/'frames'/name,'PALLET_TOWN',selected)for n,name,selected in [(1,'field-map-before-save.png','PALLET_TOWN'),(1,'field-map-route1-selected.png','ROUTE_1'),(2,'field-map-after-continue.png','PALLET_TOWN')]]
 elif case=='rope-input':
  for name in ['field-rope-actual-shop-purchase','field-rope-yes-before','field-rope-actual-checkpoint-return']:
   with Image.open(output/'frames'/f'{name}.png')as image:assert image.size==(400,240);image.load()
 identity=json.loads((output/'build.json').read_text())
 for key in ['build_id','session_id','compiled_source_sha256','sdk_version']:assert identity.get(key),'missing build identity '+key
 evidence=[]
 folders=[output]if case!='daisy-map-restart'else[output/'processes'/'0001',output/'processes'/'0002']
 for folder in folders:
  for result_path in sorted(folder.glob('*-result.json')):
   if not re.fullmatch(r'[0-9]{5}-result.json',result_path.name):continue
   request_path=result_path.with_name(result_path.name.replace('-result.json','-request.json'))
   request=json.loads(request_path.read_text());result=json.loads(result_path.read_text())
   selected=False
   if case=='contracts':
    selected=any(any(suite.get('id')=='brock-field-items'for suite in row.get('contracts',{}).get('suites',[]))for row in result.get('results',[]))
   else:selected=any(isinstance(command,str)and command.startswith('shot field-')for command in request.get('commands',[]))
   if not selected:continue
   for key in ['id','build_id','session_id']:assert result.get(key)==request.get(key),'mismatched field proof '+key
   assert result.get('status')=='ok'and result['build_id']==identity['build_id']and result['session_id']==identity['session_id'],'failed/wrong identity field proof'
   evidence.append({'request':str(request_path.relative_to(output)),'request_sha256':hashlib.sha256(request_path.read_bytes()).hexdigest(),'result':str(result_path.relative_to(output)),'result_sha256':hashlib.sha256(result_path.read_bytes()).hexdigest(),'id':request['id']})
 if case=='contracts':assert len(evidence)==1,'requires exactly one native field contract execution; repeated artifacts not supported'
 else:assert evidence,'field input proof request missing'
 runtime=output/'run.json';assert runtime.is_file(),'runtime PID manifest missing'
 records=[]
 for path,current,selected in cases:
  pixels,shade=raster(d);marker(pixels,d['cursor'],d['locations'][selected],shade);marker(pixels,grid,d['locations'][current],shade)
  expected=[(v,v,v,255)for row in pixels for v in row]
  with Image.open(path)as image:
   assert image.size==(400,240),'wrong native frame size';actual=list(image.convert('RGBA').crop((12,48,172,192)).getdata())
  changed=sum(a!=b for a,b in zip(actual,expected));assert len(actual)==23040 and changed==0,f'{path.name}: {changed} native source-map RGBA pixels differ'
  records.append({'path':str(path.relative_to(output)),'checked_pixels':23040,'changed_pixels':changed,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 (output/'field-map-qualification.json').write_text(json.dumps({'schema':1,'ok':True,'case':case,'build_id':identity['build_id'],'session_id':identity['session_id'],'compiled_source_sha256':identity['compiled_source_sha256'],'sdk_version':identity['sdk_version'],'maps':records,'executions':evidence,'runtime_manifest_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'note':'whole exact source map rectangle, including both opaque marker bodies and transparent mask composition; no fractional resampling'},indent=2)+'\n')

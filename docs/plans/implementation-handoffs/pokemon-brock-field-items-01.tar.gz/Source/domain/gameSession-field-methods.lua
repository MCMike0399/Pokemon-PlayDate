-- Append-only hunk; no session constructor/codec/schema changes.
function GameSession:useEscapeRope(request) return FieldItems._commit(self,request) end

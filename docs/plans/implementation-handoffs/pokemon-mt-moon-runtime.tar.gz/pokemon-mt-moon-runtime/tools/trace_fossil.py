#!/usr/bin/env python3
"""Source geometry witness with actor occupancy, not runtime/campaign acceptance."""
import argparse,json
from collections import deque
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--candidate',required=True);p.add_argument('--output',required=True);a=p.parse_args();root=Path(a.candidate)
NAMES=('Route3','Route4','MtMoonPokecenter','MtMoon1F','MtMoonB1F','MtMoonB2F')
defs={n:json.loads((root/'maps'/f'{n}.json').read_text()) for n in NAMES};byid={d['id']:n for n,d in defs.items()};warps={}
for w in json.loads((root/'warps.json').read_text())['warps']:
 dst=byid[w['target_map_id']];warps[(byid[w['source_map_id']],w['source_x'],w['source_y'])]=(dst,w['target_x'],w['target_y']+(1 if dst=='Route4'else 0))
dirs={'up':(0,-1),'down':(0,1),'left':(-1,0),'right':(1,0)};facing={'SPRITE_FACING_'+k.upper():k for k in dirs}
start=('MtMoonB2F',13,8)
def trace(blocked):
 def good(n,x,y):
  d=defs[n];w,h=d['dimensions']['cells'];return 0<=x<w and 0<=y<h and d['collision'][y][x]==0 and(n,x,y)not in blocked
 def foot(n,x,y):
  d=defs[n];return d['grids'][d['tile_ids'][y][x]-1]['terrain']['foot_tile']
 def neighbors(node):
  n,x,y=node;d=defs[n];w,h=d['dimensions']['cells']
  if node in warps and good(*warps[node]):yield warps[node]
  for direction,(dx,dy)in dirs.items():
   tx,ty=x+dx,y+dy
   if good(n,tx,ty)and not any({foot(n,x,y),foot(n,tx,ty)}==set(pair)for pair in d['directional_rules']['forbidden_tile_pairs']):yield n,tx,ty
   for ledge in d['directional_rules']['ledges']:
    if facing.get(ledge['facing'])==direction and 0<=tx<w and 0<=ty<h and foot(n,x,y)==ledge['standing_foot_tile']and foot(n,tx,ty)==ledge['target_foot_tile']and good(n,x+2*dx,y+2*dy):yield n,x+2*dx,y+2*dy
  if n=='Route3'and y==0 and good('Route4',x-50,17):yield 'Route4',x-50,17
  if n=='Route4'and y==17 and good('Route3',x+50,0):yield 'Route3',x+50,0
 parents={start:None};q=deque([start])
 while q:
  at=q.popleft()
  for nxt in neighbors(at):
   if nxt not in parents:parents[nxt]=at;q.append(nxt)
 out=[]
 for x,y in ((12,7),(11,6),(12,5),(13,7),(14,6),(14,5),(13,5)):
  node=('MtMoonB2F',x,y);path=[];at=node
  if at in parents:
   while at is not None:path.append(at);at=parents[at]
   path.reverse()
  out.append({'cell':[x,y],'reachable':node in parents,'path':path})
 return {'occupied_cells':sorted(blocked),'reachable_count':len(parents),'target_witnesses':out}
allactors={(n,e['x'],e['y'])for n,d in defs.items()for e in d['events']['objects']}
fossils={('MtMoonB2F',12,6),('MtMoonB2F',13,6)}
# Source talk-only prepare has no approach steps. Actor12,8 stays in place;
# victory changes its persistent flag/receipt, not its position before choice.
result={'schema':1,'revision':'af519899719f0754965776faac0e836a3b906e6d','start':start,
 'flags':{'EVENT_BEAT_MT_MOON_EXIT_SUPER_NERD':True,'EVENT_GOT_DOME_FOSSIL':False,'EVENT_GOT_HELIX_FOSSIL':False},
 'source_actor_start':{'nerd':[12,8],'fossils':[[12,6],[13,6]],'mode':'talk-only; source script starts battle without MoveSprite; current TrainerEvents talk approach returns{}'},
 'all_original_actors_visible':trace(allactors),'conservative_all_other_actors_removed':trace(fossils),
 'after_dome_actor_removed_comparison':trace({('MtMoonB2F',13,6)}),
 'conclusion':'No softlock repair inferred from actor-free graph. Inspect explicit witnesses; native root witness still required.',
 'source_scripts':['scripts/MtMoonB2F.asm:MtMoonB2FDefaultScript','scripts/MtMoonB2F.asm:MtMoonB2FSuperNerdText','scripts/MtMoonB2F.asm:MtMoonB2FMoveSuperNerdScript']}
target=Path(a.output);assert not target.exists();target.write_text(json.dumps(result,indent=2)+'\n')
for name in ('all_original_actors_visible','conservative_all_other_actors_removed','after_dome_actor_removed_comparison'):print(name,[(x['cell'],x['reachable'])for x in result[name]['target_witnesses']])

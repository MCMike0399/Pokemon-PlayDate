"""Actual-input MtMoon recipes. Owned runner supplies Client/process/handshake.

Supplementary setup is always labeled. from-current never fixtures/teleports.
"""
import hashlib,json
from pathlib import Path
from tools.harness.brock_journey import BrockJourney,SourceGeometry,MAPS as PEWTER,REVISION
from tools.harness.journeys import DIRECTIONS,lookup
from tools.harness.protocol import ProtocolError,atomic_json
MAPS={'Route3':'pokered:ROUTE_3','Route4':'pokered:ROUTE_4','MtMoonPokecenter':'pokered:MT_MOON_POKECENTER','MtMoon1F':'pokered:MT_MOON_1F','MtMoonB1F':'pokered:MT_MOON_B1F','MtMoonB2F':'pokered:MT_MOON_B2F'}
NERD='pokered:MT_MOON_B2F:objects:1';SELLER='pokered:MT_MOON_POKECENTER:objects:4';BROCK='pokered:PEWTER_GYM:objects:1'
FOSSIL={'dome':('pokered:MT_MOON_B2F:objects:6','domeFossil','EVENT_GOT_DOME_FOSSIL'),'helix':('pokered:MT_MOON_B2F:objects:7','helixFossil','EVENT_GOT_HELIX_FOSSIL')}
class MoonJourney(BrockJourney):
    def reset(self,**options):
        if not self.config['name'].endswith('-supplementary'):raise ProtocolError('from-current journey forbids fixture reset')
        self.initializing=True;self.initialized=False;self.summary.update(natural=False,supplementary=True)
        try:return super().reset(**options)
        finally:self.initializing=False
    def occupied(self):
        result=super().occupied()
        for npc in self.state.get('npcs',[]):
            motion=npc.get('motion')
            if isinstance(motion,dict)and motion.get('phase')=='moving':result.add((motion['origin_x'],motion['origin_y']));result.add((motion['target_x'],motion['target_y']))
        return result
    def step(self,step):
        self.require(root='overworld',overworld='explore',**{'player.settled':True});before_zone=self.state['zone_id'];before=self.position()
        self.send('press '+step.direction,'wait '+('17'if step.kind=='ledge'else'9'));self.drain()
        actual=self.position();self.summary['navigation'].append({'zone':before_zone,'from':before,'direction':step.direction,'kind':step.kind,'expected':step.destination,'actual_zone':self.state['zone_id'],'actual':actual})
        if self.state['zone_id']==before_zone and actual!=step.destination:
            if actual==before and step.destination in self.occupied():return
            raise ProtocolError('unexpected source step result; no hidden retries: '+str(self.summary['navigation'][-1]))
    def dependencies(self):
        super().dependencies();manifest=json.loads((self.build_evidence/'source-manifest.json').read_text())
        def read(name):
            path=self.build_evidence/'Source/data/mtMoonSlice'/name
            if hashlib.sha256(path.read_bytes()).hexdigest()!=manifest.get('data/mtMoonSlice/'+name):raise ProtocolError('new compiled source geometry changed: '+name)
            return json.loads(path.read_text())
        self.moon_descriptors=read('descriptors.json')['maps'];self.moon_trainers=read('trainers.json')['trainers']
        self.source_trainers.update({d['id']:d for d in self.moon_trainers})
        for name,stable in MAPS.items():
            d=read(name+'.json');w,h=d['dimensions']['cells']
            if d['source_revision']!=REVISION or d['id']!=stable:raise ProtocolError('wrong source region revision/ID')
            feet=[[d['grids'][identity-1]['terrain']['foot_tile']for identity in row]for row in d['tile_ids']]
            grass=[[d['grids'][identity-1]['terrain']['grass']for identity in row]for row in d['tile_ids']]
            model=SourceGeometry(stable,d['collision'],grass,feet,d['directional_rules']['ledges'],d['directional_rules']['forbidden_tile_pairs'],d['events'])
            model.source_data=d;model.padding=0;model.counter_feet=tuple(d['tileset']['counter_tiles']);self.models[stable]=model
        self.summary['source_scope']={'maps':list(MAPS.values()),'inaccessible_indexed_trainer':'pokered:ROUTE_4:objects:2','source_revision':REVISION}
    def drain(self,stop_phase=None):
        if self.state.get('root')=='event'and lookup(self.state,'event.phase')in {'gift-confirm','fossil-confirm'}:
            if lookup(self.state,'event.phase')==stop_phase:return
            raise ProtocolError('paid gift/fossil requires explicit menu decision')
        return super().drain(stop_phase)
    def project(self,direction):
        model=self.model();point=self.position();header=next((c for c in getattr(model,'source_data',{}).get('connections',[])if c['direction']=={'up':'north','down':'south','left':'west','right':'east'}[direction]),None)
        if header:
            stable='pokered:'+header['target_map'];target=self.models.get(stable)
            if target is None:raise ProtocolError('unregistered source region exit remains blocked')
            delta=header['entry_lateral_adjustment_cells']
            result=(point[0]+delta,target.height-1 if direction=='up'else 0)if direction in {'up','down'}else(target.width-1 if direction=='left'else 0,point[1]+delta)
            if not target.inside(result)or target.collision[result[1]][result[0]]:raise ProtocolError('source connection arrival blocked')
            return stable,result
        return super().project(direction)
    def warp_projection(self,event):
        if self.state['zone_id']not in MAPS.values():return super().warp_projection(event)
        dest=event['destination'];constant='ROUTE_4'if dest['kind']=='last_outdoor_map'else dest['map']
        target=self.models['pokered:'+constant];arrival=target.events['warps'][dest['warp_index']-1]
        return target.name,(arrival['x'],arrival['y']+(1 if constant=='ROUTE_4'else 0))
    def setup(self,zone,entry,**extra):
        self.summary['natural']=False
        self.reset(intro='skip',opening=False,zone=zone,entry=entry,player_pokemon={'species':'squirtle','level':30},**extra)
        self.require(root='overworld',overworld='explore',**{'player.settled':True})
    def save_actual(self):
        self.send('press b');self.require(root='pause');self.pause_option('SAVE');self.send('press a');self.require(**{'pause.phase':'save'});self.select('pause.menu.selected',1);self.send('press a')
        self.require(root='dialog',**{'pause.lastSave.ok':True});self.dialog();self.require(root='overworld')
    def seller(self,accept=True):
        self.interact(source_id=SELLER,stop_phase='gift-confirm');self.require(root='event',**{'event.phase':'gift-confirm'})
        self.checkpoint('moon-seller-offer');before=(self.inventory()['money'],lookup(self.state,'party.count'),self.quantity('potion'),lookup(self.state,'rng.rolls'))
        self.send('press a'if accept else'press b');self.drain()
        if not accept:
            after=(self.inventory()['money'],lookup(self.state,'party.count'),self.quantity('potion'),lookup(self.state,'rng.rolls'))
            if before!=after:raise ProtocolError('declined gift changed money/party/rules')
        self.checkpoint('moon-seller-result')
    def gift_case(self):
        case=self.config.get('case','success');kwargs={}
        if case=='no-money':kwargs['inventory']={'money':499,'slots':[]}
        if case=='boxed':kwargs['party_pokemon']=[{'species':'squirtle','level':30}]+[{'species':'pidgey','level':5}for _ in range(5)]
        if case=='full-box-retry':
            kwargs['party_pokemon']=[{'species':'squirtle','level':30}]+[{'species':'pidgey','level':5}for _ in range(5)]
            kwargs['boxed_pokemon']=[{'species':'rattata','level':5}for _ in range(20)]
        # Choose only the explicit roster field; no synthetic battle/outcome.
        if 'party_pokemon'in kwargs:
            self.summary['natural']=False
            self.reset(intro='skip',opening=False,zone='kanto_mt_moon_center',entry={'x':3,'y':6,'facing':'up'},**kwargs)
        else:self.setup('kanto_mt_moon_center',{'x':3,'y':6,'facing':'up'},**kwargs)
        money=self.inventory()['money'];rolls=lookup(self.state,'rng.rolls');self.seller(case!='decline')
        if case in {'decline','no-money','full-box-retry'}:
            if self.inventory()['money']!=money or self.flag('EVENT_BOUGHT_MAGIKARP')or lookup(self.state,'rng.rolls')!=rolls:raise ProtocolError('failed seller transaction changed ownership/money/RNG')
        if case=='full-box-retry':
            self.navigate((13,4));self.face('up');self.send('press a');self.require(root='pc',**{'pc.phase':'top'})
            self.send('press a');self.select('pc.menu.selected',4);self.send('press a');self.require(**{'pc.phase':'box-confirm','pc.menu.selected':2})
            self.send('press up','press a');self.require(**{'pc.phase':'boxes'});self.send('press down','press a')
            self.require(**{'pc.phase':'result','pc.result.ok':True,'session.storage.active':2});self.checkpoint('moon-new-box-saved')
            self.send('press a','press b','press b');self.require(root='overworld');self.seller(True)
        if case in {'success','boxed','full-box-retry'}:
            if self.inventory()['money']!=money-500 or not self.flag('EVENT_BOUGHT_MAGIKARP'):raise ProtocolError('seller did not commit once')
            if case in {'boxed','full-box-retry'}:
                members=lookup(self.state,'session.storage.current')
                if not any(mon['species']=='magikarp'for mon in members):raise ProtocolError('gift did not reach authoritative current box')
            before=self.inventory()['money'];self.interact(source_id=SELLER);self.require(root='overworld')
            if self.inventory()['money']!=before:raise ProtocolError('repeat charged a second gift')
            self.save_actual()
    def fossil_case(self):
        choice=self.config.get('choice','dome');id,item,flag=FOSSIL[choice]
        x,y,facing=(12,7,'up')if choice=='dome'else(13,7,'up')
        kwargs={'trainer_flags':{NERD:True}}
        if self.config.get('full_bag'):
            ids=['antidote','awakening','burnHeal','calcium','carbos','direHit','elixir','escapeRope','ether','fullHeal','fullRestore','greatBall','guardSpec','hpUp','hyperPotion','iceHeal','iron','lemonade','maxElixir','maxEther']
            kwargs['inventory']={'money':3000,'slots':[{'id':key,'quantity':1}for key in ids]}
        self.setup('kanto_mt_moon_b2f',{'x':x,'y':y,'facing':facing},**kwargs)
        self.send('press a');self.drain(stop_phase='fossil-confirm');self.require(root='event',**{'event.phase':'fossil-confirm'});self.checkpoint('moon-fossil-confirm')
        if self.config.get('decline'):
            before=lookup(self.state,'rng.rolls');self.send('press b');self.drain()
            if self.flag(flag)or self.quantity(item)or lookup(self.state,'rng.rolls')!=before:raise ProtocolError('declined fossil changed model')
            return
        self.send('press a');self.dialog()
        if self.config.get('full_bag'):
            self.require(root='overworld')
            if self.flag(flag)or self.quantity(item):raise ProtocolError('full bag granted fossil')
            self.free_bag_slot('antidote')
            self.send('press a');self.drain(stop_phase='fossil-confirm');self.send('press a');self.dialog()
        self.require(root='event',**{'event.phase':'fossil-move'})
        self.send('record moon-fossil-motion 24');self.drain();self.require(root='overworld')
        other=FOSSIL['helix'if choice=='dome'else'dome']
        if not self.flag(flag)or self.quantity(item)!=1 or self.flag(other[2])or self.quantity(other[1]):raise ProtocolError('fossil exclusive commit failed')
        if any(n.get('source_event_id')in {FOSSIL['dome'][0],FOSSIL['helix'][0]}for n in self.state['npcs']):raise ProtocolError('claimed fossils reappeared')
        self.checkpoint('moon-fossil-taken');self.save_actual()
    def free_bag_slot(self,item):
        self.send('press b');self.require(root='pause');self.pause_option('ITEM');self.send('press a');self.require(root='bag',**{'bag.phase':'list'})
        slots=self.inventory()['slots'];index=next(i+1 for i,slot in enumerate(slots)if slot['id']==item)
        if slots[index-1]['quantity']!=1:raise ProtocolError('bounded full-slot retry fixture requires quantity1')
        self.select('bag.selected',index);self.send('press a');self.require(**{'bag.phase':'actions'})
        options=lookup(self.state,'bag.menu.options');self.select('bag.menu.selected',options.index('TOSS')+1);self.send('press a');self.require(**{'bag.phase':'toss'})
        self.select('bag.menu.selected',2);self.send('press a');self.require(**{'bag.phase':'message'})
        if self.quantity(item)!=0:raise ProtocolError('actual toss did not release one slot')
        self.send('press a','press b');self.require(root='overworld')
    def warp_exact(self,index):
        model=self.model();event=model.events['warps'][index-1];target,arrival=self.warp_projection(event)
        self.navigate((event['x'],event['y']),transition=target)
        if self.state['zone_id']!=target:
            if event['y']!=model.height-1 or model.source_data['tileset']['constant']=='OVERWORLD':raise ProtocolError('exact source step warp did not fire')
            self.send('press down','wait 20');self.drain()
        self.require(zone_id=target,**{'player.x':arrival[0],'player.y':arrival[1],'player.settled':True})
    def warp_cases(self):
        for name in MAPS:
            model=self.models[MAPS[name]]
            for event in model.events['warps']:
                point=(event['x'],event['y']);outside=model.source_data['tileset']['constant']=='OVERWORLD';edge=not outside and point[1]==model.height-1
                occupied={(e['x'],e['y'])for e in model.events['objects']}
                if edge:entry={'x':point[0],'y':point[1],'facing':'down'};direction='down'
                else:
                    choices=[]
                    for direction,(dx,dy)in DIRECTIONS.items():
                        origin=(point[0]-dx,point[1]-dy)
                        if model.inside(origin)and not model.collision[origin[1]][origin[0]]and origin not in occupied and origin not in model.warps:choices.append((direction,origin))
                    if not choices:raise ProtocolError('no source-valid adjacent warp fixture')
                    direction,origin=choices[0];entry={'x':origin[0],'y':origin[1],'facing':direction}
                self.setup(self.moon_descriptors[name]['key'],entry,trainer_flags={d['id']:True for d in self.moon_trainers})
                expected=self.warp_projection(event);label='moon-warp-'+name+'-'+str(event['source_index'])
                self.send('record '+label+' 35','press '+direction,'wait 24');self.drain();self.require(zone_id=expected[0],**{'player.x':expected[1][0],'player.y':expected[1][1],'player.settled':True})
                # A stationary post-arrival wait must not bounce back.
                self.send('wait 3');self.require(zone_id=expected[0]);self.checkpoint(label)
    def connected(self,fixture=True):
        if fixture:self.setup('kanto_pewter_city',{'x':38,'y':18,'facing':'right'},trainer_flags={BROCK:True},inventory={'money':3000,'slots':[{'id':'potion','quantity':10},{'id':'antidote','quantity':5},{'id':'ether','quantity':2}]})
        else:
            self.summary['natural']=True
            if self.state.get('root')=='title':self.send('press a');self.drain()
            self.require(root='overworld',zone_id=PEWTER['PewterCity'])
            if not self.defeated(BROCK):raise ProtocolError('from-current requires real completed Brock')
            self.center(PEWTER['PewterCity'])
        self.navigate((39,18));self.cross('right',MAPS['Route3'],(0,10))
        goals=[];model=self.model()
        for x in range(50,70):
            if not model.collision[0][x]and not self.models[MAPS['Route4']].collision[17][x-50]:goals.append((x,0))
        self.navigate(goals);point=self.position();self.cross('up',MAPS['Route4'],(point[0]-50,17))
        self.warp(MAPS['MtMoonPokecenter']);self.interact(source_id='pokered:MT_MOON_POKECENTER:objects:1',stop_phase='heal-confirm');self.send('press a');self.drain();self.require(**{'session.checkpoint.zone_id':MAPS['Route4']})
        self.warp(MAPS['Route4']);self.warp(MAPS['MtMoon1F'])
        self.warp_exact(4) # 1F17,11 -> B1F25,9, original main passage
        self.warp_exact(2) # B1F17,11 -> B2F25,9
        self.interact(source_id=NERD)
        if not self.defeated(NERD):raise ProtocolError('actual source SuperNerd was not defeated')
        id,item,flag=FOSSIL[self.config.get('choice','dome')]
        self.interact(source_id=id,stop_phase='fossil-confirm');self.checkpoint('moon-natural-fossil-confirm');self.send('press a');self.dialog()
        self.require(root='event',**{'event.phase':'fossil-move'});self.send('record moon-natural-fossil-motion 24');self.drain()
        if not self.flag(flag)or self.quantity(item)!=1:raise ProtocolError('source fossil was not committed')
        self.warp_exact(4) # B2F5,7 -> B1F23,3, original exit passage
        self.warp_exact(8) # B1F27,3 -> Route4 eastern mouth24,6
        self.checkpoint('moon-eastern-exit');self.require(zone_id=MAPS['Route4'])
        goals=[(89,y)for y in range(self.model().height)if not self.model().collision[y][89]];self.navigate(goals)
        before=self.position();self.send('press right','wait 3');self.require(zone_id=MAPS['Route4'],**{'player.x':before[0],'player.y':before[1]})
        self.checkpoint('moon-cerulean-boundary-blocked');self.save_actual()

def run(client,scenario,evidence_dir,build_evidence=None,prior_receipt=None,capture_dir=None):
    config=dict(scenario['journey'])
    if config['name'].endswith('-supplementary'):config['supplementary']=True
    j=MoonJourney(client,evidence_dir,config,build_evidence,capture_dir)
    try:
        j.dependencies();name=config['name']
        if name=='mt-moon-warp-supplementary':j.warp_cases()
        elif name=='mt-moon-seller-supplementary':j.gift_case()
        elif name=='mt-moon-fossil-supplementary':j.fossil_case()
        elif name=='mt-moon-connected-supplementary':j.connected(True)
        elif name=='mt-moon-from-current':j.connected(False)
        else:raise ProtocolError('unsupported MtMoon recipe')
        j.summary['ok']=True
    except Exception as error:
        j.summary.update(ok=False,error=str(error));atomic_json(Path(evidence_dir)/'mt-moon-failure.json',j.summary);raise
    atomic_json(Path(evidence_dir)/'mt-moon-summary.json',j.summary);return j.summary

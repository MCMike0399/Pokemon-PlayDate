#!/usr/bin/env python3
"""Project/source-root explicit, frozen-source checked MtMoon runtime JSON adapter."""
import argparse,copy,hashlib,json,re,sys
from pathlib import Path
STAGE=Path(__file__).resolve().parents[1]
REV='af519899719f0754965776faac0e836a3b906e6d'
KEYS={'Route3':'kanto_route3','Route4':'kanto_route4','MtMoonPokecenter':'kanto_mt_moon_center','MtMoon1F':'kanto_mt_moon_1f','MtMoonB1F':'kanto_mt_moon_b1f','MtMoonB2F':'kanto_mt_moon_b2f'}
NAMES={'OPP_BUG_CATCHER':'BUG CATCHER','OPP_YOUNGSTER':'YOUNGSTER','OPP_LASS':'LASS','OPP_HIKER':'HIKER','OPP_SUPER_NERD':'SUPER NERD','OPP_ROCKET':'ROCKET'}
def raw(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def build(source,reference):
 source=Path(source);reference=Path(reference);pin=json.loads((source/'source-pin.json').read_text());candidate=source/'generated-02';manifest=json.loads((candidate/'source-manifest.json').read_text())
 assert pin['revision']==REV and manifest['source_files']==pin['files']
 for path,value in pin['files'].items():assert sha((reference/path).read_bytes())==value,'pinned source changed '+path
 extra=json.loads((STAGE/'additional-source-pin.json').read_text())
 assert extra['revision']==REV
 for path,value in extra['files'].items():assert sha((reference/path).read_bytes())==value,'additional source changed '+path
 names=(reference/'data/trainers/names.asm').read_text()
 for name in NAMES.values():assert ('li "'+name+'"')in names,'unresolved original trainer name'
 for path,value in manifest['artifacts'].items():assert sha((candidate/path).read_bytes())==value,'source candidate changed '+path
 out={};descriptors={};compact={'schema':1,'source_revision':REV,'maps':{},'tiles':{}};grids={};event_ids=[]
 for name,key in KEYS.items():
  d=json.loads((candidate/'maps'/f'{name}.json').read_text());w,h=d['dimensions']['cells'];assert w>=13
  for e in d['events']['warps']:e['source_x'],e['source_y']=e['x'],e['y']
  for events in d['events'].values():event_ids.extend(e['id'] for e in events)
  for entry in d['grids']:
   value={'key':entry['stable_id'],'grid':entry['grid'],'terrain':entry['terrain'],'collision':0 if entry['terrain']['land_passable'] else 1}
   if value['key'] in grids:assert grids[value['key']]==value
   grids[value['key']]=value;compact['tiles'][value['key']]={k:v for k,v in value.items() if k!='grid'}
  palette=[e['stable_id'] for e in d['grids']];blocked={}
  descriptors[name]={'name':name,'id':d['id'],'key':key,'width':w,'height':h,'source_width':w,'padding':0,'tileset':d['tileset']['constant'],'connections':d['connections'],'warps':d['events']['warps']}
  compact['maps'][name]={'name':name,'id':d['id'],'key':key,'width':w,'height':h,'source_width':w,'padding':0,'revision':REV,'palette':palette,'tile_rows':[''.join(f'{x:02x}' for x in row) for row in d['tile_ids']],'blocked':blocked,'source_sha256':sha((candidate/'maps'/f'{name}.json').read_bytes())}
  d.pop('source_refs',None);d.pop('source_refs_fields',None);out[name+'.json']=raw(d)
 for file in ('sprites','dialogue','trainers','event-requirements'):
  value=json.loads((candidate/(file+'.json')).read_text());out[file+'.json']=raw(value)
 hidden=json.loads((candidate/'event-requirements.json').read_text())['hidden_events'];event_ids.extend(e['id'] for e in hidden)
 out['hidden-events.json']=raw({'schema':1,'source_revision':REV,'events':hidden})
 out['descriptors.json']=raw({'schema':1,'source_revision':REV,'maps':descriptors})
 out['compact.json']=raw(compact);out['tile-grids.json']=raw({'schema':1,'source_revision':REV,'tiles':grids})
 out['index.json']=raw({'schema':1,'source_revision':REV,'names':sorted(KEYS),'event_ids':sorted(event_ids),'trainer_names':NAMES,
  'indexed_inaccessible_trainers':['pokered:ROUTE_4:objects:2'],'policy':'Exact source row retained in inaccessible upper component; no new shortcut.'})
 requirements=json.loads((candidate/'event-requirements.json').read_text())
 simple={e['id']:e['far_text_labels'] for e in requirements['events'] if e['status']=='source-dialogue'}
 for event in requirements['events']:
  if event['script_pointer']=='PokeCenterSignText':simple[event['id']]=['_PokeCenterSignText']
 out['simple-events.json']=raw({'schema':1,'source_revision':REV,'events':simple})
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-stage',required=True);p.add_argument('--reference',required=True);m=p.add_mutually_exclusive_group(required=True);m.add_argument('--output');m.add_argument('--check');a=p.parse_args();out=build(a.source_stage,a.reference);target=Path(a.output or a.check)
 if a.check:
  assert {x.relative_to(target).as_posix() for x in target.rglob('*') if x.is_file()}==set(out),'runtime inventory differs'
  for name,b in out.items():assert (target/name).read_bytes()==b,'runtime bytes differ '+name
 else:
  assert not target.exists() or not any(target.iterdir()),'empty unique candidate output required'
  for name,b in out.items():path=target/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b)
 print(json.dumps({'ok':True,'artifacts':len(out),'source_inputs':107,'runtime_accepted':False}))

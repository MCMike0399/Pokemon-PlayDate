#!/usr/bin/env python3
"""Current-base root-owner overlay. Compile-only unless --execute; no live writes."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');a=p.parse_args()
stage=Path(__file__).resolve().parent;project=Path(a.project).resolve();sys.path.insert(0,str(project));sys.dont_write_bytecode=True
from tools.harness import run as harness
from tools.harness.protocol import atomic_json
original=harness.prepare
base=json.loads((stage/'base-files.json').read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def prepare(project,sdk,output,session):
    for name,digest in base['files'].items():assert sha(project/name)==digest,'owned base changed; rebase explicitly '+name
    metadata=original(project,sdk,output,session)
    for file in sorted((stage/'Source').rglob('*')):
        if file.is_file():target=output/'Source'/file.relative_to(stage/'Source');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
    for name in ('npcMotion-renderer.patch','pc-terminal.patch','legacy-npc-contract-scope.patch','root-fixtures.patch','root-diagnostics.patch','root-provider-contracts.patch'):
        subprocess.run(['git','apply','--check',str(stage/'patches'/name)],cwd=output,check=True)
        subprocess.run(['git','apply',str(stage/'patches'/name)],cwd=output,check=True)
    domain=output/'Source/domain/gameSession.lua';domain.write_text(domain.read_text()+(stage/'patches/gameSession-paidGift.append.lua').read_text())
    main=output/'Source/main.lua';text=main.read_text();marker='import "world/pcTerminals"';assert text.count(marker)==1
    hook='''
import "data/mtMoonSlice"
import "world/campaignContent"
import "world/mtMoonSprites"
import "game/mtMoonEvents"
import "world/mtMoonBindings"
import "game/mtMoonFactory"
import "world/mtMoonActors"
import "game/campaignRegions"
import "game/moonInteraction"
CampaignRegions.install()
'''
    text=text.replace(marker,marker+hook,1)
    marker='import "dev/catalog"';assert text.count(marker)==1
    if (stage/'Source/dev/mtMoonContracts.lua').exists():text=text.replace(marker,'import "dev/mtMoonProof"\nimport "dev/mtMoonContracts"\nContracts.register("mt-moon", MtMoonContracts.run)\n'+marker,1)
    main.write_text(text)
    pdx=output/'Source/pdxinfo';generated=pdx.read_text();pdx.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(f.relative_to(output/'Source')):sha(f) for f in sorted((output/'Source').rglob('*')) if f.is_file()and f.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    pdx.write_text(generated);values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        value=metadata[key];values.append('    '+key+' = '+('true'if value is True else json.dumps(value,ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False)
    with (output/'mt-moon-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
try:result=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=a.scenario or str(stage/'scenario.json'),commands=[],build_only=not a.execute,timeout=60,ready_timeout=20,max_frames=1800))
finally:harness.prepare=original
raise SystemExit(result)

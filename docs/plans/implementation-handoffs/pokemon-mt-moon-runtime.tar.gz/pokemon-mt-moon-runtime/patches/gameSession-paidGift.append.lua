
-- Narrow source-paid gift. All preparation is detached; publication cannot
-- yield and retains the exact Party/Storage/Inventory owners and new mon.
function GameSession:purchaseGift(offer,expected)
    local current=state[self]
    if not current then return false,"invalid-session"end
    local ok,prepared=pcall(function()
        object(offer,{species=true,level=true,price=true,flag=true})
        assert(offer.species=="magikarp"and offer.level==5 and offer.price==500 and offer.flag=="EVENT_BOUGHT_MAGIKARP","unsupported-paid-gift")
        object(expected,{money=true,party_count=true,box=true,box_count=true})
        assert(Party._integer(expected.money,0,Inventory.MONEY_LIMIT)and Party._integer(expected.party_count,0,Party.CAPACITY)
            and Party._integer(expected.box,1,Storage.BOX_COUNT)and Party._integer(expected.box_count,0,Storage.BOX_CAPACITY),"invalid-paid-gift-guard")
        assert(Specimen.isActiveSession(self),"inactive-specimen-session")
        if current.questFlags[offer.flag]then error("already-purchased",0)end
        if current.inventory:money()~=expected.money or current.party:count()~=expected.party_count
            or current.storage:activeBox()~=expected.box or current.storage:count()~=expected.box_count then error("stale-gift-guard",0)end
        if expected.money<offer.price then error("not-enough-money",0)end
        if expected.party_count>=Party.CAPACITY and expected.box_count>=Storage.BOX_CAPACITY then error("box-full",0)end
        local nextFlags=copy(current.questFlags);nextFlags[offer.flag]=true;nextFlags=flags(nextFlags,4096)
        local bag=assert(Inventory.fromData(current.deps.itemDefinitions,current.inventory:toData()));assert(bag:spend(offer.price))
        local stream=RulesRNG.new(1);assert(stream:restoreData(RulesRNG.toData()))
        local mon,problem=Specimen.create(offer.species,offer.level,"gift",stream);assert(mon,problem)
        assert(Party._validPokemon(mon)and not Party._owner(mon),"gift-identity-not-unowned")
        return {mon=mon,bag=bag:toData(),flags=nextFlags,rng=stream:toData()}
    end)
    if not ok then return false,tostring(prepared)end
    -- Direct production methods, no caller callbacks or overriding dispatch.
    local accepted,receipt=GameSession.recruit(self,prepared.mon);assert(accepted,receipt)
    assert(Inventory._replaceData(current.inventory,prepared.bag))
    current.questFlags=prepared.flags
    assert(RulesRNG.restoreData(prepared.rng))
    return true,{pokemon=prepared.mon,destination=receipt.destination,index=receipt.index,box=receipt.box,price=500,flag="EVENT_BOUGHT_MAGIKARP"}
end

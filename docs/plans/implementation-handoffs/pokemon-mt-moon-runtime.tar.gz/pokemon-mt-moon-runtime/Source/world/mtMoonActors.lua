-- Pure current-map descriptor adapter using existing SourceActors/NPCMotion.
MtMoonActors={}
function MtMoonActors.describe(zoneID,world)
    local name=MtMoonSlice.nameForID(zoneID);if not name then return nil end
    local provider=assert(WorldDeltas.definitionProvider());local surface=provider:surface(zoneID,world)
    local d=MtMoonSlice.definition(name);local actors,protected={},{}
    local function protect(x,y)if x>=0 and y>=0 and x<surface.width and y<surface.height then protected[y*surface.width+x+1]=true end end
    for _,warp in ipairs(d.events.warps)do protect(warp.x,warp.y);if name=="Route4"then protect(warp.x,warp.y+1)end end
    for _,c in ipairs(d.connections)do
        if c.direction=="north"or c.direction=="south"then for x=0,surface.width-1 do protect(x,c.direction=="north"and 0 or surface.height-1)end
        else for y=0,surface.height-1 do protect(c.direction=="west"and 0 or surface.width-1,y)end end
    end
    for _,event in ipairs(d.events.objects)do
        local trainer=MtMoonSlice.trainer(event.id);local strip=MtMoonSlice.sprite(event.sprite);local item=event.kind=="item"or strip.fixed
        local faces={};for direction in pairs(strip.standing)do faces[direction]=true end;if faces.left then faces.right=true end
        local facing=assert(({UP="up",DOWN="down",LEFT="left",RIGHT="right",LEFT_RIGHT="left",UP_DOWN="down",NONE="down",ANY_DIR="down"})[event.range_or_facing])
        assert(faces[facing],"source actor exact initial pose absent")
        local spec={id=event.id,order=event.source_index,x=event.x,y=event.y,role=trainer and "trainer"or item and "item"or "npc",
            movement=event.movement,selector=event.range_or_facing,sprite_source=event.sprite,faces=faces,facing=facing,
            random=not trainer and not item,visibility={},script_positions={},stepImage=MtMoonSprites.stepImage}
        if trainer then
            local delta=({up={0,-1},down={0,1},left={-1,0},right={1,0}})[facing]
            for i=0,math.max(0,trainer.sight_range_cells-1)do spec.script_positions[(event.y+delta[2]*i)*surface.width+event.x+delta[1]*i+1]=true end
            if event.id==MtMoonEvents.NERD then for _,cell in ipairs({{12,8},{13,8},{13,7},{12,7}})do spec.script_positions[cell[2]*surface.width+cell[1]+1]=true end end
        end
        if MtMoonEvents.isPickup(event.id)then spec.visibility={{group="quest",id=MtMoonEvents.pickupFlag(event.id),equals=false}}
        elseif event.id=="pokered:MT_MOON_B2F:objects:6"or event.id=="pokered:MT_MOON_B2F:objects:7"then
            spec.visibility={{group="quest",id="EVENT_GOT_DOME_FOSSIL",equals=false},{group="quest",id="EVENT_GOT_HELIX_FOSSIL",equals=false}}
        end
        actors[#actors+1]=spec
    end
    local function canStand(spec,x,y,runtime)
        if x<0 or y<0 or x>=surface.width or y>=surface.height or(runtime and runtime.collision or surface.collision)[y+1][x+1]~=0 then return false end
        if spec.role=="trainer"then return spec.script_positions[y*surface.width+x+1]==true end
        if spec.movement~="WALK"then return x==spec.x and y==spec.y end
        if math.abs(x-spec.x)>4 or math.abs(y-spec.y)>4 or protected[y*surface.width+x+1]then return false end
        return not(spec.selector=="UP_DOWN"and x~=spec.x or spec.selector=="LEFT_RIGHT"and y~=spec.y)
    end
    local function canStep(spec,x,y,tx,ty,runtime)
        if not canStand(spec,x,y,runtime)or not canStand(spec,tx,ty,runtime)or math.abs(tx-x)+math.abs(ty-y)~=1 then return false end
        local a=runtime and runtime:terrainAt(x,y).foot_tile or surface.feet[y+1][x+1];local b=runtime and runtime:terrainAt(tx,ty).foot_tile or surface.feet[ty+1][tx+1]
        local direction=tx>x and "RIGHT"or tx<x and "LEFT"or ty>y and "DOWN"or "UP"
        for _,rule in ipairs(d.directional_rules.ledges)do if rule.facing=="SPRITE_FACING_"..direction and rule.standing_foot_tile==a and rule.target_foot_tile==b then return false end end
        for _,pair in ipairs(d.directional_rules.forbidden_tile_pairs)do if a==pair[1]and b==pair[2]or a==pair[2]and b==pair[1]then return false end end
        return true
    end
    return {zone_id=zoneID,revision=surface.revision,width=surface.width,height=surface.height,actors=actors,canStand=canStand,canStep=canStep,protected=protected}
end

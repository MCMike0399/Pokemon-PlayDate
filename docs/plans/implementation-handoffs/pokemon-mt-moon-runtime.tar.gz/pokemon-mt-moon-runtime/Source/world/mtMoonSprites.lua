-- Original source grids only. Existing shared source keys/renderers retained.
MtMoonSprites={}
local names={hiker="mtMoonHiker",rocket="mtMoonRocket",fossil="mtMoonFossil",middle_aged_man="mtMoonSeller",clipboard="mtMoonClipboard"}
local rendered,walks={},{}
function MtMoonSprites.key(source)
    local _,name=MtMoonSlice.sprite(source)
    return names[name]or PewterSprites.key(source)
end
function MtMoonSprites.frame(source,index)
    local strip=MtMoonSlice.sprite(source)
    assert(Party._integer(index,0,5),"bounded original sprite index required")
    return SpriteFactory.makeSprite(assert(strip.frames[tostring(index)],"missing original sprite frame"),{0,0})
end
function MtMoonSprites.installFor(definition)
    SliceSprites.install()
    for _,event in ipairs(definition.events.objects)do
        local key=MtMoonSprites.key(event.sprite);local _,name=MtMoonSlice.sprite(event.sprite)
        if not names[name]then PewterSprites.installFor({source_revision=definition.source_revision,events={objects={event}}})
        else
            assert(not SpriteFactory.npc[key]or SpriteFactory.npc[key]==rendered[key],"conflicting MtMoon native sprite owner")
            if not rendered[key]then
                local strip=MtMoonSlice.sprite(event.sprite);local images={}
                for direction,index in pairs(strip.standing)do images[direction]=MtMoonSprites.frame(event.sprite,index)end
                if images.left then images.right=SpriteFactory.flipped(images.left)end
                rendered[key]=images
            end
            SpriteFactory.npc[key]=rendered[key]
        end
    end
end
function MtMoonSprites.stepImage(source,facing,tick)
    local _,name=MtMoonSlice.sprite(source)
    if not names[name]then return PewterSprites.stepImage(source,facing,tick)end
    assert(Party._integer(tick,1,8),"bounded actual eight-frame cadence required")
    if not walks[source]then
        local strip=MtMoonSlice.sprite(source);local frames={standing=assert(SpriteFactory.npc[MtMoonSprites.key(source)]),walking={},alternate={}}
        for direction,index in pairs(strip.walking)do
            frames.walking[direction]=MtMoonSprites.frame(source,index)
            frames.alternate[direction]=(direction=="down"or direction=="up")and SpriteFactory.flipped(frames.walking[direction])or frames.walking[direction]
        end
        assert(frames.walking.left,"original actor has no walking frames")
        frames.walking.right=SpriteFactory.flipped(frames.walking.left);frames.alternate.right=frames.walking.right;walks[source]=frames
    end
    local frames=walks[source];local phase=(tick//2)%4
    return assert(phase==1 and frames.walking[facing]or phase==3 and frames.alternate[facing]or frames.standing[facing])
end

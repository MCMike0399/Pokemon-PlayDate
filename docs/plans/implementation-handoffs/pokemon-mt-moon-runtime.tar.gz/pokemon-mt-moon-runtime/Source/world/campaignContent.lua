-- One immutable boot catalog feeds the one disposable ImportedMaps provider.
-- Trusted source adapters own pure definition readers, never mutable sessions.
Class("CampaignCatalog")
local states=setmetatable({},{__mode="k"})
local function copy(v)if type(v)~="table"then return v end;local out={};for k,x in pairs(v)do out[k]=copy(x)end;return out end
local function same(a,b)
    if type(a)~=type(b)then return false end;if type(a)~="table"then return a==b end
    for k,v in pairs(a)do if not same(v,b[k])then return false end end
    for k in pairs(b)do if a[k]==nil then return false end end;return true
end
local capabilities={compact=true,descriptor=true,tile=true,trainers=true,eventIDs=true,events=true,create=true,stepImage=true,hidden=true,ownership=true}
function CampaignCatalog:init()states[self]={sealed=false,regions={},maps={},ids={},events={},trainers={},tiles={},compact={schema=1,source_revision="af519899719f0754965776faac0e836a3b906e6d",maps={},tiles={}}}end
function CampaignCatalog:register(name,adapter)
    local s=states[self];assert(not s.sealed,"campaign registration closed")
    assert(type(name)=="string"and #name<=48 and name:match("^[a-z][a-z0-9-]*$")and not s.regions[name],"duplicate/invalid campaign region")
    assert(type(adapter)=="table"and getmetatable(adapter)==nil,"explicit campaign adapter required")
    for key in pairs(adapter)do assert(capabilities[key],"unknown campaign capability")end
    for key in pairs(capabilities)do assert(type(adapter[key])==(key=="events"and "table"or "function"),"missing campaign capability: "..key)end
    for _,key in ipairs({"has","plan","pages","itemIDs"})do assert(type(adapter.events[key])=="function","event adapter incomplete")end
    local data=adapter.compact();assert(data.schema==1 and data.source_revision==s.compact.source_revision,"unverified campaign source")
    local pending={maps={},ids={},events={},trainers={},tiles={}}
    for map,d in pairs(data.maps)do
        assert(type(map)=="string"and d.name==map and type(d.id)=="string"and type(d.key)=="string","invalid campaign map identity")
        assert(not s.maps[map]and not s.ids[d.id]and not pending.ids[d.id],"duplicate campaign map stable ID")
        for _,old in pairs(s.compact.maps)do assert(old.key~=d.key,"duplicate campaign registry key")end
        for _,old in pairs(pending.maps)do assert(old.key~=d.key,"duplicate campaign registry key")end
        local descriptor=adapter.descriptor(map);assert(descriptor.name==map and descriptor.id==d.id and descriptor.key==d.key and descriptor.width==d.width and descriptor.height==d.height,"campaign descriptor differs from compact map")
        pending.maps[map]=copy(d);pending.ids[d.id]={name=map,region=name,descriptor=copy(descriptor)}
    end
    for key,metadata in pairs(data.tiles)do
        local tile=adapter.tile(key)
        assert(tile.key==key and same(metadata.terrain,tile.terrain)and metadata.collision==tile.collision,"campaign tile metadata differs")
        if s.tiles[key]then assert(same(s.tiles[key],tile),"conflicting shared campaign tile pixels/mask/terrain")end
        pending.tiles[key]=copy(tile)
    end
    for id,d in pairs(adapter.trainers())do
        assert(id==d.id and not s.trainers[id]and pending.ids[d.map_id],"duplicate/foreign campaign trainer")
        assert(Party._integer(d.payout,0,Inventory.MONEY_LIMIT),"invalid trainer payout")
        pending.trainers[id]=copy(d)
    end
    local count=0
    for _,id in ipairs(adapter.eventIDs())do
        assert(type(id)=="string"and #id<=128 and not s.events[id]and not pending.events[id],"duplicate campaign source event ID")
        local zoneID=id:match("^(pokered:[^:]+):");assert(zoneID and pending.ids[zoneID],"foreign campaign event ID")
        pending.events[id]=name;count=count+1
    end
    assert(count>0,"campaign region has no source events")
    -- All validation above is detached: failed registration publishes nothing.
    local ownership=adapter.ownership();assert(type(ownership)=="table"and type(ownership.npcs)=="table","declared NPC ownership required")
    local npcKeys={};for _,key in ipairs(ownership.npcs)do assert(type(key)=="string"and #key<=128 and not npcKeys[key],"invalid declared NPC key");npcKeys[key]=true end
    local retained=copy(adapter);retained.declaredNPCs=npcKeys;retained.declaredTiles={}
    for key in pairs(data.tiles)do retained.declaredTiles[key]=true end
    s.regions[name]=retained
    for map,d in pairs(pending.maps)do s.maps[map]=name;s.compact.maps[map]=d end
    for id,d in pairs(pending.ids)do s.ids[id]=d end
    for id,region in pairs(pending.events)do s.events[id]=region end
    for id,d in pairs(pending.trainers)do s.trainers[id]=d end
    for key,tile in pairs(pending.tiles)do s.tiles[key]=tile;s.compact.tiles[key]=copy(data.tiles[key])end
end
function CampaignCatalog:seal()local s=states[self];assert(next(s.regions),"empty campaign catalog");s.sealed=true;return self end
function CampaignCatalog:isSealed()return states[self].sealed end
function CampaignCatalog:map(nameOrID)
    local s=states[self];assert(s.sealed,"campaign catalog not sealed")
    local value=s.ids[nameOrID]
    if not value and s.maps[nameOrID]then value=s.ids[s.compact.maps[nameOrID].id]end
    if not value then return nil end
    return {name=value.name,region=value.region,descriptor=copy(value.descriptor),adapter=copy(s.regions[value.region])}
end
function CampaignCatalog:event(id)
    local s=states[self];assert(s.sealed,"campaign catalog not sealed");local name=s.events[id]
    return name and copy(s.regions[name].events)or nil,name
end
function CampaignCatalog:compact()assert(states[self].sealed,"campaign catalog not sealed");return copy(states[self].compact)end
function CampaignCatalog:trainers()assert(states[self].sealed,"campaign catalog not sealed");return copy(states[self].trainers)end
function CampaignCatalog:tile(key)assert(states[self].sealed,"campaign catalog not sealed");return copy(assert(states[self].tiles[key],"unknown canonical campaign tile"))end
CampaignCatalog.same=same
CampaignContent=CampaignCatalog()

-- Pure immutable source ownership for exporter registration; never queries LRU
-- caches, actual sprite installation or numeric tile allocation.
function CampaignCatalog:inventory(region)
    local s=states[self];assert(s.sealed,"campaign catalog not sealed");local adapter=assert(s.regions[region],"unknown content region")
    local out={region=region,maps={},tiles={},npcs={}}
    for id,d in pairs(s.ids)do if d.region==region then out.maps[#out.maps+1]={id=id,key=d.descriptor.key,name=d.name,width=d.descriptor.width,height=d.descriptor.height}end end
    for key in pairs(adapter.declaredTiles)do out.tiles[#out.tiles+1]=key end
    for key in pairs(adapter.declaredNPCs)do out.npcs[#out.npcs+1]=key end
    table.sort(out.maps,function(a,b)return a.id<b.id end);table.sort(out.tiles);table.sort(out.npcs);return out
end
function CampaignCatalog:ownsMap(region,value)
    local id=type(value)=="table"and value.stableID or value
    local d=states[self].ids[id];return d~=nil and d.region==region
end
function CampaignCatalog:ownsTile(region,key)
    local s=states[self];local adapter=assert(s.regions[region],"unknown content region");return adapter.declaredTiles[key]==true
end
function CampaignCatalog:ownsNPC(region,key)
    local adapter=assert(states[self].regions[region],"unknown content region");return adapter.declaredNPCs[key]==true
end

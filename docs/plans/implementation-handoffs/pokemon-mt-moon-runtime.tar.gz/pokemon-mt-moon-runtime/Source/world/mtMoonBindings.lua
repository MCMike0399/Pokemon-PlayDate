-- Source projection for this adapter; Zone/MapBindings retain movement authority.
MtMoonBindings={}
function MtMoonBindings.prepare(d,specs,options)
    assert(MtMoonSlice.nameForID(d.id)==d.name and d.source_revision=="af519899719f0754965776faac0e836a3b906e6d","unverified MtMoon map")
    assert(type(options.dispatch)=="function"and type(options.questFlag)=="function"and type(options.sourceFlag)=="function","explicit event/flag owners required")
    local expected,bound,npcs,doors={},{},{},{};local width,height=table.unpack(d.dimensions.cells)
    local function binding(id,event)
        assert(not expected[id],"duplicate source binding");expected[id]=true
        if event then assert(Party._integer(event.x,0,width-1)and Party._integer(event.y,0,height-1),"source event outside map")end
        local spec=assert(specs[id],"missing explicit MtMoon binding");assert(spec.status=="bound"or spec.status=="blocked","invalid binding status")
        if spec.status=="bound"then bound[id]=true end;return spec
    end
    for _,event in ipairs(d.events.objects)do
        local spec=binding(event.id,event);local key=MtMoonSprites.key(event.sprite);local id=event.id
        if not options.isolatedCatalog then assert(SpriteFactory.npc[key],"exact original MtMoon sprite not installed")end
        if spec.status=="bound"then assert(MtMoonEvents.has(id),"missing source object owner")end
        local trainer=MtMoonSlice.trainer(id)
        local def={gridX=event.x,gridY=event.y,name=trainer and trainer.name or event.text_id,sprite=key,source_event_id=id,source_sprite=event.sprite,
            source_movement={kind=event.movement,range=event.range_or_facing},
            dialog=function()assert(spec.status=="bound","unimplemented original control");return options.dispatch(id)end,
            facing=({UP="up",DOWN="down",LEFT="left",RIGHT="right",LEFT_RIGHT="left",UP_DOWN="down",NONE="down",ANY_DIR="down"})[event.range_or_facing]}
        if MtMoonEvents.isPickup(id)or id=="pokered:MT_MOON_B2F:objects:6"or id=="pokered:MT_MOON_B2F:objects:7"then
            def.appearsIf=function()return MtMoonEvents.visible(id,options.questFlag)end
        end
        npcs[#npcs+1]=def
    end
    for _,event in ipairs(d.events.warps)do
        local spec=binding(event.id,event);assert(spec.status=="bound","all original Moon warps resolved")
        local actual=MtMoonSlice.warpSpec(d.name,event)
        for _,key in ipairs({"to","toX","toY","facing","preserveFacing","target_name","target_warp","arrival_advance"})do assert(spec[key]==actual[key],"warp differs from exact source target")end
        doors[#doors+1]={x=event.x,y=event.y,to=spec.to,toX=spec.toX,toY=spec.toY,facing=spec.facing,preserveFacing=spec.preserveFacing,source_event_id=event.id,
            edge=d.tileset.constant~="OVERWORLD"and event.y==height-1 and "down"or nil}
    end
    for _,event in ipairs(d.events.background_events)do local spec=binding(event.id,event);if spec.status=="bound"then assert(MtMoonEvents.has(event.id))end end
    for _,c in ipairs(d.connections)do binding(c.direction..":"..c.target_map)end
    if #d.directional_rules.ledges>0 then binding("ledges:"..d.id)end
    binding(d.script.source)
    if d.encounters.grass.rate_byte>0 then binding(d.id)end
    for id in pairs(specs)do assert(expected[id],"unknown MtMoon source binding")end
    local encounters,total={},0
    for _,slot in ipairs(d.encounters.grass.slots)do
        assert(pokemonData[slot.species]and Party._integer(slot.level,1,100)and Party._integer(slot.weight_256,1,256),"unknown original encounter")
        encounters[#encounters+1]={species=slot.species,minLevel=slot.level,maxLevel=slot.level,weight=slot.weight_256};total=total+slot.weight_256
    end
    assert(#encounters==0 and d.encounters.grass.rate_byte==0 or #encounters==10 and total==256,"invalid original weighted encounter table")
    local warpCells={};for _,e in ipairs(d.events.warps)do warpCells[e.y*width+e.x+1]=true end
    local cave=d.tileset.constant=="CAVERN";local name=d.name
    local eligible=function(x,y,zone)
        if not Party._integer(x,0,width-1)or not Party._integer(y,0,height-1)or zone.collision[y+1][x+1]~=0 or warpCells[y*width+x+1]then return false end
        if name=="MtMoonB2F"and options.sourceFlag("EVENT_BEAT_MT_MOON_EXIT_SUPER_NERD")and x>=11 and x<=14 and y>=5 and y<=8 then return false end
        return cave or zone:isTallGrass(x,y)
    end
    return {bound=bound,npcs=npcs,doors=doors,specs=GameSession._copy(specs),encounters=encounters,encounterRateByte=d.encounters.grass.rate_byte,encounterEligible=eligible,
        source={dimensions=GameSession._copy(d.dimensions),events=GameSession._copy(d.events),directional_rules=GameSession._copy(d.directional_rules)},sliceReady=true,
        scope="mt-moon-slice-only",scopeStatus="bounded Blue MtMoon; Cerulean and optional controls remain explicitly unimplemented"}
end

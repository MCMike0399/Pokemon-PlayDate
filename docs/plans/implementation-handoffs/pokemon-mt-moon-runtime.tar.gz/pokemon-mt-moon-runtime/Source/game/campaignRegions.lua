-- Explicit two-region boot composition; registration closes before gameplay.
CampaignRegions={}
function CampaignRegions.pewter()
    local function eventIDs()
        local ids={}
        for _,name in ipairs(PewterSlice.names())do
            local d=PewterSlice.padded(name)
            for _,kind in ipairs({"objects","warps","background_events"})do for _,event in ipairs(d.events[kind])do ids[#ids+1]=event.id end end
        end
        local hidden=assert(json.decodeFile("data/pewterSlice/hidden-events.json"))
        for _,event in ipairs(hidden.events)do ids[#ids+1]=event.id end
        return ids
    end
    local function ownership()
        local seen={};for _,name in ipairs(PewterSlice.names())do for _,event in ipairs(PewterSlice.padded(name).events.objects)do seen[PewterSprites.key(event.sprite)]=true end end
        local keys={};for key in pairs(seen)do keys[#keys+1]=key end;table.sort(keys);return {npcs=keys}
    end
    local events={has=PewterEvents.has,plan=PewterEvents.plan,pages=PewterEvents.pages,afterCommit=PewterEvents.afterCommit,
        itemIDs=function()return {"potion","oaksParcel","tm34","moonStone","hpUp","antidote","pokeBall"}end}
    return {compact=PewterSlice.compact,descriptor=PewterSlice.descriptor,tile=PewterSlice.tile,trainers=PewterSlice.trainers,eventIDs=eventIDs,events=events,
        create=function(game,name,registry,desired,isolated)return PewterWorld.createSource(game,name,registry,desired,isolated)end,
        ownership=ownership,stepImage=PewterSprites.stepImage,hidden=function()return assert(json.decodeFile("data/pewterSlice/hidden-events.json")).events end}
end
function CampaignRegions.mtMoon()
    return {compact=MtMoonSlice.compact,descriptor=MtMoonSlice.descriptor,tile=MtMoonSlice.tile,trainers=MtMoonSlice.trainers,eventIDs=MtMoonSlice.eventIDs,
        events=MtMoonEvents,create=MtMoonFactory.create,stepImage=MtMoonSprites.stepImage,hidden=MtMoonSlice.hidden,
        ownership=function()
            local seen={};for _,name in ipairs(MtMoonSlice.names())do for _,event in ipairs(MtMoonSlice.definition(name).events.objects)do seen[MtMoonSprites.key(event.sprite)]=true end end
            local keys={};for key in pairs(seen)do keys[#keys+1]=key end;table.sort(keys);return {npcs=keys}
        end}
end
function CampaignRegions.install()
    assert(not CampaignContent:isSealed(),"campaign boot registration already closed")
    CampaignContent:register("pewter",CampaignRegions.pewter());CampaignContent:register("mt-moon",CampaignRegions.mtMoon());CampaignContent:seal()
end

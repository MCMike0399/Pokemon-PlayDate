-- Bounded content integration. ImportedMaps owns the disposable cache/ledger;
-- existing WorldDeltas and zoneRegistry retain their world authority.
PewterWorld={}
local installed=setmetatable({},{__mode="k"})
local starts={Route2={8,71},ViridianForestSouthGate={5,7},ViridianForest={16,47},ViridianForestNorthGate={5,7},PewterCity={18,35},PewterGym={5,13},PewterMart={5,7},PewterPokecenter={3,7}}
local function ensureKeys(registry,tiles)
    local entries,seen={},{}
    for _,tile in ipairs(tiles) do if not registry:has(tile.key) and not seen[tile.key] then
        seen[tile.key]=true;entries[#entries+1]=CampaignContent and CampaignContent:isSealed()and CampaignContent:tile(tile.key)or PewterSlice.tile(tile.key)
    end end
    if #entries>0 then registry:registerBatch(entries) end
end
local function create(game,name,registry,desired,isolated)
    local d=PewterSlice.padded(name);local start=assert(starts[name])
    if not isolated then PewterSprites.installFor(d) end
    local dispatch=function(id) assert(not isolated,"catalog source events cannot execute");return KantoWorld.dispatch(game,id) end
    local quest=function(id)return not isolated and game.session:questFlag(id) or false end
    local sourceFlag=function(id)return not isolated and game.trainers:sourceFlag(id) or false end
    local config={registry=registry,bindingAdapter=PewterBindings,compactTerrain=true,isolatedCatalog=isolated or false,
        spawn={x=start[1],y=start[2],facing="up"},sliceBindings=PewterSlice.specs(name,d),dispatch=dispatch,questFlag=quest,sourceFlag=sourceFlag}
    -- Source refs are provenance for the external generator, not a retained
    -- per-cell Lua table in a live Zone. The full immutable JSON remains on disk.
    d.source_refs=nil
    local zone=Zone.fromMapDefinition(d,registry,config)
    if desired and desired.tile_count>0 then ensureKeys(registry,desired.tiles);zone:applyDeltas(desired) end
    return zone
end
PewterWorld.createSource=create -- immutable adapter uses the original factory, not a copied controller
function PewterWorld.locationPolicy()
    assert(CampaignContent and CampaignContent:isSealed(),"closed campaign content required before context construction")
    local policy=KantoWorld.locationPolicy()
    for _,d in pairs(CampaignContent:compact().maps)do policy.sliceZones[d.id]=true end
    return policy
end
function PewterWorld.createProvider(game,registry)
    assert(CampaignContent and CampaignContent:isSealed(),"closed campaign content required")
    registry=registry or WorldTiles
    if not game.trainers then game.trainers=TrainerEvents(game)end
    return ImportedMaps(CampaignContent:compact(),{
        registry=registry,
        create=function(name,desired)return assert(CampaignContent:map(name)).adapter.create(game,name,registry,desired,false)end,
        ensureKeys=function(tiles)ensureKeys(registry,tiles)end,
        release=function(zone)zone:disposeView()end,
    })
end
function PewterWorld.install(game)
    if installed[game] then assert(WorldDeltas.definitionProvider()==installed[game],"Pewter world provider replaced");return installed[game] end
    local policy=game.sessionLocationPolicy and game.sessionLocationPolicy.sliceZones
    local declared=CampaignContent:compact().maps
    for _,d in pairs(declared)do
        assert(policy and policy[d.id]==true and not zoneRegistry[d.key],"explicit unloaded Pewter location policy required")
        for _,zone in pairs(zoneRegistry) do assert(zone.stableID~=d.id,"Pewter stable map ID already owned") end
    end
    SourceActors.register("pewter",SourceActors.describePewter)
    if MtMoonActors then SourceActors.register("mt-moon",MtMoonActors.describe)end
    local provider=PewterWorld.createProvider(game)
    WorldDeltas.installDefinitionProvider(provider);installed[game]=provider
    return provider
end
function PewterWorld.isolated(name)
    return create(nil,name,TileRegistry(),nil,true)
end
local dirs={up={0,-1},down={0,1},left={-1,0},right={1,0}}
local function target(game,key,x,y,direction)
    local legacy=zoneRegistry[key]
    local provider=WorldDeltas.definitionProvider()
    if provider and provider:hasKey(key) then
        local d=provider:descriptor(key)
        local ok=pcall(provider.resolveLocation,provider,{zone_id=d.id,x=x,y=y,facing=direction},provider:export(),game.sessionLocationPolicy)
        if not ok then return nil,"blocked-source-arrival" end
        if legacy then
            for _,npc in ipairs(legacy.npcDefs) do if npc.gridX==x and npc.gridY==y and (not npc.appearsIf or npc.appearsIf()) then return nil,"occupied-source-arrival" end end
        end
    else
        if not legacy or x<0 or y<0 or x>=legacy.width or y>=legacy.height or legacy.collision[y+1][x+1]~=0 then return nil,"blocked-source-arrival" end
        for _,npc in ipairs(legacy.npcDefs) do if npc.gridX==x and npc.gridY==y and (not npc.appearsIf or npc.appearsIf()) then return nil,"occupied-source-arrival" end end
    end
    return {to=key,toX=x,toY=y,facing=direction,connection=true,source="pinned Route2/Pewter header connection"}
end
-- Second return distinguishes this module's explicit surfaces from old Kanto.
function PewterWorld.connection(game,zone,x,y,direction)
    local content=CampaignContent and CampaignContent:isSealed()and CampaignContent:map(zone.stableID)
    local name=content and content.name or PewterSlice.nameForID(zone.stableID)
    if zone.stableID=="pokered:VIRIDIAN_CITY" and direction=="up" and y==0 then
        if game.session:getIntro().stage~="done"then return nil,true,"intro-gate"end
        local door,reason=target(game,"kanto_route2",x-10,71,"up");return door,true,reason
    end
    if not name then return nil,false end
    local vector=dirs[direction];if not vector then return nil,true,"invalid-direction"end
    if x+vector[1]>=0 and y+vector[2]>=0 and x+vector[1]<zone.width and y+vector[2]<zone.height then return nil,false end
    if game.session:getIntro().stage~="done"then return nil,true,"intro-gate"end
    if name=="PewterCity"and direction=="right"and not game.session:trainerDefeated(TrainerEvents.BROCK)then return nil,true,"source-brock-gate"end
    local descriptor=content and content.descriptor or PewterSlice.descriptor(name)
    local wanted=({up="north",down="south",left="west",right="east"})[direction]
    for _,connection in ipairs(descriptor.connections)do if connection.direction==wanted then
        local targetContent=CampaignContent and CampaignContent:isSealed()and CampaignContent:map("pokered:"..connection.target_map)
        local destination=targetContent and targetContent.descriptor
        if not destination and connection.target_map=="VIRIDIAN_CITY"then destination={key="kanto_viridian_city",width=40,height=36,padding=0}end
        if not destination then return nil,true,"unimplemented-source-exit:"..zone.stableID..":"..direction end
        local delta=connection.entry_lateral_adjustment_cells
        local tx,ty
        if direction=="up"or direction=="down"then tx=x-(descriptor.padding or 0)+delta+(destination.padding or 0);ty=direction=="up"and destination.height-1 or 0
        else tx=direction=="left"and destination.width-1 or 0;ty=y+delta end
        local door,reason=target(game,destination.key,tx,ty,direction);return door,true,reason
    end end
    return nil,true,"unimplemented-source-exit:"..zone.stableID..":"..direction
end
local function contentFor(id)
    if CampaignContent and CampaignContent:isSealed()then return CampaignContent:map(id)end
end
function PewterWorld.trySight(game)
    if not game.trainers or game.machine:getCurrent()~="overworld"or game.player.isMoving or game.player.pendingEdgeDoor then return false end
    local content=contentFor(currentZone.stableID)
    if not content and not PewterSlice.nameForID(currentZone.stableID)then return false end
    if currentZone.stableID=="pokered:MT_MOON_B2F"then
        if not game.session:trainerDefeated(MtMoonEvents.NERD)and game.player.gridX==13 and game.player.gridY==8 then
            game.machine:push("event",MtMoonEvents.NERD,{mode="talk"});return true
        end
        if game.session:questFlag("EVENT_GOT_DOME_FOSSIL")or game.session:questFlag("EVENT_GOT_HELIX_FOSSIL")then return false end
    end
    for _,npc in ipairs(game.npcManager.npcs)do
        local id=npc.def and npc.def.source_event_id
        local definition=id and game.trainers:definition(id)
        if definition and not game.session:trainerDefeated(id)then
            local steps,reason=game.trainers:approach(npc,"sight")
            if steps then game.machine:push("event",id,{mode="sight"});return true end
            if reason=="occupied-trainer-approach"or reason=="blocked-trainer-approach"or reason=="blocked-trainer-pair"then game.player.lastTraversalBlock={kind="trainer",id=reason}end
        end
    end
    return false
end
local hidden
function PewterWorld.hiddenAt(x,y)
    local content=contentFor(currentZone.stableID)
    local events
    if content then events=content.adapter.hidden()
    else if not hidden then hidden=assert(json.decodeFile("data/pewterSlice/hidden-events.json")).events end;events=hidden end
    for _,event in ipairs(events)do if event.map_id==currentZone.stableID then
        local pad=content and content.descriptor.padding or PewterSlice.descriptor(PewterSlice.nameForID(event.map_id)).padding
        if event.x+pad==x and event.y==y then return event.id end
    end end
end
function PewterWorld.tryInteract(game)
    if PCTerminals and PCTerminals.tryInteract(game) then return true end
    local content=contentFor(currentZone.stableID)
    if not content and not PewterSlice.nameForID(currentZone.stableID)then return false end
    local player=game.player;local x,y=player:getFacingTile()
    if x<0 or y<0 or x>=currentZone.width or y>=currentZone.height then return false end
    local npc=game.npcManager:getNPCAt(x,y)
    if not npc and currentZone:terrainAt(x,y).counter then
        local d=dirs[player.facing];x,y=x+d[1],y+d[2]
        if x>=0 and y>=0 and x<currentZone.width and y<currentZone.height then npc=game.npcManager:getNPCAt(x,y) end
    end
    local id=npc and npc.def and npc.def.source_event_id
    if not id and x>=0 and y>=0 and x<currentZone.width and y<currentZone.height then
        for _,event in ipairs(currentZone:sourceEventsAt(x,y)) do
            if event.kind=="background_events" or event.kind=="warps" and event.status=="blocked" then id=event.id;break end
        end
        id=id or PewterWorld.hiddenAt(x,y)
    end
    if not id then return false end
    if player.isMoving or player.pendingEdgeDoor then player.lastTraversalBlock={kind="source-event",id="movement-active"};return true end
    local events=content and content.adapter.events or PewterEvents
    if not events.has(id)then player.lastTraversalBlock={kind="unimplemented-source-event",id=id};return true end
    if npc then
        if game.npcManager.motion:requestInteraction(npc,id)then return true end
        npc:faceTowards(player.gridX,player.gridY)
    end
    KantoWorld.dispatch(game,id);return true
end

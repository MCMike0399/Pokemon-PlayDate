-- Pure source plans. EventState owns presentation; session owns every grant.
MtMoonEvents={}
local NERD="pokered:MT_MOON_B2F:objects:1"
local SELLER="pokered:MT_MOON_POKECENTER:objects:4"
local FOSSILS={
 ["pokered:MT_MOON_B2F:objects:6"]={item="domeFossil",flag="EVENT_GOT_DOME_FOSSIL",prompt="_MtMoonB2FDomeFossilYouWantText"},
 ["pokered:MT_MOON_B2F:objects:7"]={item="helixFossil",flag="EVENT_GOT_HELIX_FOSSIL",prompt="_MtMoonB2FHelixFossilYouWantText"},
}
local simple,pickups
local function content()
    if not simple then
        local d=assert(json.decodeFile("data/mtMoonSlice/simple-events.json"));assert(d.schema==1 and d.source_revision=="af519899719f0754965776faac0e836a3b906e6d")
        simple=d.events;pickups={}
        for _,name in ipairs(MtMoonSlice.names())do
            for _,event in ipairs(MtMoonSlice.definition(name).events.objects)do
                if event.kind=="item"then pickups[event.id]=assert(ItemData.bySymbol[event.extra[1]],"unknown original pickup")end
            end
        end
        for _,event in ipairs(MtMoonSlice.hidden())do if event.handler_source=="HiddenItems"then pickups[event.id]=assert(ItemData.bySymbol[event.argument_source])end end
    end
end
function MtMoonEvents.pages(labels,ram)return EventText.pagesFrom(labels,MtMoonSlice.text,ram)end
function MtMoonEvents.itemIDs()
    content();local ids={};for _,item in pairs(pickups)do ids[item]=true end;ids.domeFossil,ids.helixFossil=true,true
    local out={};for id in pairs(ids)do out[#out+1]=id end;table.sort(out);return out
end
function MtMoonEvents.isPickup(id)content();return pickups[id]~=nil end
function MtMoonEvents.pickupFlag(id)assert(MtMoonEvents.isPickup(id),"unknown source pickup");return "PICKUP:"..id end
function MtMoonEvents.visible(id,quest)
    if FOSSILS[id]then return not quest("EVENT_GOT_DOME_FOSSIL")and not quest("EVENT_GOT_HELIX_FOSSIL")end
    if MtMoonEvents.isPickup(id)then return not quest(MtMoonEvents.pickupFlag(id))end
    return true
end
function MtMoonEvents.has(id)
    content();return simple[id]~=nil or pickups[id]~=nil or FOSSILS[id]~=nil or MtMoonSlice.trainer(id)~=nil
        or id==SELLER or id=="pokered:MT_MOON_POKECENTER:objects:1"or id=="pokered:MT_MOON_POKECENTER:objects:5"
end
function MtMoonEvents.plan(id,state)
    assert(MtMoonEvents.has(id)and state.intro=="done","unsupported or gated MtMoon event")
    local plan={id=id,status="ready",steps={},source_content="mt-moon"}
    local function dialog(labels,confirmed)plan.steps[#plan.steps+1]={op=confirmed and "confirmed-dialog"or "dialog",labels=labels}end
    local trainer=MtMoonSlice.trainer(id)
    if trainer then
        if state.receipt then
            assert(state.receipt.won and state.trainers[id],"source victory receipt not confirmed")
            dialog({"_"..trainer.dialogue_script_labels.won},true);plan.ram={wAmountMoneyWon=state.receipt.payout};dialog({"_MoneyForWinningText"},true)
        end
        if not state.trainers[id]then
            plan.status="trainer-battle";plan.steps[#plan.steps+1]={op="trainer",id=id,before={"_"..trainer.dialogue_script_labels.before},mode=state.mode or "talk"}
        elseif not state.receipt then
            local label=trainer.dialogue_script_labels.after
            if id==NERD and (state.flags.EVENT_GOT_DOME_FOSSIL or state.flags.EVENT_GOT_HELIX_FOSSIL)then label="MtMoonB2FSuperNerdTheresAPokemonLabText"end
            dialog({"_"..label})
        elseif id==NERD then dialog({"_MtMoonB2fSuperNerdEachTakeOneText"})end
    elseif pickups[id]then
        local item,flag=pickups[id],MtMoonEvents.pickupFlag(id)
        if state.flags[flag]then plan.status="already-complete"
        elseif not state.can_add[item]then dialog({"_NoMoreRoomForItemText"});plan.status="pickup-full"
        else
            plan.expected={flags={[flag]=false},items={[item]=state.items[item]}}
            plan.changes={flags={[flag]=true},items={{op="add",id=item,quantity=1}}}
            plan.ram={wStringBuffer=assert(ItemData.definitions[item]).name};plan.steps={{op="receipt",labels={"_FoundItemText"}}}
            plan.failure_labels={"_NoMoreRoomForItemText"};plan.pickup=id
        end
    elseif FOSSILS[id]then
        if state.flags.EVENT_GOT_DOME_FOSSIL or state.flags.EVENT_GOT_HELIX_FOSSIL then plan.status="already-complete"
        elseif not state.trainers[NERD]then plan.status="fossil-trainer-gate" -- physical source gate; no invented dialogue
        else
            local choice=FOSSILS[id];dialog({choice.prompt});plan.steps[#plan.steps+1]={op="fossil",id=id,item=choice.item}
            plan.expected={flags={EVENT_GOT_DOME_FOSSIL=false,EVENT_GOT_HELIX_FOSSIL=false},items={[choice.item]=state.items[choice.item]},trainers={[NERD]=true}}
            plan.changes={flags={[choice.flag]=true},items={{op="add",id=choice.item,quantity=1}},trainers={}}
            plan.ram={wStringBuffer=assert(ItemData.definitions[choice.item]).name};plan.failure_labels={"_MtMoonB2FYouHaveNoRoomText"}
        end
    elseif id==SELLER then
        if state.flags.EVENT_BOUGHT_MAGIKARP then dialog({"_MtMoonPokecenterMagikarpSalesmanNoRefundsText"})
        else dialog({"_MtMoonPokecenterMagikarpSalesmanIGotADealText"});plan.steps[#plan.steps+1]={op="gift",id=id}end
    elseif id=="pokered:MT_MOON_POKECENTER:objects:1"then
        plan.steps={{op="heal",id="mtMoonPokecenter",nurse_id=id,checkpoint={zone_id="pokered:ROUTE_4",x=11,y=6,facing="down"},
            welcome="_PokemonCenterWelcomeText",prompt="_ShallWeHealYourPokemonText",before="_NeedYourPokemonText",after="_PokemonFightingFitText",farewell="_PokemonCenterFarewellText"}}
    elseif id=="pokered:MT_MOON_POKECENTER:objects:5"then
        plan.status="source-empty-text" -- exact source clipboard text has no words
    else dialog(assert(simple[id]))end
    return plan
end
function MtMoonEvents.afterCommit(game,plan)
    if plan.pickup then
        for _,npc in ipairs(game.npcManager.npcs)do if npc.def and npc.def.source_event_id==plan.pickup then game.npcManager:removeNPC(npc);break end end
    end
end
MtMoonEvents.NERD,MtMoonEvents.SELLER=NERD,SELLER

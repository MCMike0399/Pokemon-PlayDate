-- Two bounded source interactions; no generic script VM or durable owner here.
Class("MoonInteraction")
local dirs={up={0,-1},right={1,0}}
local fossilIDs={"pokered:MT_MOON_B2F:objects:6","pokered:MT_MOON_B2F:objects:7"}
function MoonInteraction:init(event,step)
    self.event,self.step,self.open=event,step,true
    if step.op=="gift"then self.expected=assert(event.giftExpected,"paid-gift guard must predate the offer dialogue")end
    event.phase,event.waiting=step.op=="gift"and "gift-confirm"or "fossil-confirm","choice"
    local selected=event:guard(function(index)
        if not self.open then return end
        event.menu:hide();event.menu.onSelect,event.menu.onCancel=nil,nil
        if index==2 then
            self.open=false
            if step.op=="gift"then event:source({"_MtMoonPokecenterMagikarpSalesmanNoText"},function()event:finish()end)
            else event:finish()end
        elseif step.op=="gift"then self:gift()else self:fossil()end
    end)
    event.menu:show({"YES","NO"},selected,function()selected(2)end)
end
function MoonInteraction:gift()
    local event=self.event;local accepted,receipt=event.session:purchaseGift({species="magikarp",level=5,price=500,flag="EVENT_BOUGHT_MAGIKARP"},self.expected)
    self.open=false
    if not accepted then
        if receipt=="not-enough-money"then event:source({"_MtMoonPokecenterMagikarpSalesmanNoMoneyText"},function()event:finish()end)
        elseif receipt=="box-full"then event:source({"_BoxIsFullText"},function()event:finish()end)
        else event:fail(receipt)end
        return
    end
    self.receipt=receipt;event.committed=true;event.plan.ram={wNameBuffer=receipt.pokemon.name,wBoxMonNicks=receipt.pokemon.name,wStringBuffer=tostring(receipt.box or 1)}
    local labels={"_GotMonText"};if receipt.destination=="storage"then labels[#labels+1]="_SentToBoxText"end
    event:dialog(event:pages(labels),function()event:finish()end,true)
end
function MoonInteraction:prepareFossil()
    local event=self.event
    if event.zone.stableID~="pokered:MT_MOON_B2F"then return false,"wrong-fossil-zone"end
    local npc
    for _,actor in ipairs(event.game.npcManager.npcs)do if actor.def and actor.def.source_event_id==MtMoonEvents.NERD then npc=actor;break end end
    if not npc or npc.isMoving or npc.gridX~=12 or npc.gridY~=8 then return false,"fossil-actor-not-at-source-origin"end
    local selected=self.step.id==fossilIDs[1]and {x=12,y=6}or{x=13,y=6}
    local x,y=event.player:getFacingTile()
    if x~=selected.x or y~=selected.y then return false,"stale-fossil-facing"end
    -- Preserve the original position-based branch, including its sanctioned
    -- coordinates. Both visible fossil actors block the upper approach before
    -- choice;13,5 is not a demonstrated pre-choice position.
    local position=event.player.gridX..","..event.player.gridY
    local dome={['12,7']=true,['11,6']=true,['12,5']=true}
    local helix={['13,7']=true,['14,6']=true,['14,5']=true}
    local directions=dome[position]and {"right","up"}or helix[position]and {"up"}or nil
    if not directions then return false,"fossil-source-position-unresolved"end
    local route={};x,y=npc.gridX,npc.gridY
    for _,direction in ipairs(directions)do
        local d=dirs[direction];x,y=x+d[1],y+d[2]
        local occupant=event.game.npcManager:getNPCAt(x,y)
        if not event.zone.collision[y+1]or event.zone.collision[y+1][x+1]~=0 or occupant and occupant~=npc
            or event.player.gridX==x and event.player.gridY==y then return false,"blocked-fossil-source-route"end
        route[#route+1]={x=x,y=y,direction=direction}
    end
    self.npc,self.route,self.index,self.tick=npc,route,1,0
    return true
end
function MoonInteraction:removeFossils(onlySelected)
    local manager=self.event.game.npcManager;local remove={}
    for _,npc in ipairs(manager.npcs)do
        local id=npc.def and npc.def.source_event_id
        if id==self.step.id or not onlySelected and(id==fossilIDs[1]or id==fossilIDs[2])then remove[#remove+1]=npc end
    end
    for _,npc in ipairs(remove)do manager:removeNPC(npc)end
end
function MoonInteraction:fossil()
    local event=self.event;local ready,reason=self:prepareFossil()
    if not ready then self.open=false;event:fail(reason);return end
    local accepted,problem=event.session:transact(event.plan.expected,event.plan.changes)
    if not accepted then
        self.open=false
        if problem=="bag-full"then event:source({"_MtMoonB2FYouHaveNoRoomText"},function()event:finish()end)
        else event:fail(problem)end
        return
    end
    event.committed=true;self.committed=true;self:removeFossils(true)
    event:dialog(event:pages({"_MtMoonB2FReceivedFossilText"}),function()
        event.phase,event.waiting="fossil-move",MtMoonEvents.NERD
    end,true)
end
function MoonInteraction:update()
    if not self.open or not self.committed then return end
    local event=self.event;local step=self.route[self.index]
    if not step then
        self.open=false
        event:source({"_MtMoonB2FSuperNerdThenThisIsMineText"},function()self:removeFossils(false);event:finish()end)
        return
    end
    local npc=self.npc
    if self.tick==0 then self.fromX,self.fromY=npc.gridX,npc.gridY;npc.facing=step.direction;npc.isMoving=true end
    self.tick=self.tick+1
    npc:moveTo((self.fromX+(step.x-self.fromX)*self.tick/8)*TILE_SIZE,(self.fromY+(step.y-self.fromY)*self.tick/8)*TILE_SIZE-8)
    npc:setImage(MtMoonSprites.stepImage("SPRITE_SUPER_NERD",step.direction,self.tick))
    if self.tick==8 then
        npc.gridX,npc.gridY,npc.isMoving=step.x,step.y,false;npc:setFacing(step.direction)
        self.index,self.tick=self.index+1,0
    end
end
function MoonInteraction:exit()
    self.open=false
    if self.committed and self.event.game.session==self.event.session and currentZone==self.event.zone then
        -- Ownership is already committed. Cancelling presentation removes the
        -- transient other fossil and settles to the validated final source pose;
        -- it cannot resurrect a choice or leave an interpolated live sprite.
        self:removeFossils(false)
        local last=self.route[#self.route];self.npc.gridX,self.npc.gridY,self.npc.isMoving=last.x,last.y,false
        self.npc:moveTo(last.x*TILE_SIZE,last.y*TILE_SIZE-8);self.npc:setFacing(last.direction)
    end
end

function MoonInteraction:snapshot()
    return {kind=self.step.op,committed=self.event.committed,choice=self.step.id,destination=self.receipt and self.receipt.destination or nil,
        box=self.receipt and self.receipt.box or nil,index=self.index,tick=self.tick,actor=self.npc and {x=self.npc.gridX,y=self.npc.gridY,facing=self.npc.facing}or nil}
end

-- Native Zone factory adapter, not a second world/provider/controller owner.
MtMoonFactory={}
local starts={Route3={0,9},Route4={11,6},MtMoonPokecenter={3,7},MtMoon1F={14,35},MtMoonB1F={5,5},MtMoonB2F={25,9}}
function MtMoonFactory.create(game,name,registry,desired,isolated)
    local d=MtMoonSlice.definition(name);local start=assert(starts[name])
    if not isolated then MtMoonSprites.installFor(d)end
    local zone=Zone.fromMapDefinition(d,registry,{registry=registry,bindingAdapter=MtMoonBindings,compactTerrain=true,isolatedCatalog=isolated or false,
        spawn={x=start[1],y=start[2],facing="up"},sliceBindings=MtMoonSlice.specs(name,d),
        dispatch=function(id)assert(not isolated,"isolated source events cannot execute");return KantoWorld.dispatch(game,id)end,
        questFlag=function(id)return not isolated and game.session:questFlag(id)or false end,
        sourceFlag=function(id)return not isolated and game.trainers:sourceFlag(id)or false end})
    if desired and desired.tile_count>0 then
        local entries={};for _,tile in ipairs(desired.tiles)do if not registry:has(tile.key)then entries[#entries+1]=CampaignContent:tile(tile.key)end end
        if #entries>0 then registry:registerBatch(entries)end;zone:applyDeltas(desired)
    end
    return zone
end
function MtMoonFactory.isolated(name)return MtMoonFactory.create(nil,name,TileRegistry(),nil,true)end

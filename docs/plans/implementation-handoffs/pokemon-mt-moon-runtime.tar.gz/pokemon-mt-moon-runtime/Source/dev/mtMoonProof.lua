-- Private native artifacts, explicitly unreviewed. Not a default catalog hook.
MtMoonProof={}
local gfx=playdate.graphics
function MtMoonProof.save(image,name)
    assert(HarnessBuild and HarnessBuild.enabled and playdate.simulator,"owned Simulator proof required")
    assert(type(name)=="string"and name:match("^[A-Za-z0-9_-]+$"),"safe native artifact name required")
    playdate.simulator.writeToFile(image,HarnessBuild.output_dir..name..".png")
end
local function mask(image)
    local actual=image:getMaskImage();if actual then return actual end
    local w,h=image:getSize();return gfx.image.new(w,h,gfx.kColorBlack)
end
function MtMoonProof.scene(g)
    local view=WorldView(currentZone,{attach=false});local terrain=view:render();view:dispose()
    local image=gfx.image.new(400,240,gfx.kColorWhite)
    local x=math.max(0,math.min(currentZone.width*TILE_SIZE-400,g.player.x+16-200))
    local y=math.max(0,math.min(currentZone.height*TILE_SIZE-240,g.player.y+8-120))
    gfx.pushContext(image);gfx.setDrawOffset(-x,-y);gfx.clearClipRect();gfx.clearStencil();gfx.setImageDrawMode(gfx.kDrawModeCopy)
    terrain:draw(0,0)
    for _,npc in ipairs(g.npcManager.npcs)do npc:getImage():draw(npc.x,npc.y)end
    g.player:getImage():draw(g.player.x,g.player.y)
    gfx.popContext();return image
end
function MtMoonProof.maps()
    local inventory={schema=1,status="unreviewed native source artifacts",images={},events={}}
    local function save(image,name,category,extra)
        MtMoonProof.save(image,name);local w,h=image:getSize();local row={path=name..".png",width=w,height=h,category=category}
        for k,v in pairs(extra or{})do row[k]=v end;inventory.images[#inventory.images+1]=row
    end
    local strips={};local bindings=assert(json.decodeFile("data/mtMoonSlice/sprites.json"))
    for name in pairs(bindings.sprites)do strips[#strips+1]=name end;table.sort(strips)
    for _,name in ipairs(strips)do
        local strip=bindings.sprites[name]
        for frame=0,5 do if strip.frames[tostring(frame)]then
            local image=SpriteFactory.makeSprite(strip.frames[tostring(frame)],{0,0});local prefix="moon-source-"..name.."-"..frame
            save(image,prefix,"source-frame",{source_id=strip.id,frame=frame});save(mask(image),prefix.."-mask","source-mask",{source_id=strip.id,frame=frame})
        end end
    end
    for _,name in ipairs(MtMoonSlice.names())do
        local zone=MtMoonFactory.isolated(name);local view
        local ok,problem=pcall(function()
            view=WorldView(zone,{attach=false});local image=view:render();save(image,"moon-"..name.."-terrain","terrain",{zone_id=zone.stableID})
            local collision=gfx.image.new(zone.width*TILE_SIZE,zone.height*TILE_SIZE,gfx.kColorWhite)
            gfx.pushContext(collision);gfx.setDrawOffset(0,0);gfx.setColor(gfx.kColorBlack)
            for y,row in ipairs(zone.collision)do for x,value in ipairs(row)do if value~=0 then gfx.fillRect((x-1)*32,(y-1)*32,32,32)end end end
            gfx.popContext();save(collision,"moon-"..name.."-collision","collision")
            local actors=image:copy();gfx.pushContext(actors);gfx.setDrawOffset(0,0)
            for _,def in ipairs(zone.npcDefs)do
                local strip=MtMoonSlice.sprite(def.source_sprite);local direction=def.facing;local frame=assert(strip.standing[direction=="right"and "left"or direction])
                local actor=SpriteFactory.makeSprite(strip.frames[tostring(frame)],{0,0});if direction=="right"then actor=SpriteFactory.flipped(actor)end
                actor:draw(def.gridX*32,def.gridY*32-8)
            end
            gfx.popContext();save(actors,"moon-"..name.."-actors","actors")
            local overlay=image:copy();gfx.pushContext(overlay);gfx.setDrawOffset(0,0);gfx.setFont(gfx.getSystemFont());gfx.setLineWidth(1)
            local definition=MtMoonSlice.definition(name)
            for _,kind in ipairs({"objects","warps","background_events"})do for index,event in ipairs(definition.events[kind])do
                gfx.setColor(gfx.kColorWhite);gfx.fillRect(event.x*32+1,event.y*32+1,30,22);gfx.setColor(gfx.kColorBlack);gfx.drawRect(event.x*32+1,event.y*32+1,30,22)
                gfx.drawText((kind=="objects"and "O"or kind=="warps"and "W"or "B")..index,event.x*32+3,event.y*32+3)
                inventory.events[#inventory.events+1]={id=event.id,x=event.x,y=event.y,kind=kind}
            end end
            gfx.popContext();save(overlay,"moon-"..name.."-events","events")
            local viewport=gfx.image.new(400,240,gfx.kColorWhite);local sx,sy=zone.spawn.x*32,zone.spawn.y*32
            gfx.pushContext(viewport);gfx.setDrawOffset(0,0);actors:draw(-math.max(0,math.min(zone.width*32-400,sx-184)),-math.max(0,math.min(zone.height*32-240,sy-112)));gfx.popContext()
            save(viewport,"moon-"..name.."-viewport","viewport")
        end)
        if view then view:dispose()end;assert(ok,problem)
    end
    json.encodeToFile("mt-moon-native-inventory.json",true,inventory)
end

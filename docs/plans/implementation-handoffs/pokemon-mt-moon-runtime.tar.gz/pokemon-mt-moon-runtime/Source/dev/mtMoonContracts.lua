MtMoonContracts={}
local gfx=playdate.graphics
local function eq(a,b)assert(a==b,"expected "..tostring(b)..", got "..tostring(a))end
local function same(a,b)assert(CampaignCatalog.same(a,b),"defensive primitive records differ")end
local function rejects(fn,fragment)
    local ok,problem=pcall(fn);assert(not ok,"expected rejection")
    if fragment then assert(tostring(problem):find(fragment,1,true),tostring(problem))end
end
local games={}
local function fresh(name,x,y,facing)
    local g=GameContext({sessionLocationPolicy=PewterWorld.locationPolicy()});games[#games+1]=g
    assert(g:recruit(Pokemon("squirtle",10)));assert(g.session:setIntro({stage="done",starter="squirtle",rivalStarter="bulbasaur",rivalOutcome=true}))
    g.trainers=TrainerEvents(g)
    if name then
        local zone=MtMoonFactory.create(g,name,TileRegistry(),nil,false);currentZone=zone
        local position={zone_id=zone.stableID,x=x,y=y,facing=facing or "up"}
        assert(g.session:captureTraversal({world=WorldDeltas.export(),location=position}))
        g.player=Player(x,y,zone.collision,g.npcManager);g.player.facing=position.facing;g.player:updateSprite();g.player:setUpdatesEnabled(false)
        zone:spawnNPCs(g.npcManager)
        local sub=StateMachine();sub:register("explore",{});sub:change("explore")
        g.machine:register("overworld",{sub=sub});g.machine:register("dialog",DialogState(g));g.machine:register("event",EventState(g));g.machine:change("overworld")
        g.npcManager.motion:attach(g,zone)
    end
    return g
end
local function providerScope(fn)
    local oldRegistry,oldList,oldZone=zoneRegistry,zoneList,currentZone
    local oldProvider=WorldDeltas.definitionProvider();local g=fresh();local registry=TileRegistry();local provider=PewterWorld.createProvider(g,registry)
    zoneRegistry,zoneList={},{}
    for _,key in ipairs(oldList)do local zone=oldRegistry[key]
        if not oldProvider:owns(zone)then zoneRegistry[key]=zone;zoneList[#zoneList+1]=key end
    end
    currentZone=zoneRegistry.reds_house_2f
    local ok,problem=pcall(function()WorldDeltas._withDefinitionProvider(provider,function()fn(g,provider,registry)end)end)
    provider:disposeCache();zoneRegistry,zoneList,currentZone=oldRegistry,oldList,oldZone
    assert(ok,problem)
end
local function closeDialogs(g,limit)
    for _=1,limit or 64 do
        if g.machine:getCurrent()~="dialog"then return end
        local d=g.machine:get("dialog");d.dialog.onComplete();d:handleInput()
    end
    error("bounded source dialogue did not complete")
end
local function fillBag(g,except)
    local ids={};for id in pairs(ItemData.definitions)do if id~=except and id~="domeFossil"and id~="helixFossil"then ids[#ids+1]=id end end;table.sort(ids)
    for _,id in ipairs(ids)do if g.session:inventory():count()==Inventory.CAPACITY then return end;assert(g.session:inventory():add(id,1))end
end
local function giftGuard(session)return {money=session:inventory():money(),party_count=session:party():count(),box=session:storage():activeBox(),box_count=session:storage():count()}end
local OFFER={species="magikarp",level=5,price=500,flag="EVENT_BOUGHT_MAGIKARP"}
local function model(g)
    return {party=assert(g.session:party():toData(PokemonCodec.encode)),storage=assert(g.session:storage():toData(PokemonCodec.encode)),bag=g.session:inventory():toData(),
        intro=g.session:getIntro(),flags=g.session:flags(),dex=g.session:pokedex(),rng=RulesRNG.toData(),worldRng=g.session:worldRngData(),actors=g.session:actorData()}
end
function MtMoonContracts.run()
    local report={ok=true,passed=0,failed=0,tests={}}
    local function test(name,fn)
        local zone=currentZone;local story=Story.currentContext();local owner=GameSession.activeRNGSession();local rng=RulesRNG.toData();local ox,oy=gfx.getDrawOffset()
        local oldSprites={};for _,s in ipairs(gfx.sprite.getAllSprites())do oldSprites[s]={visible=s:isVisible(),enabled=s:updatesEnabled()}end
        local sets={};for k,v in pairs(SpriteFactory.npc)do sets[k]=v end
        local ids=WorldTiles:maxID();local cache=WorldDeltas.definitionProvider():snapshot();games={}
        local ok,problem=pcall(fn)
        for _,g in ipairs(games)do
            if g.machine:get("overworld")then pcall(g.machine.change,g.machine,"overworld")end
            g.npcManager:clear()
            if GameSession.activeRNGSession()==g.session then g.session:deactivateRNG()end
        end
        for _,s in ipairs(gfx.sprite.getAllSprites())do if not oldSprites[s]then s:remove()end end
        for s,value in pairs(oldSprites)do s:setVisible(value.visible);s:setUpdatesEnabled(value.enabled)end
        for k in pairs(SpriteFactory.npc)do if not sets[k]then SpriteFactory.npc[k]=nil end end
        for k,v in pairs(sets)do SpriteFactory.npc[k]=v end
        currentZone=zone;Story.bind(story)
        local active=GameSession.activeRNGSession();if active and active~=owner then active:deactivateRNG()end
        if owner then assert(owner:activateRNG())end;assert(RulesRNG.restoreData(rng));gfx.setDrawOffset(ox,oy)
        local cleaned,cleanupError=pcall(function()eq(WorldTiles:maxID(),ids);same(WorldDeltas.definitionProvider():snapshot(),cache);same(RulesRNG.toData(),rng)end)
        if not cleaned then ok=false;problem=tostring(problem).." cleanup: "..tostring(cleanupError)end
        report.tests[#report.tests+1]={name=name,ok=ok,error=not ok and tostring(problem)or nil}
        if ok then report.passed=report.passed+1 else report.failed=report.failed+1;report.ok=false end
    end
    test("Closed immutable catalog composes14maps and exact shared tiles without touching provider cache",function()
        local all=CampaignContent:compact();local count=0;for _ in pairs(all.maps)do count=count+1 end;eq(count,14)
        eq(#CampaignContent:inventory("mt-moon").maps,6);eq(#CampaignContent:inventory("pewter").maps,8)
        eq(CampaignContent:ownsMap("mt-moon","pokered:MT_MOON_B1F"),true);eq(CampaignContent:ownsMap("pewter","pokered:MT_MOON_B1F"),false)
        local native=MtMoonSprites.key("SPRITE_ROCKET");eq(CampaignContent:ownsNPC("mt-moon",native),true);eq(CampaignContent:ownsNPC("pewter",native),false)
        all.maps.Route3.width=1;eq(CampaignContent:map("Route3").descriptor.width,70)
        rejects(function()CampaignContent:register("late",CampaignRegions.mtMoon())end,"closed")
        local c=CampaignCatalog();c:register("original",CampaignRegions.pewter())
        rejects(function()c:register("duplicate",CampaignRegions.pewter())end,"duplicate")
        c:register("moon",CampaignRegions.mtMoon());c:seal();eq(c:map("MtMoonB1F").descriptor.width,28)
    end)
    test("Production14map provider keeps LRU2 and Moon deltas across all regions and cold save decode",function()
        eq(#WorldDeltas.definitionProvider():inventory(),14)
        providerScope(function(g,p,registry)
            eq(#p:inventory(),14)
            for _,descriptor in ipairs(p:inventory())do currentZone=p:ensure(descriptor.key);assert(#p:snapshot().cached<=2)end
            local zone=p:ensure("kanto_mt_moon_1f");currentZone=zone;eq(zone.collision[35][15],0)
            local original=zone.registry:key(zone.tiles[35][15]);zone:setTile(14,34,"base:3");eq(zone.collision[35][15],1)
            for _,descriptor in ipairs(p:inventory())do currentZone=p:ensure(descriptor.key)end
            local world=WorldDeltas.export();eq(p:export().zone_count,1)
            local position={zone_id="pokered:MT_MOON_1F",x=14,y=35,facing="up"}
            assert(g.session:captureTraversal({location=position,world=world,checkpoint={zone_id="pokered:ROUTE_4",x=11,y=6,facing="down"}}))
            local wire=assert(SessionCodec.encode(g.session,{root="overworld",overworld="explore",settled=true}))
            local ids,cache=registry:maxID(),p:snapshot();local restored=assert(SessionCodec.decode(wire,g:getSessionDependencies()))
            eq(registry:maxID(),ids);same(p:snapshot(),cache);same(restored:worldData(),world)
            rejects(function()p:resolveLocation({zone_id=position.zone_id,x=14,y=34,facing="up"},p:export(),g.sessionLocationPolicy)end)
            local reload=p:ensure("kanto_mt_moon_1f");currentZone=reload;eq(reload.collision[35][15],1);eq(reload.registry:key(reload.tiles[35][15]),"base:3")
            reload:setTile(14,34,original);eq(p:export().zone_count,0)
        end)
    end)
    test("Actual Moon native-view fault and malformed world candidates leave provider/cache/IDs unchanged",function()
        providerScope(function(g,p,registry)
            local zone=p:ensure("kanto_mt_moon_1f");currentZone=zone
            local original=zone.registry:key(zone.tiles[35][15]);local before=p:snapshot();local ids=registry:maxID()
            local fault={applyTiles=function()error("controlled Moon view rejection")end};zone:attachView(fault)
            rejects(function()zone:setTile(14,34,"base:3")end,"controlled Moon view rejection");zone:detachView(fault)
            eq(zone.registry:key(zone.tiles[35][15]),original);eq(zone.collision[35][15],0);eq(p:export().zone_count,0);eq(registry:maxID(),ids);same(p:snapshot(),before)
            local bad={schema=1,zone_count=1,zones={{schema=1,zone_id="pokered:MT_MOON_1F",definition_revision="af519899719f0754965776faac0e836a3b906e6d",tile_count=1,tiles={{x=14,y=34,key="unknown:tile"}}}}}
            rejects(function()p:apply(bad)end);same(p:snapshot(),before);eq(registry:maxID(),ids)
            rejects(function()p:resolveLocation({zone_id="pokered:MT_MOON_1F",x=14,y=35,facing="up"},p:export(),{sliceZones={}})end)
        end)
    end)
    test("All six actual source Zones and22warp projections retain passable exact arrivals",function()
        local count=0
        for _,name in ipairs(MtMoonSlice.names())do
            local zone=MtMoonFactory.isolated(name);local d=MtMoonSlice.definition(name)
            eq(zone.stableID,d.id);eq(zone:isSliceReady(),true)
            for _,event in ipairs(d.events.warps)do
                local spec=MtMoonSlice.warpSpec(name,event);local target=MtMoonSlice.descriptor(spec.target_name)
                eq(MtMoonSlice.cell(spec.target_name,spec.toX,spec.toY).collision,0)
                eq(spec.toX,target.warps[spec.target_warp].x)
                eq(spec.toY,target.warps[spec.target_warp].y+(spec.target_name=="Route4"and 1 or 0));count=count+1
            end
            zone:disposeView()
        end
        eq(count,22)
    end)
    test("Source route connections preserve original offsets and explicit Brock/Cerulean gates",function()
        local g=fresh();local pewter=PewterWorld.isolated("PewterCity")
        local door,handled,reason=PewterWorld.connection(g,pewter,39,18,"right");eq(door,nil);eq(handled,true);eq(reason,"source-brock-gate")
        assert(g.session:setTrainerDefeated(TrainerEvents.BROCK,true))
        door=assert(PewterWorld.connection(g,pewter,39,18,"right"));eq(door.to,"kanto_route3");eq(door.toX,0);eq(door.toY,10)
        local route3=MtMoonFactory.isolated("Route3");door=assert(PewterWorld.connection(g,route3,0,10,"left"));eq(door.toX,39);eq(door.toY,18)
        local route4=MtMoonFactory.isolated("Route4");door,handled,reason=PewterWorld.connection(g,route4,89,10,"right");eq(door,nil);eq(handled,true);assert(reason:find("unimplemented-source-exit",1,true))
    end)
    test("Original inaccessible Route4 trainer stays indexed with exact Lv31party/payout",function()
        local d=assert(CampaignContent:trainers()["pokered:ROUTE_4:objects:2"]);eq(d.payout,465);eq(#d.party,3)
        for _,mon in ipairs(d.party)do eq(mon.level,31)end
        eq(d.party[1].species,"paras");eq(d.party[3].species,"parasect")
        local record=MtMoonSlice.definition("Route4");eq(record.collision[6][64],1) -- wall beneath upper eastern component
    end)
    test("Paid gift commits actual specimen identity/debit/flag once retaining domain owners",function()
        local g=fresh();assert(g.session:activateRNG());local party,box,bag=g.session:party(),g.session:storage(),g.session:inventory()
        local accepted,result=g.session:purchaseGift(OFFER,giftGuard(g.session));assert(accepted,result)
        eq(result.destination,"party");eq(party:get(2),result.pokemon);eq(result.pokemon.species,"magikarp");eq(result.pokemon.level,5)
        eq(bag:money(),2500);eq(g.session:questFlag("EVENT_BOUGHT_MAGIKARP"),true);eq(g.session:pokedex().owned.magikarp,true)
        eq(g.session:party(),party);eq(g.session:storage(),box);eq(g.session:inventory(),bag)
        local before=model(g);eq(g.session:purchaseGift(OFFER,giftGuard(g.session)),false);same(model(g),before)
    end)
    test("Paid gift party6routes same new mon to chosen box and fullbox leaves all state/RNG exact",function()
        local g=fresh();while g.session:party():count()<6 do assert(g:recruit(Pokemon("pidgey",5)))end
        assert(g.session:activateRNG());assert(g.session:storage():selectBox(3))
        local accepted,result=g.session:purchaseGift(OFFER,giftGuard(g.session));assert(accepted,result);eq(result.destination,"storage");eq(result.box,3);eq(g.session:storage():get(1,3),result.pokemon)
        local full=fresh();while full.session:party():count()<6 do assert(full:recruit(Pokemon("pidgey",5)))end
        for _=1,20 do assert(full:recruit(Pokemon("rattata",5)))end
        assert(full.session:activateRNG());local before=model(full);local ok,reason=full.session:purchaseGift(OFFER,giftGuard(full.session));eq(ok,false);eq(reason,"box-full");same(model(full),before)
        assert(full.session:storage():selectBox(2));eq(full.session:purchaseGift(OFFER,giftGuard(full.session)),true)
    end)
    test("Gift insufficient money stale guards inactive owner and exhausted creation leave exact model unchanged",function()
        local g=fresh();assert(g.session:activateRNG());assert(g.session:inventory():spend(2600))
        local before=model(g);local ok,reason=g.session:purchaseGift(OFFER,giftGuard(g.session));eq(ok,false);eq(reason,"not-enough-money");same(model(g),before)
        assert(g.session:inventory():credit(1000));local guard=giftGuard(g.session);assert(g.session:inventory():credit(1));before=model(g);eq(g.session:purchaseGift(OFFER,guard),false);same(model(g),before)
        local wire=RulesRNG.toData();wire.rolls="2147483647";assert(RulesRNG.restoreData(wire));before=model(g);eq(g.session:purchaseGift(OFFER,giftGuard(g.session)),false);same(model(g),before)
        local inactive=fresh();before=model(inactive);eq(inactive.session:purchaseGift(OFFER,giftGuard(inactive.session)),false);same(model(inactive),before)
    end)
    test("Source seller real menu NO and exited stale YES cannot debit recruit or draw RNG",function()
        local g=fresh("MtMoonPokecenter",9,6,"right");assert(g.session:activateRNG())
        -- Source seller can wander; test binds the original settled approach.
        g.machine:push("event",MtMoonEvents.SELLER);closeDialogs(g);local event=g.machine:get("event");eq(event.phase,"gift-confirm")
        local before=model(g);local stale=event.menu.onSelect;event:handleButton("b");closeDialogs(g);eq(g.machine:getCurrent(),"overworld");same(model(g),before)
        g.machine:push("event",MtMoonEvents.SELLER);closeDialogs(g);stale=event.menu.onSelect;g.machine:pop();before=model(g);stale(1);same(model(g),before)
    end)
    test("Fossil full bag retry gives exactly one original key item after real YES",function()
        local g=fresh("MtMoonB2F",12,7,"up");assert(g.session:setTrainerDefeated(MtMoonEvents.NERD,true));fillBag(g,"domeFossil")
        g.machine:push("event","pokered:MT_MOON_B2F:objects:6");closeDialogs(g);local event=g.machine:get("event");eq(event.phase,"fossil-confirm")
        local before=model(g);event:handleButton("a");closeDialogs(g);eq(g.machine:getCurrent(),"overworld");same(model(g),before)
        local remove;for _,slot in ipairs(g.session:inventory():slots())do if not ItemData.definitions[slot.id].keyItem then remove=slot;break end end
        assert(remove);assert(g.session:inventory():consume(remove.id,remove.quantity))
        g.machine:push("event","pokered:MT_MOON_B2F:objects:6");closeDialogs(g);event:handleButton("a");closeDialogs(g);eq(event.phase,"fossil-move")
        local rng=RulesRNG.toData();local worldRng=g.session:worldRngData()
        for _=1,17 do event:update()end;closeDialogs(g);eq(g.machine:getCurrent(),"overworld")
        eq(g.session:inventory():quantity("domeFossil"),1);eq(g.session:inventory():quantity("helixFossil"),0);eq(g.session:questFlag("EVENT_GOT_DOME_FOSSIL"),true);eq(g.session:questFlag("EVENT_GOT_HELIX_FOSSIL"),false)
        same(RulesRNG.toData(),rng);same(g.session:worldRngData(),worldRng)
        local count=0;for _,npc in ipairs(g.npcManager.npcs)do if npc.def.source_event_id=="pokered:MT_MOON_B2F:objects:6"or npc.def.source_event_id=="pokered:MT_MOON_B2F:objects:7"then count=count+1 end end;eq(count,0)
    end)
    test("Fossil NO precommit cancellation and stale transaction have no reward/receipt",function()
        local g=fresh("MtMoonB2F",13,7,"up");assert(g.session:setTrainerDefeated(MtMoonEvents.NERD,true))
        g.machine:push("event","pokered:MT_MOON_B2F:objects:7");closeDialogs(g);local event=g.machine:get("event");local before=model(g);event:handleButton("b");same(model(g),before)
        g.machine:push("event","pokered:MT_MOON_B2F:objects:7");closeDialogs(g);local stale=event.menu.onSelect;g.machine:pop();before=model(g);stale(1);same(model(g),before)
        g.machine:push("event","pokered:MT_MOON_B2F:objects:7");closeDialogs(g);assert(g.session:setQuestFlag("EVENT_GOT_DOME_FOSSIL",true));before=model(g);event:handleButton("a");eq(event.phase,"failed");same(model(g),before);eq(event.committed,false)
    end)
    test("Cave floor consumes one eligible encounter draw; ladders/after-Nerd safe rectangle consume none",function()
        local g=fresh("MtMoonB2F",13,8,"up");assert(g.session:activateRNG());local zone=currentZone
        local before=RulesRNG.snapshot();zone:checkEncounter(13,8);eq(RulesRNG.snapshot().rolls,before.rolls+1)
        assert(g.session:setTrainerDefeated(MtMoonEvents.NERD,true));before=RulesRNG.toData();eq(zone:checkEncounter(13,8),false);same(RulesRNG.toData(),before)
        eq(zone:checkEncounter(25,9),false);same(RulesRNG.toData(),before)
    end)
    test("Actual new seller walker uses descriptor renderer for all eight native source frames",function()
        local g=fresh("MtMoonPokecenter",3,6,"up");local motion=g.npcManager.motion;local seller
        for _,npc in ipairs(g.npcManager.npcs)do if npc.def.source_event_id==MtMoonEvents.SELLER then seller=npc end end
        assert(seller);local before=RulesRNG.toData();local count=0
        for tick=1,8 do
            motion:tick();local actor=assert(motion:actor(seller));eq(actor.tick,tick%8)
            local actual=seller:getImage();local expected=MtMoonSprites.stepImage("SPRITE_MIDDLE_AGED_MAN",seller.facing,tick)
            local am,em=assert(actual:getMaskImage()),assert(expected:getMaskImage())
            for y=0,31 do for x=0,31 do eq(actual:sample(x,y),expected:sample(x,y));eq(am:sample(x,y),em:sample(x,y))end end
            if MtMoonProof then MtMoonProof.save(actual,string.format("moon-seller-frame-%02d",tick));MtMoonProof.save(am,string.format("moon-seller-mask-%02d",tick))end
            count=count+1
        end
        eq(count,8);eq(seller.isMoving,false);same(RulesRNG.toData(),before)
        local actors=motion:snapshot();SourceActors.validate(actors,WorldDeltas.export(),{zone_id=currentZone.stableID,x=3,y=6,facing="up"},g.session:flags())
    end)
    test("Helix source UP sequence and postcommit cancellation settle without duplicate grant",function()
        local g=fresh("MtMoonB2F",13,7,"up");assert(g.session:setTrainerDefeated(MtMoonEvents.NERD,true))
        g.machine:push("event","pokered:MT_MOON_B2F:objects:7");closeDialogs(g);local event=g.machine:get("event");event:handleButton("a");closeDialogs(g)
        eq(event.phase,"fossil-move");local before=RulesRNG.toData();event:update();event:update()
        if MtMoonProof then MtMoonProof.save(MtMoonProof.scene(g),"moon-helix-motion-02")end
        g.machine:pop();eq(g.session:inventory():quantity("helixFossil"),1);eq(g.session:inventory():quantity("domeFossil"),0)
        local nerd;for _,npc in ipairs(g.npcManager.npcs)do if npc.def.source_event_id==MtMoonEvents.NERD then nerd=npc end end
        assert(nerd);eq(nerd.gridX,12);eq(nerd.gridY,7);eq(nerd.isMoving,false);same(RulesRNG.toData(),before)
        local captured=g.npcManager.motion:snapshot();SourceActors.validate(captured,WorldDeltas.export(),{zone_id=currentZone.stableID,x=13,y=7,facing="up"},g.session:flags())
    end)
    test("New Center heal real menu decline is unchanged and acceptance restores party/checkpoint",function()
        local g=fresh("MtMoonPokecenter",3,3,"up");local mon=g.session:activePokemon();mon.hp=1;mon.status="burn";mon.pp[mon.moves[1]]=0
        local held=mon.heldItem;local nature=mon.natureId;local ability=mon.abilitySlot
        g.machine:push("event","pokered:MT_MOON_POKECENTER:objects:1");closeDialogs(g);local event=g.machine:get("event");eq(event.phase,"heal-confirm")
        local before=model(g);event:handleButton("b");closeDialogs(g);same(model(g),before)
        g.machine:push("event","pokered:MT_MOON_POKECENTER:objects:1");closeDialogs(g);event:handleButton("a");closeDialogs(g);eq(event.phase,"heal-animation")
        if MtMoonProof then MtMoonProof.save(MtMoonProof.scene(g),"moon-center-heal-before")end
        for _=1,71 do event:update()end;closeDialogs(g);eq(g.machine:getCurrent(),"overworld")
        eq(mon.hp,mon.maxHP);eq(mon.status,nil);eq(mon.pp[mon.moves[1]],moveData[mon.moves[1]].maxPP)
        eq(mon.heldItem,held);eq(mon.natureId,nature);eq(mon.abilitySlot,ability)
        local checkpoint=g.session:checkpoint();eq(checkpoint.zone_id,"pokered:ROUTE_4");eq(checkpoint.x,11);eq(checkpoint.y,6)
    end)
    test("All pinned map/native actor artifacts are exported with required host inventory",function()
        assert(MtMoonProof,"native proof module required");MtMoonProof.maps()
    end)
    test("New Center machine/terminal/source checkpoint reuse exact approved geometry",function()
        local zone=MtMoonFactory.isolated("MtMoonPokecenter");local layout=HealingComposition.layout(zone);eq(layout.monitor.x,56);eq(layout.monitor.y,8)
        local terminal=PCTerminals.query({zone_id=zone.stableID,x=13,y=4,facing="up"});assert(terminal);eq(terminal.id,"pokered:MT_MOON_POKECENTER:hidden:2")
        eq(PCTerminals.query({zone_id=zone.stableID,x=13,y=4,facing="down"}),nil)
        local plan=MtMoonEvents.plan("pokered:MT_MOON_POKECENTER:objects:1",{intro="done",flags={},trainers={},items={},can_add={}})
        eq(plan.steps[1].checkpoint.x,11);eq(plan.steps[1].checkpoint.y,6)
    end)
    return report
end

-- Six pinned Blue definitions, weak raw-map cache and defensive metadata.
MtMoonSlice={}
local REV="af519899719f0754965776faac0e836a3b906e6d"
local cache=setmetatable({},{__mode="v"});local metadata={}
local function record(name)
    local d=assert(json.decodeFile("data/mtMoonSlice/"..name..".json"),"missing original MtMoon data")
    assert(d.schema==1 and d.source_revision==REV,"unverified MtMoon source revision")
    return d
end
local function data(name)if not metadata[name]then metadata[name]=record(name)end;return metadata[name]end
local function copy(v)return Party._primitive(v)end
function MtMoonSlice.names()return copy(data("index").names)end
function MtMoonSlice.descriptor(name)return copy(assert(data("descriptors").maps[name],"unknown MtMoon map"))end
function MtMoonSlice.nameForID(id)
    for name,d in pairs(data("descriptors").maps)do if d.id==id then return name end end
end
function MtMoonSlice.definition(name)
    MtMoonSlice.descriptor(name)
    if not cache[name]then cache[name]=record(name)end
    return copy(cache[name])
end
function MtMoonSlice.compact()return copy(data("compact"))end
function MtMoonSlice.tile(key)return copy(assert(data("tile-grids").tiles[key],"unknown MtMoon tile"))end
function MtMoonSlice.cell(name,x,y)
    local d=assert(data("compact").maps[name]);assert(Party._integer(x,0,d.width-1)and Party._integer(y,0,d.height-1),"MtMoon cell outside map")
    return copy(assert(data("compact").tiles[d.palette[assert(tonumber(d.tile_rows[y+1]:sub(x*2+1,x*2+2),16))]]))
end
function MtMoonSlice.trainers()
    local out={}
    for _,value in ipairs(data("trainers").trainers)do
        local d=copy(value);d.name=assert(data("index").trainer_names[d.class_source]);out[d.id]=d
        for _,mon in ipairs(d.party)do assert(pokemonData[mon.species],"unknown original trainer species")end
    end
    return out
end
function MtMoonSlice.trainer(id)return MtMoonSlice.trainers()[id]end
function MtMoonSlice.sprite(source)
    local binding=assert(data("sprites").mapping[source],"unknown MtMoon original sprite")
    return copy(assert(data("sprites").sprites[binding.name])),binding.name
end
function MtMoonSlice.text(label)return copy(assert(data("dialogue").texts[label],"missing original MtMoon text: "..tostring(label)))end
function MtMoonSlice.hidden()return copy(data("hidden-events").events)end
function MtMoonSlice.eventIDs()return copy(data("index").event_ids)end
function MtMoonSlice.warpSpec(name,event)
    local target=event.destination.kind=="last_outdoor_map"and "Route4"or MtMoonSlice.nameForID("pokered:"..tostring(event.destination.map))
    assert(target,"MtMoon source warp target missing")
    local d=MtMoonSlice.descriptor(target);local arrival=assert(d.warps[event.destination.warp_index],"MtMoon source target warp missing")
    local advance=target=="Route4"and 1 or 0
    assert(MtMoonSlice.cell(target,arrival.x,arrival.y+advance).collision==0,"MtMoon source arrival blocked")
    return {status="bound",to=d.key,toX=arrival.x,toY=arrival.y+advance,facing=advance==1 and "down"or nil,preserveFacing=advance==0,
        target_name=target,target_warp=event.destination.warp_index,arrival_advance=advance}
end
function MtMoonSlice.specs(name,d)
    d=d or MtMoonSlice.definition(name);local specs={}
    for _,kind in ipairs({"objects","background_events","warps"})do
        for _,event in ipairs(d.events[kind])do
            specs[event.id]=kind=="warps"and MtMoonSlice.warpSpec(name,event)or {status=MtMoonEvents.has(event.id)and "bound"or "blocked",reason="original optional control not implemented"}
        end
    end
    for _,c in ipairs(d.connections)do specs[c.direction..":"..c.target_map]={status=c.target_map=="CERULEAN_CITY"and "blocked"or "bound"}end
    if #d.directional_rules.ledges>0 then specs["ledges:"..d.id]={status="bound"}end
    specs[d.script.source]={status="bound"}
    if d.encounters.grass.rate_byte>0 then specs[d.id]={status="bound"}end
    return specs
end

# Batch01 errata01

Frozen original batch01 is untouched. This separate followup changes only the public calcDamage nonpositive effective-power guard, and adds one production SDK regression. Compile/run the composed helper, which overlays the original five files plus this narrow guard/contract onto current Source:

```
python3 /private/tmp/pokemon-brock-move-batch01-errata01/combined/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-brock-batch01-errata-sdk-NEW --execute
```

Expected new authored groups: original36 +errata1; root actual runtime remains authoritative. Scalar0 Electro with positive effective power still executes; fixed moves with explicit0/-1 remain zero damage without crit/variance draws. All original batch module/data bytes are preserved except the declared single guard.

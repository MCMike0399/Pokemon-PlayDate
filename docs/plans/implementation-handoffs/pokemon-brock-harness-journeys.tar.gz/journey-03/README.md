# Narrow forced-replacement/observation correction03

Base hashes in base-files.json are CURRENT live host after root integrated journey01+02 and actual-active==starter reconciliation; do not apply onto old journey01. Only patches/ changes are installation files (brock_journey.py, existing test_brock_preparation.py fixture update, new test_brock_forced_switch.py). Source and runtime remain untouched. tools/harness/scenarios/brock copies are read-only test context, not new scenarios or replacement instructions.

battle.phase forcedSwitch is a transient rules state before BattleState opens Party on the next update. Driver waits2 frames, then the existing actual Party selection chooses a conscious reserve. The existing1200-input battle bound remains; stuck forcedSwitch fails. Real terminal defeat still raises/fails, never becomes victory. Existing root actual-active==starter switch_back clear is preserved. After actual Center healing, if the observed conscious starter isn't active, set only the host pending-switch flag; the next real battle uses actual POKEMON input to switch. No domain active-index write.

Training records now bind a terminal outcome only to a newly completed battle record with matching preparation name. Midbattle exceptions preserve error and party snapshot with outcome:null/completed:false/interrupted:true, rather than copying stale last_battle_outcome from a prior victory. A genuine completed defeat/blackout retains its own terminal record and error. Actual capture-escape RUN now publishes its completed RUN receipt before return so it can be associated honestly. No outcome assertions removed.

Top-level outcome keeps compatibility as intro rival result; intro_outcome names that explicitly, journey_outcome=failed/complete gives the campaign job result. Old evidence is unchanged. The existing mocked training-loss test now supplies the actual matching terminal battle record that real battle() emits before raising a genuine blackout; its defeat assertion is preserved.

Host checks:95/95PASS,0skips,4.463s. Includes seven new semantic replacement/bound/stale-report/intro-report/Center-to-real-switch cases, plus existing policy, actual source geometry, restart ownership, motion, parcel and strict catalog qualifier compatibility. Native behavior remains unverified. Preserve Bulbasaur forcedSwitch failure as historical failed/nonterminal evidence.

Run from repository root:

```
PARCEL_BUNDLE_SOURCE=/private/tmp/pokemon-brock-natural-05 /private/tmp/pokemon-validation-venv/bin/python /private/tmp/pokemon-brock-harness-acceptance/journey-03/check_host.py
```

Separate future source audit (NOT implemented here): original Blue/B2W2 next-battle lead selection vs current retained activeIndex after reserve victory and Center. This host workaround uses legal actions until the authoritative fieldlead owner is reviewed.

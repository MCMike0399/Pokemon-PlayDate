import importlib.util,os,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent;REPO=Path.cwd();sys.path.insert(0,str(REPO))
assert os.environ.get('PARCEL_BUNDLE_SOURCE'),'set PARCEL_BUNDLE_SOURCE to manifest-identified bundle'
name='tools.harness.brock_journey';spec=importlib.util.spec_from_file_location(name,ROOT/'tools/harness/brock_journey.py');m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
import tools.harness;tools.harness.brock_journey=m
suite=unittest.TestSuite()
for folder,pattern in [(ROOT/'tools/tests','test*.py'),(REPO/'tools/tests','test_brock_policy.py'),(REPO/'tools/tests','test_protocol_restart.py'),(REPO/'tools/tests','test_protocol_suite.py'),(REPO/'tools/tests','test_parcel_journey.py'),(REPO/'tools/tests','test_motion_journey.py'),(REPO/'tools/tests','test_catalog_qualification.py')]:
 for path in folder.glob(pattern):
  spec=importlib.util.spec_from_file_location('test_'+path.stem,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(not result.wasSuccessful()or bool(result.skipped))

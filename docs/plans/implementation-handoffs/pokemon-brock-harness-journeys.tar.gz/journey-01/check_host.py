"""Read-only repository imports plus explicitly staged host overlays. No runtime launch."""
import argparse,importlib.util,os,sys,unittest
from pathlib import Path
REPO=Path.cwd().resolve()
if not(REPO/'tools/harness/protocol.py').is_file():raise SystemExit('run from the repository root')
STAGE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--bundle-evidence',required=True,type=Path);args=parser.parse_args()
if not(args.bundle_evidence/'source-manifest.json').is_file():parser.error('identified bundle source-manifest.json required')
os.environ['PARCEL_BUNDLE_SOURCE']=str(args.bundle_evidence)
sys.path.insert(0,str(REPO))
for name in ['restarting','brock_journey','suite']:
    qualified='tools.harness.'+name
    spec=importlib.util.spec_from_file_location(qualified,STAGE/'tools/harness'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);sys.modules[qualified]=module;spec.loader.exec_module(module)
    import tools.harness
    setattr(tools.harness,name,module)
suite=unittest.TestSuite()
for folder,pattern in [(STAGE/'tools/tests','test*.py'),(REPO/'tools/tests','test_protocol_suite.py'),(REPO/'tools/tests','test_protocol_restart.py'),(REPO/'tools/tests','test_motion_journey.py'),(REPO/'tools/tests','test_parcel_journey.py'),(REPO/'tools/tests','test_journey_paths.py'),(REPO/'tools/tests','test_journey_dialog.py'),(REPO/'tools/tests','test_catalog_qualification.py')]:
    for path in sorted(folder.glob(pattern)):
        name='staged_'+path.stem
        spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful() or bool(result.skipped))

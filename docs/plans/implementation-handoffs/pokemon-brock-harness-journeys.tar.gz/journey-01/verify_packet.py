"""Integrity/base/syntax only. Never imports runner or launches SDK."""
import argparse,hashlib,json,py_compile
from pathlib import Path
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--project',type=Path,default=Path.cwd());args=parser.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for path,digest in manifest['files'].items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,'packet changed: '+path
for path,digest in json.loads((root/'base-files.json').read_text()).items():
    target=args.project/path
    assert (hashlib.sha256(target.read_bytes()).hexdigest()if target.exists()else None)==digest,'base changed: '+path
for path in (root/'tools').rglob('*.py'):py_compile.compile(str(path),doraise=True)
print('Packet/base hashes and host Python compilation PASS; no Simulator launched')

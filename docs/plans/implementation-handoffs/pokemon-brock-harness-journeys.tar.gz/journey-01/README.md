# Three-starter Brock host candidate — native acceptance pending

Host-only overlay; no Source changes, launch ownership changes, save copying, or runtime proof. Base: checkpoint 1c40818; suite patch composes root's already-installed recursive discovery. All pre-existing Brock supplementary cases, motion/catalog/medicine dispatch, receipt validation, PID cleanup and strict artifact checks stay installed.

Before integrating, compare every existing file to `base-files.json`; apply only `patches/` and copy new files. The unchanged staged test_brock_policy.py is included for compatibility testing, not an overwrite requirement. check_host.py loads explicit staged host modules over repository dependencies. Run:

```
/private/tmp/pokemon-validation-venv/bin/python /private/tmp/pokemon-brock-harness-acceptance/journey-01/check_host.py --bundle-evidence /private/tmp/pokemon-brock-natural-05
```

The compatibility check includes strict image qualifier tests and therefore uses the existing validation venv with tools/requirements-dev.txt (Pillow). Functional runtime journeys still do not import Pillow. Latest check:97/97 PASS, zero skips,4.450seconds.

The identified bundle supplies immutable, manifest-verified Blue geometry; tests never inspect its saves/Data or launch the Simulator. The helper fails if any test skips. That historical bundle is suitable only for offline geometry tests; stage a fresh current build for actual journey qualification.

Runtime dependencies: actual battle.legal_moves[*].effective_accuracy computed by the engine's shared pure accuracy helper, actual battle.player.stat_stages.acc, and existing legal move attack/defense/STAB/type metadata. Missing data fails explicitly. No host formula duplicates staged accuracy mechanics. OHKO moves are deliberately outside this heuristic; only implemented Dragon Rage40/SonicBoom20 have fixed-damage scoring. Choices use current PP/type immunity/observed accuracy and effective stats, never a seed simulation. Learning preserves fixed damage coverage; evolution animation defaults to actual acceptance. Existing evolution-cancel-level is the separately labeled cancellation recipe.

Natural route: unchanged seed-only intro/parcel → real shop balls/medicine → source Route2 reciprocal grass lane → actual capture (weaken when safe, real full-health ball if damaging attacks risk KO) → real field reorder and battle switch → source Forest trainers → real wild battles/Center trips until starter≥16 and accepted evolution → Pewter Center/shop → Jr/Brock. Every ball attempt records48 actual native frames, and every terminal loss remains recorded. Both current/target and origin cells of moving NPCs stay reserved during host planning. Failed throws consume stock; replenishment requires actual shop money. No future species/XP/roll assumptions. Accuracy debuffs can trigger a legal reserve switch then return, resetting real stages. A trapping refusal falls through to attacking. Ordinary loss remains a real failure event; one explicitly bounded, source half-money/checkpoint/party-healing verified recovery is allowed before real re-preparation/retry. Trainer completion/payout/BoulderBadge/TM34/repeat/save assertions remain strict. Training tail counts254,255,256 are covered; exhaustion fails, not retry-as-pass. Existing max_actions20000/max_steps5000/max_ambient_encounters64 guards remain; training has a separate256 actual battle bound.

Run the three true two-process cases serially after integration:

```
python3 tools/harness/suite.py --only brock--brock-restart-bulbasaur brock--brock-restart-charmander brock--brock-restart --job-timeout 3600 --output /private/tmp/pokemon-three-starter-brock-UNIQUE
```

These are new-game then runner-owned Continue, sharing the same identified build/session/private save owner and requiring a fresh PID plus immutable preceding receipt. No fixture after initial seed, no forced outcome, no copied save. Existing brock--blackout, brock--failed-sight, brock--tm-full-retry and five brock--source-trainer-* remain supplementary. Single-process natural files also exist; they cannot claim true restart acceptance.

Suite default deadlines now use3600 seconds only when the identified scenario actually declares `brock-natural` (including process groups); all others240. `--job-timeout` always overrides. Effective per-job limits are written in suite-plan.json and result records; global option records whether an override was supplied. No automatic retries. A complete default suite includes all recursive scenarios, including both single/two-process campaign variants; select intended cases explicitly for bounded review.

Historical natural05 is a genuine Jr-trainer defeat, not a route pass. This candidate has host checks only. Three starters may still fail legitimately from observed battles, trapped/unsupported actions, money/ball exhaustion, or guard/deadline exhaustion; those failures must be preserved for review. No claim of broad GenV correctness, device performance, or full-campaign completion.

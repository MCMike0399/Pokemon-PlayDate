import hashlib,importlib.util,json,re,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(Path.cwd()))
spec=importlib.util.spec_from_file_location('tools.harness.brock_journey',ROOT/'tools/harness/brock_journey.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
class StockTests(unittest.TestCase):
    def test_pinned_original_stock_whole_vectors_match_guard(self):
        pin=json.loads((ROOT/'source-pin.json').read_text())
        for name,entry in pin['files'].items():self.assertEqual(hashlib.sha256((ROOT/'references'/name).read_bytes()).hexdigest(),entry['sha256'])
        text=(ROOT/'references/data/items/marts.asm').read_text()
        names={'POKE_BALL':'pokeBall','POTION':'potion','ESCAPE_ROPE':'escapeRope','ANTIDOTE':'antidote','PARLYZ_HEAL':'parlyzHeal','BURN_HEAL':'burnHeal','AWAKENING':'awakening'}
        for city in ['Viridian','Pewter']:
            symbols=re.search(city+r'MartClerkText::\s+script_mart ([^\n]+)',text)[1].split(', ')
            self.assertEqual(tuple(names[s]for s in symbols),m.SOURCE_SHOP_STOCK['pokered:'+city.upper()+'_MART:objects:1'])
    def test_impossible_viridian_potion_fails_before_any_input_or_inventory_read(self):
        journey=m.BrockJourney(None,'/private/tmp',{})
        journey.interact=lambda **kwargs:self.fail('invalid planned stock dispatched input')
        with self.assertRaisesRegex(m.ProtocolError,'pinned Blue source stock'):journey.buy_item('pokered:VIRIDIAN_MART:objects:1','potion',2,300)
        m.require_shop_stock('pokered:PEWTER_MART:objects:1','potion')
    def test_route1_real_gift_is_one_time_and_uses_only_real_source_crossings(self):
        journey=m.BrockJourney(None,'/private/tmp',{});flag=False;qty=0;interactions=[];crossings=[]
        journey.navigate=lambda point:None;journey.cross=lambda *args:crossings.append(args);journey.checkpoint=lambda name:None
        journey.flag=lambda id:flag;journey.quantity=lambda id:qty
        def interact(**kwargs):
            nonlocal flag,qty
            interactions.append(kwargs['source_id'])
            if not flag:flag=True;qty+=1
        journey.interact=interact
        journey.north_to_city();journey.north_to_city()
        self.assertEqual(interactions,['pokered:ROUTE_1:objects:1']*2);self.assertEqual(qty,1);self.assertEqual(len(crossings),4)
        self.assertEqual(journey.summary['recoveries'][0]['kind'],'source-gift')
    def test_natural_has_no_viridian_potion_plan_and_retains_real_forest_pickup(self):
        import inspect
        text=inspect.getsource(m.BrockJourney.natural)
        self.assertNotIn("'VIRIDIAN_MART:objects:1','potion'",text)
        self.assertNotIn("'pokered:VIRIDIAN_MART:objects:1','potion'",text)
        self.assertIn("'pokered:VIRIDIAN_FOREST:objects:6'",text)
        self.assertIn("'pokered:PEWTER_MART:objects:1','potion'",text)
if __name__=='__main__':unittest.main(verbosity=2)

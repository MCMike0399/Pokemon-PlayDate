# Source-stock correction over frozen journey01

Apply only patches/brock_journey.patch on journey01's exact brock_journey.py hash in base-files.json. Original journey01 stays unchanged. No Source or Simulator changes. test_stock.py:4/4PASS0.002s; pinned entire Viridian/Pewter stock vectors match independent original marts.asm, invented Viridian Potion fails before any input/inventory read, actual Route1 gift/repeat flow tested.

Natural driver now claims the actual one-time Route1 Potion sample by interacting with source object1 during its first real north crossing; repeat verifies no duplicate. No Potion is bought in Viridian. Existing actual Forest Potion object6 remains, later Pewter Potion purchases remain, Center recovery stays available. The Red PC's original Potion is not claimed: current RED'S PC item storage is unsupported and this host correction does not invent acquisition. Native healing/medicine viability remains unverified, particularly with only legitimate source stock/gifts. Failures must remain failures.

Pinned source revision af519899719f0754965776faac0e836a3b906e6d; consumed original marts.asm and Route1.asm copied/checksummed in source-pin.json. Run from repository root: python3 /private/tmp/pokemon-brock-harness-acceptance/journey-02/test_stock.py . Shared effective_accuracy/engine integration and root actual3starter runs remain pending.

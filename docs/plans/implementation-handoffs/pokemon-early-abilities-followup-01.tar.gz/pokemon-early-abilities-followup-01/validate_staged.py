#!/usr/bin/env python3
"""Overlay only this packet onto current Source; compile unless root passes --execute."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--execute',action='store_true');p.add_argument('--scenario');p.add_argument('--merge-current',action='store_true');a=p.parse_args()
project=Path(a.project).resolve();stage=Path(__file__).resolve().parent
sys.path.insert(0,str(project));from tools.harness import run as harness
from tools.harness.protocol import atomic_json
followup=json.loads((stage/'followup-manifest.json').read_text());parent=Path(followup['parent'])
assert hashlib.sha256((parent/'foundation-manifest.json').read_bytes()).hexdigest()==followup['parent_manifest_sha256'],'parent packet drift'
manifest=json.loads((parent/'foundation-manifest.json').read_text());original=harness.prepare

def prepare(project,sdk,output,session):
    for item in manifest['source_files']+manifest['tool_files']:
        assert hashlib.sha256((parent/item['path']).read_bytes()).hexdigest()==item['sha256'],'packet drift '+item['path']
    metadata=original(project,sdk,output,session)
    composed=[]
    for item in manifest['source_files']:
        source=parent/item['path'];live=project/item['path'];target=output/item['path'];base=parent/'base'/item['path']
        sha=hashlib.sha256(live.read_bytes()).hexdigest() if live.exists() else None
        target.parent.mkdir(parents=True,exist_ok=True)
        if sha in (item['base_sha256'],item['sha256']):shutil.copyfile(source,target)
        elif a.merge_current and base.is_file() and live.is_file():
            result=subprocess.run(['git','merge-file','-p',str(source),str(base),str(live)],capture_output=True)
            assert result.returncode==0,'owned hunk conflict '+item['path'];target.write_bytes(result.stdout)
        else:raise AssertionError('live owned Source changed '+item['path'])
        composed.append({'path':item['path'],'live_sha256':sha,'candidate_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
    for item in followup['source_files']+followup['tool_files']:
        assert hashlib.sha256((stage/item['path']).read_bytes()).hexdigest()==item['sha256'],'followup packet drift '+item['path']
    for item in followup['source_files']:
        target=output/item['path']
        before=hashlib.sha256(target.read_bytes()).hexdigest() if target.exists() else None
        if before==item['base_sha256']:
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/item['path'],target)
        elif a.merge_current and (parent/item['path']).is_file():
            merged=subprocess.run(['git','merge-file','-p',str(stage/item['path']),str(parent/item['path']),str(target)],capture_output=True)
            assert merged.returncode==0,'followup hunk conflict '+item['path'];target.write_bytes(merged.stdout)
        else:raise AssertionError('followup source baseline mismatch '+item['path'])
    main=output/'Source/main.lua';text=main.read_text();anchor='import "dev/catalog"';assert anchor in text
    text=text.replace(anchor,'import "dev/abilityContracts"\nContracts.register("early-abilities", AbilityContracts.run)\nimport "dev/abilityCompatibilityContracts"\nContracts.register("ability-compatibility", AbilityCompatibilityContracts.run)\n'+anchor,1);main.write_text(text)
    diag=output/'Source/dev/diagnostics.lua';view=diag.read_text()
    anchor='conditions = battle:getConditionsSnapshot(),'
    if 'effects = battle.effects:snapshot(),' not in view:
        assert anchor in view;view=view.replace(anchor,anchor+'\n            effects = battle.effects:snapshot(),',1);diag.write_text(view)
    info=output/'Source/pdxinfo';generated=info.read_text();info.write_text(metadata['original_pdxinfo'])
    metadata['source_sha256']=harness.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
    atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted((output/'Source').rglob('*')) if x.is_file() and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
    info.write_text(generated);values=[]
    for key in ('protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir'):
        value=metadata[key];values.append('    '+key+' = '+('true' if value is True else json.dumps(value,ensure_ascii=False))+',')
    (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(values)+'\n}\n')
    metadata['compiled_source_sha256']=harness.fingerprint(output,exclude_generated=False);metadata['early_abilities']=manifest;metadata['ability_compatibility']=followup;metadata['composed_files']=composed
    with (output/'early-abilities-build.log').open('w') as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
    atomic_json(output/'build.json',metadata);return metadata
harness.prepare=prepare;harness.PROJECT=project
scenario=Path(a.scenario).resolve() if a.scenario else stage/'contracts.json'
try:code=harness.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(scenario),commands=[],build_only=not a.execute,timeout=120,ready_timeout=20,max_frames=1800))
finally:harness.prepare=original
raise SystemExit(code)

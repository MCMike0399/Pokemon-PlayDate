# Separate reviewed compatibility / type-immunity followup

Parent frozen Source remains untouched at `/private/tmp/pokemon-early-abilities`; this directory is an explicit followup, not replacement of initial evidence. Root will run/capture the initial packet first. No live Source or Simulator was used.

Followup manifest SHA256: `5a32ac963d19ed12da9679dea00cc9fc48e884b2d8b2b940d6d295fdb119d8bd`. Parent manifest SHA is checked exactly. All changed bytes have original-parent SHA bases and narrow patches in `patches/`. The initial packet has two disclosed defects: nil currentMove breaks a previously valid direct Psywave DSL call; legacy damaging type immunity consumes an accuracy draw before rejecting, and one new initial assertion wrongly preserved that behavior.

Changes:

1. `BattleEffects:hit` permits absent move context: `cause="fixed"`, `contact=false`, and `receipt.move=nil`; it guesses no type/move. FullHP Sturdy still applies to a real fixed direct HP transaction. Public DirectDamage without a move remains type-independent; Psywave retains its own explicit Psychic immunity rule.
2. Primary pinned Showdown `ignoreImmunity:false` is projected as explicit generator metadata, inherited through the whole Gen8→5 chain. Only Thunder Wave enables `Move.typeImmunity`; ordinary primary status moves remain unaffected. No hand-edited move row.
3. Typed damaging/fixed immunity and enabled Thunder Wave immunity dispatch before accuracy; PP/status-gate timing remains before execution. C `ServerControl_MoveExecute`2097 removes type-immune targets before RemoveMissedTargets; `HandlerThunderWave`1602 enables event0x3d, checked at2196. Independent PS moveSteps624 type-immunity and630 accuracy are ordered the same; Gen5 swaps TryHit/type steps but both still precede accuracy. This is an engine correction, not weakening a failed test.
4. One initial AbilityContracts assertion changes immunity-only RNG delta from1 to0. Nonimmune misses still take exactly one accuracy draw. Twelve added actual SDK groups preserve HP/status/PP and cover nil public DSL, Sturdy, immune+miss, fixed type damage, primary Thunder Wave Ground/Electric, ability-induced Ground paralysis and Glare Ghost applicability.

Primary files/checksums are inherited unchanged from the parent's26-pin source manifest. Generator changes preserve all424 move scalars and effects: the ONLY row change relative to parent is Thunder Wave's generated `typeImmunity=true`; constructor adds its default false field. Existing earlier contracts were reviewed; no older strict immunity RNG-count assumption needed changing. Root runtime can still expose unrelated changed-mechanics assumptions, which must be reviewed separately.

Host proof:8/8 offline tests PASS,26 mechanic pins+5 move pins+5 CSV inputs verified,15 independent semantic literal vectors,424-row exact regeneration PASS. Compile-only followup-build-01 passed. SDK/native execution is pending. Combined expected516+47+12=575 groups.

Root command after preserving initial failure:

```sh
python3 /private/tmp/pokemon-early-abilities-followup-01/validate_staged.py \
  --project "$PWD" --output /private/tmp/pokemon-early-abilities-sdk-03 --execute
```

The helper composes ONLY the checked parent overlay and these declared followup hunks onto CURRENT Source, registers the extra contract module and adds the approved read-only `battle.effects` snapshot in private diagnostics. No old main/provider/session/world tree is copied. Default is compile-only.

Native followup `scenarios/ability-thunder-wave-ground.json` uses actual Pikachu10 Thunder Wave (slot4) versus a sleeping Sandshrew10. It asserts one global draw for enemy move selection, zero accuracy draws, one PP spent and unchanged target status/HP; captures the immunity message. Parent's six native recipes remain valid with the followup helper's private weather diagnostic hook. These are unexecuted recipes, not gameplay acceptance evidence.

After applying tools in a repository, run portable unit tests as usual. To qualify this private packet now:

```sh
PYTHONPATH="$PWD" python3 /private/tmp/pokemon-early-abilities-followup-01/tools/qualify_early_abilities.py \
  --source-root /private/tmp/pokemon-early-abilities-followup-01 \
  --mechanics-cache /private/tmp/pokemon-early-abilities/references/mechanics \
  --showdown-cache /private/tmp/pokemon-early-combat/references \
  --csv-cache /private/tmp/pokemon-early-abilities/references/pokeapi \
  --report /private/tmp/early-abilities-followup-primary.json
```

All other95 abilities, held effects, other weather, SolarBeam charging, Substitute and other producers remain full-goal work. No acquisition, save schema, roster, art, world or Inventory behavior changes.

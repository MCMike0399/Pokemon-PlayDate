# Brock capture evidence 05

No production repair: the reported black images were a multi-image preview artifact. Root independently confirmed the actual PNGs. Read-only diagnosis is retained at `/private/tmp/pokemon-brock-capture-diagnosis-01/report.json`: Badge, saved world and continued world all SHA256 `137747d0325e312edd4bacd0b9d0a857d501edd7fe72b0f2350ef73253a81d01`,49,774 opaque white/46,226 opaque black pixels,0 changed RGBA channels. Existing strict source-pose oracle proves Brock704 and Jr552 opaque native pixels in both saved/continued images. No arbitrary wait, sprite freezing or Source change is warranted.

This separate host packet is based on current `/private/tmp/pokemon-brock-integration-02`, including journey03/04 and root's actual-active reconciliation/stock/replanning fixes. Apply two guarded hunks under patches/tools/harness (brock_journey.py/run.py), install new brock_capture.py and test_brock_capture.py. Preserve all current medicine/motion/field/restart dispatch code; run.py adds only a narrow visual dependency preflight before prepare/launch. The full files here are review aids, not permission for wholesale overwrites.

Future natural Brock acceptance now requires:

- Actual Title menu with real CONTINUE selected, `brock-title-continue-selected.png`, before actual A. No save copy or injected Continue.
- Successful Save dialog at ready text, `brock-save-dialog.png`, before dismissal. The earlier composed parcel save uses distinct `parcel-save-dialog.png`, preserving both visits.
- Final `brock-game-saved.png` and `brock-continued-no-repeat.png` must be completed native400x240 opaque nonblank PNGs with settled Overworld/explore snapshots. Existing exact-source-opaque-RGBA checker validates current bound NPC frames at actual snapshot positions/tick/camera from the identified immutable staged source; at least32 visible opaque pixels are mandatory. No tolerant baseline, transparent expected art masking, or semantic-only pass. Initial pre-Brock parcel world retains its existing checkpoint behavior (four-map source oracle is not pretended to be covered by the Pewter checker).
- Every new qualified capture records actual numbered shot request/result SHA, request ID, build/session ID, PNG SHA and completed tick in `summary.presentation_evidence`. Reused capture labels in the same process fail; wrong/stale request/result/snapshot fails. Missing/corrupt/blank/source-drift evidence fails the real journey. Ready panels are semantically gated and human-reviewable, not a claimed font/text raster oracle.

No extra idle wait is inserted. `shot` captures the actual completed frame after the accepted production presentation flush. The existing exact prior-receipt Continue comparison and repeat/no-payout assertions remain unchanged. No domain write, RNG simulation, outcome relaxation, new process owner or new protocol.

Host checks (Pillow preflight is required):

```
PARCEL_BUNDLE_SOURCE=/private/tmp/pokemon-home-lead-compile-04 /private/tmp/pokemon-visual-venv/bin/python /private/tmp/pokemon-brock-capture-05/test_staged.py
```

55/55 passed,0 skips:9 new capture/identity/Save-label tests plus46 current Brock policy/preparation/forced-switch/evolution tests. Python compilation passes. Test source geometry is read from the identified compile04 bundle, not a save. New Title/saved-dialog image evidence needs the next root-owned actual two-process native campaign; it is not fabricated retroactively from the previous run. Existing two world images were independently read-only qualified, not rerun.

from pathlib import Path
import sys,unittest
p=Path(__file__).parent;base=Path('/private/tmp/pokemon-brock-integration-02')
sys.path.insert(0,str(base))
import tools.harness,tools.tests
# Overlay only owned modules; every other harness module stays current-base.
tools.harness.__path__.insert(0,str(p/'tools/harness'))
suite=unittest.TestLoader().discover(str(p/'tools/tests'),pattern='test_brock_capture.py')
for pattern in ['test_brock_policy.py','test_brock_preparation.py','test_brock_forced_switch.py','test_brock_evolution_evidence.py']:
 suite.addTests(unittest.TestLoader().discover(str(base/'tools/tests'),pattern=pattern))
result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(not result.wasSuccessful())

# Early abilities staged handoff

Source and tools are frozen for root SDK qualification. No live Source, Simulator, runtime Data, specimen/codec/world/shop/art writes were made. Current live checkpoint is root's ba8975d; five owned source files retain exactly the initial build03 hashes. Root's first sdk-01 attempt correctly stopped BEFORE launch because a tools hash was stale while documentation/qualification tooling was being completed. `refreeze-audit.json` records zero Source drift and all three explicit tool changes. No runtime pass is claimed.

Manifest SHA256: `7a824612dd1c56728663608923308713bb1dfe5aa826066ab7c2dd97266790e6` (`foundation-manifest.json`). It pins five Source files and all qualification tools. `initial-source-freeze-manifest.json` preserves the initial packet identity. Build04 compiles the same five frozen Source bytes against current root Source with refreshed harness identities.

Run root SDK qualification:

```sh
python3 /private/tmp/pokemon-early-abilities/validate_staged.py \
  --project "$PWD" --output /private/tmp/pokemon-early-abilities-sdk-02 --execute
```

Compile only is the default without `--execute`. The helper overlays ONLY manifest Source files on current Source. It never copies an old main/context/fixture/session/world tree. It registers `AbilityContracts.run` privately and refreshes build/source/compiled hashes. A changed owned live base fails closed; use reviewed `--merge-current` only if root needs explicit three-way composition. Forty-seven new SDK groups are registered; prior516 plus47 means expected563, subject to real execution. Existing contracts can expose real changed-mechanics assumptions; do not weaken strict vectors to get a pass.

## Files and interfaces

- `Source/battle/effects.lua`: battle-owned `BattleEffects`, private ability registry; pure accuracy/stat/withdraw/burn queries, one-shot direct-hit receipts, actual Static reaction, Sturdy/OHKO, field weather/Shed Skin residual entries and explicit clear/close lifecycle. `snapshot()` is pure, returns fresh `{weather="none"|"sandstorm",turns=integer}` and has no restore/install mutation API.
- Narrow `battle.lua`: instantiate/query effects; one PP attempt before moves; per-hit damage→drain→secondary→Static; whole-move recoil→faint/XP; exact multihit picker; raw-speed prior-failure flee boundaries; merge weather/ability residuals; weather cohort before verdict/XP; clear receipts on switch/exit. Existing learning coroutine and actual party/session ownership remain intact.
- Narrow DSL: Keen Eye stat-drop eligibility, explicit `SecondaryEffect` gate before chance, typed fixed-hit receipts, generic `RandomMajorStatusEffect`, weather producer/heal.
- `moves.lua` is GENERATED. All424 rows have explicit contact/secondary/OHKO metadata. Existing scalar values remain unchanged; declared effect changes are secondary provenance separation, real Sandstorm, OHKO dispatch, Tri Attack random major status, weather-dependent heals and SolarBeam sand power flag. Metadata is derived through the complete pinned Showdown Gen8→7→6→5 inheritance chain. No power/category heuristic decides whether an effect is secondary.
- `AbilityContracts.run()` returns standard `{ok,passed,failed,tests}`, using actual production Battle/DSL/StateMachine/LearningState/BattleScene classes. Failures include actual/expected values. Tests include all16 IDs, literal arithmetic, status/PP/no-target/miss/immunity timing, contact death, multi-hit, weather simultaneous faint, actual learning suspension and render invariance.

## Scope and source conclusions

`scope.json` independently audits the connected content:14 direct species,30 evolutionary closure,16 normal abilities. IDs5/8/9/14/19/50/51/61/62/65/66/67/68/69/71/77. Original graph edges do not invent pre-Brock stones/trading/encounter availability. All111 ability union remains the full goal; `remaining-mechanics.json` lists the other95 IDs and broader dependencies.

`tools/references/early-abilities-sources.json` pins26 immutable C/Nitro/Showdown/personal/Blue-inventory sources; qualification validates every checksum. The C reconstruction is corroborated by independent Showdown Gen5 behavior; it is not represented as complete matched-disassembly coverage.

Important exact call sites: `btl_server_flow.c` DamageListCore3268–3278 drains, applies additional effects, reacts then checks faint; DamageMove2988 applies whole-move recoil afterward. Showdown spreadDamage2187 drains, moveHit1156 secondaries precede DamagingHit1178. Lethal Static is preserved before final verdict. Guts confusion exclusion is verified by C ConfusionDamage6166 using raw staged stats/CalcBaseDamage without attack-modifier handlers. C fx.h FX_Mul adds0x800 before>>12; btl_calc fixed_round increments only when fractional part>0x800. The candidate keeps half-up ratio chaining distinct from half-down stat/accuracy application.

Sandstorm: C FieldEffect4658 initializes5, btl_field stores5, TurnCheckWeather5324 decrements before damage and returns on expiry. Independent PS Sandstorm duration5 and Battle.fieldEvent duration decrement skip the callback at0. Timeline after each residual is4/3/2/1/0: four damaging residuals, no damage on fifth/expiry. Weather processes all active mons in speed order before EXP/verdict (C weather loop and PS eachEvent field callback). Weather heals use sourced Q12 quarter/half and SolarBeam has sourced sand power half; its existing charge producer remains explicitly unfinished. Other weather remains unfinished.

Shed Skin is33/100, not1/3. Starter/Swarm/Guts modifiers act on the offensive stat; burn exemption is separate. Compound Eyes75→98 before stages; confused Tangled Feet75→37; Sand Veil100→80. Sturdy distinguishes fullHP direct-hit survival from anyHP OHKO immunity. Gen5 multi-hit2–5 probabilities35/35/15/15. Flee uses previous failures, raw Speed, guaranteed faster escape and no modulo256 wrap.

## Reproduction

Offline synthetic host tests (no network/cache):

```sh
python3 -m unittest discover -s /private/tmp/pokemon-early-abilities/tools/tests -p test_ability_metadata.py -v
```

Actual result:7/7 PASS. These do not replace the full primary projection proof.

Full qualification (actual result:26 mechanic pins,5 move pins,5 CSV inputs,15 independent literal metadata vectors,424 rows, byte-exact regeneration PASS):

```sh
PYTHONPATH="$PWD" python3 /private/tmp/pokemon-early-abilities/tools/qualify_early_abilities.py \
  --source-root /private/tmp/pokemon-early-abilities \
  --mechanics-cache /private/tmp/pokemon-early-abilities/references/mechanics \
  --showdown-cache /private/tmp/pokemon-early-combat/references \
  --csv-cache /private/tmp/pokemon-early-abilities/references/pokeapi \
  --report /private/tmp/early-abilities-primary-proof.json
```

After installing tools into the repository, `--source-root "$PWD"` works without PYTHONPATH. Clean external cache paths plus `--fetch` explicitly download immutable inputs; corrupt existing cache fails unchanged. Missing cache fails offline. The scope auditor takes explicit `--source-root`, `--mechanics-cache`, `--output`; it reads the pinned personal binary independently of generated specimen slots.

## Native witnesses (NOT run here)

Six JSON recipes are in `scenarios/`. They use actual controller input, legal constructor learnsets, approved explicit attribute fixtures, semantic message/phase boundaries and bounded readiness waits. Synthetic trainer fixtures are labelled TEST; they do not forge source trainer defeat flags or claim natural availability.

Root adds read-only diagnostic `effects = battle.effects:snapshot(),` beside current conditions snapshot before weather recipe. No universal rollback/private weather install is needed. Other recipes use existing diagnostics/fixtures. Run one job using the same validator with `--scenario <absolute JSON>` and fresh output.

1. `ability-sturdy.json`: fullHP Geodude12 actual Sturdy vs Charmander16 actual Dragon Rage, native hit/endurance capture at1HP then next action KOs. Single PP per real attempt.
2. `ability-static-lethal.json`: real lethal Tackle→Static popup→paralysis before faint verdict, explicit5-draw seed witness; extra recording frames cannot add rules draws.
3. `ability-shield-dust.json`: Poison Sting damage but no poison/secondary draw against actual Caterpie Shield Dust, total4 rules draws including enemy choice and damage calculations.
4. `ability-weather-shed-skin.json`: actual Sandstorm selection, sand tick before Shed Skin cure, five-round expiry timeline and final enemyHP26; source-level42 is a synthetic rules witness, not pre-Brock progression.
5. `ability-arena-trap.json`: actual trainer Diglett second slot blocks voluntary grounded Rattata→Pidgey switch, no RNG/member change, native error/selection capture.
6. `ability-run-away.json`: actual Run Away wild flee popup, no rules RNG. Existing `battle species level` debug command constructs deterministic two-argument Pokémon, so this wild Diglett has first-slot Sand Veil. Wild Arena Trap/binding bypass is proved by actual SDK Battle contracts; this native recipe intentionally does not claim a trapping source it lacks.

Root should inspect captures/frames, all563 runtime assertions, scene-offset cleanup and source Forest/Brock regression before integration. No native result or complete GenV ability/weather/held-effect claim is made here.

## Required followups and inventory policy

Root requires a separate narrow generator-driven Thunder Wave Ground-immunity followup AFTER first SDK result; frozen initial Source remains unchanged. SolarBeam charge, Substitute, other weather, other95 abilities, airborne/suppression producers and held battle activation remain full-goal work. Legacy secondary scalar issues outside this slice (e.g Poison Fang needs Gen5 bad poison30%, not legacy ordinary poison50%) are recorded explicitly instead of described as supported.

Blue duplicate stacks above99 are source-faithful when slots remain. No Inventory change: original AddItemToInventory_ splits99+remainder. Separate later policy review must address first-overflow-fullbag failure vs scanning later partial duplicate stacks, and original physical-stack-index removal vs current ID aggregate consume. Do not outlaw aggregate100 or invalidate held capacity evidence.

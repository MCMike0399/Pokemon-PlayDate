from pathlib import Path
p=Path('/private/tmp/pokemon-early-abilities/Source/battle/battle.lua');s=p.read_text()
s=s.replace('import "battle/conditions"','import "battle/conditions"\nimport "battle/effects"')
s=s.replace('function calcDamage(attacker, defender, move, effectivePower)','function calcDamage(attacker, defender, move, effectivePower, effects)')
s=s.replace('    local defStat = applyStageMod(defBase, defStage)','    local defStat = applyStageMod(defBase, defStage)\n    if effects then\n        atkStat=effects:attackStat(attacker,move,atkStat)\n        defStat=effects:defenseStat(defender,move,defStat)\n    end')
s=s.replace('if attacker.status == "burn" and move.category == "physical" then','if attacker.status == "burn" and move.category == "physical" and not (effects and effects:ignoresBurn(attacker)) then')
s=s.replace('function checkAccuracy(move, attacker, defender)','function checkAccuracy(move, attacker, defender, effects)')
s=s.replace('    local threshold = move.accuracy * accStageMult(stage)','    local base=effects and effects:accuracy(attacker,defender,move) or move.accuracy\n    local threshold = math.min(100,math.floor(base * accStageMult(stage)))')
s=s.replace('    self.conditions = BattleConditions(self)','    self.conditions = BattleConditions(self)\n    self.effects = BattleEffects(self)')
s=s.replace('    self.conditions:clearAll()','    self.conditions:clearAll()\n    self.effects:close()')
s=s.replace('if not forced and self.conditions:trapped(self.player) then','if not forced and (self.conditions:trapped(self.player) or self.effects:withdrawBlocked(self.player)) then')
s=s.replace('    self.conditions:clear(old)','    self.conditions:clear(old)\n    self.effects:clear(old)') # bothswitchsites indentation harmless
s=s.replace('    if self:isAwaitingCommand() and self.conditions:trapped(self.player) then return false,"trapped" end','    if self:isAwaitingCommand() and not self.effects:sureEscape(self.player)\n       and (self.conditions:trapped(self.player) or self.effects:withdrawBlocked(self.player)) then return false,"trapped" end')
a=s.index('    self.runAttempts = self.runAttempts + 1',s.index('function Battle:tryRun()'));b=s.index('        self:runScript(function()',a)
s=s[:a]+'''    local playerSpe,enemySpe=self.player.spe,math.max(1,self.enemy.spe)
    local chance=((playerSpe*4096)//enemySpe)*128//4096 + 30*self.runAttempts
    local escaped=self.effects:sureEscape(self.player) or playerSpe>enemySpe
    if not escaped then escaped=RulesRNG.random(0,255)<chance end
    if escaped then
'''+s[b:]
s=s.replace('    else\n        self:runScript(function()\n            self:say("Can\'t escape!")','    else\n        self.runAttempts=self.runAttempts+1\n        self:runScript(function()\n            self:say("Can\'t escape!")')
s=s.replace('    if not checkAccuracy(move, attacker, defender) then','''    if move.ohko then
        local hit,reason=self.effects:ohko(attacker,defender,move)
        if not hit then
            self:say(reason=="sturdy" and (defender.name .. " is protected by Sturdy!") or "But it failed!")
            return nil
        end
        local receipt=self.effects:hit(attacker,defender,move,defender.hp)
        self.lastDamage=receipt.removed
        self:say("It's a one-hit KO!")
        self.effects:afterHit(receipt)
        return self:handleFaint()
    end
    if not checkAccuracy(move, attacker, defender, self.effects) then''')
s=s.replace('''                local roll = RulesRNG.random(6)
                if roll <= 2 then hits = 2
                elseif roll <= 4 then hits = 3
                elseif roll == 5 then hits = 4''','''                local roll = RulesRNG.random(0,99)
                if roll < 35 then hits = 2
                elseif roll < 70 then hits = 3
                elseif roll < 85 then hits = 4''')
s=s.replace('''            local result = calcDamage(attacker, defender, move, power)
            local before = defender.hp
            defender:takeDamage(result.damage)
            total = total + before - defender.hp''','''            local result = calcDamage(attacker, defender, move, power,self.effects)
            local receipt=self.effects:hit(attacker,defender,move,result.damage)
            local before=receipt.before
            total=total+receipt.removed''')
s=s.replace('''            if before>defender.hp then self.conditions:rageHit(defender) end
            if not defender:isAlive() then break end''','''            if receipt.removed>0 then self.conditions:rageHit(defender) end
            self.effects:announceEndure(receipt)
            -- C DamageListCore: drain, secondary effects, contact reactions;
            -- whole-move recoil follows DamageMultiHit, before terminal verdict.
            if move.drain and move.drain>0 then
                attacker:heal(math.max(1,math.floor(receipt.removed*move.drain/100+0.5)))
                self:say(defender.name .. " had its energy drained!")
            end
            self:applyMoveSecondaries(move)
            self.effects:afterHit(receipt)
            if not defender:isAlive() or not attacker:isAlive() then break end''')
a=s.index('        if move.drain and move.drain > 0 then',s.index('function Battle:performMove'));b=s.index('        self:applyMoveEffects(move)',a)
s=s[:a]+'''        if move.struggleRecoil then
            attacker:takeDamage(math.max(1, math.floor(attacker.maxHP / 4 + 0.5)))
            self:say(attacker.name .. " is damaged by recoil!")
        elseif move.drain and move.drain < 0 and not self.effects:recoilBlocked(attacker,move) then
            attacker:takeDamage(math.max(1, math.floor(total * -move.drain / 100 + 0.5)))
            self:say(attacker.name .. " is damaged by recoil!")
        end

'''+s[b:]
s=s.replace('function Battle:applyMoveEffects(move)','''function Battle:applyMoveSecondaries(move)
    for _,effect in ipairs(move.secondaries or {}) do effect:apply(self) end
end

function Battle:applyMoveEffects(move)''')
s=s.replace('    local events=self.conditions:events()','    local events=self.conditions:events()\n    for _,event in ipairs(self.effects:events()) do events[#events+1]=event end')
s=s.replace('''        local sa,sb=effectiveSpeed(a.pokemon),effectiveSpeed(b.pokemon)''','''        local sa,sb=effectiveSpeed(a.pokemon),effectiveSpeed(b.pokemon)''') # sameorderfieldunique0 noquery
s=s.replace('''        self.conditions:residual(event)
        if not event.pokemon:isAlive() then''','''        if event.owner=="effects" then self.effects:residual(event) else self.conditions:residual(event) end
        if event.pokemon and not event.pokemon:isAlive() then''')
s=s.replace('-- Gen V 2-5 distribution: 2 or 3 hits 1/3 each, 4 or 5 hits 1/6 each','-- Gen V 2-5 distribution: 35/35/15/15 percent.')
p.write_text(s)
p=Path('/private/tmp/pokemon-early-abilities/Source/battle/dsl.lua');s=p.read_text()
s=s.replace('    local oldStage = pokemon.statStages[self.stat] or 0','''    if battle.effects and not battle.effects:canDropStat(battle.attacker,pokemon,self.stat,self.stages) then
        battle:say(pokemon.name .. "'s Keen Eye prevents accuracy loss!");return
    end
    local oldStage = pokemon.statStages[self.stat] or 0''')
s=s.replace('''    -- Volatile conditions live''','''    if not pokemon:isAlive() then return end
    -- Volatile conditions live''')
s=s.replace('''    pokemon:takeDamage(damage)
    battle.lastDamage = before - pokemon.hp''','''    local receipt=battle.effects and battle.effects:hit(battle.attacker,pokemon,move,damage)
    if not receipt then pokemon:takeDamage(damage) end
    battle.lastDamage = before - pokemon.hp''')
s=s.replace('''    battle:say(pokemon.name .. " took " .. battle.lastDamage .. " damage!")''','''    battle:say(pokemon.name .. " took " .. battle.lastDamage .. " damage!")
    if receipt then battle.effects:announceEndure(receipt);battle.effects:afterHit(receipt) end''')
s=s.replace('''    defender:takeDamage(amount)
    battle.lastDamage = before - defender.hp''','''    local receipt=battle.effects and battle.effects:hit(attacker,defender,battle.currentMove,amount)
    if not receipt then defender:takeDamage(amount) end
    battle.lastDamage = before - defender.hp''')
s=s.replace('''    battle:say(defender.name .. " took " .. battle.lastDamage .. " damage!")''','''    battle:say(defender.name .. " took " .. battle.lastDamage .. " damage!")
    if receipt then battle.effects:announceEndure(receipt);battle.effects:afterHit(receipt) end''')
s+='''
-- Explicit generated secondary provenance. Eligibility precedes chance evaluation.
Class("SecondaryEffect")
function SecondaryEffect:init(target,effect) self.target=Target.from(target);self.effect=effect end
function SecondaryEffect:apply(battle)
    local target=self.target:resolve(battle)
    if battle.effects and not battle.effects:allowsSecondary(battle.attacker,target) then return end
    self.effect:apply(battle)
end
Class("SandstormEffect")
function SandstormEffect:apply(battle) battle.effects:setSandstorm() end
'''
p.write_text(s)

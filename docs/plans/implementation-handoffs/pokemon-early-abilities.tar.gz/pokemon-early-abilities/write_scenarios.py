from pathlib import Path
import json
OUT=Path(__file__).parent/'scenarios'
def at(path,value):return {'op':'await','path':path,'equals':value,'frames':300}
def check(path,value):return {'op':'assert','path':path,'equals':value}
def msg(text):return [at('battle.message',text),at('battle.waiting',True),'wait 12']
def advance(text):return msg(text)+['press a']
def base(player,enemies,name='ABILITY TEST',party=None):
 options={'intro':'skip','opening':False,'zone':'reds_house_2f','seed':42,'trainer_name':name,'enemy_party':enemies}
 if party:options['party_pokemon']=party
 else:options['player_pokemon']=player
 return [{'op':'fixture','options':options},at('battle.introPhase','ready')]+advance(name+' wants to battle!')+advance(name+' sent out '+enemies[0]['species'].upper()+'!')+[at('battle.phase','command'),at('battle.menu.active',True)]
def choose(index):
 keys={1:[],2:['press right'],3:['press down'],4:['press right','press down']}[index]
 return ['press a',at('battle.inMoveSelect',True)]+keys+['press a']
def save(name,c,outputs):
 (OUT/(name+'.json')).write_text(json.dumps({'commands':c,'outputs':outputs},indent=2)+'\n')
sleep={'status':'sleep','status_turns':3,'sleep_duration':3}
c=base({'species':'charmander','level':16},[{'species':'geodude','level':12,'ability_slot':'second',**sleep}],'STURDY TEST')
c+=['seed 1']+choose(4)+advance('CHARMANDER used DRAGON RAGE!')
c+=[at('battle.enemy.hp',1),check('battle.lastDamage',30),'record ability-sturdy-first-hit 36']
c+=advance('GEODUDE took 30 damage!')+msg('GEODUDE held on with Sturdy!')+['shot ability-sturdy-held','press a']
c+=advance('GEODUDE is fast asleep!')+[at('battle.phase','command'),check('battle.player.pp.dragonRage',9)]+choose(4)
c+=advance('CHARMANDER used DRAGON RAGE!')+[at('battle.enemy.hp',0)]+msg('GEODUDE took 1 damage!')+['shot ability-sturdy-second-hit']
save('ability-sturdy',c,['ability-sturdy-first-hit-frames','ability-sturdy-held.png','ability-sturdy-second-hit.png'])
c=base({'species':'rattata','level':6},[{'species':'pikachu','level':5,'hp':1,**sleep}],'STATIC TEST')
c+=['seed 1']+choose(1)+advance('PIKACHU is fast asleep!')+advance('RATTATA used TACKLE!')
c+=[at('battle.enemy.hp',0),'wait 12','press a']+msg("PIKACHU's Static!")+['record ability-static-lethal 36','shot ability-static-popup','press a']
c+=msg('RATTATA is paralyzed!')+['shot ability-static-status',check('battle.player.status','paralyze'),check('battle.enemy.hp',0),check('rng.rolls',5)]
save('ability-static-lethal',c,['ability-static-lethal-frames','ability-static-popup.png','ability-static-status.png'])
c=base({'species':'weedle','level':9},[{'species':'caterpie','level':8,**sleep}],'DUST TEST')
c+=['seed 42']+choose(1)+advance('WEEDLE used POISON STING!')
# Damage itself is seed-dependent; HP mutation is observed through currentMove,
# then one ready-boundary press advances the sole damage narration.
c+=[at('battle.current_move','poisonSting'),at('battle.waiting',True),'wait 12','press a']
c+=advance('CATERPIE is fast asleep!')+[at('battle.phase','command'),check('battle.enemy.status','sleep'),check('battle.enemy.statusTurns',2),check('rng.rolls',4),check('battle.player.pp.poisonSting',34),'shot ability-shield-dust']
save('ability-shield-dust',c,['ability-shield-dust.png'])
c=base({'species':'sandshrew','level':42},[{'species':'metapod','level':10,'status':'burn'}],'WEATHER TEST')
c+=['seed 26']+choose(4)+advance('SANDSHREW used SANDSTORM!')+msg('A sandstorm kicked up!')+['shot ability-sandstorm-start','press a']
c+=advance('METAPOD used HARDEN!')+advance("METAPOD's DEFENSE rose!")+advance('METAPOD is buffeted by the sandstorm!')
c+=msg('METAPOD shed its status with Shed Skin!')+['shot ability-shed-skin',check('battle.enemy.status','none'),'press a',at('battle.phase','command'),check('battle.effects.turns',4)]
for turn in range(2,6):
 c+=choose(3)+advance('SANDSHREW used SWORDS DANCE!')
 c+=advance("SANDSHREW's ATTACK rose sharply!" if turn<5 else "SANDSHREW's ATTACK won't go any higher!")
 c+=advance('METAPOD used HARDEN!')+advance("METAPOD's DEFENSE rose!")
 if turn<5:c+=advance('METAPOD is buffeted by the sandstorm!')
 else:c+=msg('The sandstorm subsided.')+['shot ability-sandstorm-expiry','press a']
 c+=[at('battle.phase','command'),check('battle.effects.turns',5-turn)]
c+=[check('battle.effects.weather','none'),check('battle.enemy.hp',26)]
save('ability-weather-shed-skin',c,['ability-sandstorm-start.png','ability-shed-skin.png','ability-sandstorm-expiry.png'])
c=base(None,[{'species':'diglett','level':11,'ability_slot':'second',**sleep}],'TRAP TEST',party=[{'species':'rattata','level':6,'ability_slot':'second'},{'species':'pidgey','level':5}])
c+=['seed 1','press down','press a',at('root','party'),'press down','press a',check('root','party'),check('battle.player.species','rattata'),check('rng.rolls',0),'shot ability-arena-trap-switch']
save('ability-arena-trap',c,['ability-arena-trap-switch.png'])
c=[{'op':'fixture','options':{'intro':'skip','opening':False,'zone':'reds_house_2f','seed':1,'player_pokemon':{'species':'rattata','level':6,'ability_slot':'first'}}},'battle diglett 11',at('battle.introPhase','ready')]+advance('A wild DIGLETT appeared!')+[at('battle.phase','command'),at('battle.menu.active',True),'seed 1','press right','press down','press a']
c+=msg("RATTATA's Run Away!")+['shot ability-run-away',check('rng.rolls',0),'press a']+advance('Got away safely!')+[at('root','overworld'),check('last_battle_outcome.kind','run'),check('rng.rolls',0)]
save('ability-run-away',c,['ability-run-away.png'])

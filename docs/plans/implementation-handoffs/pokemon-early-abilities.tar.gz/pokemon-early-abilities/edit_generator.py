from pathlib import Path
p=Path('/private/tmp/pokemon-early-abilities/tools/generate_gen5_data.py');s=p.read_text().replace('import io\n','import io\nimport json\n')
s=s.replace('"mudSport": ["MudSportEffect()"],','"sandstorm": ["SandstormEffect()"],\n        "mudSport": ["MudSportEffect()"],')
s=s.replace("    out, missing = [], []","    ability_metadata=json.loads((Path(ROOT)/'tools/references/ability-move-metadata.json').read_text())['moves']\n    out, missing = [], []")
s=s.replace('        display = camel_to_kebab(key)', '''        semantics=ability_metadata[key]
        secondaries=[]
        if semantics['secondary']:
            primary=[]
            for effect in effects:
                # Eligibility is from the pinned resolved Gen5 secondary field,
                # never power/category or chance alone. Target comes from the DSL.
                if ('ApplyStatus(' in effect or 'ModifyStat(' in effect) and 'DEFENDER' in effect:
                    secondaries.append('SecondaryEffect(DEFENDER, '+effect+')')
                elif ('ApplyStatus(' in effect or 'ModifyStat(' in effect) and 'ATTACKER' in effect:
                    secondaries.append('SecondaryEffect(ATTACKER, '+effect+')')
                else:primary.append(effect)
            effects=primary
        if semantics['ohko']:effects=[]
        display = camel_to_kebab(key)''')
s=s.replace('        if key == "rollout": parts.append', '''        parts.extend(["contact = " + str(semantics['contact']).lower(),
                      "hasSecondary = " + str(semantics['secondary']).lower(),
                      "ohko = " + str(semantics['ohko']).lower()])
        if key == "rollout": parts.append''')
s=s.replace('        if effects:\n            parts.append', '        if secondaries:\n            parts.append("secondaries = { " + ", ".join(secondaries) + " }")\n        if effects:\n            parts.append')
s=s.replace('    self.effects = m.effects','    self.contact = m.contact or false\n    self.hasSecondary = m.hasSecondary or false\n    self.ohko = m.ohko or false\n    self.secondaries = m.secondaries\n    self.effects = m.effects')
start=s.index('        # The one-time target metadata migration')
end=s.index('        changed =',start)
s=s[:start]+'''        def compatible(key, old, new):
            if new is None:return False
            def clean(row):
                row=re.sub(r", (?:contact|hasSecondary|ohko) = (?:true|false)", "", row)
                return row
            def scalars(row):return re.split(r", (?:secondaries|effects) = \\{",clean(row))[0].rstrip(' },')
            if scalars(old)!=scalars(new):return False
            if ability_metadata[key]['secondary'] or ability_metadata[key]['ohko'] or key=='sandstorm':return True
            return clean(old)==clean(new)
'''+s[end:]
p.write_text(s)

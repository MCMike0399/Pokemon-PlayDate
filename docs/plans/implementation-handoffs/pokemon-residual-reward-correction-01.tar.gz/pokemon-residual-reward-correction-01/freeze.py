from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
new=['Source/dev/residualRewardProbe.lua','Source/dev/conditionCheckpointContracts.lua'];shared=json.loads((P/'shared-hunks.json').read_text())
m={'schema':1,'packet':'residual-reward-correction-01','requires':'reviewed B owner+HUD and accepted Roost','new_source_files':new,'files':{}}
for f in sorted(P.rglob('*')):
 if not f.is_file()or f.name=='manifest.json'or'__pycache__'in f.parts:continue
 rel=f.relative_to(P).as_posix()
 if rel.startswith('Source/')and rel not in new and rel not in [i['path']for i in shared]:continue
 m['files'][rel]=hashlib.sha256(f.read_bytes()).hexdigest()
(P/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest())

#!/usr/bin/env python3
"""Run the composed staged modules against the current project without Simulator."""
import sys,unittest
from pathlib import Path
stage=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(stage/'tools/tests'))
import test_catalog_qualification,test_motion_journey,test_comprehensive_catalog,test_motion_profile,test_motion_render
from tools.harness import run
run.PROJECT=Path.cwd()
modules=[test_catalog_qualification,test_motion_journey,test_comprehensive_catalog,test_motion_profile,test_motion_render]
names=['tools.tests.test_protocol','tools.tests.test_protocol_captures','tools.tests.test_protocol_restart','tools.tests.test_protocol_unicode','tools.tests.test_protocol_integers','tools.tests.test_protocol_suite','tools.tests.test_journey_dialog','tools.tests.test_journey_paths','tools.tests.test_parcel_journey','tools.tests.test_brock_policy']
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(m)for m in modules]+[unittest.defaultTestLoader.loadTestsFromName(name)for name in names])
result=unittest.TextTestRunner().run(suite)
if result.skipped:raise SystemExit('unexpected skips: '+repr(result.skipped))
raise SystemExit(not result.wasSuccessful())

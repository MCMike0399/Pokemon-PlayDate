# Frozen composed host packet over ba8975d

Manifest SHA256:33d075f328d3a5396447908e831e290f2ae8531ec915011a39cb139af4c14ec9.
Base commit:ba8975da86fb469a4b0bfb21f45244c0c43cb60d. Exact existing-file base hashes are in base-files.json/manifest.json. Existing-file changes are reviewable unified hunks under patches/. Originals pokemon-motion-journeys and pokemon-catalog-qualification remain untouched.

Compile-only PASS: /private/tmp/pokemon-host-composed-ba8975d-build-01.
Combined host verification:116/116 PASS5.575s, no skips. This includes all protocol/capture/restart/unicode/integer/suite tests, existing dialog/path/parcel/Brock policy tests, and the staged catalog/motion/comprehensive/profile/render tests. The intentionally failing child runs printed by suite tests are fixtures verifying fail/continue behavior; overall tests pass. Test bootstrap sets staged run.PROJECT to actual project before suite imports, matching validator behavior. No SDK run was launched by this worker.

Root validator, compile by default:

```
/private/tmp/pokemon-validation-venv/bin/python /private/tmp/pokemon-host-composed-ba8975d/validate_staged.py --project /Users/burbujamc/Developer/Pokemon-PlayDate --case motion-save-continue --output /private/tmp/pokemon-host-composed-build-UNIQUE
```

Root alone adds --execute. Cases:motion-south-gate,motion-pewter-city,motion-pewter-mart,motion-save-continue,catalog-normal. catalog-normal execution explicitly requires root's reviewed catalog Source already present; this composed validator NEVER overlays catalog Source or imports. Only Source/dev/contracts metadata and readonly Source/dev/diagnostics are overlaid. Main/production gameplay/render code is untouched.

Installation: apply six existing-file patches serially (run,restarting,journeys,dev/contracts,dev/diagnostics,harness.md); copy the new host modules/tests/four motion scenarios/catalog scenario and profile helper. New comprehensive.py and comprehensive-catalog.json are byte-identical dependencies from the reviewed catalog packet; root can retain its identical copies when integrating. Do not overwrite full shared files blindly. Existing Brock source implementation, dynamic replanning, medicine journey, owner/PID lifecycle and restart code remain repository-owned; all disjoint original patch hunks applied to ba8975d without fuzz/offset.

Followups included:

1. catalog-invariance execution evidence records request_sha256 AND result_sha256, with an explicit regression checking actual raw evidence bytes. Existing native523/523,859pairs/1718PNGs,1635protected/1041source acceptance remains root's prior proof, not a new combined run claim.
2. Portable seven comprehensive tests retain inventory/directions/missing-path/source-mutation/hiddenRGB+alpha/materialization coverage. They no longer read private scenario.json or validate_staged.py. They check repository native before/after write declarations and normal qualifier expected859×2 inventories plus strict missing/duplicate failure. Materializer byte preservation uses the independently pinned accepted helper SHA835529cc84f2881ebf6bd0f21f2a2e2e9bd8b6cd174bfda81747c6d20df4cac6, avoiding comparison of two same-checkout copies. The strict normal qualifier comparator is exercised alongside the independent source pixel oracle. Before catalog Source integration, CATALOG_FEATURE_SOURCE explicitly selects reviewed staged feature Source; after integration its default is repository Source.
3. Corrected Continue image labeling. PNG02 is the prior Title render at the semantically restored install boundary. The previous successful two-process exact DTO/pose/RNG/session proof is retained; its screenshot was not a rendered-world proof. New driver atomically sends record3/A/snapshot: command2 snapshot still proves exact pre-first-world-tick install, command3 snapshot is exactly one frame/tick later. PNG03 is checked against that actual post-update snapshot using identified staged source sprites, native tick/facing/flip, pixel positions and camera. Every visible expected opaque source pixel must match RGBA exactly; source-transparent cells belong to underlying terrain and are excluded, never used to conceal opaque art. Mart moving actor must have at least32 visible opaque samples. A separate96-frame live resume follows. This explicitly visual Continue recipe preflights Pillow; ordinary functional/protocol paths remain Pillow-free.
4. Profile helper now selects per-process traces when present, otherwise normal root trace or runtime-data/trace.jsonl. Three tests cover fallback/no duplicate archives/missing trace. Portable module is tools/harness/profile_motion.py; root profile_motion.py is a same-byte convenience copy.

Readonly proof against retained root artifacts is under evidence/: the old real resume01 world PNG passed1952 exact opaque pixels across3 source actors; old Title boundary02 correctly failed world-pose qualification. These are host checks of existing native evidence, not a new Simulator run. Actual Mart trace profile:150active consecutive intervals,28moving samples;median33ms,p95=34,max38;heap9756.8..14533KiB. These include capture/trace/GC overhead and do not measure isolated NPC CPU or physical-device capacity.

pure-render-recommendation.md is separate, unimplemented advice for the discovered stale transition frame. No Source presentation fix is bundled here.

Reproduce combined tests with the existing Pillow environment:

```
CATALOG_FEATURE_SOURCE=/private/tmp/pokemon-comprehensive-catalog/Source PARCEL_BUNDLE_SOURCE=/private/tmp/pokemon-npc-motion-native-02 PYTHONPATH="$PWD" /private/tmp/pokemon-validation-venv/bin/python /private/tmp/pokemon-host-composed-ba8975d/run_host_tests.py
```

The script sets actual project context before suite imports and fails on any skipped test. No Source/Simulator/Data mutations occur.

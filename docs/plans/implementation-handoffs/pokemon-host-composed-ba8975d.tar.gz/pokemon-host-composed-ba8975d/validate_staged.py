#!/usr/bin/env python3
"""Composed catalog/motion host packet over ba8975d. Compile only; root owns --execute."""
import argparse,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True);p.add_argument('--output',required=True);p.add_argument('--sdk');p.add_argument('--case',choices=['motion-south-gate','motion-pewter-city','motion-pewter-mart','motion-save-continue','catalog-normal'],required=True);p.add_argument('--execute',action='store_true');a=p.parse_args();stage=Path(__file__).parent;project=a.project.resolve()
sys.path.insert(0,str(project));import tools.harness
tools.harness.__path__.insert(0,str(stage/"tools/harness"))
from tools.harness import run as runner
from tools.harness.protocol import atomic_json
manifest=json.loads((stage/'manifest.json').read_text());original=runner.prepare

def prepare(project,sdk,output,session):
 for relative,expected in manifest['base_files'].items():
  assert hashlib.sha256((project/relative).read_bytes()).hexdigest()==expected,'root owned module changed: '+relative
 metadata=original(project,sdk,output,session)
 for entry in manifest['owned_files']:
  source=stage/entry['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==entry['sha256'],'motion journey packet changed'
  if entry['path'].startswith('Source/'):
   destination=output/entry['path'];destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination)
 if a.execute and a.case=='catalog-normal':assert (output/'Source/dev/comprehensiveCatalogContracts.lua').is_file(),'integrate reviewed catalog Source first; this packet never overlays it'
 pdxinfo=output/'Source/pdxinfo';generated=pdxinfo.read_text();pdxinfo.write_text(metadata['original_pdxinfo']);metadata['source_sha256']=runner.fingerprint(output);metadata['build_id']=metadata['revision']+':'+metadata['source_sha256']
 atomic_json(output/'source-manifest.json',{str(x.relative_to(output/'Source')):hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted((output/'Source').rglob('*'))if x.is_file()and x.relative_to(output/'Source').as_posix()!='dev/harness_build.lua'})
 pdxinfo.write_text(generated);lines=[]
 for key in ['protocol','session_id','build_id','output_dir','bundle_id','sdk_version','enabled','data_dir']:
  value=metadata[key];lines.append('    '+key+' = '+('true'if value is True else json.dumps(value))+',')
 (output/'Source/dev/harness_build.lua').write_text('HarnessBuild = {\n'+'\n'.join(lines)+'\n}\n')
 metadata['compiled_source_sha256']=runner.fingerprint(output,exclude_generated=False);metadata['host_composed_packet']={'packet':manifest['packet'],'base_revision':manifest['base_revision'],'owned_files':manifest['owned_files']}
 with (output/'host-composed-build.log').open('w')as log:subprocess.run([str(sdk/'bin/pdc'),str(output/'Source'),metadata['bundle']],stdout=log,stderr=subprocess.STDOUT,check=True)
 atomic_json(output/'build.json',metadata);return metadata
runner.prepare=prepare;runner.PROJECT=project;scenario=stage/'scenarios'/(a.case+'.json')
try:code=runner.run(SimpleNamespace(sdk=a.sdk,output=a.output,scenario=str(scenario),commands=[],build_only=not a.execute,timeout=90,ready_timeout=20,max_frames=1800))
finally:runner.prepare=original
raise SystemExit(code)

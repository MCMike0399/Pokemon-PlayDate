from pathlib import Path
import json,hashlib,difflib,shutil
p=Path(__file__).parent;base=Path('/private/tmp/pokemon-brock-integration-02')
changed=[];new=[];base_files={}
owned={'Source/game/eventState.lua', 'Source/game/context.lua', 'Source/domain/party.lua', 'Source/game/kantoWorld.lua', 'Source/game/overworldState.lua', 'Source/game/debugState.lua', 'Source/game/battleState.lua', 'Source/game/story.lua'}
for f in sorted((p/'Source').rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(p).as_posix();old=base/rel
 if not old.exists():new.append(rel)
 elif rel in owned and f.read_bytes()!=old.read_bytes():
  changed.append(rel);base_files[rel]=hashlib.sha256(old.read_bytes()).hexdigest()
  target=p/'patches'/Path(rel).with_suffix('.patch');target.parent.mkdir(parents=True,exist_ok=True)
  target.write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),f.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
for rel in ['Source/main.lua','Source/dev/diagnostics.lua']:
 base_files[rel]=hashlib.sha256((base/rel).read_bytes()).hexdigest()
# Root-only imports/registration hook, kept separate from shared file overlays.
main=(base/'Source/main.lua').read_text();marker='game = GameContext('
main=main.replace(marker,'import "game/fieldBattle"\nimport "game/homeRest"\nimport "dev/homeLeadContracts"\nContracts.register("home-lead",HomeLeadContracts.run)\n\n'+marker)
main=main.replace('machine:register("townMap",TownMapState(game))','machine:register("townMap",TownMapState(game))\nmachine:register("homeRest",HomeRestState(game))')
(p/'patches/main-root-hook.patch').write_text(''.join(difflib.unified_diff((base/'Source/main.lua').read_text().splitlines(True),main.splitlines(True),fromfile='a/Source/main.lua',tofile='b/Source/main.lua')))
# Don't overlay this full main; validator applies narrow hook after guarded copies.
ref=Path('/private/tmp/pokered-af519899719f0754965776faac0e836a3b906e6d');pins={}
for rel in ['scripts/RedsHouse1F.asm','text/RedsHouse1F.asm','engine/battle/core.asm','engine/events/pokecenter.asm','data/maps/special_warps.asm']:
 out=p/'references/pokered'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ref/rel,out)
 pins[rel]={'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'url':'https://github.com/pret/pokered/blob/af519899719f0754965776faac0e836a3b906e6d/'+rel}
proposal=Path('/private/tmp/pokemon-home-lead-proposal')
for rel in ['system/btl_setup.c','ov167/btl_main.c']:
 out=p/'references/b2w2'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(proposal/'references'/rel,out)
(p/'source-pins.json').write_text(json.dumps({'pokered_revision':'af519899719f0754965776faac0e836a3b906e6d','pokered':pins,'b2w2_revision':'b279bbefa99bb2f6fbabcc95e4b6d3e939290353','b2w2':json.loads((proposal/'b2w2-pin.json').read_text())},indent=2)+'\n')
manifest={'schema':1,'packet':'home-lead-01','base':'/private/tmp/pokemon-brock-integration-02','base_files':base_files,'overlay_files':changed+new,'shared_patches':changed,'new_files':new,'files':{}}
for f in sorted(p.rglob('*')):
 if f.is_file() and f.name!='manifest.json' and not any(x in f.parts for x in ['__pycache__','.pytest_cache']):
  rel=f.relative_to(p).as_posix()
  if rel.startswith('Source/') and rel not in manifest['overlay_files']:continue
  manifest['files'][rel]=hashlib.sha256(f.read_bytes()).hexdigest()
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'shared':changed,'new':new,'manifest_sha256':hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()},indent=2))

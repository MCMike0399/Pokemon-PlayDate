from pathlib import Path
import shutil
base=Path('/private/tmp/pokemon-brock-integration-02'); stage=Path(__file__).parent
shutil.copytree(base/'Source',stage/'Source',dirs_exist_ok=True)
def edit(rel,old,new):
 p=stage/'Source'/rel;s=p.read_text();assert s.count(old)==1,(rel,old);p.write_text(s.replace(old,new))
edit('game/context.lua','checkpoint=startLocation(),seed=','checkpoint={zone_id="pallet_town",x=5,y=6,facing="down"},seed=')
p=stage/'Source/domain/party.lua'
p.write_text(p.read_text()+'''
-- Internal controller construction scope. Restore even a previously fainted
-- active member if admission fails; never reorder or recreate the roster.
function Party:_withActiveForEntry(index, build)
    local mon=self:get(index)
    assert(mon and mon:isAlive() and type(build)=="function","invalid field lead")
    local state=states[self];local previous=state.active
    state.active=index
    local result=table.pack(pcall(build,mon))
    if not result[1] then state.active=previous;error(result[2],0) end
    return table.unpack(result,2,result.n)
end
''')
edit('game/battleState.lua','''    self.npc = npc
    self.finished=false;self.epoch=(self.epoch or 0)+1;self.trainerToken=nil
    playdate.graphics.sprite.removeAll()
    self.game.camera:reset()
    playerPokemon:resetStages()

    self.battle = Battle(playerPokemon, enemyPokemon, npc and npc.name,
        {party = self.game.session:party(), session = self.game.session, enemyParty = enemyParty})
    self.scene = BattleScene(self.battle)
''','''    local plan,reason=FieldBattle.prepare(self.game,playerPokemon,enemyPokemon,npc,enemyParty)
    assert(plan,reason)
    local battle,scene=FieldBattle.construct(plan)
    self.npc = npc
    self.finished=false;self.epoch=(self.epoch or 0)+1;self.trainerToken=nil
    self.battle,self.scene=battle,scene
    playdate.graphics.sprite.removeAll()
    self.game.camera:reset()
''')
# Production entry callers retain their lifecycle, but reject invalid model input
# before replacing the current stack. FieldBattle.start revalidates in enter.
for rel in ['game/story.lua','game/eventState.lua','game/debugState.lua','game/overworldState.lua']:
 p=stage/'Source'/rel;s=p.read_text()
 s=s.replace('game.machine:change("battle",','assert(FieldBattle.start(game,').replace('self.machine:change("battle",','assert(FieldBattle.start(self.game,').replace('rootMachine:change("battle",','assert(FieldBattle.start(game,')
 # close changed calls, exact known lines
 s=s.replace('enemy, blue)','enemy, blue))').replace('party:active(),self.trainerNPC,party)','party:active(),self.trainerNPC,party))').replace('game:getPlayerPokemon(), enemy, nil)','game:getPlayerPokemon(), enemy, nil))').replace('game:getPlayerPokemon(), enemy, npc)','game:getPlayerPokemon(), enemy, npc))').replace('game:getPlayerPokemon(), currentZone:rollEncounter(game.session), nil)','game:getPlayerPokemon(), currentZone:rollEncounter(game.session), nil))')
 if rel=='game/overworldState.lua':
  s=s.replace('and game:getPlayerPokemon() then','and game.session:party():firstUsable() then')
  s=s.replace('or not Specimen.isActiveSession(session) then','or not Specimen.isActiveSession(session) or not session:party():firstUsable() then')
 if rel=='game/story.lua':s=s.replace('or not game.machine:is("overworld") then','or not game.machine:is("overworld") or not session:party():firstUsable() then')
 if rel=='game/debugState.lua':s=s.replace('action.type=="wildBattle" and game:getPlayerPokemon() then','action.type=="wildBattle" and game.session:party():firstUsable() then')
 p.write_text(s)
edit('game/kantoWorld.lua','function KantoWorld.tryInteract(game)\n','function KantoWorld.tryInteract(game)\n    if HomeRest and HomeRest.tryInteract(game)then return true end\n')

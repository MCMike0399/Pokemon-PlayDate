# Home and field lead packet 01

Private implementation against `/private/tmp/pokemon-brock-integration-02` after charge integration. No repository files or Simulator were modified/launched. Apply only the eight `patches/Source/...` hunks plus three `new_files` from manifest; full Source snapshots are validator input, not a wholesale replacement. Root-owned import/registration delta is `patches/main-root-hook.patch`; optional diagnostics adds `home_rest=root:get("homeRest") and root:get("homeRest"):getSnapshot() or {phase="closed"}`. Preserve all charge, teaching, field, evolution/learning, ability, catalog and motion imports.

New `FieldBattle.prepare` is pure and selects `Party:firstUsable()` in physical order. `start` rejects invalid input before replacing the root stack. `BattleState.enter` revalidates, then constructs real Battle/BattleScene with that member; only a successful construction retains the active-index change. A narrow internal Party scope restores even a previously fainted active member on constructor errors. The selected member's original stage table and session discovery data restore on construction failure. Sprite removal and camera reset occur after construction succeeds. Existing field starts now use `FieldBattle.start`; the wild trigger rejects an unusable party before encounter/specimen RNG, and trainer/debug/intro creation gates retain ownership checks. Existing source TrainerEvents already rejects empty/all-fainted parties before detached team sampling. No rules engine, enemy replacement, learning, Battle.finish, session append methods, party order, or Pokémon identity changes.

Only production `newModel` changes checkpoint to Pallet `(5,6,down)`; initial bedroom location remains `(5,3,up)`. Generic SessionCodec decode and existing saved checkpoints are untouched. No legacy-save rewrite.

`HomeRest.tryInteract` requires the actual adjacent authored MOM in Red's house and settled base exploration. Root must register `homeRest`. Pre-starter interaction gives source wake-up text and cannot heal. Acquired starter (intro tuple, not Pokédex) gives source rest text, a 12-tick white fade, one `healAll` at full white, 12 ticks white, 12-tick return, then source looking-great text. This is a native 30FPS presentation adaptation preserving source ordering; exact GB palette timing/music is not claimed. Full restore includes fainted reserves/status/PP using the existing production method. It does not choose a field lead, capture traversal, change checkpoint/flags/money or sample either stream. Existing Overworld pause/resume/pure presentation owns actor suspension and rendering. During the bounded fade only, Mom clears the preceding overlay through the existing EventState.redrawSprites pure SDK bridge (temporary callback suppression with exact restoration); no logical actor update is added. Stale dialogue callbacks and precommit interruption cannot heal. Dialogue/overlay is not a save boundary.

## Proof and root jobs

Host: `python3 -m unittest discover -s /private/tmp/pokemon-home-lead-01/tests -v` (6 source/pin/patch checks). Source vectors independently establish Blue first-conscious scan, B2W2 physical-copy/order restore, Mom starter gate/text/heal ordering/no checkpoint, and Pallet FlyWarp5,6. Pins include complete consumed original files and Git blob hashes for the independent GenV source.

Compile only (safe for workers):

```
python3 /private/tmp/pokemon-home-lead-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-home-lead-compile-04
```

Root-only native proof, after reviewing manifest and enforcing sole Simulator ownership:

```
python3 /private/tmp/pokemon-home-lead-01/validate_staged.py --project /private/tmp/pokemon-brock-integration-02 --output /private/tmp/pokemon-home-lead-native-01 --execute
```

Eleven new SDK cases exercise actual controller entry/Party/Battle/BattleScene; first/fainted leads; rejected admission purity; constructor rollback including fainted prior active; standalone rules/trainer replacement; default/old codec checkpoint; Mom pre-starter/rest/abort/stale callback/actual-NPC gating. Two native images are requested by contracts: `home-mom-white.png` and `home-mom-rested.png`. These cases are declared, NOT run by the worker. Full existing contracts remain strict. Re-run intro, source trainer, medicine/learning and protected2494 catalog after integration. The prior compile01 used the baseline before charge integration; compile04 is the intended final current composition.

Additional actual-input root recipe: begin new game, walk downstairs and A on MOM before starter (source text, no heal); complete intro, take real damage, walk home, face MOM at `(5,4)` from `(5,5)`, press A, await/dismiss rest paragraph, record48 during white/rest transition, await/dismiss looking-great paragraph. Observe healed whole party, unchanged checkpoint/both streams and actor pose; capture settled world after presentation flush. For later-checkpoint proof, heal at Pewter first, return naturally/explicitly labeled supplementary navigation, rest at Mom and verify checkpoint remains Pewter. Save at settled exploration and actual second-process Continue should retain healed party and that checkpoint. No copied saves or debug outcome overrides in natural acceptance.

Remaining explicit gaps: original healed music/map music subsystem and exact GB palette timing; Red PC Potion/item storage. This packet does not implement either. Black Save/Continue images reported from the earlier Charmander campaign remain invalid visual evidence, pending a separate capture-barrier diagnosis.

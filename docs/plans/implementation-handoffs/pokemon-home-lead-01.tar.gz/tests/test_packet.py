import hashlib,json,re,unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1]
class SourceProof(unittest.TestCase):
 def test_all_consumed_primary_bytes_are_pinned(self):
  pins=json.loads((P/'source-pins.json').read_text())
  for repo in ('pokered','b2w2'):
   for rel,record in pins[repo].items():
    raw=(P/'references'/repo/rel).read_bytes()
    self.assertEqual(hashlib.sha256(raw).hexdigest(),record['sha256'],rel)
    if 'git_blob' in record:self.assertEqual(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),record['git_blob'])
 def test_blue_first_sendout_literal_vector(self):
  s=(P/'references/pokered/engine/battle/core.asm').read_text();s=s[s.index('.playerSendOutFirstMon\n'):]
  vector=['xor a','ld [wWhichPokemon], a','call HasMonFainted','jr nz, .foundFirstAliveMon','inc [hl]','ld [wPlayerMonNumber], a']
  for token in vector:self.assertIn(token,s[:850])
 def test_mom_starter_gate_heal_order_and_no_checkpoint_write(self):
  s=(P/'references/pokered/scripts/RedsHouse1F.asm').read_text()
  self.assertIn('bit BIT_GOT_STARTER, a',s);self.assertNotIn('POKEDEX',s)
  positions=[s.index(x)for x in ['call PrintText\n\tcall GBFadeOutToWhite','predef HealParty','call GBFadeInFromWhite','ld hl, RedsHouse1FMomLookingGreatText']]
  self.assertEqual(positions,sorted(positions));self.assertNotIn('SetLastBlackoutMap',s)
  text=(P/'references/pokered/text/RedsHouse1F.asm').read_text();self.assertIn('quick rest.',text);self.assertIn('looking great!',text)
 def test_pallet_source_checkpoint_literal(self):
  s=(P/'references/pokered/data/maps/special_warps.asm').read_text()
  self.assertRegex(s,r'fly_warp PALLET_TOWN,\s*5,\s*6')
 def test_genv_physical_party_copy_and_order_restore_independent(self):
  setup=(P/'references/b2w2/system/btl_setup.c').read_text();battle=(P/'references/b2w2/ov167/btl_main.c').read_text()
  self.assertIn('GameData_GetParty',setup)
  for token in ['BattleParty_MoveFaintedToEnd','PokeCon_StoreClientSrcPartyInOrder','BattleParty_GetFirstAlive']:self.assertIn(token,battle)
 def test_guarded_patch_inventory_preserves_engine_and_learning(self):
  manifest=json.loads((P/'manifest.json').read_text())
  self.assertEqual(len(manifest['shared_patches']),8)
  self.assertEqual(set(manifest['new_files']),{'Source/game/fieldBattle.lua','Source/game/homeRest.lua','Source/dev/homeLeadContracts.lua'})
  for rel in manifest['overlay_files']:self.assertNotIn(rel,{'Source/main.lua','Source/battle/battle.lua','Source/game/learningState.lua','Source/domain/gameSession.lua'})
  for rel,digest in manifest['files'].items():self.assertEqual(hashlib.sha256((P/rel).read_bytes()).hexdigest(),digest,rel)
if __name__=='__main__':unittest.main()

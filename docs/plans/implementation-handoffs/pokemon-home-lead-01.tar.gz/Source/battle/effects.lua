-- Gen V ability hooks owned by one actual Battle. No persistent volatile state.
Class("BattleEffects")
local function has(mon,t) return mon.type==t or mon.type2==t end
local function ability(mon) return mon and mon.ability and mon:ability() or 0 end
local function alive(mon) return mon and mon:isAlive() end
local function round(value,ratio) return (value*ratio+2047)//4096 end -- half down
local function chain(value,ratio) return (value*ratio+2048)//4096 end -- FX_Mul
BattleEffects.fixedRound=round
BattleEffects.chain=chain
local handlers={}
local function lowHP(t)
    return {attack=function(_,mon,move,value)
        if mon.hp<=mon.maxHP//3 and move.type==t then return round(value,6144) end
        return value
    end}
end
handlers[65],handlers[66],handlers[67],handlers[68]=lowHP("grass"),lowHP("fire"),lowHP("water"),lowHP("bug")
handlers[62]={attack=function(_,mon,move,value)
    if mon.status and move.category=="physical" then return round(value,6144) end
    return value
end}
handlers[14]={accuracy=function() return 5325 end}
handlers[77]={evasion=function(_,mon) return mon.confusion and 2048 or 4096 end}
handlers[8]={evasion=function(owner) return owner.weather and 3277 or 4096 end}
handlers[5],handlers[9],handlers[19],handlers[50],handlers[51],handlers[61],handlers[69],handlers[71]={},{},{},{},{},{},{},{}
-- Captivate-only Oblivious dependency; Attract producer remains explicitly pending.
handlers[12],handlers[17],handlers[38],handlers[79]={},{},{},{}
handlers[20]={}
function BattleEffects:init(battle)
    self.battle=battle;self.weather=nil;self.receipts=setmetatable({},{__mode="k"});self.closed=false;self.round=nil
end
function BattleEffects:supported(id) return handlers[id]~=nil end
function BattleEffects:active(mon) return not self.closed and (self.battle.player==mon or self.battle.enemy==mon) end
local critDenominators <const> = {[0]=16,[1]=8,[2]=4,[3]=3,[4]=2}
function BattleEffects.criticalDenominator(stage)
    return critDenominators[math.max(0,math.min(4,stage))]
end
function BattleEffects:criticalStage(mon,move)
    local state=self.battle.conditions.members[mon]
    return math.max(0,math.min(4,(move.critStage or 0)+(state and state.focusEnergy and 2 or 0)))
end

function BattleEffects:accuracy(attacker,defender,move)
    local ratio=4096;local a,d=handlers[ability(attacker)],handlers[ability(defender)]
    if a and a.accuracy then ratio=chain(ratio,a.accuracy(self,attacker)) end
    if d and d.evasion then ratio=chain(ratio,d.evasion(self,defender)) end
    return round(move.accuracy,ratio)
end
-- One logical round, retained while the production script yields for learning.
-- Identity keys prevent a replacement from inheriting the outgoing action/damage.
function BattleEffects:beginRound(turns)
    local round={pending={},damaged={}}
    for _,turn in ipairs(turns or {}) do
        local mon=self.battle[turn.side]
        round.pending[mon]={turn=turn,move=turn.move}
    end
    self.round=round
end
function BattleEffects:endRound() self.round=nil end
function BattleEffects:beginAction(turn,mon)
    local pending=self.round and self.round.pending[mon]
    if pending and pending.turn==turn then self.round.pending[mon]=nil end
end
function BattleEffects:pendingMove(mon)
    local pending=self.round and self.round.pending[mon]
    return self:active(mon) and alive(mon) and pending and pending.move or nil
end
function BattleEffects:damagedThisRound(mon)
    return self.round~=nil and self.round.damaged[mon]==true
end
-- All enabled HP-loss producers pass through this owner. HP payments and
-- Struggle recoil are directDamage provenance, not Assurance's hurtThisTurn.
function BattleEffects:damage(mon,amount,cause)
    local before=mon.hp
    mon:takeDamage(amount)
    local removed=before-mon.hp
    if self.round and removed>0 and cause~="cost" and cause~="struggle-recoil" then
        self.round.damaged[mon]=true
    end
    return removed
end
function BattleEffects:canAttempt(move,attacker,defender)
    if move.attemptRule=="oppositeSex" then
        -- GenV TryHit ability immunity precedes move-specific sex immunity.
        if ability(defender)==12 then return false,"oblivious" end
        local a,d=attacker:getSex(),defender:getSex()
        if a=="genderless" or d=="genderless" or a==d then return false,"sex" end
    end
    if move.attemptRule=="singlesRedirect" then return false end
    if move.attemptRule=="suckerPunch" then
        local pending=self:pendingMove(defender)
        if not pending or pending.category=="status" then return false end
    end
    if move.damageRule=="endeavor" and attacker.hp>=defender.hp then return false end
    return true
end
function BattleEffects:fixedDamage(move,attacker,defender)
    if move.damageRule=="endeavor" then return defender.hp-attacker.hp end
end
-- Move-defined power precedes conditional field modifiers (e.g. Mud Sport).
function BattleEffects:movePower(move,power,attacker,defender)
    if move.powerRule=="electroBall" then
        local ratio=self.battle:effectiveSpeed(attacker)//math.max(1,self.battle:effectiveSpeed(defender))
        return ({[0]=40,60,80,120,150})[math.min(4,ratio)]
    end
    if move.powerRule=="assurance" and self:damagedThisRound(defender) then return power*2 end
    return power
end
-- Canonical GenV query seam. Only Sand has a current producer; other IDs
-- are policy inputs for future real weather owners, not new acquisition.
function BattleEffects:weatherId()
    return self.weather and (self.weather.id or "sandstorm") or "none"
end
function BattleEffects.solarPolicy(weather)
    assert(weather=="none" or weather=="sunnyday" or weather=="raindance"
        or weather=="sandstorm" or weather=="hail","unsupported-GenV-weather")
    local weak=weather=="raindance" or weather=="sandstorm" or weather=="hail"
    return weather=="sunnyday",weak and 2048 or 4096
end
function BattleEffects:basePower(move,power,attacker,defender)
    attacker,defender=attacker or self.battle.attacker,defender or self.battle.defender
    local ratio=4096
    if move.sandWeakened and select(2,BattleEffects.solarPolicy(self:weatherId()))==2048 then ratio=chain(ratio,2048) end
    if power>0 and attacker and defender and ability(attacker)==79 then
        local a,d=attacker:getSex(),defender:getSex()
        if a~="genderless" and d~="genderless" then ratio=chain(ratio,a==d and 5120 or 3072) end
    end
    if power>0 and ratio~=4096 then return math.max(1,round(power,ratio)) end
    return power
end
-- Shared major-status query; no RNG or changes to persistent stats/status here.
function BattleEffects:statusImmunity(mon,status)
    if ability(mon)==17 and (status=="poison" or status=="badPoison") then return "Immunity" end
    if ability(mon)==20 and status=="confuse" then return "Own Tempo" end
end
function BattleEffects:entry(mon)
    if not self:active(mon) or not alive(mon) then return false end
    if self:statusImmunity(mon,mon.status)=="Immunity" then
        mon.status,mon.statusTurns,mon.sleepDuration=nil,0,0
        self.battle.conditions:of(mon).toxic=nil
        self.battle:say(mon.name.."'s Immunity cured its poison!")
        return true
    end
    if mon.confusion~=nil and self:statusImmunity(mon,"confuse")=="Own Tempo" then
        mon.confusion=nil
        self.battle:say(mon.name.."'s Own Tempo cured its confusion!")
        return true
    end
    return false
end
function BattleEffects:weatherHeal(mon)
    return math.max(1,round(mon.maxHP,self.weather and 1024 or 2048))
end
function BattleEffects:attackStat(attacker,move,value)
    local h=handlers[ability(attacker)]
    value=h and h.attack and h.attack(self,attacker,move,value) or value
    -- B2W2 item attack modifier, after stat stages; never durable stats/power.
    if attacker.species=="pikachu" and attacker.heldItem=="lightBall"
        and (move.category=="physical" or move.category=="special") then return value*2 end
    return value
end
function BattleEffects:defenseStat(defender,move,value)
    if self.weather and move.category=="special" and has(defender,"rock") then return round(value,6144) end
    return value
end
function BattleEffects:ignoresBurn(mon) return ability(mon)==62 end
function BattleEffects:canDropStat(source,target,stat,delta)
    return not (source~=target and stat=="acc" and delta<0 and ability(target)==51)
end
function BattleEffects:allowsSecondary(source,target)
    return alive(target) and (source==target or ability(target)~=19)
end
function BattleEffects:recoilBlocked(mon,move) return ability(mon)==69 and not move.struggleRecoil end
function BattleEffects:grounded(mon) return not has(mon,"flying") end
function BattleEffects:withdrawBlocked(mon)
    local other=mon==self.battle.player and self.battle.enemy or self.battle.player
    return alive(other) and ability(other)==71 and self:grounded(mon)
end
function BattleEffects:sureEscape(mon) return ability(mon)==50 end
function BattleEffects:limitDirectHit(source,target,move,amount)
    local endure=ability(target)==5 and target.hp==target.maxHP and amount>=target.hp and source~=target
    return endure and math.max(0,target.hp-1) or amount,endure
end
-- Each receipt is made immediately around the direct HP commit and resolved once.
function BattleEffects:hit(source,target,move,amount,hitNumber)
    local before=target.hp
    local limited,endured=self:limitDirectHit(source,target,move,amount)
    self:damage(target,limited,"hit")
    local cause="fixed"
    if move then cause=move.ohko and "ohko" or (move.power==0 and not move.powerRule and "fixed" or "move") end
    local receipt={source=source,target=target,move=move,before=before,removed=before-target.hp,endured=endured,
        cause=cause,contact=move~=nil and move.contact==true,hit=hitNumber or 1}
    if move and move.category~="status" then self.battle.conditions:bideHit(target,source,receipt.removed) end
    self.receipts[receipt]=true
    return receipt
end
function BattleEffects:afterHit(receipt)
    if not self.receipts[receipt] or not self:active(receipt.source) or not self:active(receipt.target) then return false,"stale-hit" end
    self.receipts[receipt]=nil
    local b,source,target,move=self.battle,receipt.source,receipt.target,receipt.move
    local id=ability(target)
    if (id==9 or id==38) and receipt.contact and receipt.removed>0 and RulesRNG.random(0,99)<30 then
        -- Preserve native/Static chance-before-eligibility order, including KO.
        local status=id==9 and "paralyze" or "poison"
        local eligible=status~="poison" or (not has(source,"poison") and not has(source,"steel")
            and not self:statusImmunity(source,status))
        if alive(source) and not source.status and eligible then
            b:say(target.name .. (id==9 and "'s Static!" or "'s Poison Point!"))
            ApplyStatus({resolve=function() return source end},status):apply(b)
        end
    end
    return true
end
function BattleEffects:announceEndure(receipt)
    if receipt.endured then self.battle:say(receipt.target.name .. " held on with Sturdy!") end
end
function BattleEffects:ohko(attacker,defender,move)
    if attacker.level<defender.level then return false,"level" end
    if TypeChart.getMatchup(move.type,defender.type,defender.type2)==0 then return false,"immune" end
    if ability(defender)==5 then return false,"sturdy" end
    return RulesRNG.random(0,99)<move.accuracy+attacker.level-defender.level,"accuracy"
end
function BattleEffects:setSandstorm()
    if self.weather then self.battle:say("But it failed!");return false end
    self.weather={turns=5};self.battle:say("A sandstorm kicked up!");return true
end
function BattleEffects:events()
    local events={}
    if self.weather then events[#events+1]={kind="weatherTick",order=0,side="field",owner="effects"} end
    for _,side in ipairs({"player","enemy"}) do
        local mon=self.battle[side]
        if alive(mon) then
            if self.weather then events[#events+1]={kind="sand",order=1,side=side,pokemon=mon,owner="effects"} end
            if ability(mon)==61 and mon.status then events[#events+1]={kind="shedSkin",order=5,side=side,pokemon=mon,owner="effects"} end
        end
    end
    return events
end
function BattleEffects:residual(event)
    local b,mon=self.battle,event.pokemon
    if event.kind=="weatherTick" then
        if self.weather then
            self.weather.turns=self.weather.turns-1
            if self.weather.turns==0 then self.weather=nil;b:say("The sandstorm subsided.") end
        end
    elseif event.kind=="sand" and self.weather and self:active(mon) and alive(mon) then
        if not has(mon,"rock") and not has(mon,"ground") and not has(mon,"steel") and ability(mon)~=8 then
            self:damage(mon,math.max(1,mon.maxHP//16),"weather");b:say(mon.name .. " is buffeted by the sandstorm!")
        end
    elseif event.kind=="shedSkin" and self:active(mon) and alive(mon) and mon.status and ability(mon)==61 then
        if RulesRNG.random(0,99)<33 then
            mon.status,mon.statusTurns,mon.sleepDuration=nil,0,0
            b.conditions:of(mon).toxic=nil
            b:say(mon.name .. " shed its status with Shed Skin!")
        end
    end
end
function BattleEffects:clear(mon)
    if self.round then self.round.pending[mon]=nil;self.round.damaged[mon]=nil end
    for receipt in pairs(self.receipts) do if receipt.source==mon or receipt.target==mon then self.receipts[receipt]=nil end end
end
function BattleEffects:close() self:endRound();self.closed=true;self.weather=nil;self.receipts=setmetatable({},{__mode="k"}) end
function BattleEffects:snapshot() return {weather=self.weather and "sandstorm" or "none",turns=self.weather and self.weather.turns or 0} end

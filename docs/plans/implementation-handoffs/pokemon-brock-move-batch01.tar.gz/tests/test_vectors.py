"""Independent literal expectations and packet integrity; SDK runs production Lua."""
import hashlib,json,math,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class Vectors(unittest.TestCase):
 def test_electro_boundaries(self):
  expected=[(1,100,40),(99,100,40),(100,100,60),(199,100,60),(200,100,80),(299,100,80),(300,100,120),(399,100,120),(400,100,150),(1000,100,150)]
  for a,d,bp in expected:self.assertEqual([40,60,80,120,150][min(a//max(1,d),4)],bp)
 def test_literal_damage(self):
  # Independent GenV neutral Pikachu100 SpA105 -> Rattata100 SpD75,
  # no crit, literal87% variance, STAB, no active item/ability modifiers.
  expected={40:63,60:93,80:124,120:186,150:231}
  for bp,want in expected.items():
   base=(42*bp*105//75)//50+2
   self.assertEqual((base*87//100)*3//2,want)
 def test_park_miller_literal_seed2_ordinary_hit(self):
  n=2;states=[]
  for _ in range(3):n=n*16807%2147483647;states.append(n)
  self.assertEqual(states,[33614,564950498,1097816499])
  self.assertEqual(1+(states[0]-1)%100,14)
  self.assertEqual(1+(states[1]-1)%16,2)
  self.assertEqual(85+(states[2]-1)%16,87)
 def test_assurance_literal_round(self):
  # Seed2 explicit enemyTakeDown -> playerAssurance; no AI-selection draw.
  n=2;states=[]
  for _ in range(6):n=n*16807%2147483647;states.append(n)
  take=(42*90*117//75)//50+2
  hp_lost=(take*(85+(states[2]-1)%16)//100)*3//2
  self.assertEqual(hp_lost,154)
  recoil=math.floor(hp_lost/4+0.5);self.assertEqual(recoil,39)
  assurance=(42*100*117//75)//50+2
  self.assertEqual(assurance,133)
  self.assertEqual(85+(states[5]-1)%16,100)
  self.assertEqual(min(170-recoil,assurance),131)
 def test_generated_dependency_exact(self):
  path=ROOT/'Source/battle/moves.lua'
  self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),'6063f7501ff53e151e826eb51fb6310af1caed5962124a8483e6f0cae9d32c87')
 def test_metadata_request_exactly_six(self):
  data=json.loads((ROOT/'generator-request.json').read_text())
  self.assertEqual(set(data['rows']),{'electroBall','endeavor','suckerPunch','assurance','sweetScent','ragePowder'})
if __name__=='__main__':unittest.main()

import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
cases=[('electro-ball','pikachu',18,34,'electroBall','ELECTRO BALL','METAPOD took 16 damage!','battle.enemy.hp',62),('endeavor','rattata',34,34,'endeavor','ENDEAVOR','METAPOD took 40 damage!','battle.enemy.hp',30),('sucker-punch-fail','rattata',19,34,'suckerPunch','SUCKER PUNCH','But it failed!','battle.player.pp.suckerPunch',4),('assurance','rattata',25,34,'assurance','ASSURANCE','METAPOD took 9 damage!','battle.enemy.hp',69),('sweet-scent','bulbasaur',21,5,'sweetScent','SWEET SCENT',"METAPOD's EVASIVENESS fell!",'battle.enemy.stat_stages.eva',-1),('rage-powder-fail','butterfree',34,34,'ragePowder','RAGE POWDER','But it failed!','battle.player.pp.ragePowder',19)]
def wait(path,want):return {'op':'await','path':path,'equals':want,'frames':300}
def say(message):return [wait('battle.message',message),wait('battle.waiting',True),'wait 12']
for name,species,level,enemy_level,key,label,result,path,value in cases:
 player={'species':species,'level':level};enemy={'species':'metapod','level':enemy_level}
 if key=='endeavor':player['hp']=30;enemy['hp']=70
 commands=[{'op':'fixture','options':{'intro':'skip','opening':False,'zone':'reds_house_2f','seed':2,'player_pokemon':player,'trainer_name':'BATCH TEST','enemy_party':[enemy]}},wait('battle.introPhase','ready')]
 commands+=say('BATCH TEST wants to battle!')+['press a']+say('BATCH TEST sent out METAPOD!')+['press a',wait('battle.phase','command'),wait('battle.menu.active',True),'seed 2','press a',wait('battle.inMoveSelect',True),'press right','press down','press a']
 hero={'pikachu':'PIKACHU','rattata':'RATTATA','bulbasaur':'BULBASAUR','butterfree':'BUTTERFREE'}[species]
 commands+=say(hero+' used '+label+'!')+['press a']+say(result)+['record '+name+' 24','shot '+name,{'op':'assert','path':path,'equals':value}]
 (ROOT/'scenarios'/('brock-batch01-'+name+'.json')).write_text(json.dumps({'commands':commands,'outputs':[name+'-01.png',name+'.png']},indent=2)+'\n')

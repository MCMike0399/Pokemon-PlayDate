from pathlib import Path
s=Path('/private/tmp/pokemon-brock-move-batch01/Source/battle')
p=s/'effects.lua';t=p.read_text();t=t.replace('self.closed=false','self.closed=false;self.round=nil')
anchor='function BattleEffects:basePower(move,power)\n'
insert='''-- One logical round, retained while the production script yields for learning.
-- Identity keys prevent a replacement from inheriting the outgoing action/damage.
function BattleEffects:beginRound(turns)
    local round={pending={},damaged={}}
    for _,turn in ipairs(turns or {}) do
        local mon=self.battle[turn.side]
        round.pending[mon]={turn=turn,move=turn.move}
    end
    self.round=round
end
function BattleEffects:endRound() self.round=nil end
function BattleEffects:beginAction(turn,mon)
    local pending=self.round and self.round.pending[mon]
    if pending and pending.turn==turn then self.round.pending[mon]=nil end
end
function BattleEffects:pendingMove(mon)
    local pending=self.round and self.round.pending[mon]
    return self:active(mon) and alive(mon) and pending and pending.move or nil
end
function BattleEffects:damagedThisRound(mon)
    return self.round~=nil and self.round.damaged[mon]==true
end
-- All enabled HP-loss producers pass through this owner. HP payments and
-- Struggle recoil are directDamage provenance, not Assurance's hurtThisTurn.
function BattleEffects:damage(mon,amount,cause)
    local before=mon.hp
    mon:takeDamage(amount)
    local removed=before-mon.hp
    if self.round and removed>0 and cause~="cost" and cause~="struggle-recoil" then
        self.round.damaged[mon]=true
    end
    return removed
end
function BattleEffects:canAttempt(move,attacker,defender)
    if move.attemptRule=="singlesRedirect" then return false end
    if move.attemptRule=="suckerPunch" then
        local pending=self:pendingMove(defender)
        if not pending or pending.category=="status" then return false end
    end
    if move.damageRule=="endeavor" and attacker.hp>=defender.hp then return false end
    return true
end
function BattleEffects:fixedDamage(move,attacker,defender)
    if move.damageRule=="endeavor" then return defender.hp-attacker.hp end
end
'''
assert t.count(anchor)==1;t=t.replace(anchor,insert+anchor)
t=t.replace(anchor,anchor+'''    if move.powerRule=="electroBall" then
        local attacker,defender=self.battle.attacker,self.battle.defender
        local ratio=self.battle:effectiveSpeed(attacker)//math.max(1,self.battle:effectiveSpeed(defender))
        power=({[0]=40,60,80,120,150})[math.min(4,ratio)]
    elseif move.powerRule=="assurance" and self:damagedThisRound(self.battle.defender) then
        power=power*2
    end
''')
t=t.replace('target:takeDamage(limited)','self:damage(target,limited,"hit")')
t=t.replace('mon:takeDamage(math.max(1,mon.maxHP//16))','self:damage(mon,math.max(1,mon.maxHP//16),"weather")')
t=t.replace('function BattleEffects:close() self.closed=true;', 'function BattleEffects:close() self:endRound();self.closed=true;')
p.write_text(t)
p=s/'battle.lua';t=p.read_text();t=t.replace('function BattleScriptPhase:exit()\n    self.battle:cancelPendingLearning()', 'function BattleScriptPhase:exit()\n    self.battle.effects:endRound()\n    self.battle:cancelPendingLearning()')
anchor='function Battle:resolveRound(turns)\n';assert t.count(anchor)==1;t=t.replace(anchor,anchor+'    self.effects:beginRound(turns)\n')
t=t.replace('    local attacker = self.attacker\n\n    -- Fainted by', '    local attacker = self.attacker\n    self.effects:beginAction(turn,attacker)\n\n    -- Fainted by')
# Public observer delegates to exact ordering Speed implementation (stages/paralysis).
pos=t.index('\nend',t.index('local function effectiveSpeed(pokemon)'))+4
t=t[:pos]+'\nfunction Battle:effectiveSpeed(pokemon) return effectiveSpeed(pokemon) end\n'+t[pos:]
# Every accepted non-fight command creates a fresh round; rejection paths remain inert.
t=t.replace('    local old=self.player\n    assert(self.party:switch(index))','    local old=self.player\n    self.effects:beginRound()\n    assert(self.party:switch(index))')
t=t.replace('    self.captureResult=result\n','    self.effects:beginRound()\n    self.captureResult=result\n')
t=t.replace('        self.runAttempts=self.runAttempts+1\n','        self.runAttempts=self.runAttempts+1\n        self.effects:beginRound()\n')
t=t.replace('    self.selectionKind=nil\n    self:clearHitPresentation()\n    self:runScript(function()\n        self:say("RED used', '    self.effects:beginRound()\n    self.selectionKind=nil\n    self:clearHitPresentation()\n    self:runScript(function()\n        self:say("RED used')
# Attempt failures precede accuracy, but target/type-immunity still own their earlier guards.
anchor='    -- One accuracy roll for the whole move (Gen V) — status moves miss too\n'
t=t.replace(anchor,'''    -- Move-specific failure after type immunity, before accuracy. PP has been
    -- consumed at the actual attempt, and no failure here samples damage RNG.
    if not self.effects:canAttempt(move,attacker,defender) then
        self:say("But it failed!")
        return nil
    end

'''+anchor)
t=t.replace('    if move.power > 0 then\n','''    local fixed=self.effects:fixedDamage(move,attacker,defender)
    if fixed then
        DirectDamage(DEFENDER,fixed):apply(self)
        if not defender:isAlive() then return self:handleFaint() end
        return nil
    end
    if move.power > 0 or move.powerRule then
''')
# calcDamage must not return0 for variable base-power moves whose scalar stays0.
t=t.replace('if move.power == 0 then return { damage = 0,', 'if move.power == 0 and not effectivePower then return { damage = 0,')
t=t.replace('attacker:takeDamage(damage)','self.effects:damage(attacker,damage,"confusion")')
t=t.replace('attacker:takeDamage(math.max(1, math.floor(attacker.maxHP / 4 + 0.5)))','self.effects:damage(attacker,math.max(1, math.floor(attacker.maxHP / 4 + 0.5)),"struggle-recoil")')
t=t.replace('attacker:takeDamage(math.max(1, math.floor(total * -move.drain / 100 + 0.5)))','self.effects:damage(attacker,math.max(1, math.floor(total * -move.drain / 100 + 0.5)),"recoil")')
t=t.replace('pokemon:takeDamage(math.max(1, math.floor(pokemon.maxHP / 8)))','self.effects:damage(pokemon,math.max(1, math.floor(pokemon.maxHP / 8)),"status")')
p.write_text(t)
p=s/'conditions.lua';t=p.read_text();t=t.replace('local function damage(mon,n) local hp=mon.hp;mon:takeDamage(math.max(1,math.floor(n)));return hp-mon.hp end','''local function damage(owner,mon,n,cause)
    local amount=math.max(1,math.floor(n))
    if owner.battle.effects then return owner.battle.effects:damage(mon,amount,cause or "condition") end
    local hp=mon.hp;mon:takeDamage(amount);return hp-mon.hp
end''')
t=t.replace('damage(user,user.maxHP/2)','damage(self,user,user.maxHP/2,"cost")')
# Every other condition loss is damage, not a payment.
t=t.replace('damage(mon,','damage(self,mon,')
p.write_text(t)

# Six exposed GenV moves — frozen batch01

Staged only, based on `1c40818` plus the exact frozen seen/Focus overlay now integrated by root. Five source files are listed in `foundation-manifest.json`: battle.lua, conditions.lua, effects.lua, the root-generated epoch3 moves.lua, and a new36-group SDK contract module. No live Source, art, Simulator or runtime Data writes were performed. Root SDK execution and native acceptance remain pending.

## Behavior and public seams

- Electro Ball retains scalar power0 and uses effective Speed ratios `<1/1/2/3/4+` →40/60/80/120/150. Variable power is evaluated before Mud Sport/weather modifiers and then follows the ordinary accuracy/crit/variance/type/STAB path. The old scalar0 early return is repaired without changing scalar data. Shared effective Speed now has the source-correct minimum1.
- Endeavor checks positive defenderHP−userHP after normal type immunity and before accuracy. Success uses the existing fixed-hit receipt, real HP removed and contact/Static handling, with no crit/variance. Equal/lower targetHP fails after spending PP with no accuracy draw. Normal-vs-Ghost immunity spends attempt PP and draws nothing. A positive-HP user means fullHP Sturdy cannot trigger from Endeavor itself.
- Sucker Punch checks an actual pending target damaging action, not whether the target is likely to execute it successfully. A later sleeping target's damaging selection qualifies; already executed/status/switch/bag/run/ball actions do not. Failure spends attempt PP without accuracy/contact draws. This is singles only; unsupported Me First/recharge producers are not added by this packet.
- Assurance doubles50→100 when its actual target has qualifying HP loss in the current logical round. Ordinary hit/recoil, confusion, hazards/status/condition damage count; healing cannot erase the fact. Existing injury, zero damage, Ghost Curse HP payment and Struggle's direct recoil do not count under the explicit root-approved reference policy below. Each identity owns its own record; withdraw/replacement cannot inherit the outgoing record.
- Sweet Scent lowers one evasion stage in GenV, rather than the later-gen two.
- Rage Powder spends PP and explicitly fails in singles. It does not narrate successful redirection or consume chance/accuracy RNG.

`BattleEffects` owns one transient round record: pending selected actions and qualifying HP-loss identities. `resolveRound` installs it; actual action entry removes the acting battler before status gates. Every accepted switch/run-failure/capture/medicine response starts fresh. `BattleScriptPhase.exit` clears it on normal/terminal/forced exit. Move-learning suspension does not exit that script, so the same context survives the real LearningState overlay and is cleared when the round actually ends. Nothing is persisted and no global event bus is introduced.

Two read-only methods share production calculations:

```lua
battle:effectiveSpeed(mon) -- staged/paralyzed, minimum1
battle:effectiveMovePower(move, attacker, defender) -- explicit identities; no setDirection needed
```

The power observer includes variable power, existing Rollout/Mud Sport and current weather modifiers, with no RNG or condition-table allocation. Fixed Endeavor still has scalar/effective power0; `effects:canAttempt` and `effects:fixedDamage` are separate pure queries. Root diagnostics/driver must recognize category/damageRule/powerRule instead of assuming every damaging move has scalar power>0. No main/diagnostic/host-driver patch is included in this owner packet.

## Generator dependency

Exact root-authored generated move SHA256 is `6063f7501ff53e151e826eb51fb6310af1caed5962124a8483e6f0cae9d32c87`. Six declared rows change; all424 original scalar values remain unchanged. `generator-request.json` names five rule-field additions across three optional constructor fields, plus Sweet Scent's single effect correction. Root owns strict epoch3 migration/inverse/mutants; generated data was copied unchanged, never hand edited. Apply root's generator/migration files alongside the generated Source when integrating.

## Reproduce

Compile only (SDK3.1.2 compile passed at `/private/tmp/pokemon-brock-move-batch01-build-01`):

```sh
python3 /private/tmp/pokemon-brock-move-batch01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-brock-move-batch01-build-NEW
python3 -m unittest discover -s /private/tmp/pokemon-brock-move-batch01/tests -v
```

Six host checks pass: literal power endpoints, independent damage vectors, literal Park–Miller seed2 continuation, real-recoil Assurance vector, exact generated dependency and six-row request integrity. Host math is an independent expected-vector source; it is not a substitute for executing production Lua.

Root-only production SDK run:

```sh
python3 /private/tmp/pokemon-brock-move-batch01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-brock-move-batch01-sdk-NEW --execute
```

The adapter overlays only manifest files onto CURRENT Source, privately imports/registers `BrockMoveBatchContracts` as `brock-move-batch01`, refreshes all source/build fingerprints and compiles the identified bundle. It checks base/file hashes before staging. Existing seen/Focus/controller/learning integration is retained. It defaults to compile-only.

Optional actual native witnesses (all six recipes host-encoded, not runtime accepted):

```sh
python3 /private/tmp/pokemon-brock-move-batch01/validate_staged.py --project "$PWD" --output /private/tmp/pokemon-batch01-electro-native-NEW --scenario /private/tmp/pokemon-brock-move-batch01/scenarios/brock-batch01-electro-ball.json --execute
```

Other recipes in `scenarios/` cover Endeavor HPdiff40, selected-status Sucker failure, ordinary Assurance, Sweet Scent -1 and singles Rage Powder failure. Each uses its genuine current level initializer's fourth move, actual menu input, semantic readiness, captures and independent HP/PP/stage assertions. These are supplementary synthetic-trainer mechanics witnesses, not natural campaign acceptance. Recoil/confusion/hazard Assurance and actual LearningState suspension are covered by production SDK groups.

## Evidence and limits

The36 authored SDK groups exercise real Battle/Party/GameSession/BattleState/LearningState/Capture/Items/scene interfaces, literal RNG boundaries, rejection/noPP, statuses, immunity, contact, all nonfight responses, stale identities, inert rendering, exit and actual two-enemy learning continuation. Runtime counts/results must be recorded by root; no predicted pass is claimed here.

This packet implements only the six named mechanics and the necessary shared Speed floor/round provenance. It does not add doubles redirection, Me First, recharge, Protect, charging, other weather, machines/teaching, new held effects or broader ability coverage. Those remain goal work. Bide for original TM34 is the next bounded dependency; root owns Teaching domain/UI integration separately.

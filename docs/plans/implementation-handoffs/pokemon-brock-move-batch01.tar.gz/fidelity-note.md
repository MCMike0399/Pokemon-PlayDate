# Assurance reference resolution and action eligibility

**Root-approved policy,2026-10-21:** use the pinned maintained Pokémon Showdown Gen5 outcome behavior for contested Assurance damage provenance, while explicitly preserving the disagreement with the C reconstruction. This does not establish exact retail ROM equivalence, and is not a permission to lower acceptance assertions. Our Park–Miller rules stream is already an intentional replay seam, not Game Freak RNG emulation.

Pinned revisions and exact checksums are in `source-pins.json`. C revision is `b279bbefa99bb2f6fbabcc95e4b6d3e939290353`; Showdown is `9b136a8c8cdb860a8ab96fa063f906604e352547`.

| Cause | C reconstruction call chain | Maintained Gen5 PS call chain | Packet policy |
|---|---|---|---|
| Ordinary direct hit | DamageList flow3261 sets turnflag2; HandlerAssurance3589 tests flag2 | battle.damage2155 sets hurtThisTurn; Assurance callback643 tests it | Counts actual positive HP removed |
| Ordinary recoil | CalcRecoil3688→SimpleDamageCore3710 sets flag2 | actions recoil→battle.damage sets hurtThisTurn | Counts |
| Confusion self-hit | ConfusionDamage6180→DisplayConfusionDamage5616→SimpleHP5877→DecreaseHP6047→HPSub1063; these bodies do not set flag2 | inherited gen6 conditions19–39→battle.damage→hurtThisTurn | Counts per approved PS policy; substantive disagreement, not draw-only adaptation |
| Struggle recoil | CalcRecoil3688 forced path→SimpleDamageCore3710 sets flag2 | actions1445→battle.directDamage2224, no hurtThisTurn assignment | Excluded per approved PS policy; substantive disagreement |
| Ghost Curse HP payment | HandlerCurse1537→work8→ChangeHP8156→SimpleHP, no flag2 | moves3293→battle.directDamage, no hurtThisTurn | Excluded; both traced paths agree |
| Hazard/status/trap damage | SimpleDamageCore path supplies flag2 | battle.damage supplies hurtThisTurn | Counts, scoped to currently implemented producers |

The implementation retains a typed `cause` at HP-loss commits, so a future policy correction can change a named provenance rather than guessing from before/after HP or special-casing Assurance's display message. Healing after damage preserves the qualifying history; pre-round injury does not count. Per-identity records reset at the actual round boundary and withdrawal. Explicit literal cases cover both excluded costs, counted confusion, ordinary recoil and actual entry hazards.

Sucker Punch's unambiguous maintained implementation checks `queue.willMove(target)` and nonstatus category; a target that already acted has no pending move. C `HandlerSuckerPunch2501–2540` also consults the pending action/turn flag, but its reconstructed fallback reads `action` in a branch where the displayed code may not initialize it. We do not imitate undefined C reconstruction artifacts or claim independent equivalence for that fallback. The packet uses real typed pending action identities, consumed before status gates, and tests actual priority/speed order and sleeping target selection. No prediction of a later status roll is made.

Primary move bodies provide Electro Ball's five exact buckets; Endeavor's positive HP difference and move-specific immunity guard; Gen5 Sweet Scent Eva-1; Gen5 Rage Powder priority3 and inherited singles failure. Existing PP attempt gates precede these failures; type immunity remains before accuracy; fixed Endeavor does not enter critical/variance sampling. Old scalar bytes are not rewritten to fake variable damage.

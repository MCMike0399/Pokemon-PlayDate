"""Independent literal expectations for actual primary probes; no SDK execution."""
import copy,hashlib,json,unittest
from pathlib import Path
S=Path(__file__).resolve().parent
class MirrorReferenceContracts(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.obs=json.loads((S/'observations-final-pinned.json').read_text());cls.rows={r['name']:r for r in cls.obs['rows']};cls.elig=json.loads((S/'eligibility.json').read_text())
 def choices(self,key):return[e for e in self.rows[key]['events']if'choices'in e]
 def log(self,key):return'\n'.join(self.rows[key]['log'])
 def test_all_actual_engine_cases_completed_without_fixture_errors(self):
  self.assertEqual(len(self.rows),27)
  for row in self.rows.values():self.assertNotIn('error',row,row['name'])
 def test_exact_425_primary_flags_and_literal_forbidden_vectors(self):
  self.assertEqual(self.elig['count'],425);self.assertEqual(self.elig['eligible'],322);self.assertEqual(len({r['key']for r in self.elig['rows']}),425)
  flags={r['key']:r['mirrorEligible']for r in self.elig['rows']}
  for key in('mirrorMove','bide','protect','focusEnergy','splash','struggle','metronome','mimic','transform'):self.assertIs(flags[key],False)
  for key in('tackle','growl','tailWhip','toxic','zapCannon','solarBeam','skullBash','petalDance'):self.assertIs(flags[key],True)
 def test_faster_previous_history_vs_slower_current_attempt(self):
  self.assertIn('|-fail|',self.log('faster-missing-history'));self.assertNotIn('[from] move: Mirror Move',self.log('faster-missing-history'))
  self.assertIn('|Tail Whip|p2a: Squirtle|[from] move: Mirror Move',self.log('slower-copies-current-attempt-not-queued'))
  self.assertIn('|Tackle|p2a: Squirtle|[from] move: Mirror Move',self.log('faster-copies-prior-physical'))
  self.assertIn('|Growl|p2a: Squirtle|[from] move: Mirror Move',self.log('ordinary-status-call'))
 def test_ineligible_and_miss_and_immunity_history_boundaries(self):
  self.assertEqual(self.choices('ineligible-attempt-invalidates-old-eligible')[-1]['before']['p2']['lastMove'],'focusenergy')
  self.assertNotIn('[from] move: Mirror Move',self.log('ineligible-attempt-invalidates-old-eligible'))
  self.assertIn('[miss]',self.log('miss-still-records-attempt'));self.assertEqual(self.choices('miss-still-records-attempt')[0]['after']['p2']['lastMove'],'zapcannon')
  self.assertIn('|Zap Cannon|p2a: Pikachu|[from] move: Mirror Move',self.log('miss-still-records-attempt'))
  self.assertEqual(self.choices('type-immune-attempt-still-history')[0]['after']['p2']['lastMove'],'toxic');self.assertIn('|Toxic|p2a: Nidoran-M|[from] move: Mirror Move',self.log('type-immune-attempt-still-history'))
 def test_sleep_flinch_para_block_before_history_and_PP(self):
  for key in('sleep-blocked-caller-preserves-history-no-MirrorPP','flinch-blocked-caller-preserves-history-no-MirrorPP','paralysis-blocked-caller-attempt-history'):
   e=self.choices(key)[-1];self.assertEqual(e['before']['p1']['lastMove'],'tackle');self.assertEqual(e['after']['p1']['lastMove'],'tackle');self.assertEqual(e['before']['p1']['pp'][1]['pp'],e['after']['p1']['pp'][1]['pp'])
  e=self.choices('sleep-blocked-opponent-retains-Tackle-not-queued-Growl')[-1];self.assertEqual(e['after']['p2']['lastMove'],'tackle');self.assertIn('|Tackle|p2a: Squirtle|[from] move: Mirror Move',self.log('sleep-blocked-opponent-retains-Tackle-not-queued-Growl'))
 def test_only_Mirror_PP_consumed_and_noPP_choice_preserves_history_RNG(self):
  e=self.choices('Mirror-onePP-called-owned-Tackle-zeroPP')[-1];self.assertEqual(e['after']['p1']['pp'][0]['pp'],e['before']['p1']['pp'][0]['pp']-1);self.assertEqual(e['after']['p1']['pp'][1],e['before']['p1']['pp'][1]);self.assertEqual([x['id']for x in e['after']['p1']['pp']],['mirrormove','tackle','splash'])
  zero=self.choices('called-owned-zeroPP-still-executes-without-PP-use')[-1];self.assertEqual(zero['before']['p1']['pp'][1]['pp'],0);self.assertEqual(zero['after']['p1']['pp'][1]['pp'],0);self.assertLess(zero['after']['p2']['hp'],zero['before']['p2']['hp'])
  detail=self.rows['noPP-choice-rejected-history-and-RNG-unchanged']['events'][-1]['detail'];self.assertIs(detail['accepted'],False);self.assertEqual(detail['before'],detail['after'])
 def test_protect_outer_ineligible_and_called_move_protection_are_distinct(self):
  self.assertNotIn('[from] move: Mirror Move',self.log('opponent-Protect-invalidates-old-eligible'));self.assertIn('|-fail|',self.log('opponent-Protect-invalidates-old-eligible'))
  self.assertIn('|Tackle|p2a: Squirtle|[from] move: Mirror Move',self.log('called-Tackle-blocked-by-existing-Protect'));self.assertIn('|-activate|p2a: Squirtle|move: Protect',self.log('called-Tackle-blocked-by-existing-Protect'))
 def test_unlearned_charge_and_rampage_locks_without_fake_slots(self):
  key='unlearned-SolarBeam-lock-and-forgotten-Mirror';events=self.choices(key);self.assertEqual(events[1]['after']['p1']['locked'],'solarbeam');self.assertEqual(events[-1]['after']['p1']['lastMove'],'solarbeam');self.assertEqual([x['id']for x in events[-1]['after']['p1']['pp']],['splash']);self.assertEqual(events[-1]['after']['p1']['pp'][0]['pp'],events[-1]['before']['p1']['pp'][0]['pp'])
  key='unlearned-SkullBash-release-current-opposing-slot';e=self.choices(key)[-1];self.assertEqual(e['after']['p2']['species'],'snorlax');self.assertEqual(e['after']['p2']['hp'],348);self.assertEqual(e['after']['p1']['boosts']['def'],1)
  key='unlearned-PetalDance-lock-and-forgotten-Mirror';e=self.choices(key);self.assertEqual(e[1]['after']['p1']['locked'],'petaldance');self.assertNotIn('petaldance',[x['id']for x in e[2]['after']['p1']['pp']]);self.assertEqual(e[2]['after']['p1']['lastMove'],'petaldance');self.assertIn('|-start|p1a: Pidgey|confusion|[fatigue]',self.log(key))
  e=self.choices('Bide-ineligible-no-called-lock')[-1];self.assertIsNone(e['after']['p1']['locked']);self.assertEqual(e['after']['p1']['pp'][0]['pp'],e['before']['p1']['pp'][0]['pp']-1);self.assertNotIn('[from] move: Mirror Move',self.log('Bide-ineligible-no-called-lock'))
 def test_switch_faint_replacement_clear_only_appropriate_identity(self):
  self.assertNotIn('[from] move: Mirror Move',self.log('opponent-switch-clears-incoming-history'))
  e=self.choices('other-side-switch-does-not-clear-active-history-Gen5')[-1];self.assertEqual(e['after']['p1']['lastMove'],'tackle');self.assertIsNone(e['after']['p2']['lastMove'])
  self.assertIn('|faint|',self.log('faint-replacement-new-history-empty'));self.assertNotIn('[from] move: Mirror Move',self.log('faint-replacement-new-history-empty'))
 def test_called_move_does_not_requeue_or_replace_actual_pending_action(self):
  key='queued-Mirror-stays-status-called-SuckerPunch-sees-current-queue';self.assertEqual(self.log(key).count('|-fail|'),2);self.assertIn('|Sucker Punch||[from] move: Mirror Move',self.log(key));e=self.choices(key)[0];self.assertEqual(e['after']['p1']['hp'],e['before']['p1']['hp']);self.assertEqual(e['after']['p2']['hp'],e['before']['p2']['hp'])
  key='called-QuickAttack-does-not-reorder-outer-action';text=self.log(key);self.assertLess(text.index('|move|p2a: Squirtle|Quick Attack'),text.index('|move|p1a: Pidgey|Mirror Move'));self.assertEqual(text.count('[from] move: Mirror Move'),1)
 def test_actualPS_outer_history_disagreement_is_explicit(self):
  e=self.choices('Mirror-of-Mirror-disagreement-probe');self.assertEqual(e[1]['after']['p1']['lastMove'],'mirrormove');self.assertEqual(e[1]['after']['p1']['lastMoveUsed'],'tackle');self.assertEqual(e[2]['after']['p1']['lastMove'],'mirrormove');self.assertEqual(self.log('Mirror-of-Mirror-disagreement-probe').count('[from] move: Mirror Move'),1)
 def test_erratum_exact_34_rows_no_wordmatching_promotion(self):
  r=json.loads((S/'audit-erratum/final.json').read_text());self.assertEqual(r['counts'],{'reviewed':34,'scoped_implemented':25,'downgraded':9})
  missing={x['move']for x in r['rows']if x['meaningful_case']is None};self.assertEqual(missing,{'dig','earthquake','furyCutter','gyroBall','heavySlam','magnitude','smackDown','selfDestruct','explosion'})
  for row in r['rows']:
   self.assertTrue(row['current_row_same_as_950'])
   if row['meaningful_case']:self.assertTrue(row['meaningful_case']['sdk_pass']);self.assertTrue('eq('in row['meaningful_case']['body']or'assert('in row['meaningful_case']['body'])
   else:self.assertFalse(row['natural_player_key'])
if __name__=='__main__':unittest.main()

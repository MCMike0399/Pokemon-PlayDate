# Final separate correction of the34 promoted audit rows

The frozen exposure report is untouched. Its blanket `integrated-with-scoped-SDK-evidence` classification was too broad. `final.json` rechecks **all34 exact Move definitions** against CURRENT root03 Source and the accepted950 rows, selects explicit meaningful test bodies, and validates exact executed test names. There is no substring evidence promotion (`Diglett` cannot qualify `dig`). Each selected assertion body is byte-identical to the accepted950 tree; its exact source/line/body hash and accepted result name are included. This supports only the stated assertion scope, never full per-move/native certification.

**25 scoped implementations remain supported**: assurance, captivate, electroBall, endeavor, feint, focusEnergy, hurricane, lightScreen, nightSlash, petalDance, protect, ragePowder, rainDance, razorLeaf, safeguard, shadowClaw, skullBash, slash, solarBeam, stoneEdge, suckerPunch, sweetScent, tailwind, thunder, worrySeed. The five high-critical family rows are explicitly backed by the exact16-row metadata assertion plus shared literal critical-damage endpoint assertion; they are not five individually exercised attacks. LightScreen/Safeguard/Tailwind include actual move producer+PP/duration assertions in addition to their specific rule tests.

**Nine classifications are withdrawn/downgraded**:

| Key | Literal current production support | Corrected requirement |
|---|---|---|
| dig |80 ordinary damage, no chargeRule/effects | Charge/underground/interruption pending. |
| furyCutter |20 ordinary damage, no chain field/effects | Consecutive power/reset pending. |
| gyroBall |power0, no powerRule/effects | Speed-ratio actual damage absent. |
| heavySlam |power0, no powerRule/effects | Weight-ratio actual damage absent. |
| magnitude |power0, no powerRule/effects | Distribution/power actual damage absent. |
| selfDestruct |200 ordinary damage, no self-faint producer | User self-faint/order absent. |
| explosion |250 ordinary damage, no self-faint producer | User self-faint/order absent. |
| smackDown |50 ordinary damage, no grounding state | Grounding/airborne cancellation absent. |
| earthquake |100 ordinary damage | Underground doubled damage absent; accepted950 contact-receipt case is not a whole ordinary attack. New root996 Roost attack/type cases provide separate scoped ordinary-damage evidence, not underground behavior. |

All nine have `player_natural_key=false` and are absent from actual fixed trainer initial move selections in the frozen first-gate closure. They remain required technical/full-scope rows, not deleted or accepted; no new natural acquisition boundary changes. HelpingHand remains source-correct singles failure with no direct named SDK/native witness, outside these34. No claim about every other source-path row is promoted by this correction.

Run check.py with explicit `--project --current --old-report --sdk --output`; it refuses overwrite, requires the exact34 old classifications, exact declared current metadata and literal meaningful cases. No SDK/Source edits or runtime was performed. `qualify.py` independently checks the final ledger and wrong-promotion/missing-test/metadata mutants. Freeze hashes are in the parent packet manifest.

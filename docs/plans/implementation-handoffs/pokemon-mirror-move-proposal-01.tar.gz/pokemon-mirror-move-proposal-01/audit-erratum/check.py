"""Explicit34-row promotion correction; no substring-based evidence attribution."""
import argparse,hashlib,json,re,sys
from pathlib import Path
S=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(project,current,old,sdk):
 sys.path.insert(0,str(project));from tools.verify_moves.parse_lua import read_moves
 from tools.harness.run import fingerprint
 oldrows=json.loads(old.read_text())['moves'];keys={r['move']for r in oldrows if r['status']=='integrated-with-scoped-SDK-evidence'};assert len(keys)==34
 moves=read_moves(current/'Source/battle/moves.lua');before=read_moves(project/'Source/battle/moves.lua')
 result=json.loads(sdk.read_text());tests=next(r['contracts']['tests']for r in result['results']if r.get('contracts'))
 mapping={
 'assurance':('brockMoveBatchContracts','Assurance literal damage after faster TakeDown recoil doubles50to100','powerRule','assurance'),
 'captivate':('sexAbilityContracts','Captivate opposite-sex female user also succeeds with one accuracy sample','attemptRule','oppositeSex'),
 'electroBall':('brockMoveBatchContracts','Actual Electro Ball traverses scalar0 gate and literal seed2 damage63','powerRule','electroBall'),
 'endeavor':('brockMoveBatchContracts','Endeavor positive HP difference is fixed50 independent of stages/type resistance/crit','damageRule','endeavor'),
 'feint':('protectContracts','Feint breaks real protection after accuracy, no contact reaction, preserving stall','breaksProtect',True),
 'hurricane':('rainContracts','Actual rain attacks hit with their real secondary/PP order; no accuracy draw','weatherAccuracy',True),
 'lightScreen':('sideContracts','LightScreen exact final modifier halves15 to7; physical fixed crit self bypass',None,None),
 'petalDance':('chargeLockContracts','Petal Dance literal duration2 ends with fatigue3 after121+126 damage','lockRule','rampage'),
 'protect':('protectContracts','First Protect priority4 blocks actual faster attack before accuracy/critical/contact draws',None,None),
 'ragePowder':('brockMoveBatchContracts','Rage Powder explicitly fails singles after PP without accuracy or random draws','attemptRule','singlesRedirect'),
 'rainDance':('rainContracts','Real RainDance PP4 no accuracy/duration draw and first residual leaves4',None,None),
 'safeguard':('sideContracts','Safeguard blocks opponent primary majors/confusion before duration but not flinch',None,None),
 'skullBash':('chargeLockContracts','Skull Bash initial Defense+1 protects same turn and is not repeated on release','chargeRule','skullBash'),
 'solarBeam':('chargeLockContracts','Solar Beam charge then ordinary release123 spends once and only release samples damage','chargeRule','solarBeam'),
 'suckerPunch':('brockMoveBatchContracts','Sucker Punch public round hits pending damaging selection even slower','attemptRule','suckerPunch'),
 'sweetScent':('brockMoveBatchContracts','Sweet Scent actually lowers one GenV evasion stage, respects cap and PP',None,None),
 'tailwind':('sideContracts','Actual shared effectiveSpeed doubles BEFORE GenVparalysisfloor with minimum1',None,None),
 'thunder':('rainContracts','Actual rain attacks hit with their real secondary/PP order; no accuracy draw','weatherAccuracy',True),
 'worrySeed':('worrySeedContracts','Actual WorrySeed attempt spends1PP/1accuracy and overrides Static without specimen mutation','attemptRule','worrySeed'),
 'focusEnergy':('brockMechanicsContracts','Rattata level7 natural initializer exposes real FocusEnergy producer',None,None),
 }
 for key in('razorLeaf','slash','nightSlash','shadowClaw','stoneEdge'):mapping[key]=('brockMechanicsContracts','All16 generated high-critical moves add one; forcedcrit is never a stage6 clamp','critStage',1)
 missing={
 'dig':'No charge/semi-invulnerability rule. Current80ordinary damage is not Gen5Dig; technical/non-natural here.',
 'furyCutter':'No consecutive-use power/interruption producer. Current20ordinary damage only; technical/non-natural here.',
 'gyroBall':'Currentpower0 without powerRule/effects; no speed-ratio damage execution. Technical/non-natural here.',
 'heavySlam':'Currentpower0 without powerRule/effects; no weight-ratio damage execution. Technical/non-natural here.',
 'magnitude':'Currentpower0 without powerRule/effects; no distribution/power producer. Technical/non-natural here.',
 'smackDown':'Current50ordinarydamage without grounding/airborne cancellation owner. Technical/non-natural here.',
 'selfDestruct':'Current200damage without user-faint producer/ordering. Technical/non-natural here.',
 'explosion':'Current250damage without user-faint producer/ordering. Technical/non-natural here.',
 'earthquake':'Ordinary100damage path exists; Dig/underground doubledamage missing. No meaningful exactEarthquake ordinarydamage case in accepted950 selected here; current996 Roost suite contains ordinarydamage/type interactions but does not prove underground semantics.'}
 assert set(mapping)|set(missing)==keys
 def primitive(v):
  if hasattr(v,'text'):return v.text
  if isinstance(v,dict):return{k:primitive(x)for k,x in v.items()}
  if isinstance(v,list):return[primitive(x)for x in v]
  return v
 def case(file,name):
  p=current/'Source/dev'/f'{file}.lua';text=p.read_text();matches=list(re.finditer(r'\btest\("([^"]+)"',text));m=next(m for m in matches if m[1]==name);index=matches.index(m);end=matches[index+1].start()if index+1<len(matches)else text.index('    return report',m.end())if'    return report'in text[m.end():]else len(text)
  body=text[m.start():end];assert 'eq('in body or'assert('in body,'assertion-free case'
  passed=[t for t in tests if t['name']==name or t['name'].endswith(': '+name)];assert len(passed)==1 and passed[0]['ok'] is True,'not accepted exact named case'
  oldtext=(project/'Source/dev'/f'{file}.lua').read_text();oldm=re.search(r'\btest\("'+re.escape(name)+r'"',oldtext);assert oldm,'current fixture unavailable in accepted950 tree'
  oldmatches=list(re.finditer(r'\btest\(\"([^\"]+)\"',oldtext));oldmatch=next(v for v in oldmatches if v[1]==name);oldindex=oldmatches.index(oldmatch)
  oldend=oldmatches[oldindex+1].start()if oldindex+1<len(oldmatches)else oldtext.index('    return report',oldmatch.end())if'    return report'in oldtext[oldmatch.end():]else len(oldtext)
  oldbody=oldtext[oldmatch.start():oldend];assert oldbody==body,'selected assertion body changed from accepted950: '+name
  # Every scope is explicitly selected by reviewer mapping, not a wordmatch.
  return {'file':str(p),'file_sha256':sha(p),'line':text[:m.start()].count('\n')+1,'name':name,'sdk_exact_name':passed[0]['name'],'sdk_pass':True,'body':body,'body_sha256':hashlib.sha256(body.encode()).hexdigest()}
 rows=[]
 for key in sorted(keys):
  assert primitive(moves[key])==primitive(before[key]),'promoted row changed from accepted950 metadata '+key
  row={'move':key,'old_status':'integrated-with-scoped-SDK-evidence','current_exact_Move':primitive(moves[key]),'current_row_same_as_950':True,'natural_player_key':next(m['player_natural_key']for m in oldrows if m['move']==key)}
  if key in missing:
   row.update(corrected_status='unsupported-specific-rule'if key!='earthquake'else'ordinary-source-path-with-conditional-gap',reason=missing[key],meaningful_case=None)
   if key in('gyroBall','heavySlam','magnitude'):assert moves[key]['power']==0 and not moves[key].get('powerRule')and not moves[key].get('effects')
   if key in('dig','furyCutter','smackDown','selfDestruct','explosion'):assert not moves[key].get('effects')and not moves[key].get('chargeRule')and not moves[key].get('powerRule')
  else:
   file,name,field,value=mapping[key]
   if field:assert moves[key].get(field)==value,(key,field)
   selected=case(file,name)
   if key in('razorLeaf','slash','nightSlash','shadowClaw','stoneEdge'):
    assert key+'=true'in selected['body']and 'm.critStage'in selected['body'],'literal family member/field assertion absent'
   additional=[]
   if key in('lightScreen','safeguard','tailwind'):additional.append(case('sideContracts','Actual side producers tick5 5 4 once perround and refuse timer refresh'))
   if key in('razorLeaf','slash','nightSlash','shadowClaw','stoneEdge'):additional.append(case('brockMechanicsContracts','Each critical stage passes and fails literal roll endpoints through actual damage'))
   row.update(corrected_status='implemented-scoped-assertions-accepted-not-exhaustive',additional_meaningful_cases=additional,meaningful_case=selected,reason='Reviewer-selected exact executed test exercises the declared behavior. This is not fullmove/native certification; see literal body and known pending conditional branches. High-critical family proof is metadata/sharedcritical arithmetic, not a dedicated attack by everyfamily member.')
  rows.append(row)
 return {'schema':1,'purpose':'separate erratum only; original frozen reports untouched; blanket promotion withdrawn','old_report_sha256':sha(old),'current_source_sha256':fingerprint(current),'accepted950sdk_sha256':sha(sdk),'rows':rows,'counts':{'reviewed':len(rows),'scoped_implemented':len(mapping),'downgraded':len(missing)},'no_wordmatching_promotion':True,'no_new_runtime_executed':True}
if __name__=='__main__':
 p=argparse.ArgumentParser();
 for key in('project','current','old-report','sdk','output'):p.add_argument('--'+key,type=Path,required=True)
 a=p.parse_args();r=run(a.project,a.current,a.old_report,a.sdk);assert not a.output.exists();a.output.write_text(json.dumps(r,indent=2)+'\n');print(r['counts'])

# Mirror Move — proposal/reference only

No implementation, Source edits, Simulator, save access or subagents. This proposal reads CURRENT root03 A+Roost+context, Source `a2db85c48668993e27036c46f714e931d52506641359e84ad812c4291245b714`, and actual compiled pinned Showdown Gen5. Root's996 SDK statement is composition evidence, not a Mirror implementation pass. Route22 and all prior frozen packets stay untouched. The separate34-row audit erratum is in `audit-erratum/README.md` and `final.json`.

## Natural acquisition

Pidgey45 / Spearow21 learn Mirror Move naturally with no level cutoff. Pidgeotto52/Pidgeot56/Fearow23 have later direct events; retaining Spearow's21 move on a delayed evolution21 can expose it earlier than Fearow23. This does not require a relearner or a fabricated evolution moveset. Current fixed first-gate opponents have only their exact low-level initial slots, so this does not grant opponents unlimited grind-tail moves.

## Small interface and ownership

Reuse **Battle + its BattleEffects + BattleConditions**. No HistoryManager, parallel party controller, durable Pokemon fields, known-move replacement or save schema change.

Proposed private BattleEffects interface:

- `recordMoveAttempt(mon, key)` after the actual major/volatile status gates and successful normal PP commit (or an existing valid locked continuation). It replaces that active identity's previous attempt even if the new key is ineligible, subsequently misses, encounters type immunity, fails a move-specific gate or is protected. It returns an opaque receipt tied to this Battle/identity/sequence if delegated-result recording is selected below.
- `mirrorMoveKey(source, target)` is a pure read: require this live open Battle's current active source/target identities, a present canonical key and exact generated mirrorEligible=true. Return the canonical key or a bounded failure reason. No RNG/state allocation, queued-action consumption, bench fallback, last-success/last-eligible fallback, or global singleton lookup.
- A private `recordCalledMove(receipt, key)` is needed **only for the C-style delegated-result policy below**. It updates executed identity while retaining attempted identity for diagnostics. It is not an external arbitrary history setter. All accepted keys must be exact registered moveData objects, never new cloned Move objects with lost canonical identities.

`Battle:performMove` handles the declared `callRule='mirrorMove'` after the outer used-Mirror narration, live-target/type/protection/attempt gates, and its accuracy0 bypass. It resolves exactly one key through the pure interface and enters a lexically private called-move executor. The executor reuses the CURRENT actor/opposing slot, canonical move definition and normal type/Protect/accuracy/damage/effect/entry/faint owners. It does not call `selectMove`, enqueue another action, sample enemy AI, apply pre-move status twice, or spend called-move PP. A bounded call-depth/opaque-origin guard rejects recursion, stale/foreign identities, closed Battles and impossible current-script ownership before any child mutation/RNG.

The original queued action remains Mirror Move (status/priority0) for order and Sucker Punch. The called move's own priority never reorders the already executing half-turn. Nested Sucker Punch sees the actual remaining queue, not a fabricated target action. `beginAction` runs once. Child completion, hit receipts, afterHit, residual/faint/learning boundaries run once; the outer Mirror branch returns the child outcome and does not apply a second `moveFinished`/residual/turn. Active currentMove/currentMoveKey must point to the called canonical key while its existing producers execute; a presentation-origin field may retain Mirror without changing durable slots.

History lives with the existing one-Battle effects owner. `clear(mon)` removes only the outgoing/fainted identity's history; `entry` starts an incoming identity empty; `close` clears all. Gen5 does NOT clear the still-active other side's history when one side switches. Clear history at the existing supported faint/withdraw/exit cleanup sites, without changing contact receipt/ability KO order. Reads of foreign/benched/fainted/closed identities fail without mutation. No history is serialized.

## Required policy decision: delegated history disagreement

Two primary lines disagree. This is deliberately unresolved until root review; no implementation should silently choose one or claim cartridge equivalence.

**Actual pinned PS Gen5:** `runMove` calls `pokemon.moveUsed(outer)` after BeforeMove/PP; nested `actions.useMove(called)` changes `lastMoveUsed`, not `lastMove`. After Mirror copies Tackle, lastMove=MirrorMove (ineligible), lastMoveUsed=Tackle. A second Mirror against that history fails, even if the original caller is asleep and cannot overwrite it. `Mirror-of-Mirror-disagreement-probe` records exactly this with real choices.

**Pinned reconstructed C implication:** `ServerControl_Fight` sets actualMove=work.called.move (line1615), then `BattleMon_SetPrevMove(...actualMove,move)` (1676). The setter stores prevMoveId=actualMove/prevMoveUsed=outer (btl_pokeparam1454), and HandlerMirrorMove reads prevMoveId (move_handlers7329). This implies the delegated Tackle remains Mirror-copyable. The C source was inspected/hashed, not executed on cartridge or a native reconstructed engine; its match/completeness is not asserted.

Recommendation for root review: use the B2W2 C-style explicit attempted/executed pair if the reconstruction is accepted as sufficient evidence, and document the isolated maintained-PS disagreement with separate expected vectors. If root prefers existing PS policy pending stronger C proof, only attempted key is queried. Store policy as one fixed project choice, not a runtime/general configuration framework. All common attempt/PP/miss/eligibility/slot/cleanup conclusions below are independent of this disputed nested-history choice. The27 actualPS traces retain PS expectations; an eventual C-policy SDK must intentionally differ only at declared vectors.

## Literal trace findings

`observations-final-pinned.json`:27 actual pinned PS cases, fixed seed[1,2,3,4], original151 species with clearly controlled custom moves/status/volatile/forgetting fixtures. No mocked battle/PRNG; wrapper only delegates and records real PRNG calls. PS uses its normal PPup convention, so compare deltas, not root's base maximum.

| Case | Literal observation / required behavior |
|---|---|
| Faster Mirror, no prior history | Fails; does not copy the opponent's selected future Tackle. |
| Slower Mirror | Copies Tail Whip actually attempted earlier this same turn. |
| Faster Mirror with prior Tackle/Growl | Copies previous actual physical/status move, not the opponent's later queued Tail Whip/Tackle. |
| New Focus Energy/Protect attempt | Replaces old eligible history with an ineligible key; Mirror fails rather than fallback. |
| Missed Zap Cannon / immune Toxic | Both become history. Mirror calls them and independently resolves its own miss/immunity. |
| Caller sleep/flinch/full paralysis | BeforeMove blocks; prior Tackle history and Mirror PP are unchanged. |
| Opponent asleep after prior Tackle | Retains Tackle despite currently queued Growl; Mirror copies Tackle. |
| No-PP illegal choice | Actual choice rejected; history and PRNG state unchanged. |
| Known Tackle copy | Mirror loses1; the caller's owned Tackle PP does not change. An owned Tackle already at0 still executes when called and stays0. |
| Existing target Protect, old Tackle history | Outer Mirror is not itself Protect-blocked; the called Tackle is blocked by the normal guard. This differs from the opponent actually attempting Protect and replacing history. |
| Sucker Punch versus queued Mirror | Opponent fails because original queued Mirror is status. Mirror then calls the recorded Sucker Punch, which fails because target already acted. No fabricated pending damaging action. |
| Copied Quick Attack | Executes at Mirror's already established position; does not reorder/produce an extra action. |
| Unlearned Solar Beam / Skull Bash | Creates normal canonical charge state; continuation spends no extra caller/called PP, survives forgetting Mirror without inserting a fake learned slot, and Skull release targets the CURRENT opposing slot after a switch (Snorlax348HP in recorded vector). |
| Unlearned Petal Dance | Existing rampage lock continues after Mirror is forgotten; stored key executes, no durable Petal slot exists, and real fatigue occurs. A controlled target SpA-6 fixture keeps the mechanism alive; no RNG is mocked. |
| Bide | **Ineligible.** Mirror spends its ordinary1PP and fails; caller receives no Bide lock. Do not implement a fictional copied-Bide continuation. |
| Opponent switch/back or faint replacement | Incoming history empty; old Pokemon identity cannot leak its Tackle to the replacement. Other active side history survives a switch in Gen5. |

Ordinary cost here is1 Mirror PP and0 child PP. No naturally acquired pre-Brock Pressure46 exists; full-game Pressure can charge extra caller PP and must be an explicit future ability interaction, not an assertion that every possible Gen5 caller always costs1. Existing source construction/derived IV/EV/nature/sex/ability ownership stays unchanged.

## Producer13 request

`producer-request.json` + `eligibility.json`: exact425 canonical keys/native IDs, derived by actual merged `Dex.mod('gen5').moves.get(key).flags.mirror`, **322 true /103 false**. No category/target/name heuristic. New explicit `mirrorEligible` boolean on ALL425 rows; bounded `callRule='mirrorMove'` only on Mirror Move; two constructor fields. No scalar/effect changes, row deletion, baseline normalization or durable move replacement.

False literal vectors include MirrorMove/Bide/Protect/FocusEnergy/Splash/Struggle/Metronome/Mimic/Transform. SolarBeam/SkullBash/PetalDance/Tackle/Growl/TailWhip/Toxic/ZapCannon are true. Current epoch13 missing/wrong-type/wrong-present true/false must reject; only legitimate complete older epochs may migrate absent fields under explicit per-field introduction. Preserve original424 inverse hashes and every unrelated producer migration. Root owns generation/strict producer tests. Metadata eligibility is NOT evidence that all425 moves already have complete execution semantics.

## Current source audit / precise integration places

- `battle.lua:resolveTurn` already owns status gates, normal PP, then `performMove`. Insert attempt recording there; do not record at menu selection or generic `beginAction` before status gates.
- `performMove` currently just narrates Mirror's empty status row: no history/query/child execution. It already resolves canonical currentMoveKey and all shared gates; reuse that path for the child exactly once.
- `BattleEffects` owns live/closed/identity checks and `clear/close`; reuse them rather than another global registry. Existing pendingMove is a logical-round selected-action ledger, **not** historical move ownership. Never repurpose it for Mirror history.
- `BattleConditions` already stores canonical Solar/Skull/rampage identities. `Battle:update`/enemyTurn already continue stored keys when no learned slot exists; do not add a fake borrowed slot or copy known/PP tables. Current Bide is ineligible; no Bide changes needed for Mirror.
- Learning already offers/settles choices inside real battle scripts. A meaningful implementation regression should use natural Pidgey48 near49: copy a charge, allow an actual poisoned foe KO/XP and replacement to offer its real AirSlash49 choice, replace Mirror, then continue the stored charge through the existing owner. No competing learning controller.
- Dig remains an unsupported ordinary-damage technical row, not implemented charge. See34-row erratum. Do not claim a copied Dig works because called dispatch exists. All322 eligibility flags preserve future requirements; a valid copied unsupported move remains the underlying move's explicit mechanics gap, not silently completed by this feature.

## Proposed SDK / native / mutant acceptance (unrun)

Owned implementation files after approval: narrow battle/effects/conditions hunks only as necessary; new `dev/mirrorMoveContracts.lua`; root-owned producer13 plus separate constructor/row request; root-owned main registration/diagnostic hook. No UI controller, save/domain/species/art/provider edits. Preserve ongoing PoisonFang-only stage and Roost/IndividualStats/context composition; root serial-merges.

Actual SDK cases must exercise real `selectMove/resolveRound` and exact canonical Move definitions with actual Pokemon/Party, not a mock battle. Cover all common table rows, pure read/no RNG/no allocation, missing/ineligible/closed/stale/foreign history, PP deltas and already0 child PP, both speed orders/current queue, exact425 flag inventory322/103, single contact/secondary/residual/KO, borrowed charge and fatigue, actual learning replacing Mirror and real opponent replacement, cancellation while narrating, switch/faint/exit and codec absence. Record phase/identity/PP/status/RNG before/after; use root engine's own literal seed vectors, not PS PRNG values. The nested-history disputed vector must name the selected policy and preserve the opposing primary expectation.

Meaningful deliberate faults: cache last-eligible/successful instead of latest attempt; record before sleep/PP gates; spend child PP; insert fake learned slot; change queued Mirror category to child; reroll enemy AI/requeue copied priority; allow Bide/Mirror recursion; stale history across replacement; restore forgotten caller to satisfy a lock; duplicate fatigue/residual; mutate current boolean metadata/remove false field. Every compiled mutant must fail its intended actual SDK assertion; no engine/SDK mutation is performed by this proposal.

Root native recipes after implementation: controlled real-input Pidgey45 Mirror fixture versus legal synthetic source-labeled foe, caption≤30; show prior eligible hit then Mirror physical/status copy, ineligible failure, missing history, blocked caller, existing Protect, charge→release without new durable slots, actual learning/forget/replacement, plus ordinary natural Pidgey/Spearow acquisition witness when grinding is exercised. Native screenshots/recordings must show readable Mirror and called-move messages separately, actual HP/PP and lock continuation. Add Save/Continue proof that only normal selected moves/PP persist, no battle history/borrowed slots. Root alone compiles/launches/owns private Data and inspects pixels. No native success is claimed here.

## Reproduction and pins

`probe.js <pinned-showdown-tree>` emits actual27-case observations; output replay is byte-exact. `eligibility.js <tree> move-keys.json` emits exact425 rows; replay is byte-exact. `qualify.py` runs literal host assertions, not production rules. `references.json` pins original source+compiled PS files and C handlers/server flow/pokeparam (checked against existing immutable primary pins); native-C is explicitly reconstructed source, not executed engine proof.

Source references: [PS Mirror callback](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/data/moves.ts#L12029), [PS attempt/PP boundary](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/sim/battle-actions.ts#L267), [PS moveUsed](https://github.com/smogon/pokemon-showdown/blob/9b136a8c8cdb860a8ab96fa063f906604e352547/sim/pokemon.ts#L925), [C Mirror](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/move_handlers.c#L7329), [C delegated actualMove](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/btl_server_flow.c#L1595), [C prevMove setter/clear](https://github.com/fuddlesworth/pokebw2/blob/b279bbefa99bb2f6fbabcc95e4b6d3e939290353/src/ov167/btl_pokeparam.c#L1454).

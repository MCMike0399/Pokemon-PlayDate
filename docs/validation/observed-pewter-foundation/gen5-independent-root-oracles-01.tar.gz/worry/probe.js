'use strict';
const path=require('path'),fs=require('fs'),crypto=require('crypto');const root=path.resolve(process.argv[2]);const {Battle,Dex}=require(path.join(root,'dist/sim'));
const set=(species,ability,level,moves)=>({species,ability,gender:'M',nature:'Hardy',level,ivs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},moves});
function fresh(ability){const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,4],p1:{name:'SOURCE',team:[set('Bulbasaur','Overgrow',100,['worryseed','sleeppowder','splash'])]},p2:{name:'TARGET',team:[set('Pikachu',ability,5,['splash']),set('Squirtle','Torrent',5,['splash'])]}});if(b.requestState==='teampreview')b.makeChoices('team 1','team 12');return b;}
const rows=[];
for(const fixture of [{ability:'Static'},{ability:'Insomnia'},{ability:'Truant'},{ability:'Multitype'},{ability:'Wonder Guard'},{ability:'Static',asleep:true},{ability:'Static',miss:true}]){
 const b=fresh(fixture.ability),p=b.p1.active[0],e=b.p2.active[0];if(fixture.asleep)e.setStatus('slp',p);if(fixture.miss)p.boosts.accuracy=-6;
 const start=b.log.length,draws=[],random=b.prng.random;b.prng.random=function(...args){const out=random.apply(this,args);draws.push({args,result:out,effect:b.effect?.id,event:b.event?.id});return out;};
 const before={ability:e.ability,baseAbility:e.baseAbility,status:e.status,pp:p.moveSlots[0].pp,seed:b.prng.getSeed()};b.makeChoices('move worryseed','move splash');
 const after={ability:e.ability,baseAbility:e.baseAbility,status:e.status,pp:p.moveSlots[0].pp,seed:b.prng.getSeed()};const log=b.log.slice(start).filter(x=>!x.startsWith('|t:|'));
 rows.push({fixture,before,after,draws,log});b.destroy();
}
const b=fresh('Static'),p=b.p1.active[0],e=b.p2.active[0];b.makeChoices('move worryseed','move splash');const lifecycle=[{stage:'after-hit',ability:e.ability,base:e.baseAbility}];
b.makeChoices('move worryseed','move splash');lifecycle.push({stage:'repeat',ability:e.ability,pp:p.moveSlots[0].pp});
b.makeChoices('move splash','switch 2');b.makeChoices('move splash','switch 2');lifecycle.push({stage:'return',ability:b.p2.active[0].ability,sameIdentity:b.p2.active[0]===e});const lifecycleLog=b.log.filter(x=>!x.startsWith('|t:|'));b.destroy();
const files=['data/moves.ts','data/abilities.ts','data/mods/gen8/abilities.ts','sim/pokemon.ts','sim/battle-actions.ts','sim/battle.ts','dist/data/moves.js','dist/data/abilities.js','dist/sim/pokemon.js','dist/sim/battle-actions.js'];
console.log(JSON.stringify({revision:'9b136a8c8cdb860a8ab96fa063f906604e352547',node:process.version,format:'gen5customgame',qualification:'Actual engine and real choices, original151 species/custom learnsets. Truant/Multitype/WonderGuard on Pikachu are explicitly illegal ability fixtures only to audit generic eligibility/timing. Sleep/miss state controlled before observation; real rule callbacks unchanged. Wrapped PRNG delegates original and records calls, not a mocked RNG.',unreplaceableGen5:Dex.mod('gen5').abilities.all().filter(a=>a.num>0&&a.num<=164&&a.flags.cantsuppress).map(a=>({id:a.id,num:a.num})),rows,lifecycle,lifecycleLog,files:files.map(file=>({file,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')}))},null,2));

const assert=require('assert');
const {Battle}=require('/private/tmp/pokemon-brock-charge-lock-01/references/pokemon-showdown-9b136a8c8cdb860a8ab96fa063f906604e352547/dist/sim');
const ivs={hp:0,atk:0,def:0,spa:0,spd:0,spe:0},evs={...ivs};
const rows=[];
for(const [species,ability]of[['Gastly','Levitate'],['Golem','Rock Head'],['Magnemite','Sturdy']]){
 const user={species:'Squirtle',ability:'Torrent',nature:'Hardy',level:50,ivs:{...ivs},evs:{...evs},moves:['bide','growl']};
 const enemy={species,ability,nature:'Hardy',level:5,ivs:{...ivs},evs:{...evs},moves:['nightshade','splash']};
 const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,4],p1:{name:'USER',team:[user]},p2:{name:'FOE',team:[enemy]}});
 if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');
 const a=b.p1.active[0],d=b.p2.active[0],before={userHP:a.hp,enemyHP:d.hp,pp:a.moveSlots[0].pp,maxPP:a.moveSlots[0].maxpp};const turns=[];
 for(let n=0;n<3&&!b.ended;n++){
  b.makeChoices('move 1','move 1');turns.push({userHP:a.hp,enemyHP:d.hp,pp:a.moveSlots[0].pp,bide:a.volatiles.bide?{duration:a.volatiles.bide.duration,totalDamage:a.volatiles.bide.totalDamage}:null});
 }
 const log=b.log.filter(x=>!x.startsWith('|t:|'));
 assert.equal(turns[0].enemyHP,before.enemyHP);assert.equal(turns[1].enemyHP,before.enemyHP);
 assert.equal(turns[0].userHP,before.userHP-5);assert.equal(turns[1].userHP,before.userHP-10);
 for(const turn of turns)assert.equal(turn.pp,before.pp-1);
 assert.equal(turns[2].bide,null);
 if(species==='Gastly'){assert.equal(turns[2].enemyHP,before.enemyHP);assert(log.some(x=>x.startsWith('|-immune|p2a:')));}
 if(species==='Golem')assert.equal(turns[2].enemyHP,before.enemyHP-20);
 if(species==='Magnemite'){assert.equal(turns[2].enemyHP,1);assert(log.some(x=>x.includes('Sturdy')));}
 rows.push({enemy:species,ability,fixture:{user,enemy},before,turns,log});b.destroy();
}
process.stdout.write(JSON.stringify({revision:'9b136a8c8cdb860a8ab96fa063f906604e352547',format:'gen5customgame',note:'Explicit IV0 EV0 Hardy; illegal NightShade sets isolate fixed incoming5 without claiming acquisition. PS default PP Ups gives16PP, require exactly1 spent. Full mechanical log; wallclock only excluded.',rows},null,2)+'\n');

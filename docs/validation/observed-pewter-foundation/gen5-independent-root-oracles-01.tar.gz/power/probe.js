'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const base=path.resolve(process.argv[2]);const {Battle}=require(path.join(base,'dist/sim'));
function make(species='Nidoran-M',ability='Rivalry',target='Charmander',gender='M'){
 const set=(species,ability,gender,moves)=>({species,ability,gender,nature:'Hardy',level:50,ivs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},evs:{hp:0,atk:0,def:0,spa:0,spd:0,spe:0},moves});
 const b=new Battle({formatid:'gen5customgame',seed:[1,2,3,4],p1:{name:'ACTOR',team:[set(species,ability,'M',['mudsport','thundershock','solarbeam','rollout'])]},p2:{name:'TARGET',team:[set(target,target==='Staryu'?'Natural Cure':'Blaze',gender,['mudsport','splash'])]}});
 if(b.requestState==='teampreview')b.makeChoices('team 1','team 1');return b;
}
function observe(b,p,e,move,power){
 const calls=[],original=b.chainModify;b.chainModify=function(...args){const before=this.event.modifier;const out=original.apply(this,args);calls.push({effect:this.effect.id,priority:this.effect.onBasePowerPriority??this.effect.onAnyBasePowerPriority??0,args,beforeQ12:before*4096,afterQ12:this.event.modifier*4096});return out;};
 let result;try{result=b.runEvent('BasePower',p,e,move,power,true);}finally{b.chainModify=original;}return {raw:power,result,calls};
}
const rows=[];
for(const who of [{species:'Nidoran-M',ability:'Rivalry',target:'Charmander',gender:'M'},{species:'Nidoran-M',ability:'Rivalry',target:'Charmander',gender:'F'},{species:'Pikachu',ability:'Static',target:'Charmander',gender:'M'},{species:'Nidoran-M',ability:'Rivalry',target:'Staryu',gender:''}])for(const mud of [0,1,2]){
 const b=make(who.species,who.ability,who.target,who.gender),p=b.p1.active[0],e=b.p2.active[0];if(mud)b.makeChoices('move 1',mud===2?'move 1':'move 2');
 rows.push({fixture:who,mud,holders:[!!p.volatiles.mudsport,!!e.volatiles.mudsport],...observe(b,p,e,b.dex.getActiveMove('thundershock'),40)});b.destroy();
}
const solar=[];for(const weather of ['', 'sunnyday','raindance','sandstorm','hail']){
 const b=make(),p=b.p1.active[0],e=b.p2.active[0];if(weather)b.field.setWeather(weather,p);solar.push({weather:weather||'none',...observe(b,p,e,b.dex.getActiveMove('solarbeam'),120)});b.destroy();
}
const paths=['data/mods/gen5/moves.ts','data/abilities.ts','data/moves.ts','sim/battle.ts','sim/battle-actions.ts','dist/data/mods/gen5/moves.js','dist/data/abilities.js','dist/data/moves.js','dist/sim/battle.js','dist/sim/battle-actions.js'];
console.log(JSON.stringify({revision:'9b136a8c8cdb860a8ab96fa063f906604e352547',node:process.version,format:'gen5customgame',qualification:'Actual compiled engine, real makeChoices for Mud Sport, observer wraps original chainModify unchanged and records actual callbacks. Original151 custom learnsets isolate rules only, not acquisition. Weather is explicitly installed as a labeled rule fixture, not ordinary availability.',rows,solar,files:paths.map(file=>({file,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(base,file))).digest('hex')}))},null,2));

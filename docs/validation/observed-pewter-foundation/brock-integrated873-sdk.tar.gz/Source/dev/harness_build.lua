HarnessBuild = {
    protocol = 1,
    session_id = "160ce14a51a24e53ad9f170a420e5003",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:cd1d3c0464ca348f7b418d6fa0ea767b5c9e315d3e4b39ce9b6d506e7a1de3c2",
    output_dir = "/private/tmp/pokemon-brock-composed-sdk-02/frames/",
    bundle_id = "com.poc.pokemon.harness.160ce14a51a24e53ad9f170a420e5003",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.160ce14a51a24e53ad9f170a420e5003",
}

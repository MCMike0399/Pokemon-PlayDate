HarnessBuild = {
    protocol = 1,
    session_id = "1d8ad3824121430398d2befd121fffd1",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:3e58eb7324c424af90142874c9992d512bfa9997dd9a8ecc89a7bc4f15da3fcb",
    output_dir = "/private/tmp/pokemon-root-title-save-recovery-sdk-01/frames/",
    bundle_id = "com.poc.pokemon.harness.1d8ad3824121430398d2befd121fffd1",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.1d8ad3824121430398d2befd121fffd1",
}

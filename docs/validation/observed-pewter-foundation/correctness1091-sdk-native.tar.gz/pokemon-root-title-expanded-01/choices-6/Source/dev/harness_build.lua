HarnessBuild = {
    protocol = 1,
    session_id = "29a3f40ef2e14e1990bf9ed38bfb53f0",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:88fc85fbc60f88b35fb715c9bd372e79d3a848d4134e75b006fb6d1af1911165",
    output_dir = "/private/tmp/pokemon-root-title-expanded-01/choices-6/frames/",
    bundle_id = "com.poc.pokemon.harness.29a3f40ef2e14e1990bf9ed38bfb53f0",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.29a3f40ef2e14e1990bf9ed38bfb53f0",
}

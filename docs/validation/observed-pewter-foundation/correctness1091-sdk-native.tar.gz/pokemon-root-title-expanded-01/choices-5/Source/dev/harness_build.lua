HarnessBuild = {
    protocol = 1,
    session_id = "f3ef2465c5a749a79e7fa535aaf40fdd",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:03e0639a5af4b2bea0763a528ccb28c5458b395a7845d415db5c944383cb8799",
    output_dir = "/private/tmp/pokemon-root-title-expanded-01/choices-5/frames/",
    bundle_id = "com.poc.pokemon.harness.f3ef2465c5a749a79e7fa535aaf40fdd",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.f3ef2465c5a749a79e7fa535aaf40fdd",
}

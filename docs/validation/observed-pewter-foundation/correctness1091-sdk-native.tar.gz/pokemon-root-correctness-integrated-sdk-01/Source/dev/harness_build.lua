HarnessBuild = {
    protocol = 1,
    session_id = "8b2625886d484adf8d30e574deb12198",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc",
    output_dir = "/private/tmp/pokemon-root-correctness-integrated-sdk-01/frames/",
    bundle_id = "com.poc.pokemon.harness.8b2625886d484adf8d30e574deb12198",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.8b2625886d484adf8d30e574deb12198",
}

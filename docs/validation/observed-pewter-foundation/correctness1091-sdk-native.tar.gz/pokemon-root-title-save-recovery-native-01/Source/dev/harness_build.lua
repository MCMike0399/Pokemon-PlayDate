HarnessBuild = {
    protocol = 1,
    session_id = "b35660593fb34849b2917b60bce92e4f",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:0869d026f9d208267870fb451828f2b6e000c86ca8f01fba3449871df14e7b15",
    output_dir = "/private/tmp/pokemon-root-title-save-recovery-native-01/frames/",
    bundle_id = "com.poc.pokemon.harness.b35660593fb34849b2917b60bce92e4f",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.b35660593fb34849b2917b60bce92e4f",
}

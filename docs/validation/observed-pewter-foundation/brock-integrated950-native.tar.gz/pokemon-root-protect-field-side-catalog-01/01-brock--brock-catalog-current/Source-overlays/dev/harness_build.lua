HarnessBuild = {
    protocol = 1,
    session_id = "d9987bb5a8a548dc9d578bedc3feb356",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:49832dd1c89953784f13c65a54f21a63771ae7b9b73ef16b405a8118932c8386",
    output_dir = "/private/tmp/pokemon-root-protect-field-side-catalog-01/01-brock--brock-catalog-current/frames/",
    bundle_id = "com.poc.pokemon.harness.d9987bb5a8a548dc9d578bedc3feb356",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.d9987bb5a8a548dc9d578bedc3feb356",
}

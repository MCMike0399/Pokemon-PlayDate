HarnessBuild = {
    protocol = 1,
    session_id = "47bb51bd121a4a03ab8df054baef50dc",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:49832dd1c89953784f13c65a54f21a63771ae7b9b73ef16b405a8118932c8386",
    output_dir = "/private/tmp/pokemon-root-sides-native-01/03-brock--brock-tailwind-order-expiry/frames/",
    bundle_id = "com.poc.pokemon.harness.47bb51bd121a4a03ab8df054baef50dc",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.47bb51bd121a4a03ab8df054baef50dc",
}

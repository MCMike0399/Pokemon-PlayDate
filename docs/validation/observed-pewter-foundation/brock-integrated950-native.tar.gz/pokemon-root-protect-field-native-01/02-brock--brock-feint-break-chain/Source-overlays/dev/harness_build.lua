HarnessBuild = {
    protocol = 1,
    session_id = "486bef0dc3fb40039c1c85f5cece9f37",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:022ff9fd8c326bc6c9e7c7ac2846fa87db87394a8637af5c70c16db7683b2490",
    output_dir = "/private/tmp/pokemon-root-protect-field-native-01/02-brock--brock-feint-break-chain/frames/",
    bundle_id = "com.poc.pokemon.harness.486bef0dc3fb40039c1c85f5cece9f37",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.486bef0dc3fb40039c1c85f5cece9f37",
}

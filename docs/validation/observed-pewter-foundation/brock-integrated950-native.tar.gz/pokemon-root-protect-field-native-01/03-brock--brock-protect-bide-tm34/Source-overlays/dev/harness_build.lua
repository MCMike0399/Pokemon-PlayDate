HarnessBuild = {
    protocol = 1,
    session_id = "41ef6f722d744bd3939bdd0c8e17166e",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:022ff9fd8c326bc6c9e7c7ac2846fa87db87394a8637af5c70c16db7683b2490",
    output_dir = "/private/tmp/pokemon-root-protect-field-native-01/03-brock--brock-protect-bide-tm34/frames/",
    bundle_id = "com.poc.pokemon.harness.41ef6f722d744bd3939bdd0c8e17166e",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.41ef6f722d744bd3939bdd0c8e17166e",
}

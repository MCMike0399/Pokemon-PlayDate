HarnessBuild = {
    protocol = 1,
    session_id = "586d3fe4eef44cf3971072009ce8dabb",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:022ff9fd8c326bc6c9e7c7ac2846fa87db87394a8637af5c70c16db7683b2490",
    output_dir = "/private/tmp/pokemon-root-protect-field-native-01/04-brock--field-static/frames/",
    bundle_id = "com.poc.pokemon.harness.586d3fe4eef44cf3971072009ce8dabb",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.586d3fe4eef44cf3971072009ce8dabb",
}

import json,sys,subprocess,hashlib
from pathlib import Path
project=Path('/private/tmp/pokemon-brock-integration-02');sys.path.insert(0,str(project))
from tools.harness import run as runner
from tools.harness.protocol import atomic_json
base=runner.fingerprint(project);control=Path('/private/tmp/pokemon-root-sides-sdk-01');metadata=json.loads((control/'build.json').read_text());assert metadata['source_sha256']==base
reports=[r['contracts']for f in control.glob('[0-9][0-9][0-9][0-9][0-9]-result.json')for r in json.loads(f.read_text()).get('results',[])if'contracts'in r]
assert len(reports)==1 and reports[0]['ok'] and reports[0]['passed']==950 and reports[0]['failed']==0
expected={
'after-accuracy':'protect: First Protect priority4 blocks actual faster attack before accuracy/critical/contact draws',
'refresh-chain':'protect: Consecutive public Protect success doubles counter; failure then next attempt resets',
'clear-stall-feint':'protect: Feint breaks real protection after accuracy, no contact reaction, preserving stall',
'alwaysfail-cap':'protect: Saturated counter256 samples BOTH16bit draws and has real reproducible success',
'bide-bypass':'protect: Native-C source-resolved Bide release blocked; retained actual PS bypass discrepancy explicit',
'gate-boundary':'field-encounters: source50 gate49 inactive and50 active, with Blue table physical duplicate indices',
'static-first-slot':'field-encounters: Static uniformly chooses matching slot indices, preserving duplicate Pikachu levels',
'suppression-boundary':'field-encounters: KeenEye and Intimidate suppress at exactly5below before any creation',
'physical-threshold':'field-encounters: fainted physical lead supplies ability but conscious member supplies suppression level',
'rapidspin-wipes':'sides: RapidSpin removes only hazards and bindings while preserving all side timers',
'wind-after-para':'sides: Actual shared effectiveSpeed doubles BEFORE GenVparalysisfloor with minimum1',
'block-self':'sides: Source-self sleep and late residual fatigue pass Safeguard with explicit provenance',
'screen-min1':'sides: Natural Pikachu100 screen vs Sandshrew11 Swift is actual successful0HP hit',
'skip-zero-contact':'sides: ZeroHP contact hit starts real rampage and samples Static with no HP ledger',
'skip-zero-lock':'sides: ZeroHP contact hit starts real rampage and samples Static with no HP ledger',
'skip-zero-rage':'sides: Successful zeroHP Swift builds living Rage receiver while HP ledgers stay unchanged',
}
assert set(expected.values())<={t['name']for t in reports[0]['tests']}
out=Path('/private/tmp/pokemon-root-16-mutants-sdk-01');out.mkdir(exist_ok=False)
report={'schema':1,'executed':True,'complete':False,'ok':False,'base_source_sha256':base,'control':str(control),'control_passed':950,'requested':list(expected),'results':[]}
atomic_json(out/'qualification.json',report)
for name,witness in expected.items():
 assert runner.fingerprint(project)==base,'Source changed during qualification'
 dest=out/name;print('Running',name,flush=True)
 with(out/(name+'.log')).open('w')as log:
  result=subprocess.run([sys.executable,'/private/tmp/pokemon-root-protect-field-mutants-01.py','--variant',name,'--output',str(dest)],stdout=log,stderr=subprocess.STDOUT)
 found=[(f,r['contracts'])for f in dest.glob('[0-9][0-9][0-9][0-9][0-9]-result.json')for r in json.loads(f.read_text()).get('results',[])if'contracts'in r]
 assert len(found)==1,(name,'missing or duplicate numbered contract report')
 path,c=found[0];failed={t['name']for t in c['tests']if not t['ok']};assert result.returncode!=0 and not c['ok'] and witness in failed,(name,result.returncode,failed)
 build=json.loads((dest/'build.json').read_text());changes=build['mutation']['changes'];assert len(changes)==1
 cm=json.loads((control/'source-manifest.json').read_text());mm=json.loads((dest/'source-manifest.json').read_text());ignore={'dev/harness_build.lua'}
 assert set(cm)-ignore==set(mm)-ignore
 diffs={k for k in set(cm)-ignore if cm[k]!=mm[k]};assert diffs=={changes[0]['path']},(name,diffs)
 row={'variant':name,'qualified':True,'returncode':result.returncode,'passed':c['passed'],'failed':c['failed'],'failed_tests':sorted(failed),'required_witness':witness,'evidence':str(path),'compiled_source_sha256':build['compiled_source_sha256'],'changes':changes};report['results'].append(row);atomic_json(out/'qualification.json',report)
 print('Killed',name,c['passed'],c['failed'],flush=True)
report['complete']=True;report['ok']=True;atomic_json(out/'qualification.json',report)
print(out/'qualification.json',flush=True)

import argparse,sys,importlib.util,hashlib,json,subprocess
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser();p.add_argument('--variant',required=True);p.add_argument('--output',required=True);a=p.parse_args()
project=Path('/private/tmp/pokemon-brock-integration-02');sys.path.insert(0,str(project))
from tools.harness import run as runner
spec=importlib.util.spec_from_file_location('root_contract_mutations',project/'tools/rules-tests/mutations.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.BASELINE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip()+':'+runner.fingerprint(project)
runner.PROJECT=project
mapping={
'gate-boundary':('domain/fieldEncounters.lua','receipt.gate_roll>=50','receipt.gate_roll>50'),
'static-first-slot':('domain/fieldEncounters.lua','index=candidates[receipt.preferred_roll]','index=candidates[1]'),
'suppression-boundary':('domain/fieldEncounters.lua','r.level>=level+5','r.level>level+5'),
'physical-threshold':('domain/fieldEncounters.lua','level=party:get(usable).level','level=lead.level'),
'refresh-chain':('battle/conditions.lua','local counter=state and state.stall and state.stall.counter or 1','local counter=1'),
'clear-stall-feint':('battle/conditions.lua','state.protect=nil -- GenV Feint deliberately preserves the stall counter.','state.protect=nil;state.stall=nil -- deliberately wrong GenVI semantics'),
'alwaysfail-cap':('battle/conditions.lua','return first==65535 and second==65535','return false'),
'bide-bypass':('battle/conditions.lua','    if TypeChart.getMatchup(b.currentMove.type,target.type,target.type2)~=0\n       and self:blocks(b.currentMove,mon,target) then return nil end\n',''),
'rapidspin-wipes':('battle/conditions.lua','side.spikes,side.toxicSpikes,side.stealthRock,side.order,side.hazardOrigins=nil,nil,nil,nil,nil','self.sides[self:side(user)]={}'),
'block-self':('battle/conditions.lua','if not origin or not origin.source or origin.source==mon then return false end','if not origin or not origin.source then return false end'),
'screen-min1':('battle/battle.lua','damage=effects.battle.conditions:screenDamage(attacker,defender,move,damage,isCrit)','damage=math.max(1,effects.battle.conditions:screenDamage(attacker,defender,move,damage,isCrit))'),
'skip-zero-contact':('battle/effects.lua','receipt.contact and receipt.before>0','receipt.contact and receipt.removed>0'),
'skip-zero-lock':('battle/battle.lua','            self.conditions:landedMove(move)','            if receipt.removed>0 then self.conditions:landedMove(move) end'),
'skip-zero-rage':('battle/battle.lua','            self.conditions:rageHit(defender)','            if receipt.removed>0 then self.conditions:rageHit(defender) end'),
}
def mutate(source,variant):
 if variant=='after-accuracy':
  target=source/'battle/battle.lua';before=target.read_bytes();body=before.decode();start=body.index('    -- GenV TryHit protection follows');end=body.index('    -- Move-specific failure after',start);guard=body[start:end];body=body[:start]+body[end:];anchor='    self.conditions:breakProtection(move,defender)';assert body.count(anchor)==1;target.write_text(body.replace(anchor,guard+anchor,1))
 elif variant=='wind-after-para':
  target=source/'battle/battle.lua';before=target.read_bytes();body=before.decode();line='    if conditions then speed=conditions:speed(pokemon,speed) end\n';assert body.count(line)==1;body=body.replace(line,'',1);anchor='    return math.max(1,speed)';assert body.count(anchor)==1;target.write_text(body.replace(anchor,line+anchor,1))
 else:
  rel,old,new=mapping[variant];target=source/rel;before=target.read_bytes();text=before.decode();assert text.count(old)==1,(variant,old);target.write_text(text.replace(old,new,1))
 return [{'path':str(target.relative_to(source)),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}]
module.mutate=mutate
original=runner.prepare;runner.prepare=module.prepare_wrapper(original,a.variant)
try:code=runner.run(SimpleNamespace(sdk=None,output=a.output,scenario=None,commands=['contracts'],build_only=False,timeout=180,ready_timeout=20,max_frames=2400))
finally:runner.prepare=original
raise SystemExit(code)

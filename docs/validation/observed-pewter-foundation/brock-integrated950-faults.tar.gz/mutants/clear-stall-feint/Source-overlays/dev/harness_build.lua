HarnessBuild = {
    protocol = 1,
    session_id = "1d20bb7674594c758a02285f6feb1790",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:29a0d371e3866a4da477e2573fc2736c671030cf5b308a7ffcf8cae4aefb0389",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/clear-stall-feint/frames/",
    bundle_id = "com.poc.pokemon.harness.1d20bb7674594c758a02285f6feb1790",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.1d20bb7674594c758a02285f6feb1790",
}

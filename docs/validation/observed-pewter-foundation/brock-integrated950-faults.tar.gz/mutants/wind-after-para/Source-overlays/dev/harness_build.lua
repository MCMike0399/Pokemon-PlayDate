HarnessBuild = {
    protocol = 1,
    session_id = "9b97cce04dce4a5ba166e89ff2c0bb69",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:5773bd98461bdeee72429dee8a6933cc0c3d5e2017c0ba60f80c7b86b561c480",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/wind-after-para/frames/",
    bundle_id = "com.poc.pokemon.harness.9b97cce04dce4a5ba166e89ff2c0bb69",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.9b97cce04dce4a5ba166e89ff2c0bb69",
}

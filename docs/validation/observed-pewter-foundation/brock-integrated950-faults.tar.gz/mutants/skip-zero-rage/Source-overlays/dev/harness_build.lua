HarnessBuild = {
    protocol = 1,
    session_id = "e5fe2779548e43a2827aeb941ae05bd0",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:3717b5520553c5cde61f19e77e162c5b9e40e6a0939cf487092b56c552945dde",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/skip-zero-rage/frames/",
    bundle_id = "com.poc.pokemon.harness.e5fe2779548e43a2827aeb941ae05bd0",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.e5fe2779548e43a2827aeb941ae05bd0",
}

HarnessBuild = {
    protocol = 1,
    session_id = "af852538baab40698129837f746fc88e",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:1f6a9f5a0bdb6971ac28e22b6bd2ca23c32acc4298e60dfb6fd6b1a583d5cabe",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/screen-min1/frames/",
    bundle_id = "com.poc.pokemon.harness.af852538baab40698129837f746fc88e",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.af852538baab40698129837f746fc88e",
}

HarnessBuild = {
    protocol = 1,
    session_id = "04122a9eb7174c808f8f6468f7bdfacc",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:2b469fbc4c138ab22c9317556032ed8311d86a2a6009dfe2e464c046437b41a8",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/block-self/frames/",
    bundle_id = "com.poc.pokemon.harness.04122a9eb7174c808f8f6468f7bdfacc",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.04122a9eb7174c808f8f6468f7bdfacc",
}

HarnessBuild = {
    protocol = 1,
    session_id = "cf92a21c65db4f14add0146215c8523a",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:8881f4fe1505caf140bb8ab868e523ccee09191c05949023c0d3d695637e72b0",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/after-accuracy/frames/",
    bundle_id = "com.poc.pokemon.harness.cf92a21c65db4f14add0146215c8523a",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.cf92a21c65db4f14add0146215c8523a",
}

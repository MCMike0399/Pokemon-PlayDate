HarnessBuild = {
    protocol = 1,
    session_id = "7a5cd98c250149b484af0f8bb21266d5",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:bc41ec0b070f3705835683344a6e8df580e3bb5dc51855456189bcd733b87495",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/physical-threshold/frames/",
    bundle_id = "com.poc.pokemon.harness.7a5cd98c250149b484af0f8bb21266d5",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.7a5cd98c250149b484af0f8bb21266d5",
}

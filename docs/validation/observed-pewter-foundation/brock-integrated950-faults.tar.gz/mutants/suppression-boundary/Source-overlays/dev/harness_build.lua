HarnessBuild = {
    protocol = 1,
    session_id = "fe1d4b7ab7cb4cd898d32995c9041bbc",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:9005c1b6de732edec62aeb4e6d4f65f703b584f9d0b19f7772f8e43497f45e7b",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/suppression-boundary/frames/",
    bundle_id = "com.poc.pokemon.harness.fe1d4b7ab7cb4cd898d32995c9041bbc",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.fe1d4b7ab7cb4cd898d32995c9041bbc",
}

HarnessBuild = {
    protocol = 1,
    session_id = "5a24ef878624434c9e6bfa965dd62d18",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:911fe76214ab20bbeb9296192e67efac67f234970756b32aeab205fb27b1642e",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/rapidspin-wipes/frames/",
    bundle_id = "com.poc.pokemon.harness.5a24ef878624434c9e6bfa965dd62d18",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.5a24ef878624434c9e6bfa965dd62d18",
}

HarnessBuild = {
    protocol = 1,
    session_id = "55207d691efe43998a70b1a5b51661fb",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:5c14d3115a6b41ff2b042dd187190915dd63643ed13763b8155c7ee6c743cfcd",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/bide-bypass/frames/",
    bundle_id = "com.poc.pokemon.harness.55207d691efe43998a70b1a5b51661fb",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.55207d691efe43998a70b1a5b51661fb",
}

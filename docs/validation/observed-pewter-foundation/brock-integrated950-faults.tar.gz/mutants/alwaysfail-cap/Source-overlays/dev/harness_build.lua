HarnessBuild = {
    protocol = 1,
    session_id = "17d88d55bfd24f24b21350c0f2294bfe",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:4a7d179850ef7a5f6e00ba7e1593169f254b8020d63eddc156ad8ea507f841d1",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/alwaysfail-cap/frames/",
    bundle_id = "com.poc.pokemon.harness.17d88d55bfd24f24b21350c0f2294bfe",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.17d88d55bfd24f24b21350c0f2294bfe",
}

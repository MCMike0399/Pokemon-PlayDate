HarnessBuild = {
    protocol = 1,
    session_id = "41d5f1aada604795b8d3365bb23f4fb6",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:6c86141103aa1a25d6dc761c528fd5bbfd924e8ccaaaa263417997423319837a",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/skip-zero-lock/frames/",
    bundle_id = "com.poc.pokemon.harness.41d5f1aada604795b8d3365bb23f4fb6",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.41d5f1aada604795b8d3365bb23f4fb6",
}

HarnessBuild = {
    protocol = 1,
    session_id = "d5c3c9d0267b462b8b2cbff82bf17aa4",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:f09534024ee628f5492f54c2b4b56f6faae5f7d3752a45825195ac8239badd55",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/refresh-chain/frames/",
    bundle_id = "com.poc.pokemon.harness.d5c3c9d0267b462b8b2cbff82bf17aa4",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.d5c3c9d0267b462b8b2cbff82bf17aa4",
}

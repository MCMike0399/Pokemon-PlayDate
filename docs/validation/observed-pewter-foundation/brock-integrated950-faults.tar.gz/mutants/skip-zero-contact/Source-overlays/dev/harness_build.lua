HarnessBuild = {
    protocol = 1,
    session_id = "b940029711e640b18e4522b47c71252e",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:b5696b0952dc32b2600f9ba6852bf7695137a596c34b5a13068e9a34e50e6e9d",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/skip-zero-contact/frames/",
    bundle_id = "com.poc.pokemon.harness.b940029711e640b18e4522b47c71252e",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.b940029711e640b18e4522b47c71252e",
}

HarnessBuild = {
    protocol = 1,
    session_id = "826b45aa460e423db18a8978c2620bea",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:b75428ada8e30243243fce25bec70d0ad18f58459967077d04569fc9cca67e89",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/static-first-slot/frames/",
    bundle_id = "com.poc.pokemon.harness.826b45aa460e423db18a8978c2620bea",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.826b45aa460e423db18a8978c2620bea",
}

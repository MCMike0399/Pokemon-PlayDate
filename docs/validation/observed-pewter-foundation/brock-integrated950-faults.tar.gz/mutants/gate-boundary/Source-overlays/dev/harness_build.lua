HarnessBuild = {
    protocol = 1,
    session_id = "b47c6e8d870f4a87a1da6b121a8a65cf",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:f585b3150c1b002242e843b0bcdb17195c57c5b8f7e40c326c860f739cafcbe2",
    output_dir = "/private/tmp/pokemon-root-16-mutants-sdk-01/gate-boundary/frames/",
    bundle_id = "com.poc.pokemon.harness.b47c6e8d870f4a87a1da6b121a8a65cf",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.b47c6e8d870f4a87a1da6b121a8a65cf",
}

HarnessBuild = {
    protocol = 1,
    session_id = "c5ca1c04b1484019907a08053e69c33f",
    build_id = "82cb2073d2e20f1a85cb3643428fc342a23c8e66:44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc",
    output_dir = "/private/tmp/pokemon-root-brock-freeze82cb207-01/03-brock--brock-restart-charmander/frames/",
    bundle_id = "com.poc.pokemon.harness.c5ca1c04b1484019907a08053e69c33f",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.c5ca1c04b1484019907a08053e69c33f",
}

HarnessBuild = {
    protocol = 1,
    session_id = "8e60b01e15ff467c9eeef6a732e89bae",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:f9dc3cfa51aafbae8c1abba40e98730bd37eddee2d306f8cf3d1bc9915afaa34",
    output_dir = "/private/tmp/pokemon-root-protect-field-sdk-02/frames/",
    bundle_id = "com.poc.pokemon.harness.8e60b01e15ff467c9eeef6a732e89bae",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.8e60b01e15ff467c9eeef6a732e89bae",
}

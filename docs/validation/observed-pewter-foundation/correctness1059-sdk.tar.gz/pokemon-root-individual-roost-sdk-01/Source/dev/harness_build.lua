HarnessBuild = {
    protocol = 1,
    session_id = "c9a3c56a292c4947adfad8f3080ec32f",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:a2db85c48668993e27036c46f714e931d52506641359e84ad812c4291245b714",
    output_dir = "/private/tmp/pokemon-root-individual-roost-sdk-01/frames/",
    bundle_id = "com.poc.pokemon.harness.c9a3c56a292c4947adfad8f3080ec32f",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.c9a3c56a292c4947adfad8f3080ec32f",
}

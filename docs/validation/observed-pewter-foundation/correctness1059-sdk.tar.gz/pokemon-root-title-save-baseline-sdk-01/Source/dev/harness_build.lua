HarnessBuild = {
    protocol = 1,
    session_id = "00d902b4e446456995bc3f835b6df453",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:6644254cb815aeae13da31c93260c397cfef60b78e4d34689c1253e825a3e0d9",
    output_dir = "/private/tmp/pokemon-root-title-save-baseline-sdk-01/frames/",
    bundle_id = "com.poc.pokemon.harness.00d902b4e446456995bc3f835b6df453",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.00d902b4e446456995bc3f835b6df453",
}

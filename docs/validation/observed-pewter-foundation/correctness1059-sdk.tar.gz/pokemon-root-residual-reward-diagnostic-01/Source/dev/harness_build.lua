HarnessBuild = {
    protocol = 1,
    session_id = "2afa0dbc0e22410793feb4363a39979c",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:40106b009a6eb5de66a8f6ec5d685aeebe1aa3aefa853295b44a9dc1f698148c",
    output_dir = "/private/tmp/pokemon-root-residual-reward-diagnostic-01/frames/",
    bundle_id = "com.poc.pokemon.harness.2afa0dbc0e22410793feb4363a39979c",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.2afa0dbc0e22410793feb4363a39979c",
}

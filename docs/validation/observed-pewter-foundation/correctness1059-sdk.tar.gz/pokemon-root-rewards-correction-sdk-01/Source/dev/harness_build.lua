HarnessBuild = {
    protocol = 1,
    session_id = "05d73ff39aae463faf9af337d586cf84",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:aa6fec9af2f66f6cf5779dd97b7bc76fd92491139a8076a5910b971a898ff5f8",
    output_dir = "/private/tmp/pokemon-root-rewards-correction-sdk-01/frames/",
    bundle_id = "com.poc.pokemon.harness.05d73ff39aae463faf9af337d586cf84",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.05d73ff39aae463faf9af337d586cf84",
}

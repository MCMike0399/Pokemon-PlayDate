HarnessBuild = {
    protocol = 1,
    session_id = "0e36b2a0d08746e9991b44803cf1a66f",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:0d88392102725cd82a58ff82d71216b2e5dc6f3462be64c074a3f1066707e90b",
    output_dir = "/private/tmp/pokemon-root-individual-roost-poison-sdk-01/frames/",
    bundle_id = "com.poc.pokemon.harness.0e36b2a0d08746e9991b44803cf1a66f",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.0e36b2a0d08746e9991b44803cf1a66f",
}

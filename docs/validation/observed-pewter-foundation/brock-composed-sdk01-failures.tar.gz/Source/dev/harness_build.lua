HarnessBuild = {
    protocol = 1,
    session_id = "ae55b82cd68c4d1e8792b892cef11ccf",
    build_id = "1c40818cce099f8c4463ba5073b95cc1fafb4502:61980c9964f42030c6d9d7e41e59e76b8fca42fc7a7ad598b60282fd22f8b929",
    output_dir = "/private/tmp/pokemon-brock-composed-sdk-01/frames/",
    bundle_id = "com.poc.pokemon.harness.ae55b82cd68c4d1e8792b892cef11ccf",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.ae55b82cd68c4d1e8792b892cef11ccf",
}

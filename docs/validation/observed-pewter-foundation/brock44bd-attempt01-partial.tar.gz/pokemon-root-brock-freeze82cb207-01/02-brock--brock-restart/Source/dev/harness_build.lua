HarnessBuild = {
    protocol = 1,
    session_id = "0bc29945a122469fb61a7911f3fe8f9d",
    build_id = "82cb2073d2e20f1a85cb3643428fc342a23c8e66:44bd25bac9b1968cc8691eedc05ecd104faf708796602a492f997dccd1ae9ddc",
    output_dir = "/private/tmp/pokemon-root-brock-freeze82cb207-01/02-brock--brock-restart/frames/",
    bundle_id = "com.poc.pokemon.harness.0bc29945a122469fb61a7911f3fe8f9d",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.0bc29945a122469fb61a7911f3fe8f9d",
}

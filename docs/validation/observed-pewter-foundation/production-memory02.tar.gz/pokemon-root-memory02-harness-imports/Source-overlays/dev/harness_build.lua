HarnessBuild = {
    protocol = 1,
    session_id = "cbf500c75f6f4897bf4ca0371280efc0",
    build_id = "48e88ac464e3c21d539f0f94c3a660a44dd1ca39:production-probe:ae0ebc140ed38c7bbc7132837268b2c8f4d945887747bd6dc455f2400631e2dc",
    output_dir = "/private/tmp/pokemon-root-memory02-harness-imports/frames/",
    bundle_id = "com.poc.pokemon.productionprobe.cbf500c75f6f4897bf4ca0371280efc0",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.productionprobe.cbf500c75f6f4897bf4ca0371280efc0",
}

ProductionProbeBuild = {
    enabled = true,
    mode = "harness",
    observer = "milestones",
    frames = 600,
    run_id = "53e2d01696644b59b990d151b019d852",
    build_id = "48e88ac464e3c21d539f0f94c3a660a44dd1ca39:production-probe:ae0ebc140ed38c7bbc7132837268b2c8f4d945887747bd6dc455f2400631e2dc",
    bundle_id = "com.poc.pokemon.productionprobe.53e2d01696644b59b990d151b019d852",
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.productionprobe.53e2d01696644b59b990d151b019d852",
    sdk_version = "3.1.2",
}

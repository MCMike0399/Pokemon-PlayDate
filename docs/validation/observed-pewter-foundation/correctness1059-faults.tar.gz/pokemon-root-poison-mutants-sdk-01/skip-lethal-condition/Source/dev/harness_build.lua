HarnessBuild = {
    protocol = 1,
    session_id = "bb6a5ca832c04c2c83252bee265d68d3",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:dc2875728b415bd5d749419fd4b0a841cb092f737cacdf9820fa7a306d84824a",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/skip-lethal-condition/frames/",
    bundle_id = "com.poc.pokemon.harness.bb6a5ca832c04c2c83252bee265d68d3",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.bb6a5ca832c04c2c83252bee265d68d3",
}

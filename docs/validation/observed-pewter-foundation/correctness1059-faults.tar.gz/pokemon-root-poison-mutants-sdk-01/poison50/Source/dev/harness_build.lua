HarnessBuild = {
    protocol = 1,
    session_id = "15fc76ea87a6499bb057e2dac104387a",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:b9d627777d416d7866029e47c57596853ce7b9e6653ce3b85853a9fb293162a5",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/poison50/frames/",
    bundle_id = "com.poc.pokemon.harness.15fc76ea87a6499bb057e2dac104387a",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.15fc76ea87a6499bb057e2dac104387a",
}

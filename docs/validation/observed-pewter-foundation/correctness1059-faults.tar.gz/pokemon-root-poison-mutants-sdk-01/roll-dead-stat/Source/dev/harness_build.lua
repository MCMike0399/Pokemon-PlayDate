HarnessBuild = {
    protocol = 1,
    session_id = "8d9315af065548a8a784bdcb3c16ba25",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:66b584c0a94791a9b3b53fb9b9ad0f6ae0a39beffe2ef2c17bb3d5351be2986b",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/roll-dead-stat/frames/",
    bundle_id = "com.poc.pokemon.harness.8d9315af065548a8a784bdcb3c16ba25",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.8d9315af065548a8a784bdcb3c16ba25",
}

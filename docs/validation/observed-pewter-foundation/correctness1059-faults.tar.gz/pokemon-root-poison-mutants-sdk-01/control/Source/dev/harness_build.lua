HarnessBuild = {
    protocol = 1,
    session_id = "2c70d0e7d0f2493e8d5894b966a16643",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:0d88392102725cd82a58ff82d71216b2e5dc6f3462be64c074a3f1066707e90b",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/control/frames/",
    bundle_id = "com.poc.pokemon.harness.2c70d0e7d0f2493e8d5894b966a16643",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.2c70d0e7d0f2493e8d5894b966a16643",
}

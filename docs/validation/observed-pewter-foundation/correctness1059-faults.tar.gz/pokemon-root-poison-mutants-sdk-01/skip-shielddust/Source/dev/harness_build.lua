HarnessBuild = {
    protocol = 1,
    session_id = "577b8dca482046fbb68cbeb15582b8a5",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:41a119b917d7ffc6d5f10fbfa95cd558444d8b0a8c19384dd5f98e5c8420dc13",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/skip-shielddust/frames/",
    bundle_id = "com.poc.pokemon.harness.577b8dca482046fbb68cbeb15582b8a5",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.577b8dca482046fbb68cbeb15582b8a5",
}

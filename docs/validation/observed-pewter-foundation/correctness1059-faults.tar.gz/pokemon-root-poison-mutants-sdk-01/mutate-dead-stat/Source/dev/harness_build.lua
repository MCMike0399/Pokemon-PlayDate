HarnessBuild = {
    protocol = 1,
    session_id = "ab03dee5b7c64da4be8af33200daa643",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:36bcb9dee26d1090e980bc8e0505f65348f596478176ac625fe279432f932cf2",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/mutate-dead-stat/frames/",
    bundle_id = "com.poc.pokemon.harness.ab03dee5b7c64da4be8af33200daa643",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.ab03dee5b7c64da4be8af33200daa643",
}

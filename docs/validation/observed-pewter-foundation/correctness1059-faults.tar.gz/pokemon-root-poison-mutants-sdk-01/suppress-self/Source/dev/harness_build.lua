HarnessBuild = {
    protocol = 1,
    session_id = "adf2ef4486c840ce8f6fefa516aa02c5",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:fb57f85bd1ea768749b9bf01b3963f49c0d589551e5ce8f74187816dc88fce69",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/suppress-self/frames/",
    bundle_id = "com.poc.pokemon.harness.adf2ef4486c840ce8f6fefa516aa02c5",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.adf2ef4486c840ce8f6fefa516aa02c5",
}

HarnessBuild = {
    protocol = 1,
    session_id = "8712e8676d8e4c3eb8f9bdb8f922554f",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:ca4a0998d24f1bc48fb02d4f98e1d5970b748da1d3291e96803f44c74fcd5fde",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/tri-skip-dead-choice/frames/",
    bundle_id = "com.poc.pokemon.harness.8712e8676d8e4c3eb8f9bdb8f922554f",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.8712e8676d8e4c3eb8f9bdb8f922554f",
}

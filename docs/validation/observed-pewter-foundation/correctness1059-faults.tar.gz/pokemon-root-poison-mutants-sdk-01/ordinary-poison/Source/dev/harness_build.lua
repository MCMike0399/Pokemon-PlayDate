HarnessBuild = {
    protocol = 1,
    session_id = "280376cb1baf42e79d760dbf88b1c8f6",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:ed12c82ba810018f79d4ced639bddd2155c6752c69b39da5c5701dafc5d9afad",
    output_dir = "/private/tmp/pokemon-root-poison-mutants-sdk-01/ordinary-poison/frames/",
    bundle_id = "com.poc.pokemon.harness.280376cb1baf42e79d760dbf88b1c8f6",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.280376cb1baf42e79d760dbf88b1c8f6",
}

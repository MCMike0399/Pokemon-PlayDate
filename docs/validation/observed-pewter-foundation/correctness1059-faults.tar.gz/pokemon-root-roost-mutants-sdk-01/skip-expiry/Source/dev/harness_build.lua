HarnessBuild = {
    protocol = 1,
    session_id = "a83c1596707a427aaf41218c013d4774",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:941f0f93214be4d261d310463cab8a43a62bd377bb18ae2f7646dabae7c57d35",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/skip-expiry/frames/",
    bundle_id = "com.poc.pokemon.harness.a83c1596707a427aaf41218c013d4774",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.a83c1596707a427aaf41218c013d4774",
}

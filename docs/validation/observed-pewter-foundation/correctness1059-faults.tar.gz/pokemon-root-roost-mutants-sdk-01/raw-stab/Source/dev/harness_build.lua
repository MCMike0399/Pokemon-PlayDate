HarnessBuild = {
    protocol = 1,
    session_id = "fff23166dda342a495a6a81a91447588",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:d461935433009750fd304fc30df342e9b60bf20c5ae106773303bd8daa079890",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/raw-stab/frames/",
    bundle_id = "com.poc.pokemon.harness.fff23166dda342a495a6a81a91447588",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.fff23166dda342a495a6a81a91447588",
}

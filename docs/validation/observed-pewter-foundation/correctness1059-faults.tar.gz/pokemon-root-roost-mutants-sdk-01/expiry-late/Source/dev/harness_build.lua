HarnessBuild = {
    protocol = 1,
    session_id = "6e203740e74b4d5d8d0bb547c54be163",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:daf4f2ff30d7f1bd89c878194db29b65e6e62926611bf6e030bbd281b3fadc11",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/expiry-late/frames/",
    bundle_id = "com.poc.pokemon.harness.6e203740e74b4d5d8d0bb547c54be163",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.6e203740e74b4d5d8d0bb547c54be163",
}

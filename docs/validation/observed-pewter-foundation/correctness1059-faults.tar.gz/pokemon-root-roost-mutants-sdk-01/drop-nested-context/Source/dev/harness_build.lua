HarnessBuild = {
    protocol = 1,
    session_id = "97a1d98c9a7a47399d952b523aad515e",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:320a0ee45b57d6084d85e8bac91d0de6a5c0b5eac5b15f35bde8f647b03ba81f",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/drop-nested-context/frames/",
    bundle_id = "com.poc.pokemon.harness.97a1d98c9a7a47399d952b523aad515e",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.97a1d98c9a7a47399d952b523aad515e",
}

HarnessBuild = {
    protocol = 1,
    session_id = "63441a25492a4b16b3f0db249d072375",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:1834d78ffdd71d9b7cff3753f0226049c1fd5131b9f6df5ff03bbc821132efee",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/floor-half/frames/",
    bundle_id = "com.poc.pokemon.harness.63441a25492a4b16b3f0db249d072375",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.63441a25492a4b16b3f0db249d072375",
}

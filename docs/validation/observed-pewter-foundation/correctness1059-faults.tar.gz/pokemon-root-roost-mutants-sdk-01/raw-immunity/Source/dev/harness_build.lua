HarnessBuild = {
    protocol = 1,
    session_id = "fce9b461143249c2b9ec820b17e9d81f",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:afbedb5136cad96fa69ed676a42170051d07ae135fe0dba976181470e85fbd41",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/raw-immunity/frames/",
    bundle_id = "com.poc.pokemon.harness.fce9b461143249c2b9ec820b17e9d81f",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.fce9b461143249c2b9ec820b17e9d81f",
}

HarnessBuild = {
    protocol = 1,
    session_id = "593e4e530d3c4540b0eaa83548506787",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:64cb5371869bb502efd1c73a56aaeb7472345f232a4ad6e851f96dcc59391d08",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/durable-types/frames/",
    bundle_id = "com.poc.pokemon.harness.593e4e530d3c4540b0eaa83548506787",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.593e4e530d3c4540b0eaa83548506787",
}

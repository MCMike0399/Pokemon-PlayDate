HarnessBuild = {
    protocol = 1,
    session_id = "9d6a4ef0e0424308bda0ea14304e2e2a",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:6b4cab9537473f3ba73d9879e2bdca5a57af3f122c649155130922d9676aabff",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/raw-ground/frames/",
    bundle_id = "com.poc.pokemon.harness.9d6a4ef0e0424308bda0ea14304e2e2a",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.9d6a4ef0e0424308bda0ea14304e2e2a",
}

HarnessBuild = {
    protocol = 1,
    session_id = "2d80a780d2334ae5afa1f278d4f162c6",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:8e165c08a8ce616f2b2d2947c23982c577f43fd56a0d0bc3e0d3df16aaab9edd",
    output_dir = "/private/tmp/pokemon-root-roost-mutants-sdk-01/mark-full/frames/",
    bundle_id = "com.poc.pokemon.harness.2d80a780d2334ae5afa1f278d4f162c6",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.2d80a780d2334ae5afa1f278d4f162c6",
}

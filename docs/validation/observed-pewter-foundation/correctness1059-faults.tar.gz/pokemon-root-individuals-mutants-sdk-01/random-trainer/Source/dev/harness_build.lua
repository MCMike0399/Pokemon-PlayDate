HarnessBuild = {
    protocol = 1,
    session_id = "58762866298545e19360f1f0b13df686",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:989c50e0e84b3dfd6319780a0e99e6f53cdd3bff39bae55e6845deb5ef868aeb",
    output_dir = "/private/tmp/pokemon-root-individuals-mutants-sdk-01/random-trainer/frames/",
    bundle_id = "com.poc.pokemon.harness.58762866298545e19360f1f0b13df686",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.58762866298545e19360f1f0b13df686",
}

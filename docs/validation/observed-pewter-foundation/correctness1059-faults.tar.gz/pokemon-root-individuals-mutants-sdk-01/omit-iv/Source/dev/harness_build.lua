HarnessBuild = {
    protocol = 1,
    session_id = "8389b4232f574d5687825fd70c72b0d4",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:9d5b3628c73719deb62e9a02bed4032a8cf9fd93c0daacf11db0bea77a7241ce",
    output_dir = "/private/tmp/pokemon-root-individuals-mutants-sdk-01/omit-iv/frames/",
    bundle_id = "com.poc.pokemon.harness.8389b4232f574d5687825fd70c72b0d4",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.8389b4232f574d5687825fd70c72b0d4",
}

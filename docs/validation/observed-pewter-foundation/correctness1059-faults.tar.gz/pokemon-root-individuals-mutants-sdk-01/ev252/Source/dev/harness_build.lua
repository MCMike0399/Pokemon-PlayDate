HarnessBuild = {
    protocol = 1,
    session_id = "43853bde73f548bb8ae9e024b4f6e90a",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:e266cac13ef93cb1bbe4a0f885ce8a6192fa78b78088b80f303a23dc52c6806e",
    output_dir = "/private/tmp/pokemon-root-individuals-mutants-sdk-01/ev252/frames/",
    bundle_id = "com.poc.pokemon.harness.43853bde73f548bb8ae9e024b4f6e90a",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.43853bde73f548bb8ae9e024b4f6e90a",
}

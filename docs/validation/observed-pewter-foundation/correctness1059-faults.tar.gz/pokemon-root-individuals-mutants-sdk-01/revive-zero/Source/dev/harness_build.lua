HarnessBuild = {
    protocol = 1,
    session_id = "9b7f629953f2445e9598c1187eca1e23",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:50c855db97a0d4b9aee5cfdcc78f9c9c0e6f4edc30e7029f330a40bad8ac1515",
    output_dir = "/private/tmp/pokemon-root-individuals-mutants-sdk-01/revive-zero/frames/",
    bundle_id = "com.poc.pokemon.harness.9b7f629953f2445e9598c1187eca1e23",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.9b7f629953f2445e9598c1187eca1e23",
}

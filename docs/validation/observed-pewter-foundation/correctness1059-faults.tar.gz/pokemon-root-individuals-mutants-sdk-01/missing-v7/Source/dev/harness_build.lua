HarnessBuild = {
    protocol = 1,
    session_id = "027a8af530bd4844a339f56bca56bf64",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:b18a372ba864cb0c1e3b19e2be29ad7d875104446b6778d9de1fd696e64a5944",
    output_dir = "/private/tmp/pokemon-root-individuals-mutants-sdk-01/missing-v7/frames/",
    bundle_id = "com.poc.pokemon.harness.027a8af530bd4844a339f56bca56bf64",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.027a8af530bd4844a339f56bca56bf64",
}

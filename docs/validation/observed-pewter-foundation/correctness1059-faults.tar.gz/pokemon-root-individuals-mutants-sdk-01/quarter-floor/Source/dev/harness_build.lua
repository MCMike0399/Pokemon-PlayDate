HarnessBuild = {
    protocol = 1,
    session_id = "f93fb279876a4df1a19f0edb87de75af",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:9a33fbb5e573d0a7f2d7b599fcbcef1deec307bd25fcd283d17371732fbaf788",
    output_dir = "/private/tmp/pokemon-root-individuals-mutants-sdk-01/quarter-floor/frames/",
    bundle_id = "com.poc.pokemon.harness.f93fb279876a4df1a19f0edb87de75af",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.f93fb279876a4df1a19f0edb87de75af",
}

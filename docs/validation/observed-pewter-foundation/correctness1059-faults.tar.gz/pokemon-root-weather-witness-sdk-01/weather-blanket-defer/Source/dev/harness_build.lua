HarnessBuild = {
    protocol = 1,
    session_id = "8719a19cc2aa477ba056f489f90d5f8c",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:2f5e03b4c448100083e8acada5d936c1a89a71c18a6354564a80285e195107a3",
    output_dir = "/private/tmp/pokemon-root-weather-witness-sdk-01/weather-blanket-defer/frames/",
    bundle_id = "com.poc.pokemon.harness.8719a19cc2aa477ba056f489f90d5f8c",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.8719a19cc2aa477ba056f489f90d5f8c",
}

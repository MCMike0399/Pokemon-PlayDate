HarnessBuild = {
    protocol = 1,
    session_id = "feacda37c5d540128d8bc67b3f902069",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:ced2c808d5698342c39726b969f19894661e6c29385ab70fc236374b8d5ccfe6",
    output_dir = "/private/tmp/pokemon-root-weather-witness-sdk-01/control/frames/",
    bundle_id = "com.poc.pokemon.harness.feacda37c5d540128d8bc67b3f902069",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.feacda37c5d540128d8bc67b3f902069",
}

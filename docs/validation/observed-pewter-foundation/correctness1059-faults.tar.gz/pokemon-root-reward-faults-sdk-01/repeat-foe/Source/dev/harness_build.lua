HarnessBuild = {
    protocol = 1,
    session_id = "8f287953085c45139713f2d135a390d0",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:670df6c72aa7921037dc88f2ff809f630774866f8da9dcde50f373c3bf954f1d",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/repeat-foe/frames/",
    bundle_id = "com.poc.pokemon.harness.8f287953085c45139713f2d135a390d0",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.8f287953085c45139713f2d135a390d0",
}

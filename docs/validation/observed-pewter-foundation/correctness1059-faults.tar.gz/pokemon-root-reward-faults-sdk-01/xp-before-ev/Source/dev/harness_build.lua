HarnessBuild = {
    protocol = 1,
    session_id = "623ff74373f845f9b6f3faa7a888003b",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:1fd81ea73738f4aa51aeae7a4d3c16c7571325a8ddb04c80e374e6924d7db576",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/xp-before-ev/frames/",
    bundle_id = "com.poc.pokemon.harness.623ff74373f845f9b6f3faa7a888003b",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.623ff74373f845f9b6f3faa7a888003b",
}

HarnessBuild = {
    protocol = 1,
    session_id = "5026679902b247e3a31845e716ab6446",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:458a9ba353ee4051b1135127a04b6cd253daa21ecea4ff384f409f8d9c81eb87",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/no-immediate-cleanup/frames/",
    bundle_id = "com.poc.pokemon.harness.5026679902b247e3a31845e716ab6446",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.5026679902b247e3a31845e716ab6446",
}

HarnessBuild = {
    protocol = 1,
    session_id = "d76cf4a240df429cb00c3f538efc5bb3",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:f413f83e68317a725b5ce17a15d121c4c15ba970674092599148f29eb691ea0e",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/no-return-flush/frames/",
    bundle_id = "com.poc.pokemon.harness.d76cf4a240df429cb00c3f538efc5bb3",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.d76cf4a240df429cb00c3f538efc5bb3",
}

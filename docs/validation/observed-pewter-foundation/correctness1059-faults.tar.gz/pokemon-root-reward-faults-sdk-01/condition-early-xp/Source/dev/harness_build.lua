HarnessBuild = {
    protocol = 1,
    session_id = "0bc8f06c40194dc9a90b4a189eb74097",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:c0695ec6d3317cc236a1dba3bbb31cc2c87561394bca8d411ae06d52f170dd37",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/condition-early-xp/frames/",
    bundle_id = "com.poc.pokemon.harness.0bc8f06c40194dc9a90b4a189eb74097",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.0bc8f06c40194dc9a90b4a189eb74097",
}

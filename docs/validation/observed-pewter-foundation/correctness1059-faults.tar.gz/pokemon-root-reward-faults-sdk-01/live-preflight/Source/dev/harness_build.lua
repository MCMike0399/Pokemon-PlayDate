HarnessBuild = {
    protocol = 1,
    session_id = "3d5248b90e324b42a28b126e0fc4fce4",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:40c8327635e7118dd6f3fe4a139e0593c56ac464e98f524ada8e9fb9e7dcd57a",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/live-preflight/frames/",
    bundle_id = "com.poc.pokemon.harness.3d5248b90e324b42a28b126e0fc4fce4",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.3d5248b90e324b42a28b126e0fc4fce4",
}

HarnessBuild = {
    protocol = 1,
    session_id = "92438de2d2804367834e580460156165",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:7cc71c6190c8beccab9b5887d9bbac3349f879eabedc664c34d68819c361af10",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/weather-blanket-defer/frames/",
    bundle_id = "com.poc.pokemon.harness.92438de2d2804367834e580460156165",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.92438de2d2804367834e580460156165",
}

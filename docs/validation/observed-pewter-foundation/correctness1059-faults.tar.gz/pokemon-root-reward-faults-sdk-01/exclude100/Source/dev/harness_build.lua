HarnessBuild = {
    protocol = 1,
    session_id = "f60125b429a9404abd5c568158c34c25",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:5d59a1ddeaeee73f1947515f947a75850b571c4542610fe52620c4fbcb2e8219",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/exclude100/frames/",
    bundle_id = "com.poc.pokemon.harness.f60125b429a9404abd5c568158c34c25",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.f60125b429a9404abd5c568158c34c25",
}

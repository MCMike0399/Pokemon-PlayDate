HarnessBuild = {
    protocol = 1,
    session_id = "808aeb99ae6b4b70bdde2231756af4db",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:18cc3c086e23c0126462df6df4947dd0dc463f350e2e98332dbfbd22b59bc4e5",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/wrong-order/frames/",
    bundle_id = "com.poc.pokemon.harness.808aeb99ae6b4b70bdde2231756af4db",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.808aeb99ae6b4b70bdde2231756af4db",
}

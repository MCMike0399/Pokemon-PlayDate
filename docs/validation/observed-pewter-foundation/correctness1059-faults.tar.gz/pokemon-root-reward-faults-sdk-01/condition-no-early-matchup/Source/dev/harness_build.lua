HarnessBuild = {
    protocol = 1,
    session_id = "5d2a51256ad04f039ec84f1417dda033",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:24db49dc802f5e7a6a996e684942ec88f96d70c04292de4eeb670679c62e4a26",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/condition-no-early-matchup/frames/",
    bundle_id = "com.poc.pokemon.harness.5d2a51256ad04f039ec84f1417dda033",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.5d2a51256ad04f039ec84f1417dda033",
}

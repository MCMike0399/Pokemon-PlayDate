HarnessBuild = {
    protocol = 1,
    session_id = "0ac1d984a8e24be793e57cbe46c7ec97",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:c6767f3c93a901187dc37c72f8e77a0bc4edcc7ceb557aa6c0c2097ebb7dd4f2",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/condition-poison-only/frames/",
    bundle_id = "com.poc.pokemon.harness.0ac1d984a8e24be793e57cbe46c7ec97",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.0ac1d984a8e24be793e57cbe46c7ec97",
}

HarnessBuild = {
    protocol = 1,
    session_id = "15a6b7c721c746cfa073981d507b5106",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:843b31b8867b184176e289dc7c3a4ca4cd6f84280456b16853300086bab2cd8f",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/direct-blanket-defer/frames/",
    bundle_id = "com.poc.pokemon.harness.15a6b7c721c746cfa073981d507b5106",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.15a6b7c721c746cfa073981d507b5106",
}

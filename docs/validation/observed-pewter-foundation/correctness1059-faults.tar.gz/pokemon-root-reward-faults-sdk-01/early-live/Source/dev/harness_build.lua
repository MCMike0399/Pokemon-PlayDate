HarnessBuild = {
    protocol = 1,
    session_id = "dc246e12d7344d07a88eb2eb6188c1e2",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:b78643802979ef62aa38f03918c4b6dbfab801bbb924c1060f3072e696028174",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/early-live/frames/",
    bundle_id = "com.poc.pokemon.harness.dc246e12d7344d07a88eb2eb6188c1e2",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.dc246e12d7344d07a88eb2eb6188c1e2",
}

HarnessBuild = {
    protocol = 1,
    session_id = "404c737e0f72457db38a3f905b43e312",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:38c866739eea9d13b7cd6470075211b0f8c6ba4577a9c070ed4488a9b12f3ddc",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/control/frames/",
    bundle_id = "com.poc.pokemon.harness.404c737e0f72457db38a3f905b43e312",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.404c737e0f72457db38a3f905b43e312",
}

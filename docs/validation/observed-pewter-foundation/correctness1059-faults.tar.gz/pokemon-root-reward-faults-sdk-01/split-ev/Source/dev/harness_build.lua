HarnessBuild = {
    protocol = 1,
    session_id = "363542eba577463b8bfc4c968a9d96a2",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:c77fb72e78d40d650ed6c14601a16a9759d8ed5fe63e9eb4cbaf4dce95a92c9a",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/split-ev/frames/",
    bundle_id = "com.poc.pokemon.harness.363542eba577463b8bfc4c968a9d96a2",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.363542eba577463b8bfc4c968a9d96a2",
}

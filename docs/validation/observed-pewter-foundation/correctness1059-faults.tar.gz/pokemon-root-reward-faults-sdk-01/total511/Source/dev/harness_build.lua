HarnessBuild = {
    protocol = 1,
    session_id = "b4b0ec3dd02b4b3c8ca3f92dfc67dba6",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:29bcc28fc002ccdac11d18d7cea9f4ed3861f12587e6c310c0597ef929758fed",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/total511/frames/",
    bundle_id = "com.poc.pokemon.harness.b4b0ec3dd02b4b3c8ca3f92dfc67dba6",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.b4b0ec3dd02b4b3c8ca3f92dfc67dba6",
}

HarnessBuild = {
    protocol = 1,
    session_id = "5e5b303b61544225b52e87aa4a1ed7d5",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:79440a16fbdf1bec86ca923c6fa208183274f5f21f8c138ad1ab6c7ab29d30a5",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/condition-first-faint-wins/frames/",
    bundle_id = "com.poc.pokemon.harness.5e5b303b61544225b52e87aa4a1ed7d5",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.5e5b303b61544225b52e87aa4a1ed7d5",
}

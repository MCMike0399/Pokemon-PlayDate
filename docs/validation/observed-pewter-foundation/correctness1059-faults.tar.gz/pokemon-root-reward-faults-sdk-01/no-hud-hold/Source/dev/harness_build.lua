HarnessBuild = {
    protocol = 1,
    session_id = "fd446c3efb1e451190e6d84c59c008a4",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:567acd1c3baa7f08f7dea59d27544d97712fda1d4bbf4c2ab3bfde25abd6d949",
    output_dir = "/private/tmp/pokemon-root-reward-faults-sdk-01/no-hud-hold/frames/",
    bundle_id = "com.poc.pokemon.harness.fd446c3efb1e451190e6d84c59c008a4",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.fd446c3efb1e451190e6d84c59c008a4",
}

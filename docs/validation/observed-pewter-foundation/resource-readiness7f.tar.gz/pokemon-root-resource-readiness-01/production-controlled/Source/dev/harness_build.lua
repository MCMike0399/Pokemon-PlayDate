HarnessBuild = {
    protocol = 1,
    session_id = "898b10890a32467e8a5efcefacecc7e6",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:production-probe:3989198a8834ae73b08351961abb57f65e8ca2d265acbee1525bf123c1f9ff0d",
    output_dir = "/private/tmp/pokemon-root-resource-readiness-01/production-controlled/frames/",
    bundle_id = "com.poc.pokemon.productionprobe.898b10890a32467e8a5efcefacecc7e6",
    sdk_version = "3.1.2",
    enabled = false,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.productionprobe.898b10890a32467e8a5efcefacecc7e6",
}

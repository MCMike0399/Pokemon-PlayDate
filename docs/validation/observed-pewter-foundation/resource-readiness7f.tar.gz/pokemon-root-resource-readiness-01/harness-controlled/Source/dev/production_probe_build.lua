ProductionProbeBuild = {
    enabled = true,
    mode = "harness",
    observer = "milestones",
    frames = 1800,
    workload = "controlled",
    run_id = "2d1b275125d94db9b880c2f6fbab9aee",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:production-probe:3989198a8834ae73b08351961abb57f65e8ca2d265acbee1525bf123c1f9ff0d",
    bundle_id = "com.poc.pokemon.productionprobe.2d1b275125d94db9b880c2f6fbab9aee",
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.productionprobe.2d1b275125d94db9b880c2f6fbab9aee",
    sdk_version = "3.1.2",
}

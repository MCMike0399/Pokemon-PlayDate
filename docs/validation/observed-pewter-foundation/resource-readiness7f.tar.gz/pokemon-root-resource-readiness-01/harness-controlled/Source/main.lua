import "dev/production_probe_build"
import "dev/productionProbe"
ProductionProbe.importMark("before-import:1:CoreLibs/object")
import "CoreLibs/object"
ProductionProbe.importMark("after-import:1:CoreLibs/object")
ProductionProbe.importMark("before-import:2:CoreLibs/graphics")
import "CoreLibs/graphics"
ProductionProbe.importMark("after-import:2:CoreLibs/graphics")
ProductionProbe.importMark("before-import:3:CoreLibs/sprites")
import "CoreLibs/sprites"
ProductionProbe.importMark("after-import:3:CoreLibs/sprites")
ProductionProbe.importMark("before-import:4:CoreLibs/timer")
import "CoreLibs/timer"
ProductionProbe.importMark("after-import:4:CoreLibs/timer")
ProductionProbe.importMark("before-import:5:CoreLibs/frameTimer")
import "CoreLibs/frameTimer"
ProductionProbe.importMark("after-import:5:CoreLibs/frameTimer")

ProductionProbe.importMark("before-import:6:lib/oop")
import "lib/oop"
ProductionProbe.importMark("after-import:6:lib/oop")
ProductionProbe.importMark("before-import:7:lib/rng")
import "lib/rng"
ProductionProbe.importMark("after-import:7:lib/rng")
ProductionProbe.importMark("before-import:8:lib/shade")
import "lib/shade"
ProductionProbe.importMark("after-import:8:lib/shade")
ProductionProbe.importMark("before-import:9:lib/statemachine")
import "lib/statemachine"
ProductionProbe.importMark("after-import:9:lib/statemachine")
ProductionProbe.importMark("before-import:10:world/tilefactory")
import "world/tilefactory"
ProductionProbe.importMark("after-import:10:world/tilefactory")
ProductionProbe.importMark("before-import:11:world/tileRegistry")
import "world/tileRegistry"
ProductionProbe.importMark("after-import:11:world/tileRegistry")
ProductionProbe.importMark("before-import:12:world/spritefactory")
import "world/spritefactory"
ProductionProbe.importMark("after-import:12:world/spritefactory")
ProductionProbe.importMark("before-import:13:world/zone")
import "world/zone"
ProductionProbe.importMark("after-import:13:world/zone")
ProductionProbe.importMark("before-import:14:data/individualData")
import "data/individualData"
ProductionProbe.importMark("after-import:14:data/individualData")
ProductionProbe.importMark("before-import:15:domain/individualStats")
import "domain/individualStats"
ProductionProbe.importMark("after-import:15:domain/individualStats")
ProductionProbe.importMark("before-import:16:data/pokemon")
import "data/pokemon"
ProductionProbe.importMark("after-import:16:data/pokemon")
ProductionProbe.importMark("before-import:17:data/pokemonArt")
import "data/pokemonArt"
ProductionProbe.importMark("after-import:17:data/pokemonArt")
ProductionProbe.importMark("before-import:18:domain/party")
import "domain/party"
ProductionProbe.importMark("after-import:18:domain/party")
ProductionProbe.importMark("before-import:19:domain/storage")
import "domain/storage"
ProductionProbe.importMark("after-import:19:domain/storage")
ProductionProbe.importMark("before-import:20:domain/inventory")
import "domain/inventory"
ProductionProbe.importMark("after-import:20:domain/inventory")
ProductionProbe.importMark("before-import:21:data/typechart")
import "data/typechart"
ProductionProbe.importMark("after-import:21:data/typechart")
ProductionProbe.importMark("before-import:22:battle/dsl")
import "battle/dsl"
ProductionProbe.importMark("after-import:22:battle/dsl")
ProductionProbe.importMark("before-import:23:battle/moves")
import "battle/moves"
ProductionProbe.importMark("after-import:23:battle/moves")
ProductionProbe.importMark("before-import:24:domain/pokemonCodec")
import "domain/pokemonCodec"
ProductionProbe.importMark("after-import:24:domain/pokemonCodec")
ProductionProbe.importMark("before-import:25:domain/saveStore")
import "domain/saveStore"
ProductionProbe.importMark("after-import:25:domain/saveStore")
ProductionProbe.importMark("before-import:26:data/items")
import "data/items"
ProductionProbe.importMark("after-import:26:data/items")
ProductionProbe.importMark("before-import:27:data/lightBall")
import "data/lightBall"
ProductionProbe.importMark("after-import:27:data/lightBall")
ProductionProbe.importMark("before-import:28:domain/items")
import "domain/items"
ProductionProbe.importMark("after-import:28:domain/items")
ProductionProbe.importMark("before-import:29:domain/worldMotion")
import "domain/worldMotion"
ProductionProbe.importMark("after-import:29:domain/worldMotion")
ProductionProbe.importMark("before-import:30:domain/itemStorage")
import "domain/itemStorage"
ProductionProbe.importMark("after-import:30:domain/itemStorage")
ProductionProbe.importMark("before-import:31:domain/pcItems")
import "domain/pcItems"
ProductionProbe.importMark("after-import:31:domain/pcItems")
ProductionProbe.importMark("before-import:32:domain/gameSession")
import "domain/gameSession"
ProductionProbe.importMark("after-import:32:domain/gameSession")
ProductionProbe.importMark("before-import:33:domain/teaching")
import "domain/teaching"
ProductionProbe.importMark("after-import:33:domain/teaching")
ProductionProbe.importMark("before-import:34:domain/sessionCodec")
import "domain/sessionCodec"
ProductionProbe.importMark("after-import:34:domain/sessionCodec")
ProductionProbe.importMark("before-import:35:data/captureData")
import "data/captureData"
ProductionProbe.importMark("after-import:35:data/captureData")
ProductionProbe.importMark("before-import:36:domain/capture")
import "domain/capture"
ProductionProbe.importMark("after-import:36:domain/capture")
ProductionProbe.importMark("before-import:37:ui/dialog")
import "ui/dialog"
ProductionProbe.importMark("after-import:37:ui/dialog")
ProductionProbe.importMark("before-import:38:ui/menu")
import "ui/menu"
ProductionProbe.importMark("after-import:38:ui/menu")
ProductionProbe.importMark("before-import:39:ui/debug")
import "ui/debug"
ProductionProbe.importMark("after-import:39:ui/debug")
ProductionProbe.importMark("before-import:40:world/camera")
import "world/camera"
ProductionProbe.importMark("after-import:40:world/camera")
ProductionProbe.importMark("before-import:41:world/npc")
import "world/npc"
ProductionProbe.importMark("after-import:41:world/npc")
ProductionProbe.importMark("before-import:42:world/player")
import "world/player"
ProductionProbe.importMark("after-import:42:world/player")
ProductionProbe.importMark("before-import:43:world/overworld")
import "world/overworld"
ProductionProbe.importMark("after-import:43:world/overworld")
ProductionProbe.importMark("before-import:44:battle/battle")
import "battle/battle"
ProductionProbe.importMark("after-import:44:battle/battle")
ProductionProbe.importMark("before-import:45:battle/battleScene")
import "battle/battleScene"
ProductionProbe.importMark("after-import:45:battle/battleScene")
ProductionProbe.importMark("before-import:46:game/story")
import "game/story"
ProductionProbe.importMark("after-import:46:game/story")
ProductionProbe.importMark("before-import:47:data/maps")
import "data/maps"
ProductionProbe.importMark("after-import:47:data/maps")
ProductionProbe.importMark("before-import:48:game/context")
import "game/context"
ProductionProbe.importMark("after-import:48:game/context")
ProductionProbe.importMark("before-import:49:game/overworldState")
import "game/overworldState"
ProductionProbe.importMark("after-import:49:game/overworldState")
ProductionProbe.importMark("before-import:50:game/dialogState")
import "game/dialogState"
ProductionProbe.importMark("after-import:50:game/dialogState")
ProductionProbe.importMark("before-import:51:game/battleState")
import "game/battleState"
ProductionProbe.importMark("after-import:51:game/battleState")
ProductionProbe.importMark("before-import:52:game/debugState")
import "game/debugState"
ProductionProbe.importMark("after-import:52:game/debugState")
ProductionProbe.importMark("before-import:53:game/learningState")
import "game/learningState"
ProductionProbe.importMark("after-import:53:game/learningState")
ProductionProbe.importMark("before-import:54:game/saves")
import "game/saves"
ProductionProbe.importMark("after-import:54:game/saves")
ProductionProbe.importMark("before-import:55:game/titleState")
import "game/titleState"
ProductionProbe.importMark("after-import:55:game/titleState")
ProductionProbe.importMark("before-import:56:game/pauseState")
import "game/pauseState"
ProductionProbe.importMark("after-import:56:game/pauseState")
ProductionProbe.importMark("before-import:57:game/partyState")
import "game/partyState"
ProductionProbe.importMark("after-import:57:game/partyState")
ProductionProbe.importMark("before-import:58:game/bagState")
import "game/bagState"
ProductionProbe.importMark("after-import:58:game/bagState")
ProductionProbe.importMark("before-import:59:game/shopState")
import "game/shopState"
ProductionProbe.importMark("after-import:59:game/shopState")
ProductionProbe.importMark("before-import:60:data/pilotWorld")
import "data/pilotWorld"
ProductionProbe.importMark("after-import:60:data/pilotWorld")
ProductionProbe.importMark("before-import:61:world/sliceEvents")
import "world/sliceEvents"
ProductionProbe.importMark("after-import:61:world/sliceEvents")
ProductionProbe.importMark("before-import:62:world/sliceSprites")
import "world/sliceSprites"
ProductionProbe.importMark("after-import:62:world/sliceSprites")
ProductionProbe.importMark("before-import:63:world/mapBindings")
import "world/mapBindings"
ProductionProbe.importMark("after-import:63:world/mapBindings")
ProductionProbe.importMark("before-import:64:data/viridianSlice")
import "data/viridianSlice"
ProductionProbe.importMark("after-import:64:data/viridianSlice")
ProductionProbe.importMark("before-import:65:data/pewterSlice")
import "data/pewterSlice"
ProductionProbe.importMark("after-import:65:data/pewterSlice")
ProductionProbe.importMark("before-import:66:world/importedMaps")
import "world/importedMaps"
ProductionProbe.importMark("after-import:66:world/importedMaps")
ProductionProbe.importMark("before-import:67:world/pewterSprites")
import "world/pewterSprites"
ProductionProbe.importMark("after-import:67:world/pewterSprites")
ProductionProbe.importMark("before-import:68:game/trainerEvents")
import "game/trainerEvents"
ProductionProbe.importMark("after-import:68:game/trainerEvents")
ProductionProbe.importMark("before-import:69:game/pewterEvents")
import "game/pewterEvents"
ProductionProbe.importMark("after-import:69:game/pewterEvents")
ProductionProbe.importMark("before-import:70:world/pewterBindings")
import "world/pewterBindings"
ProductionProbe.importMark("after-import:70:world/pewterBindings")
ProductionProbe.importMark("before-import:71:game/pewterWorld")
import "game/pewterWorld"
ProductionProbe.importMark("after-import:71:game/pewterWorld")
ProductionProbe.importMark("before-import:72:world/sourceActors")
import "world/sourceActors"
ProductionProbe.importMark("after-import:72:world/sourceActors")
ProductionProbe.importMark("before-import:73:world/npcMotion")
import "world/npcMotion"
ProductionProbe.importMark("after-import:73:world/npcMotion")
ProductionProbe.importMark("before-import:74:game/kantoWorld")
import "game/kantoWorld"
ProductionProbe.importMark("after-import:74:game/kantoWorld")
ProductionProbe.importMark("before-import:75:game/eventText")
import "game/eventText"
ProductionProbe.importMark("after-import:75:game/eventText")
ProductionProbe.importMark("before-import:76:game/eventArt")
import "game/eventArt"
ProductionProbe.importMark("after-import:76:game/eventArt")
ProductionProbe.importMark("before-import:77:game/healingComposition")
import "game/healingComposition"
ProductionProbe.importMark("after-import:77:game/healingComposition")
ProductionProbe.importMark("before-import:78:game/eventState")
import "game/eventState"
ProductionProbe.importMark("after-import:78:game/eventState")
ProductionProbe.importMark("before-import:79:game/pokedexState")
import "game/pokedexState"
ProductionProbe.importMark("after-import:79:game/pokedexState")
ProductionProbe.importMark("before-import:80:game/pcState")
import "game/pcState"
ProductionProbe.importMark("after-import:80:game/pcState")
ProductionProbe.importMark("before-import:81:game/evolutionState")
import "game/evolutionState"
ProductionProbe.importMark("after-import:81:game/evolutionState")
ProductionProbe.importMark("before-import:82:world/pcTerminals")
import "world/pcTerminals"
ProductionProbe.importMark("after-import:82:world/pcTerminals")
ProductionProbe.mark("before-development-region")
ProductionProbe.importMark("before-import:83:dev/sliceCatalog")
import "dev/sliceCatalog"
ProductionProbe.importMark("after-import:83:dev/sliceCatalog")
ProductionProbe.importMark("before-import:84:dev/sliceContracts")
import "dev/sliceContracts"
ProductionProbe.importMark("after-import:84:dev/sliceContracts")
ProductionProbe.importMark("before-import:85:dev/worldContracts")
import "dev/worldContracts"
ProductionProbe.importMark("after-import:85:dev/worldContracts")
ProductionProbe.importMark("before-import:86:dev/contracts")
import "dev/contracts"
ProductionProbe.importMark("after-import:86:dev/contracts")
ProductionProbe.importMark("before-import:87:dev/learnsetContracts")
import "dev/learnsetContracts"
ProductionProbe.importMark("after-import:87:dev/learnsetContracts")
ProductionProbe.importMark("before-import:88:dev/partyContracts")
import "dev/partyContracts"
ProductionProbe.importMark("after-import:88:dev/partyContracts")
ProductionProbe.importMark("before-import:89:dev/learningContracts")
import "dev/learningContracts"
ProductionProbe.importMark("after-import:89:dev/learningContracts")
ProductionProbe.importMark("before-import:90:dev/saveContracts")
import "dev/saveContracts"
ProductionProbe.importMark("after-import:90:dev/saveContracts")
ProductionProbe.importMark("before-import:91:dev/combatContracts")
import "dev/combatContracts"
ProductionProbe.importMark("after-import:91:dev/combatContracts")
ProductionProbe.importMark("before-import:92:dev/rngPersistenceContracts")
import "dev/rngPersistenceContracts"
ProductionProbe.importMark("after-import:92:dev/rngPersistenceContracts")
ProductionProbe.importMark("before-import:93:dev/growthContracts")
import "dev/growthContracts"
ProductionProbe.importMark("after-import:93:dev/growthContracts")
ProductionProbe.importMark("before-import:94:dev/itemContracts")
import "dev/itemContracts"
ProductionProbe.importMark("after-import:94:dev/itemContracts")
ProductionProbe.importMark("before-import:95:dev/sessionContracts")
import "dev/sessionContracts"
ProductionProbe.importMark("after-import:95:dev/sessionContracts")
ProductionProbe.importMark("before-import:96:dev/captureContracts")
import "dev/captureContracts"
ProductionProbe.importMark("after-import:96:dev/captureContracts")
ProductionProbe.importMark("before-import:97:dev/sessionBridgeContracts")
import "dev/sessionBridgeContracts"
ProductionProbe.importMark("after-import:97:dev/sessionBridgeContracts")
ProductionProbe.importMark("before-import:98:dev/partyBattleContracts")
import "dev/partyBattleContracts"
ProductionProbe.importMark("after-import:98:dev/partyBattleContracts")
ProductionProbe.importMark("before-import:99:dev/shopContracts")
import "dev/shopContracts"
ProductionProbe.importMark("after-import:99:dev/shopContracts")
ProductionProbe.importMark("before-import:100:dev/captureAnimationContracts")
import "dev/captureAnimationContracts"
ProductionProbe.importMark("after-import:100:dev/captureAnimationContracts")
ProductionProbe.importMark("before-import:101:dev/traversalContracts")
import "dev/traversalContracts"
ProductionProbe.importMark("after-import:101:dev/traversalContracts")
ProductionProbe.importMark("before-import:102:dev/eventContracts")
import "dev/eventContracts"
ProductionProbe.importMark("after-import:102:dev/eventContracts")
ProductionProbe.importMark("before-import:103:dev/eventCatalogContracts")
import "dev/eventCatalogContracts"
ProductionProbe.importMark("after-import:103:dev/eventCatalogContracts")
ProductionProbe.importMark("before-import:104:dev/pokedexContracts")
import "dev/pokedexContracts"
ProductionProbe.importMark("after-import:104:dev/pokedexContracts")
ProductionProbe.importMark("before-import:105:dev/earlyCombatContracts")
import "dev/earlyCombatContracts"
ProductionProbe.importMark("after-import:105:dev/earlyCombatContracts")
ProductionProbe.importMark("before-import:106:dev/runtimeArtContracts")
import "dev/runtimeArtContracts"
ProductionProbe.importMark("after-import:106:dev/runtimeArtContracts")
ProductionProbe.importMark("before-import:107:dev/pcContracts")
import "dev/pcContracts"
ProductionProbe.importMark("after-import:107:dev/pcContracts")
ProductionProbe.importMark("before-import:108:dev/evolutionContracts")
import "dev/evolutionContracts"
ProductionProbe.importMark("after-import:108:dev/evolutionContracts")
ProductionProbe.importMark("before-import:109:dev/healingCompositionContracts")
import "dev/healingCompositionContracts"
ProductionProbe.importMark("after-import:109:dev/healingCompositionContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"learnsets\", LearnsetContracts.run)")
Contracts.register("learnsets", LearnsetContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"learnsets\", LearnsetContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"collections\", PartyContracts.run)")
Contracts.register("collections", PartyContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"collections\", PartyContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"learning\", LearningContracts.run)")
Contracts.register("learning", LearningContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"learning\", LearningContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"persistence\", SaveContracts.run)")
Contracts.register("persistence", SaveContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"persistence\", SaveContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"combat\", CombatContracts.run)")
Contracts.register("combat", CombatContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"combat\", CombatContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"rng-persistence\", RNGPersistenceContracts.run)")
Contracts.register("rng-persistence", RNGPersistenceContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"rng-persistence\", RNGPersistenceContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"world\", WorldContracts.run)")
Contracts.register("world", WorldContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"world\", WorldContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"growth\", GrowthContracts.run)")
Contracts.register("growth", GrowthContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"growth\", GrowthContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"items\", ItemContracts.run)")
Contracts.register("items", ItemContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"items\", ItemContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"session\", SessionContracts.run)")
Contracts.register("session", SessionContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"session\", SessionContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"capture\", CaptureContracts.run)")
Contracts.register("capture", CaptureContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"capture\", CaptureContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"viridian-slice\", SliceContracts.run)")
Contracts.register("viridian-slice", SliceContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"viridian-slice\", SliceContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"session-bridge\", SessionBridgeContracts.run)")
Contracts.register("session-bridge", SessionBridgeContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"session-bridge\", SessionBridgeContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"party-battle\", PartyBattleContracts.run)")
Contracts.register("party-battle", PartyBattleContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"party-battle\", PartyBattleContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"shop\", ShopContracts.run)")
Contracts.register("shop", ShopContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"shop\", ShopContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"capture-animation\", CaptureAnimationContracts.run)")
Contracts.register("capture-animation", CaptureAnimationContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"capture-animation\", CaptureAnimationContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"traversal\", TraversalContracts.run)")
Contracts.register("traversal", TraversalContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"traversal\", TraversalContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"event-ui\", EventContracts.run)")
Contracts.register("event-ui", EventContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"event-ui\", EventContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"event-catalog\", EventCatalogContracts.run)")
Contracts.register("event-catalog", EventCatalogContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"event-catalog\", EventCatalogContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"pokedex\", PokedexContracts.run)")
Contracts.register("pokedex", PokedexContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"pokedex\", PokedexContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"early-combat\", EarlyCombatContracts.run)")
Contracts.register("early-combat", EarlyCombatContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"early-combat\", EarlyCombatContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"runtime-art\", RuntimeArtContracts.run)")
Contracts.register("runtime-art", RuntimeArtContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"runtime-art\", RuntimeArtContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"pc-ui\", PCContracts.run)")
Contracts.register("pc-ui", PCContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"pc-ui\", PCContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"evolution\", EvolutionContracts.run)")
Contracts.register("evolution", EvolutionContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"evolution\", EvolutionContracts.run)")
ProductionProbe.importMark("before-call:Contracts.register(\"healing-composition\", HealingCompositionContracts.run)")
Contracts.register("healing-composition", HealingCompositionContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"healing-composition\", HealingCompositionContracts.run)")
ProductionProbe.importMark("before-import:110:dev/trainerContracts")
import "dev/trainerContracts"
ProductionProbe.importMark("after-import:110:dev/trainerContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"trainerContracts\", TrainerContracts.run)")
Contracts.register("trainerContracts", TrainerContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"trainerContracts\", TrainerContracts.run)")
ProductionProbe.importMark("before-import:111:dev/pewterProviderContracts")
import "dev/pewterProviderContracts"
ProductionProbe.importMark("after-import:111:dev/pewterProviderContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"pewterProviderContracts\", PewterProviderContracts.run)")
Contracts.register("pewterProviderContracts", PewterProviderContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"pewterProviderContracts\", PewterProviderContracts.run)")
ProductionProbe.importMark("before-import:112:dev/pewterInstallContracts")
import "dev/pewterInstallContracts"
ProductionProbe.importMark("after-import:112:dev/pewterInstallContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"pewterInstallContracts\", PewterInstallContracts.run)")
Contracts.register("pewterInstallContracts", PewterInstallContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"pewterInstallContracts\", PewterInstallContracts.run)")
ProductionProbe.importMark("before-import:113:dev/eventReceiptContracts")
import "dev/eventReceiptContracts"
ProductionProbe.importMark("after-import:113:dev/eventReceiptContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"eventReceiptContracts\", EventReceiptContracts.run)")
Contracts.register("eventReceiptContracts", EventReceiptContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"eventReceiptContracts\", EventReceiptContracts.run)")
ProductionProbe.importMark("before-import:114:dev/battleLearningContracts")
import "dev/battleLearningContracts"
ProductionProbe.importMark("after-import:114:dev/battleLearningContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"battleLearningContracts\", BattleLearningContracts.run)")
Contracts.register("battleLearningContracts", BattleLearningContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"battleLearningContracts\", BattleLearningContracts.run)")
ProductionProbe.importMark("before-import:115:dev/battleLearningEvolutionContracts")
import "dev/battleLearningEvolutionContracts"
ProductionProbe.importMark("after-import:115:dev/battleLearningEvolutionContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"battleLearningEvolutionContracts\", BattleLearningEvolutionContracts.run)")
Contracts.register("battleLearningEvolutionContracts", BattleLearningEvolutionContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"battleLearningEvolutionContracts\", BattleLearningEvolutionContracts.run)")
ProductionProbe.importMark("before-import:116:dev/battleItemContracts")
import "dev/battleItemContracts"
ProductionProbe.importMark("after-import:116:dev/battleItemContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"battle-items\", BattleItemContracts.run)")
Contracts.register("battle-items", BattleItemContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"battle-items\", BattleItemContracts.run)")
ProductionProbe.importMark("before-import:117:dev/residualRewardProbe")
import "dev/residualRewardProbe"
ProductionProbe.importMark("after-import:117:dev/residualRewardProbe")
ProductionProbe.importMark("before-call:Contracts.register(\"native-condition-witness\",ResidualRewardProbe.run)")
Contracts.register("native-condition-witness",ResidualRewardProbe.run)
ProductionProbe.importMark("after-call:Contracts.register(\"native-condition-witness\",ResidualRewardProbe.run)")
ProductionProbe.importMark("before-import:118:dev/conditionCheckpointContracts")
import "dev/conditionCheckpointContracts"
ProductionProbe.importMark("after-import:118:dev/conditionCheckpointContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"condition-checkpoints-v1\",ConditionCheckpointContracts.run)")
Contracts.register("condition-checkpoints-v1",ConditionCheckpointContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"condition-checkpoints-v1\",ConditionCheckpointContracts.run)")
ProductionProbe.importMark("before-import:119:dev/rewardContracts")
import "dev/rewardContracts"
ProductionProbe.importMark("after-import:119:dev/rewardContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"battle-rewards-v1\", RewardContracts.run)")
Contracts.register("battle-rewards-v1", RewardContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"battle-rewards-v1\", RewardContracts.run)")
ProductionProbe.importMark("before-import:120:dev/individualContracts")
import "dev/individualContracts"
ProductionProbe.importMark("after-import:120:dev/individualContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"individual-stats-v1\", IndividualContracts.run)")
Contracts.register("individual-stats-v1", IndividualContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"individual-stats-v1\", IndividualContracts.run)")
ProductionProbe.importMark("before-import:121:dev/specimenContracts")
import "dev/specimenContracts"
ProductionProbe.importMark("after-import:121:dev/specimenContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"specimenContracts\", SpecimenContracts.run)")
Contracts.register("specimenContracts", SpecimenContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"specimenContracts\", SpecimenContracts.run)")
ProductionProbe.importMark("before-import:122:dev/specimenTrainerContracts")
import "dev/specimenTrainerContracts"
ProductionProbe.importMark("after-import:122:dev/specimenTrainerContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"specimenTrainerContracts\", SpecimenTrainerContracts.run)")
Contracts.register("specimenTrainerContracts", SpecimenTrainerContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"specimenTrainerContracts\", SpecimenTrainerContracts.run)")
ProductionProbe.importMark("before-import:123:dev/specimenOwnershipContracts")
import "dev/specimenOwnershipContracts"
ProductionProbe.importMark("after-import:123:dev/specimenOwnershipContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"specimen-ownership\", SpecimenOwnershipContracts.run)")
Contracts.register("specimen-ownership", SpecimenOwnershipContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"specimen-ownership\", SpecimenOwnershipContracts.run)")
ProductionProbe.importMark("before-import:124:dev/npcMotionContracts")
import "dev/npcMotionContracts"
ProductionProbe.importMark("after-import:124:dev/npcMotionContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"npcMotionContracts\", NPCMotionContracts.run)")
Contracts.register("npcMotionContracts", NPCMotionContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"npcMotionContracts\", NPCMotionContracts.run)")
ProductionProbe.importMark("before-import:125:dev/npcMotionLegacyContracts")
import "dev/npcMotionLegacyContracts"
ProductionProbe.importMark("after-import:125:dev/npcMotionLegacyContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"npcMotionLegacyContracts\", NPCMotionLegacyContracts.run)")
Contracts.register("npcMotionLegacyContracts", NPCMotionLegacyContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"npcMotionLegacyContracts\", NPCMotionLegacyContracts.run)")
ProductionProbe.importMark("before-import:126:dev/worldViewRollbackContracts")
import "dev/worldViewRollbackContracts"
ProductionProbe.importMark("after-import:126:dev/worldViewRollbackContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"worldViewRollbackContracts\", WorldViewRollbackContracts.run)")
Contracts.register("worldViewRollbackContracts", WorldViewRollbackContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"worldViewRollbackContracts\", WorldViewRollbackContracts.run)")
ProductionProbe.importMark("before-import:127:dev/heldItemContracts")
import "dev/heldItemContracts"
ProductionProbe.importMark("after-import:127:dev/heldItemContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"held-items\", HeldItemContracts.run)")
Contracts.register("held-items", HeldItemContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"held-items\", HeldItemContracts.run)")
ProductionProbe.importMark("before-import:128:dev/heldLifecycleContracts")
import "dev/heldLifecycleContracts"
ProductionProbe.importMark("after-import:128:dev/heldLifecycleContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"held-lifecycle\", HeldLifecycleContracts.run)")
Contracts.register("held-lifecycle", HeldLifecycleContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"held-lifecycle\", HeldLifecycleContracts.run)")
ProductionProbe.importMark("before-import:129:dev/abilityContracts")
import "dev/abilityContracts"
ProductionProbe.importMark("after-import:129:dev/abilityContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"early-abilities\", AbilityContracts.run)")
Contracts.register("early-abilities", AbilityContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"early-abilities\", AbilityContracts.run)")
ProductionProbe.importMark("before-import:130:dev/abilityCompatibilityContracts")
import "dev/abilityCompatibilityContracts"
ProductionProbe.importMark("after-import:130:dev/abilityCompatibilityContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"ability-compatibility\", AbilityCompatibilityContracts.run)")
Contracts.register("ability-compatibility", AbilityCompatibilityContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"ability-compatibility\", AbilityCompatibilityContracts.run)")
ProductionProbe.importMark("before-import:131:dev/brockMechanicsContracts")
import "dev/brockMechanicsContracts"
ProductionProbe.importMark("after-import:131:dev/brockMechanicsContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"brock-mechanics\", BrockMechanicsContracts.run)")
Contracts.register("brock-mechanics", BrockMechanicsContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"brock-mechanics\", BrockMechanicsContracts.run)")
ProductionProbe.importMark("before-import:132:game/townMapState")
import "game/townMapState"
ProductionProbe.importMark("after-import:132:game/townMapState")
ProductionProbe.importMark("before-import:133:game/fieldItems")
import "game/fieldItems"
ProductionProbe.importMark("after-import:133:game/fieldItems")
ProductionProbe.importMark("before-import:134:dev/brockMoveBatchContracts")
import "dev/brockMoveBatchContracts"
ProductionProbe.importMark("after-import:134:dev/brockMoveBatchContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"brock-move-batch01\", BrockMoveBatchContracts.run)")
Contracts.register("brock-move-batch01", BrockMoveBatchContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"brock-move-batch01\", BrockMoveBatchContracts.run)")
ProductionProbe.importMark("before-import:135:dev/brockMoveBatchErrataContracts")
import "dev/brockMoveBatchErrataContracts"
ProductionProbe.importMark("after-import:135:dev/brockMoveBatchErrataContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"brock-move-batch01-errata\", BrockMoveBatchErrataContracts.run)")
Contracts.register("brock-move-batch01-errata", BrockMoveBatchErrataContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"brock-move-batch01-errata\", BrockMoveBatchErrataContracts.run)")
ProductionProbe.importMark("before-import:136:dev/bideContracts")
import "dev/bideContracts"
ProductionProbe.importMark("after-import:136:dev/bideContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"bide\", BideContracts.run)")
Contracts.register("bide", BideContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"bide\", BideContracts.run)")
ProductionProbe.importMark("before-import:137:dev/traitContracts")
import "dev/traitContracts"
ProductionProbe.importMark("after-import:137:dev/traitContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"specimen-sex-light-ball\", TraitContracts.run)")
Contracts.register("specimen-sex-light-ball", TraitContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"specimen-sex-light-ball\", TraitContracts.run)")
ProductionProbe.importMark("before-import:138:dev/teachingContracts")
import "dev/teachingContracts"
ProductionProbe.importMark("after-import:138:dev/teachingContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"teaching\",TeachingContracts.run)")
Contracts.register("teaching",TeachingContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"teaching\",TeachingContracts.run)")
ProductionProbe.importMark("before-import:139:dev/bideTeachingContracts")
import "dev/bideTeachingContracts"
ProductionProbe.importMark("after-import:139:dev/bideTeachingContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"bide-teaching\", BideTeachingContracts.run)")
Contracts.register("bide-teaching", BideTeachingContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"bide-teaching\", BideTeachingContracts.run)")
ProductionProbe.importMark("before-import:140:dev/fieldItemContracts")
import "dev/fieldItemContracts"
ProductionProbe.importMark("after-import:140:dev/fieldItemContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"brock-field-items\",FieldItemContracts.run)")
Contracts.register("brock-field-items",FieldItemContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"brock-field-items\",FieldItemContracts.run)")
ProductionProbe.importMark("before-import:141:dev/sexAbilityContracts")
import "dev/sexAbilityContracts"
ProductionProbe.importMark("after-import:141:dev/sexAbilityContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"sex-abilities\",SexAbilityContracts.run)")
Contracts.register("sex-abilities",SexAbilityContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"sex-abilities\",SexAbilityContracts.run)")
ProductionProbe.importMark("before-import:142:dev/ownTempoContracts")
import "dev/ownTempoContracts"
ProductionProbe.importMark("after-import:142:dev/ownTempoContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"own-tempo\",OwnTempoContracts.run)")
Contracts.register("own-tempo",OwnTempoContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"own-tempo\",OwnTempoContracts.run)")
ProductionProbe.importMark("before-import:143:dev/chargeLockContracts")
import "dev/chargeLockContracts"
ProductionProbe.importMark("after-import:143:dev/chargeLockContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"charge-lock\",ChargeLockContracts.run)")
Contracts.register("charge-lock",ChargeLockContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"charge-lock\",ChargeLockContracts.run)")
ProductionProbe.importMark("before-import:144:dev/chargeOwnTempoContracts")
import "dev/chargeOwnTempoContracts"
ProductionProbe.importMark("after-import:144:dev/chargeOwnTempoContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"charge-own-tempo\",ChargeOwnTempoContracts.run)")
Contracts.register("charge-own-tempo",ChargeOwnTempoContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"charge-own-tempo\",ChargeOwnTempoContracts.run)")
ProductionProbe.importMark("before-import:145:dev/powerOrderContracts")
import "dev/powerOrderContracts"
ProductionProbe.importMark("after-import:145:dev/powerOrderContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"basepower-order\",PowerOrderContracts.run)")
Contracts.register("basepower-order",PowerOrderContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"basepower-order\",PowerOrderContracts.run)")
ProductionProbe.importMark("before-import:146:dev/rainContracts")
import "dev/rainContracts"
ProductionProbe.importMark("after-import:146:dev/rainContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"rain\",RainContracts.run)")
Contracts.register("rain",RainContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"rain\",RainContracts.run)")
ProductionProbe.importMark("before-import:147:dev/worrySeedContracts")
import "dev/worrySeedContracts"
ProductionProbe.importMark("after-import:147:dev/worrySeedContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"worry-seed\",WorrySeedContracts.run)")
Contracts.register("worry-seed",WorrySeedContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"worry-seed\",WorrySeedContracts.run)")
ProductionProbe.importMark("before-import:148:dev/brockIntegrationContracts")
import "dev/brockIntegrationContracts"
ProductionProbe.importMark("after-import:148:dev/brockIntegrationContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"brock-integration\",BrockIntegrationContracts.run)")
Contracts.register("brock-integration",BrockIntegrationContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"brock-integration\",BrockIntegrationContracts.run)")
ProductionProbe.importMark("before-import:149:dev/protectContracts")
import "dev/protectContracts"
ProductionProbe.importMark("after-import:149:dev/protectContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"protect\",ProtectContracts.run)")
Contracts.register("protect",ProtectContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"protect\",ProtectContracts.run)")
ProductionProbe.importMark("before-import:150:dev/sideContracts")
import "dev/sideContracts"
ProductionProbe.importMark("after-import:150:dev/sideContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"sides\",SideContracts.run)")
Contracts.register("sides",SideContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"sides\",SideContracts.run)")
ProductionProbe.importMark("before-import:151:dev/roostContracts")
import "dev/roostContracts"
ProductionProbe.importMark("after-import:151:dev/roostContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"roost\",RoostContracts.run)")
Contracts.register("roost",RoostContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"roost\",RoostContracts.run)")
ProductionProbe.importMark("before-import:152:dev/roostPredicateContracts")
import "dev/roostPredicateContracts"
ProductionProbe.importMark("after-import:152:dev/roostPredicateContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"roost-predicates\",RoostPredicateContracts.run)")
Contracts.register("roost-predicates",RoostPredicateContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"roost-predicates\",RoostPredicateContracts.run)")
ProductionProbe.importMark("before-import:153:dev/poisonFangContracts")
import "dev/poisonFangContracts"
ProductionProbe.importMark("after-import:153:dev/poisonFangContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"poison-fang\",PoisonFangContracts.run)")
Contracts.register("poison-fang",PoisonFangContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"poison-fang\",PoisonFangContracts.run)")
ProductionProbe.importMark("before-import:154:dev/secondaryContracts")
import "dev/secondaryContracts"
ProductionProbe.importMark("after-import:154:dev/secondaryContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"secondaries\",SecondaryContracts.run)")
Contracts.register("secondaries",SecondaryContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"secondaries\",SecondaryContracts.run)")
ProductionProbe.importMark("before-import:155:dev/catalog")
import "dev/catalog"
ProductionProbe.importMark("after-import:155:dev/catalog")
ProductionProbe.importMark("before-import:156:dev/pewterCatalogExporter")
import "dev/pewterCatalogExporter"
ProductionProbe.importMark("after-import:156:dev/pewterCatalogExporter")
ProductionProbe.importMark("before-call:PewterCatalogExporter.register()")
PewterCatalogExporter.register()
ProductionProbe.importMark("after-call:PewterCatalogExporter.register()")
ProductionProbe.importMark("before-import:157:dev/comprehensiveCatalogContracts")
import "dev/comprehensiveCatalogContracts"
ProductionProbe.importMark("after-import:157:dev/comprehensiveCatalogContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"comprehensive-catalog\", ComprehensiveCatalogContracts.run)")
Contracts.register("comprehensive-catalog", ComprehensiveCatalogContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"comprehensive-catalog\", ComprehensiveCatalogContracts.run)")
ProductionProbe.importMark("before-import:158:dev/catalogMotionContracts")
import "dev/catalogMotionContracts"
ProductionProbe.importMark("after-import:158:dev/catalogMotionContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"catalog-motion\", CatalogMotionContracts.run)")
Contracts.register("catalog-motion", CatalogMotionContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"catalog-motion\", CatalogMotionContracts.run)")
ProductionProbe.importMark("before-import:159:dev/catalogAbilityContracts")
import "dev/catalogAbilityContracts"
ProductionProbe.importMark("after-import:159:dev/catalogAbilityContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"catalog-ability\", CatalogAbilityContracts.run)")
Contracts.register("catalog-ability", CatalogAbilityContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"catalog-ability\", CatalogAbilityContracts.run)")
ProductionProbe.importMark("before-import:160:dev/presentationContracts")
import "dev/presentationContracts"
ProductionProbe.importMark("after-import:160:dev/presentationContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"world-presentation\", PresentationContracts.run)")
Contracts.register("world-presentation", PresentationContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"world-presentation\", PresentationContracts.run)")
ProductionProbe.importMark("before-import:161:dev/harness_build")
import "dev/harness_build"
ProductionProbe.importMark("after-import:161:dev/harness_build")
ProductionProbe.importMark("before-import:162:dev/harness_capture")
import "dev/harness_capture"
ProductionProbe.importMark("after-import:162:dev/harness_capture")
ProductionProbe.importMark("before-import:163:dev/diagnostics")
import "dev/diagnostics"
ProductionProbe.importMark("after-import:163:dev/diagnostics")
ProductionProbe.importMark("before-import:164:dev/fixtures")
import "dev/fixtures"
ProductionProbe.importMark("after-import:164:dev/fixtures")
ProductionProbe.inputBaseline()
ProductionProbe.importMark("before-import:165:dev/autopilot")
import "dev/autopilot"
ProductionProbe.importMark("after-import:165:dev/autopilot")
ProductionProbe.importMark("before-import:166:dev/harness")
import "dev/harness"
ProductionProbe.importMark("after-import:166:dev/harness")

playdate.display.setRefreshRate(30)
if not HarnessBuild.enabled then
    RulesRNG.seed(playdate.getSecondsSinceEpoch())
end

-- Shared context: root machine, camera, npc manager, player, player pokemon.
-- Global so dev tooling (autopilot, debug) can reach it.
ProductionProbe.importMark("before-import:167:game/fieldBattle")
import "game/fieldBattle"
ProductionProbe.importMark("after-import:167:game/fieldBattle")
ProductionProbe.importMark("before-import:168:game/homeRest")
import "game/homeRest"
ProductionProbe.importMark("after-import:168:game/homeRest")
ProductionProbe.importMark("before-import:169:dev/homeLeadContracts")
import "dev/homeLeadContracts"
ProductionProbe.importMark("after-import:169:dev/homeLeadContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"home-lead\",HomeLeadContracts.run)")
Contracts.register("home-lead",HomeLeadContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"home-lead\",HomeLeadContracts.run)")

ProductionProbe.importMark("before-import:170:game/itemPCState")
import "game/itemPCState"
ProductionProbe.importMark("after-import:170:game/itemPCState")
ProductionProbe.importMark("before-import:171:dev/itemPCContracts")
import "dev/itemPCContracts"
ProductionProbe.importMark("after-import:171:dev/itemPCContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"red-pc-items\",ItemPCContracts.run)")
Contracts.register("red-pc-items",ItemPCContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"red-pc-items\",ItemPCContracts.run)")

ProductionProbe.importMark("before-import:172:domain/fieldEncounters")
import "domain/fieldEncounters"
ProductionProbe.importMark("after-import:172:domain/fieldEncounters")
ProductionProbe.importMark("before-import:173:dev/fieldEncounterContracts")
import "dev/fieldEncounterContracts"
ProductionProbe.importMark("after-import:173:dev/fieldEncounterContracts")
ProductionProbe.importMark("before-call:Contracts.register(\"field-encounters\",FieldEncounterContracts.run)")
Contracts.register("field-encounters",FieldEncounterContracts.run)
ProductionProbe.importMark("after-call:Contracts.register(\"field-encounters\",FieldEncounterContracts.run)")

ProductionProbe.mark("before:game = GameContext({sessionLocationPolicy=PewterWorld.locationPolicy()})")
game = GameContext({sessionLocationPolicy=PewterWorld.locationPolicy()})
ProductionProbe.mark("after:game = GameContext({sessionLocationPolicy=PewterWorld.locationPolicy()})")

local machine <const> = game.machine
machine:register("overworld", OverworldState(game))
machine:register("dialog", DialogState(game))
machine:register("battle", BattleState(game))
machine:register("debug", DebugState(game))
machine:register("learning", LearningState(game))
machine:register("evolution", EvolutionState(game))
machine:register("title", TitleState(game))
machine:register("pause", PauseState(game))
machine:register("party", PartyState(game))
machine:register("bag", BagState(game))
machine:register("shop", ShopState(game))
machine:register("event", EventState(game))
machine:register("pokedex", PokedexState(game))
machine:register("pc", PCState(game))
machine:register("itemPC",ItemPCState(game))
machine:register("townMap",TownMapState(game))
machine:register("homeRest",HomeRestState(game))
ProductionProbe.mark("before:KantoWorld.install(game)")
KantoWorld.install(game)
ProductionProbe.mark("after:KantoWorld.install(game)")
ProductionProbe.mark("before:PewterWorld.install(game)")
PewterWorld.install(game)
ProductionProbe.mark("after:PewterWorld.install(game)")
ProductionProbe.mark("before:game.saves = GameSaves(game)")
game.saves = GameSaves(game)
ProductionProbe.mark("after:game.saves = GameSaves(game)")

-- Debug menu rides on top of the overworld via the system menu
local sysMenu = playdate.getSystemMenu()
sysMenu:addMenuItem("Debug", function()
    if machine:is("overworld") then
        machine:push("debug")
    end
end)

-- ============================================================
-- GAME LOOP
-- ============================================================
-- New game: the intro questline starts in Red's bedroom with Oak's
-- monologue (debug menu "Skip Intro" jumps straight to free play)
game.saves:start()
ProductionProbe.mark("after-initial-game-state")

---@diagnostic disable-next-line: duplicate-set-field
local function updateGame()
    Harness.beforeFrame(game)

    machine:update()
    machine:handleInput()
    machine:get("overworld"):flushPendingPresentation()
    machine:draw()

    playdate.timer.updateTimers()
    collectgarbage("step", 1)

    local top = machine:getCurrent()
    if top ~= "battle" then
        if DEBUG_FLAGS.showGrid then DebugMenu.drawOverlays() end
        if DEBUG_FLAGS.showFPS then
            game.camera:reset()
            playdate.drawFPS(4, 4)
            game.camera:apply()
        end
    end
end

-- Harness failures are evidence rather than an unacknowledged mailbox hang.
function playdate.update()
    if ProductionProbe.done then return end
    if Harness.isQuiescent then return end
    ProductionProbe.beginFrame(game)
    if HarnessBuild.enabled and playdate.isSimulator then
        local ok, message = pcall(updateGame)
        Harness.afterFrame(game, not ok and tostring(message) or nil)
    else
        updateGame()
    end
    ProductionProbe.afterFrame(game)
end
ProductionProbe.ready(game)

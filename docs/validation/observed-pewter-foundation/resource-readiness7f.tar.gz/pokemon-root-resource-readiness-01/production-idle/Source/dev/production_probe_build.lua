ProductionProbeBuild = {
    enabled = true,
    mode = "production",
    observer = "milestones",
    frames = 600,
    workload = "idle",
    run_id = "dd17af804f9b43259031d426265f01df",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:production-probe:3989198a8834ae73b08351961abb57f65e8ca2d265acbee1525bf123c1f9ff0d",
    bundle_id = "com.poc.pokemon.productionprobe.dd17af804f9b43259031d426265f01df",
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.productionprobe.dd17af804f9b43259031d426265f01df",
    sdk_version = "3.1.2",
}

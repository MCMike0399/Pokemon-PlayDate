ProductionProbeBuild = {
    enabled = true,
    mode = "production",
    observer = "imports",
    frames = 1800,
    workload = "controlled",
    run_id = "c043eb56bcc542a9bff9e418ee44c17a",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:production-probe:3989198a8834ae73b08351961abb57f65e8ca2d265acbee1525bf123c1f9ff0d",
    bundle_id = "com.poc.pokemon.productionprobe.c043eb56bcc542a9bff9e418ee44c17a",
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.productionprobe.c043eb56bcc542a9bff9e418ee44c17a",
    sdk_version = "3.1.2",
}

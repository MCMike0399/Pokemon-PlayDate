HarnessBuild = {
    protocol = 1,
    session_id = "c2092da1474f4d969ba187ac9307950e",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:56013355c8930253369d0e4d9213ab496e411f6e25356c2aa530d9266889cee2",
    output_dir = "/private/tmp/pokemon-root-individuals-a-native-01/03-brock--individuals-intro-charmander/frames/",
    bundle_id = "com.poc.pokemon.harness.c2092da1474f4d969ba187ac9307950e",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.c2092da1474f4d969ba187ac9307950e",
}

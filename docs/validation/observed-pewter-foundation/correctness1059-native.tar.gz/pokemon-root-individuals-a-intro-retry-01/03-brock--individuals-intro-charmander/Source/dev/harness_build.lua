HarnessBuild = {
    protocol = 1,
    session_id = "89a524de37314bac8274694a48e70cd2",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:56013355c8930253369d0e4d9213ab496e411f6e25356c2aa530d9266889cee2",
    output_dir = "/private/tmp/pokemon-root-individuals-a-intro-retry-01/03-brock--individuals-intro-charmander/frames/",
    bundle_id = "com.poc.pokemon.harness.89a524de37314bac8274694a48e70cd2",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.89a524de37314bac8274694a48e70cd2",
}

HarnessBuild = {
    protocol = 1,
    session_id = "0a2e8378d7d14636a550971078ccdc6e",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:0d88392102725cd82a58ff82d71216b2e5dc6f3462be64c074a3f1066707e90b",
    output_dir = "/private/tmp/pokemon-root-poison-native-02/poison-fang-fail31/frames/",
    bundle_id = "com.poc.pokemon.harness.0a2e8378d7d14636a550971078ccdc6e",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.0a2e8378d7d14636a550971078ccdc6e",
}

HarnessBuild = {
    protocol = 1,
    session_id = "16079efe970244af83ffa73d17d660d0",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:aa6fec9af2f66f6cf5779dd97b7bc76fd92491139a8076a5910b971a898ff5f8",
    output_dir = "/private/tmp/pokemon-root-rewards-hud-native-01/frames/",
    bundle_id = "com.poc.pokemon.harness.16079efe970244af83ffa73d17d660d0",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.16079efe970244af83ffa73d17d660d0",
}

HarnessBuild = {
    protocol = 1,
    session_id = "f0c7352474c94f7c98fe7425d57086e9",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:7f2f4eda2d8e3d1fd0c0d2b63eb7ad4a824a290d7bf1e42ae421a9f16e8e2979",
    output_dir = "/private/tmp/pokemon-root-rewards-hud-native-02/frames/",
    bundle_id = "com.poc.pokemon.harness.f0c7352474c94f7c98fe7425d57086e9",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.f0c7352474c94f7c98fe7425d57086e9",
}

HarnessBuild = {
    protocol = 1,
    session_id = "baad281f7f1c465fa3fcab6162a2fbd7",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:a2db85c48668993e27036c46f714e931d52506641359e84ad812c4291245b714",
    output_dir = "/private/tmp/pokemon-root-roost-native-01/02-brock--brock-roost-full/frames/",
    bundle_id = "com.poc.pokemon.harness.baad281f7f1c465fa3fcab6162a2fbd7",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.baad281f7f1c465fa3fcab6162a2fbd7",
}

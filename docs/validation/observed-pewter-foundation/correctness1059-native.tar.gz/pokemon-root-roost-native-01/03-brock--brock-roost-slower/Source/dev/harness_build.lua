HarnessBuild = {
    protocol = 1,
    session_id = "14b4c5bfc351484794a732ebedaa1b86",
    build_id = "d9f57eaba6b24d6eb42c9a8e57ac220f68a486d7:a2db85c48668993e27036c46f714e931d52506641359e84ad812c4291245b714",
    output_dir = "/private/tmp/pokemon-root-roost-native-01/03-brock--brock-roost-slower/frames/",
    bundle_id = "com.poc.pokemon.harness.14b4c5bfc351484794a732ebedaa1b86",
    sdk_version = "3.1.2",
    enabled = true,
    data_dir = "/Users/burbujamc/Developer/PlaydateSDK/Disk/Data/com.poc.pokemon.harness.14b4c5bfc351484794a732ebedaa1b86",
}
